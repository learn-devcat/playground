CREATE PROCEDURE [dbo].[CCS_AddModifiersToNotes_v4]
@PatientVisitID	varchar(50),
@Modifiers	varchar(1000),
@TransactionIdentifier varchar(50),
@OrderType	varchar(50),
@NoteType	varchar(50),
@Source		varchar(100),
@ActiveDate	varchar(50)=null,
@ExpirationDate varchar(50)=null


AS
	SET NOCOUNT ON
	
	DECLARE @NoteTypeID	varchar(50)

	-- Default NoteTypeID to Diet Note if NoteType does not exist in XLAT Table or is blank
	IF (@NoteType = '') OR (NOT EXISTS (SELECT 1 FROM dbo.tblXLAT WHERE xlatID = 'NoteType' AND KeyIn = @NoteType))
		SET @NoteTypeID = '100'
	ELSE
		SELECT @NoteTypeID = KeyOut
		FROM dbo.tblXLAT
		WHERE xlatID = 'NoteType' AND KeyIn = @NoteType

	EXEC dbo.CCS_PatientNotesUpdate_v4 @PatientVisitID, @NoteTypeID, @Source, @Modifiers, @TransactionIdentifier, @OrderType, @ActiveDate, 1, @ExpirationDate

	RETURN


go

