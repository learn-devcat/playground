

CREATE FUNCTION dbo.GetRandomIDString(@Today AS datetime)
RETURNS varchar(12)
AS
BEGIN
	DECLARE @Return	varchar(15)

	SELECT @Return = CAST(YEAR(@Today) AS varchar(4)) + CAST(MONTH(@Today) AS varchar(2)) + 
		CAST(DAY(@Today) AS varchar(2)) + CAST(DATEPART(mi,@Today) AS varchar(2)) + 
		CAST(DATEPART(ss,@Today) AS varchar(2)) + CAST(DATEPART(ms,@Today) AS varchar(3))

	RETURN @Return
END
go

