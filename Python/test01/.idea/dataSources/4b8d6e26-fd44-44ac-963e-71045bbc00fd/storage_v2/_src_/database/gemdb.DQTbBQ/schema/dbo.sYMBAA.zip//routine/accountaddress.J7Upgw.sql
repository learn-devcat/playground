

CREATE FUNCTION dbo.AccountAddress (@AccountNo char(19),@AddressString char(10), @AddressPart int) 
RETURNS varchar(32)
AS 
BEGIN 
	DECLARE	@Return	varchar(32)
	IF (@AddressPart = 1)
	BEGIN
		SELECT	@Return = A.Address1
		FROM		dbo.tblAccountAddress AS A LEFT JOIN
				dbo.tblAddressClass AS C
		ON		A.AddressID = C.AddressID
		WHERE	A.AccountNo = @AccountNo AND
				C.Description = @AddressString
		IF (@Return IS NULL) 
			SELECT	@Return = A.Address1
			FROM		dbo.tblAccountAddress AS A LEFT JOIN
					dbo.tblAddressClass AS C
			ON		A.AddressID = C.AddressID
			WHERE	A.AccountNo = @AccountNo AND
					UPPER(C.Description) = 'PRIMARY'
		GOTO EndFunc
	END
	ELSE
		
		IF (@AddressPart = 2)
		BEGIN
			SELECT	@Return = A.Address2
			FROM		dbo.tblAccountAddress AS A LEFT JOIN
					dbo.tblAddressClass AS C
			ON		A.AddressID = C.AddressID
			WHERE	A.AccountNo = @AccountNo AND
					C.Description = @AddressString
			IF (@Return IS NULL) 
				SELECT	@Return = A.Address2
				FROM		dbo.tblAccountAddress AS A LEFT JOIN
						dbo.tblAddressClass AS C
				ON		A.AddressID = C.AddressID
				WHERE	A.AccountNo = @AccountNo AND
						UPPER(C.Description) = 'PRIMARY'
		GOTO EndFunc
		END
		ELSE
	
			IF (@AddressPart = 3)
			BEGIN
				SELECT	@Return = A.Address3
				FROM		dbo.tblAccountAddress AS A LEFT JOIN
						dbo.tblAddressClass AS C
				ON		A.AddressID = C.AddressID
				WHERE	A.AccountNo = @AccountNo AND
						C.Description = @AddressString
				IF (@Return IS NULL) 
					SELECT	@Return = A.Address3
					FROM		dbo.tblAccountAddress AS A LEFT JOIN
							dbo.tblAddressClass AS C
					ON		A.AddressID = C.AddressID
					WHERE	A.AccountNo = @AccountNo AND
							UPPER(C.Description) = 'PRIMARY'
			GOTO EndFunc
			END
			ELSE
				IF (@AddressPart = 4)
				BEGIN
					SELECT	@Return = A.Address4
					FROM		dbo.tblAccountAddress AS A LEFT JOIN
							dbo.tblAddressClass AS C
					ON		A.AddressID = C.AddressID
					WHERE	A.AccountNo = @AccountNo AND
							C.Description = @AddressString
			
					IF (@Return IS NULL) 
						SELECT	@Return = A.Address4
						FROM		dbo.tblAccountAddress AS A LEFT JOIN
								dbo.tblAddressClass AS C
						ON		A.AddressID = C.AddressID
						WHERE	A.AccountNo = @AccountNo AND
								UPPER(C.Description) = 'PRIMARY'
				GOTO EndFunc	
		
				END
				ELSE
				BEGIN
					IF (@AddressPart = 5)
					SELECT	@Return = A.Address5
					FROM		dbo.tblAccountAddress AS A LEFT JOIN
							dbo.tblAddressClass AS C
					ON		A.AddressID = C.AddressID
					WHERE	A.AccountNo = @AccountNo AND
							C.Description = @AddressString
							--UPPER(C.Description) = 'PRIMARY')
					IF (@Return IS NULL) 
						SELECT	@Return = A.Address5
						FROM		dbo.tblAccountAddress AS A LEFT JOIN
								dbo.tblAddressClass AS C
						ON		A.AddressID = C.AddressID
						WHERE	A.AccountNo = @AccountNo AND
								UPPER(C.Description) = 'PRIMARY'
				GOTO EndFunc
				END
EndFunc:
	RETURN @Return
END
go

