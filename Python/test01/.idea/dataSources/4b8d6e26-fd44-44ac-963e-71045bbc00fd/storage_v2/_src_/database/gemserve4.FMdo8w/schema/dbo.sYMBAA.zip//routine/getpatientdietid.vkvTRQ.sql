CREATE FUNCTION [dbo].[GetPatientDietID](@PatientVisitID varchar(50), @FutureDate datetime, @EndTime as char(5))

RETURNS int

AS
	BEGIN
		DECLARE @Return	int

		SET @FutureDate = dbo.dDatePlusNewTime(@FutureDate,@EndTime)

		SELECT TOP 1 @Return = [ID]
		FROM tblPatientDiet
		WHERE PatientVisitID = @PatientVisitID
			AND ActiveDate <= @FutureDate
			AND COALESCE(Cancelled,0) = 0
		ORDER BY ActiveDate DESC, PostDate DESC

		RETURN ISNULL( @Return, -1 )
	END
go

