CREATE PROCEDURE dbo.DietDelete
(
       @LoginUserID		varchar(250),
        @DietID 	int	
     )

AS

    SET NOCOUNT ON
	
   	DECLARE @POSMenuEditing	int,
			@POSDietPrefix	varchar(10),
			@iPOSDietID		int
			
	-- Check to see if the MICROS editing is allowed - default is not allowed (0)
	SET @POSMenuEditing = COALESCE(dbo.GetOverheadValueNull('POSMenuEditing'),'0')	
	
	--Remove Diet from GEMserve
    DELETE dbo.tblDietOHD WHERE DietID = @DietID
	
	-- Check to see if editing is allowed on the MICROS to delete the diet
	IF(@POSMenuEditing = '1') AND (@DietID > 0)
	BEGIN
		-- Get the number to be added to the DietId to create the POS Diet ID on the MICROS
		SET @POSDietPrefix = COALESCE(dbo.GetOverheadValueNull('POSDietPrefix'),'9000000')
		
		-- Set the POS Diet ID that will be used on the MICROS
		SET @iPOSDietID = @POSDietPrefix + @DietID
		
		-- Delete the Diet from Micros
		EXEC dbo.Micros_DietDelete @LoginUserID, @iPOSDietID
		
	END

   RETURN
go

