

CREATE PROCEDURE dbo.ad_MealPlanDTL_Delete
@DtlID		int
AS
	DELETE 	tblPlanDtl
	WHERE	DtlID = @DtlID
go

