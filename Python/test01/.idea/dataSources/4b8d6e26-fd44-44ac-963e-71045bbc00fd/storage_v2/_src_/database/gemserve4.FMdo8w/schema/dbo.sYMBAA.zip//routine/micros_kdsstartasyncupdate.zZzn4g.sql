CREATE PROCEDURE [dbo].[Micros_KDSStartAsyncUpdate]
AS
	SET NOCOUNT ON

	DECLARE @RC 		int,
		@Object 	int,
		@MyDatabase	varchar(50),
		@SQL		nvarchar(2000),
		@LastIdleEvent	datetime,
		@Now		datetime,
		@Interval	int

	SET @Now = getdate()	

	SET @Interval = ISNULL(dbo.GetOverheadValueNIULL('KDSSyncInterval'),60)

	-- See if we have recently run this process
	IF EXISTS (SELECT 1 FROM dbo.tblWorkstation WHERE WorkstationID = 'kds1001')
	BEGIN
		SELECT TOP 1 @LastIdleEvent = LastIdleEvent
		FROM dbo.tblWorkstation
		WHERE WorkStationID = 'kds1001'
		ORDER BY LastIdleEvent DESC 

		-- If we have recently run and not waited for @Interval amount of time, then skip and exit
		IF (DATEADD(ss,@Interval,@LastIdleEvent) > @Now)
			GOTO Finish
	END

	SELECT @MyDatabase = dbo.GetOverheadValue('MyDatabase')
	SET @SQL = 'osql -S(local) -Ugemuser -Pdiamonds2 -d' + @MyDatabase + ' -Q"dbo.Micros_KDSUpdateOrderStatus"'

	-- Create OLE object
	EXEC @RC = sp_oacreate 'wscript.shell', @Object out

	IF (@RC = 0)
	BEGIN
		EXEC @RC = sp_oamethod @Object, 'run', null, @SQL
		EXEC @RC = sp_oadestroy @Object
	END

Finish:

	RETURN
go

