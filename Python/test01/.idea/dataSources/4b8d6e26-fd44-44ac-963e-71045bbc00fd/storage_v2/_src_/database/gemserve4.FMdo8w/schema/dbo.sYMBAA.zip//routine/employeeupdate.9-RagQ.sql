

CREATE PROCEDURE dbo.EmployeeUpdate
@LoggedOnUser varchar(250),
@LoginUserID     varchar(250),
@FirstName  varchar(30),
@LastName   varchar(30),
@Department varchar(30),
@IsAdmin    bit,
@BadgeNo varchar(50)

AS
	SET NOCOUNT ON 
	
	UPDATE  dbo.tblEmployees
	    SET FirstName = @FirstName,
	        LastName = @LastName,
	        Department = @Department,
	        IsAdmin = @IsAdmin,
		BadgeNo = @BadgeNo
	WHERE   LoginUserID = @LoginUserID

	IF (@@ROWCOUNT = 0)
		INSERT INTO dbo.tblEmployees(LoginUserID, FirstName, LastName, Department, IsAdmin, BadgeNo)
			VALUES(@LoginUserID, @FirstName, @LastName, @Department, @IsAdmin, @BadgeNo)

	
	RETURN
go

