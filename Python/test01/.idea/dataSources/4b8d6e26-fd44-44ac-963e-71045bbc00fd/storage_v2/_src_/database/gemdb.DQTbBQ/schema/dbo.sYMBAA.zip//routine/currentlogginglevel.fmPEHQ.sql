

CREATE FUNCTION dbo.CurrentLoggingLevel ()
RETURNS smallint
AS 
BEGIN 
	DECLARE @LoggingLevel smallint
	-- Check the Overhead file for an entry --
	SELECT @LoggingLevel = CAST(sValue as smallint) FROM cfgOverhead WHERE oKey='LoggingLevel'
	-- Default to 1 (Write/Updates) IF we didn't get one.
	RETURN ISNULL( @LoggingLevel , 1 )
END
go

