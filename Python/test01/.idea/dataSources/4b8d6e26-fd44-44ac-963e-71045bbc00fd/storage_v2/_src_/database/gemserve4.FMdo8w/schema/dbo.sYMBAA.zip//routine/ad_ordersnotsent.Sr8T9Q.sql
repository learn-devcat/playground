

CREATE PROCEDURE dbo.ad_OrdersNotSent
AS

	SELECT 	P.FullName,
		P.MedicalRecordID,
		O.OrderID, 
		O.WaveID, 
		O.OrderDate, 
		O.PostDate, 
		O.PatientID, 
		O.NonSelectOrder,
		W.[Description] AS WaveName,
		R.RoomNumber,
		COALESCE(PV.Bed,'') AS Bed,
		COALESCE(L.Description,'N/A') AS Location
	FROM tblOrderOHD AS O (NOLOCK)
		JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON O.PatientVisitID = PV.PatientVisitID AND PV.DischargeDate IS NULL
		JOIN dbo.tblPatientOHD AS P (NOLOCK) ON PV.PatientID = P.PatientID
		JOIN dbo.tblWave AS W (NOLOCK)ON O.WaveID = W.WaveID
		LEFT JOIN dbo.tblRoomOHD AS R (NOLOCK) ON PV.RoomID = R.RoomID
		LEFT JOIN dbo.tblLocationClass  AS L (NOLOCK) ON R.LocationClassID = L.LocationClassID
	WHERE O.SentDate IS NULL
		AND ISNULL(O.Cancelled,0) = 0
		AND O.OrderDate >= DATEDIFF(d,1, getdate())
	ORDER BY O.OrderDate, R.RoomNumber
go

