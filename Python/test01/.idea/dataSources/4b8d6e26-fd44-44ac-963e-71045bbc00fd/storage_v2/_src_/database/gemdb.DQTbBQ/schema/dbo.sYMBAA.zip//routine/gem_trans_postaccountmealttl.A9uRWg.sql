

CREATE procedure dbo.gem_trans_postaccountmealttl
@user		varchar(20),
@coreid		int,
@accountno	char(19),
@slotno		smallint,
@transdate	datetime,
@qty		int,
@transtotal	money,
@correction	bit,
@mealplanid	int
as
	
	DECLARE @mealplandtlid  int
	IF (@correction = 1)
	BEGIN
		SET @qty = -@qty
		SET @transtotal = -@transtotal
	END
	-- get the meal plan id of the current ttl because the mealohd doesn't have the plan id, it only had
	-- slot numbers.  this is because we resolve the actual meal plan at run time based on the active
	-- time periods.
--	SELECT 		@mealplanid = m.mealplanid
--	FROM 		tblaccountmealttl as t
--			inner JOIN
--			tblaccountmeal as m 
--	on		m.accountno = t.accountno 
--			AND t.mealplanid = m.mealplanid
--			AND m.slot = @slotno
--			inner JOIN	
--			tblplandtl as d
--	on		m.mealplanid = d.mealplanid
--	WHERE		t.accountno = @accountno 
--			AND dbo.ddateonly(@transdate) between dbo.ddateonly(activedate) AND dbo.ddateonly(expiredate)
--			AND dbo.timeonly(@transdate) between d.begtime AND d.endtime
	-- UPDATE the ttl 
	UPDATE	tblaccountmealttl
	SET		currentcount = currentcount - @qty,
			currentbalance = currentbalance - @transtotal,
			usedcount = usedcount + @qty,
			usedbalance = usedbalance + @transtotal
	FROM		tblaccountmealttl as t
	inner JOIN 	tblaccountmeal m
	on		t.accountno = m.accountno
			AND t.mealplanid = m.mealplanid
	inner JOIN	tblplandtl as d
	on		m.mealplanid = d.mealplanid
	WHERE	t.accountno = @accountno
			AND m.mealplanid = @mealplanid
--			AND m.slot = @slotno
			AND dbo.ddateonly(@transdate) between dbo.ddateonly(activedate) AND dbo.ddateonly(expiredate)
			AND dbo.timeonly(@transdate) between d.begtime AND d.endtime
	IF (@@rowcount = 0)
	BEGIN
		EXEC dbo.sp_logit 0, @coreid, @user, 'unable to post to tblaccountmealttl. no active ttl.'
		RETURN 1
	END
	-- get the current detail id FROM the plan detail file so that we can look at the tblaccountmeal table
	-- AND see what the last one we used was.  IF these don't match, we have no current counts used.
	SELECT 	@mealplandtlid =  p.dtlid 
	FROM	tblplandtl as p
	WHERE    p.mealplanid = @mealplanid
		AND p.begtime <=  dbo.timeonly( getdate())
		AND p.endtime >= dbo.timeonly( getdate()) 
	UPDATE 	tblaccountmeal 
	SET		lastused = getdate(),
			currentpasscount =  ISNULL( dbo.isdailyqtyex( currentpasscount , lastused , getdate() , lastmealdtl , @mealplandtlid ) , 0 ) + 1, 
			lastmealdtl = ISNULL( @mealplandtlid , -1 )
	FROM		tblaccountmeal m
	WHERE		m.accountno = @accountno 
			AND m.slot = @slotno
			AND m.mealplanid = @mealplanid
	-- no rows updated, so RETURN fail code
	IF (@@rowcount = 0)
	BEGIN
		EXEC dbo.sp_logit 0, @coreid, @user, 'unable to post to tblaccountmeal. no active ttl or matching slotno.'
		RETURN 1
	END
go

