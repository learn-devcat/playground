

CREATE PROCEDURE dbo.sp_GiftCard_Setup
AS 
	INSERT INTO tblAccountClass (AccountClassID, Name, Status, Category)
			VALUES (3000, 'GiftCard', 1, 1)
	
    INSERT INTO tblBadgeClass (BadgeClassID, Description)
    		VALUES (3000, 'GiftCard')
			
	INSERT INTO tblTransClass (TransClassID, Description, Status)
			VALUES (3000, 'GiftCard', 0)
			
	INSERT INTO tblOutletClass (OutletClassID, Type, Status, Description)
			VALUES (3000, 0, 0, 'GiftCard')			
			
	INSERT INTO tblOutletOHD (OutletNo, OutletName, OutletClassID, TransClassID, SubType)
			VALUES (3000, 'GiftCard', 3000, 3000, -1)
			
	INSERT INTO tblTransDef (TransID, TransClassID, Description, Payment)
			VALUES (3000, 3000, 'GiftCard', 1)
go

