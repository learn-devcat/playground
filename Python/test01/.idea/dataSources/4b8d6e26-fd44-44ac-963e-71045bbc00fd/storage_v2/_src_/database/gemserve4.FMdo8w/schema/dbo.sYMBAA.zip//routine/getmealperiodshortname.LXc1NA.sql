
CREATE FUNCTION dbo.GetMealPeriodShortName(@MealPeriodID int)
RETURNS varchar(10)
BEGIN
	DECLARE @Return	varchar(10)

	SELECT @Return = ShortName
	FROM dbo.tblMealPeriods
	WHERE MealPeriodID = @MealPeriodID

	RETURN ISNULL(@Return, 'N/A')
END
go

