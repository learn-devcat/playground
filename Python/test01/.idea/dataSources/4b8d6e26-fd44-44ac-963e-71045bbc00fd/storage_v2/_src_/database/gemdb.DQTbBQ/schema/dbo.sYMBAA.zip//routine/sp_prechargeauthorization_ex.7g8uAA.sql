CREATE PROCEDURE [dbo].[sp_PreChargeAuthorization_EX]
@AccountNo	char(19),
@BadgeNo	char(19),
@TransTotal	money,
@TransID	int,
@OutletNo	int,
@ReturnMsg	varchar(255) OUTPUT,
@OverBy		money OUTPUT,
@LimitsBitMask int = -1
AS
	DECLARE	@Balance			money,
			@Limit				money,
			@Qty				int,
			@QtyLimit			int,
			@ActiveAccount		char(19),
			@Active				int,
			@ActiveBadge		char(19),
			@Today				datetime,
			@AccountSubType 	int,
			@OutletSubType		int,
			@AccountClassID		int,
			@MessageIdIsInt		bit,
			@TransClassID		int,
			@BadgeClassID		int,
			@XlatID				varchar(10),
			@CurrentCycle		int
	/*
		Procedure:		sp_PreChargeAuthorization_EX
		Author:			Richard Beverly
		Create Date:	6-17-2008

		Checks all current limits as well as several config AND permission based conditions 
		that must be met for proper posting. The @LimitsBitMask param tells the procedure 
		which limits to check by determining the "on" bits represented by the integer 
		parameter value. Optimally, the calling procedure will pull this value FROM
		overhead. The @LimitsBitMask param defaults to -1 (all bits on) AND accepts
		an integer up to 31 bits wide. Meaning 31 statuses are available.

		A varchar(50) describing the condition that failed is returned as an output parameter called 
		"@ReturnMsg". The calling procedure must assign this to a variable included in the call
		AND must also use the OUTPUT keyword to specify it is to recieve the RETURN data.

		The procedure will search the tblMessages table to find the condition description text. 
		IF not found a default will be used. The PageID for the mesage will be "PreChargeAuth". 
		The ID passed in this proc is an integer, but the function actually specifies a varchar(50). 
		This way, it is compatible with the old AND new message table schema.

		IF a limit is breached the @OverBy output parameter will contain the amount of the
		balance + trans that is over the limit 

		IF the transaction is authorized, it will RETURN an empty string..


		Limits to be checked:
		
		LIMIT								BIT Position
		
		AccountClass Limit					1
		AccountClass Daily Limit			2
		AccountClass Daily Qty Limit		3
		Account TTL Limit					4
		Account TTL Qty Limit				5
		Account	TTL Daily Limit				6
		Account	TTL Daily Qty Limit			7
		Badge Class Limit					8
		Badge Class Daily Limit				9
		Badge Class Daily Qty Limit			10
		Badge OHD Limit						11
		Badge OHD Daily Limit				12
		Badge OHD Daily Qty Limit			13
		Badge OHD Trans Limit				14
		TransDEF Limit						15
		Account Global Limit				16

		Other conditions checked:
		
		* Outlet number exists
		* Badge class cycle exists
		* Outlet blocked for Account Class
		* IF Account Number is an empty string, it must be resolvable FROM the badge number
		* Badge inactive or expired
		* Account inactive or expired
	*/

	SET NOCOUNT ON

/*#####################################################################################
					SET initial VALUES AND resolve identifiers
#######################################################################################*/
	
	-- Removes badge swipe character if it exists in @BadgeNo
	SET @BadgeNo = dbo.RemoveBadgeSwipePrefix(@BadgeNo);

	SET @Today = getdate()

	SET @OverBy = 0

	-- resolve transclass
	SELECT	@TransClassID = TransClassID
	FROM	dbo.tblTransDEF
	WHERE	TransID = @TransID


/************************************************************
	Failure: Outlet undefined
************************************************************/
	IF NOT EXISTS  (SELECT 	*
					FROM	tblOutletOHD
					WHERE	OutletNo = @OutletNo)
	BEGIN
		SET @ReturnMsg = CAST(dbo.GetMessage_D(1,'PreChargeAuth','Outlet not found') AS varchar(40)) + ': ' + CAST(@OutletNo AS varchar(8))
		RETURN
	END


	--resolve acct# IF not passed
	IF (@AccountNo = '')
		SELECT 	TOP 1 @AccountNo = AccountNo
		FROM	tblBadgesOHD
		WHERE	BadgeNo = @BadgeNo
/************************************************************
	Failure: Badge not resolved to an account
************************************************************/
		IF (ISNULL(@AccountNo,'') = '')
		BEGIN
			SET @ReturnMsg = CAST(dbo.GetMessage_D(2,'PreChargeAuth','Badge# unresolved') AS varchar(40)) + ': ' + CAST(@OutletNo AS varchar(8))
			RETURN
		END


	--resolve badge class
	SELECT	@BadgeClassID = BadgeClassID
	FROM	tblBadgesOHD
	WHERE		BadgeNo = @BadgeNo
			AND AccountNo = @AccountNo


	-- SET Xlat ID FROM cycle xlat table
	SET @XlatID = 'BC' + CAST(@BadgeClassID AS varchar(8))

	IF NOT EXISTS (SELECT TOP 1 * FROM tblCycleXlat WHERE xlatid = @XlatID) 
	BEGIN
		IF NOT EXISTS (SELECT TOP 1 * FROM tblCycleXlat WHERE xlatid = 'BC')
		BEGIN
/************************************************************
	Failure: Badge class cycle doesn't exist
************************************************************/
			SET @ReturnMsg = dbo.GetMessage_D(21,'PreChargeAuth','Badge Class Cycle Undefined')
			RETURN
		END	
		ELSE
			SET @XlatID = 'BC'		
	END

	IF NOT EXISTS (SELECT TOP 1 * FROM tblCycleXlat WHERE xlatid = @XlatID) 
	BEGIN
		SET @XlatID = 'BC'		
	END


	--SET current badge cycle
	SET @CurrentCycle = dbo.GetCycleByXREF(0,@Today,@XlatID)


/*#####################################################################################
					Check inactive status AND basic permissions
#######################################################################################*/

/************************************************************
	Failure: Badge Inactive
************************************************************/
	IF NOT EXISTS  (SELECT 	BadgeNo
					FROM	tblBadgesOHD
					WHERE	BadgeNo = @BadgeNo
							AND AccountNo = @AccountNo
							AND Inactive = 0
							AND ActiveDate <= @Today
							AND ExpireDate >= @Today)
	BEGIN
		SET @ReturnMsg = CAST(dbo.GetMessage_D(3,'PreChargeAuth','Badge inactive') AS varchar(29)) + ': ' + CAST(@BadgeNo AS varchar(19))
		RETURN
	END


/************************************************************
	Failure: Account Inactive
************************************************************/
	IF NOT EXISTS  (SELECT 	AccountNo
					FROM	tblAccountOHD
					WHERE	AccountNo = @AccountNo
							AND Inactive = 0    
							AND ActiveDate <= @Today
							AND ExpireDate >= @Today)
	BEGIN
		SET @ReturnMsg = CAST(dbo.GetMessage_D(4,'PreChargeAuth','Account Inactive') AS varchar(29)) + ': ' + CAST(@AccountNo AS varchar(19))
		RETURN
	END


	--Check IF account class is blocked FROM outlet
	SELECT	@AccountClassID = AccountClassID
	FROM	tblAccountOHD
	WHERE	AccountNo = @AccountNo
/************************************************************
	Failure: Account Class Blocked FROM Outlet
************************************************************/
	IF dbo.IsAllowed(@OutletNo,@AccountClassID,-1 ) < 1
	BEGIN
		SET @ReturnMsg = CAST(dbo.GetMessage_D(5,'PreChargeAuth','Location Permission Denied') AS varchar(29)) + ': ' + CAST(@BadgeNo AS varchar(19))
		RETURN
	END


/*#####################################################################################
									TEST LIMITS
#######################################################################################*/

	-- check account class limit
	IF ((@LimitsBitMask & dbo.BinaryPosition(1)) > 0)
	BEGIN
		SELECT	@Limit = Limit
		FROM	tblAccountClass
		WHERE	AccountClassID = @AccountClassID

		SELECT	@Balance = Balance + @TransTotal
		FROM	tblAccountTTL
		WHERE		AccountNo = @AccountNo
				AND	TransClassID = @TransClassID
/************************************************************
	Failure:  Account Class Limit
************************************************************/	
		IF (@Balance > @Limit)
		BEGIN
			SET @ReturnMsg = dbo.GetMessage_D(6,'PreChargeAuth','Over Account Class Limit')
			SET @OverBy = @Balance - @Limit
			RETURN
		END
	END



	-- check account class Daily limit
	IF ((@LimitsBitMask & dbo.BinaryPosition(2)) > 0)
	BEGIN
		SELECT	@Limit = DailyLimit
		FROM	tblAccountClass
		WHERE	AccountClassID = @AccountClassID

		SELECT	@Balance = dbo.IsDailyMoney(DailyBalance,LastChgDate,@Today) + @TransTotal
		FROM	tblAccountTTL
		WHERE		AccountNo = @AccountNo
				AND	TransClassID = @TransClassID
/************************************************************
	Failure:  Account Class Daily Limit
************************************************************/	
		IF (@Balance > @Limit)
		BEGIN
			SET @ReturnMsg = dbo.GetMessage_D(7,'PreChargeAuth','Over Account Class Daily Limit')
			SET @OverBy = @Balance - @Limit
			RETURN
		END
	END



	-- check account class Daily Qty limit
	IF ((@LimitsBitMask & dbo.BinaryPosition(3)) > 0)
	BEGIN
		SELECT	@QtyLimit = DailyQtyLimit
		FROM	tblAccountClass
		WHERE	AccountClassID = @AccountClassID

		SELECT	@Qty = dbo.IsDailyQty(DailyQty,LastChgDate,@Today) + 1
		FROM	tblAccountTTL
		WHERE		AccountNo = @AccountNo
				AND	TransClassID = @TransClassID
/************************************************************
	Failure:  Account Class Daily Qty Limit
************************************************************/	
		IF (@Qty > @QtyLimit)
		BEGIN
			SET @ReturnMsg = dbo.GetMessage_D(8,'PreChargeAuth','Over Account Class Daily Qty Limit')
			RETURN 
		END
			
	END



	-- check account limit
	IF ((@LimitsBitMask & dbo.BinaryPosition(4)) > 0)
	BEGIN
		SELECT	@Limit = Limit,
				@Balance = Balance + @TransTotal
		FROM	tblAccountTTL
		WHERE		AccountNo = @AccountNo
				AND	TransClassID = @TransClassID
/************************************************************
	Failure:  Account Limit
************************************************************/	
		IF (@Balance > @Limit)
		BEGIN
			SET @ReturnMsg = dbo.GetMessage_D(9,'PreChargeAuth','Over Account Limit')
			SET @OverBy = @Balance - @Limit
			RETURN
		END
	END



	-- check account Qty limit
	IF ((@LimitsBitMask & dbo.BinaryPosition(5)) > 0)
	BEGIN
		SELECT	@QtyLimit = QtyLimit,
				@Qty = Qty + 1
		FROM	tblAccountTTL
		WHERE		AccountNo = @AccountNo
				AND	TransClassID = @TransClassID
/************************************************************
	Failure:  Account Qty Limit
************************************************************/	
		IF (@Qty > @QtyLimit)
		BEGIN
			SET @ReturnMsg = dbo.GetMessage_D(10,'PreChargeAuth','Over Account Qty Limit')
			RETURN
		END
	END



	-- check account Daily limit
	IF ((@LimitsBitMask & dbo.BinaryPosition(6)) > 0)
	BEGIN
		SELECT	@Limit = DailyLimit,
				@Balance = dbo.IsDailyMoney(DailyBalance,LastChgDate,@Today) + @TransTotal
		FROM	tblAccountTTL
		WHERE		AccountNo = @AccountNo
				AND	TransClassID = @TransClassID
/************************************************************
	Failure:  Account Daily Limit
************************************************************/	
		IF (@Balance > @Limit)
		BEGIN
			SET @ReturnMsg = dbo.GetMessage_D(11,'PreChargeAuth','Over Account Daily Limit')
			SET @OverBy = @Balance - @Limit
			RETURN
		END
	END



	-- check account Daily Qty limit
	IF ((@LimitsBitMask & dbo.BinaryPosition(7)) > 0)
	BEGIN
		SELECT	@QtyLimit = DailyQtyLimit,
				@Qty = dbo.IsDailyQty(DailyQty,LastChgDate,@Today) + 1
		FROM	tblAccountTTL
		WHERE		AccountNo = @AccountNo
				AND	TransClassID = @TransClassID
/************************************************************
	Failure:  Account Qty Limit
************************************************************/	
		IF (@Qty > @QtyLimit)
		BEGIN
			SET @ReturnMsg = dbo.GetMessage_D(12,'PreChargeAuth','Over Account Daily Qty Limit')			
			RETURN
		END
	END



	-- check badge class limit
	IF ((@LimitsBitMask & dbo.BinaryPosition(8)) > 0)
	BEGIN
		SELECT	@Limit = Limit
		FROM	tblBadgeClass
		WHERE	BadgeClassID = @BadgeClassID

		SELECT	@Balance = Total + @TransTotal
		FROM	tblBadgeTTL
		WHERE 		dbo.GetCycleByXREF(0,[Date],@XlatID)  = @CurrentCycle
				AND BadgeNo = @BadgeNo
				AND AccountNo = @AccountNo
/************************************************************
	Failure:  Badge Class Limit
************************************************************/	
		IF (@Balance > @Limit)
		BEGIN
			SET @ReturnMsg = dbo.GetMessage_D(13,'PreChargeAuth','Over Badge Class Limit')
			SET @OverBy = @Balance - @Limit		
			RETURN
		END
	END


	-- check badge class Daily limit
	IF ((@LimitsBitMask & dbo.BinaryPosition(9)) > 0)
	BEGIN
		SELECT	@Limit = DailyLimit
		FROM	tblBadgeClass
		WHERE	BadgeClassID = @BadgeClassID

		SELECT	@Balance = dbo.IsDailyMoney(DailyBalance,LastChgDate,@Today) + @TransTotal
		FROM	tblBadgesOHD
		WHERE		AccountNo = @AccountNo
				AND BadgeNo = @BadgeNo
/************************************************************
	Failure:  Badge Class Daily Limit
************************************************************/	
		IF (@Balance > @Limit)
		BEGIN
			SET @ReturnMsg = dbo.GetMessage_D(14,'PreChargeAuth','Over Badge Class Daily Limit')
			SET @OverBy = @Balance - @Limit		
			RETURN
		END
	END



	-- check Badge Class Daily Qty limit
	IF ((@LimitsBitMask & dbo.BinaryPosition(10)) > 0)
	BEGIN
		SELECT	@QtyLimit = DailyQtyLimit
		FROM	tblBadgeClass
		WHERE	BadgeClassID = @BadgeClassID

		SELECT	@Qty = dbo.IsDailyQty(DailyQty,LastChgDate,@Today) + 1
		FROM	tblBadgesOHD
		WHERE		AccountNo = @AccountNo
				AND BadgeNo = @BadgeNo
/************************************************************
	Failure:  Bagde Class Daily Qty Limit
************************************************************/	
		IF (@Qty > @QtyLimit)
		BEGIN
			SET @ReturnMsg = dbo.GetMessage_D(15,'PreChargeAuth','Over Badge Class Daily Qty Limit')			
			RETURN
		END
	END



	-- check Badge limit
	IF ((@LimitsBitMask & dbo.BinaryPosition(11)) > 0)
	BEGIN
		SELECT	@Limit = Limit
		FROM	tblBadgesOHD
		WHERE		AccountNo = @AccountNo
				AND BadgeNo = @BadgeNo

		SELECT	@Balance = Total + @TransTotal
		FROM	tblBadgeTTL
		WHERE 		dbo.GetCycleByXREF(0,[Date],@XlatID)  = @CurrentCycle
				AND BadgeNo = @BadgeNo
				AND AccountNo = @AccountNo
/************************************************************
	Failure:  Badge Limit
************************************************************/	
		IF (@Balance > @Limit)
		BEGIN
			SET @ReturnMsg = dbo.GetMessage_D(16,'PreChargeAuth','Over Badge Limit')
			SET @OverBy = @Balance - @Limit			
			RETURN
		END
	END



	-- check badge Daily limit
	IF ((@LimitsBitMask & dbo.BinaryPosition(12)) > 0)
	BEGIN
		SELECT	@Limit = DailyLimit,
				@Balance = dbo.IsDailyMoney(DailyBalance,LastChgDate,@Today) + @TransTotal
		FROM	tblBadgesOHD
		WHERE		AccountNo = @AccountNo
				AND BadgeNo = @BadgeNo
/************************************************************
	Failure:  Badge Daily Limit
************************************************************/	
		IF (@Balance > @Limit)
		BEGIN
			SET @ReturnMsg = dbo.GetMessage_D(17,'PreChargeAuth','Over Badge Daily Limit')
			SET @OverBy = @Balance - @Limit		
			RETURN
		END
	END



	-- check Badge Daily Qty limit
	IF ((@LimitsBitMask & dbo.BinaryPosition(13)) > 0)
	BEGIN
		SELECT	@QtyLimit = DailyQtyLimit,
				@Qty = dbo.IsDailyQty(DailyQty,LastChgDate,@Today) + 1
		FROM	tblBadgesOHD
		WHERE		AccountNo = @AccountNo
				AND BadgeNo = @BadgeNo
/************************************************************
	Failure:  Bagde Daily Qty Limit
************************************************************/	
		IF (@Qty > @QtyLimit)
		BEGIN
			SET @ReturnMsg = dbo.GetMessage_D(18,'PreChargeAuth','Over Badge Daily Qty Limit')			
			RETURN
		END
	END



	-- check Badge trans limit
	IF ((@LimitsBitMask & dbo.BinaryPosition(14)) > 0)
	BEGIN
		SELECT	@Limit = TransLimit
		FROM	tblBadgesOHD
		WHERE		AccountNo = @AccountNo
				AND BadgeNo = @BadgeNo
/************************************************************
	Failure:  Badge Trans Limit
************************************************************/	
		IF (@TransTotal > @Limit)
		BEGIN
			SET @ReturnMsg = dbo.GetMessage_D(19,'PreChargeAuth','Over Badge Trans Limit')
			SET @OverBy = @Balance - @Limit		
			RETURN
		END
	END



	-- check trans type limit
	IF ((@LimitsBitMask & dbo.BinaryPosition(15)) > 0)
	BEGIN
		SELECT	@Limit = TransLimit
		FROM	tblTransDef
		WHERE	TransID = @TransID
/************************************************************
	Failure:  Trans Type Limit
************************************************************/	
		IF (@TransTotal > @Limit)
		BEGIN
			SET @ReturnMsg = dbo.GetMessage_D(20,'PreChargeAuth','Over Trans Type Limit')
			SET @OverBy = @TransTotal - @Limit			
			RETURN
		END
	END


	-- check Account Global Limit
	IF ((@LimitsBitMask & dbo.BinaryPosition(16)) > 0)
	BEGIN
		SELECT	@Limit = GlobalLimit
		FROM	tblAccountClass
		WHERE	AccountClassID = @AccountClassID

		SET @Balance = dbo.GetGlobalBalance(@AccountNo) + @TransTotal
/************************************************************
	Failure:  Account Global Limit
************************************************************/	
		IF (@Balance > @Limit)
		BEGIN
			SET @ReturnMsg = dbo.GetMessage_D(22,'PreChargeAuth','Over Account Global Limit')
			SET @OverBy = @Balance - @Limit				
			RETURN
		END
	END


/************************************************************
	Transaction Authorized!
************************************************************/
-- keep the authorized RETURN message simple
SET @ReturnMsg = ''
RETURN
go

