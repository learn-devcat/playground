
CREATE PROCEDURE [dbo].[WaveListAvailableEX] 
@MaxWaves		int,
@PatientVisitID varchar(50),
@OrderType		int

AS

   	-- Passing in the PatientVisitID allows us to check to see if the patient has an outstanding order for this waave id/order date 
	SET NOCOUNT ON

	DECLARE	@WaveDays		int,
		@DayCount		int,
		@LocationClassID	int,
		@PatientID		int,
		@MultipleOrdersPerMealPeriod	bit,
		@NPOGuestOrdering bit,
		@Today			datetime,
		@TodayString	varchar(50),
		@OrderDate2		datetime

	SELECT @MultipleOrdersPerMealPeriod = COALESCE(dbo.GetOverheadValueNull('MultipleOrdersPerMealPeriod'),0)
	SELECT @NPOGuestOrdering = COALESCE(dbo.GetOverheadValueNull('NPOGuestOrdering'),1)

	SELECT @PatientVisitID = COALESCE(MergedTo, PatientVisitID)
		FROM dbo.tblPatientVisit
		WHERE PatientVisitID = @PatientVisitID

	SELECT @PatientID = PV.PatientID
	FROM	dbo.tblPatientVisit AS PV (NOLOCK) 
	WHERE	PV.PatientVisitID = @PatientVisitID
		AND PV.MergedTo IS NULL
		AND PV.DischargeDate IS NULL

	SET @DayCount = 0
	SET @Today = getdate()

	SELECT	@WaveDays = Value
	FROM	cfgOverhead
	WHERE	KeyID = 'WaveDays'
	
	SELECT	@LocationClassID = R.LocationClassID
	FROM	dbo.tblPatientVisit AS P (NOLOCK)
		JOIN dbo.tblRoomOHD AS R (NOLOCK) ON P.RoomID = R.RoomID
	WHERE 	P.PatientVisitID = @PatientVisitID
		AND P.DischargeDate IS NULL

	DECLARE @Count           	int,
            @ReturnMsg   	varchar(8000),
		    @WaveID		int,
		    @Description	varchar(50),
		    @OrderDate		varchar(32),
		    @AvailableOrders	int,
		    @DateOffset	  	int,
		    @OrderStatus	int,
	 	    @BeginTime		varchar(32),
		    @EndTime		varchar(32),
		    @MealPeriodID	int,
		    @Status		int

	DECLARE @MyWaves TABLE (
		MyID		int IDENTITY (1,1),
		WaveID	int,
		Description	varchar(50),
		OrderDate	varchar(32),
		AvailableOrders	int,
		DateOffset	int,
		OrderStatus	int,
		BeginTime	varchar(32),
		EndTime	varchar(32),
		MealPeriodID int,
		DietID	int)

	WHILE (@DayCount <= @WaveDays)
	BEGIN
		SET @Today = @Today + @DayCount
		SET @TodayString = dbo.DateString(@Today)
		SET @OrderDate2 = dbo.dDateOnly(@Today)

		INSERT INTO @MyWaves (WaveID, Description, OrderDate, AvailableOrders, DateOffset, OrderStatus,BeginTime,EndTime, MealPeriodID, DietID)
		SELECT DISTINCT W.WaveID, 
			CASE WHEN (O.Sent = 1 AND O.Received = 1) THEN 'ORDER: ' + COALESCE(O.CheckNo,'0000')
				ELSE W.Description
			END,
			@TodayString AS OrderDate, 
			AvailableOrders = 
			CASE
			WHEN (@DayCount = 0 AND EndTime <= dbo.TimeString(@Today)) THEN -1
			ELSE (W.MaxOrder - (SELECT COUNT(WaveID) FROM dbo.tblOrderOHD (NOLOCK)
				WHERE WaveID = W.WaveID 
				AND OrderDate BETWEEN @OrderDate2 AND (@OrderDate2 + 1)
				AND COALESCE(Cancelled,0) = 0))
			END,
			@DayCount AS DateOffset , 
			CASE
			WHEN (O.Sent = 1 AND O.Received = 0) THEN 18					-- Error..Order sent to POS but not received.		18 = Red
			WHEN (O.Sent = 1 AND O.Received = 1 AND @OrderType = 1) THEN 17 -- order sent to and received by POS (Patient ONLY) 17 = White
			WHEN (O.Sent = 0 AND O.Received = 0 ) THEN 20					-- Order allowed to be edited.						20 = Yellow
			ELSE 
				CASE
				WHEN @DayCount = 0 THEN 28						--28 = Green
				ELSE 28											--30 = Blue
				END
			END,
			W.BeginTime,
			W.EndTime,
			W.MealPeriodID,
			CASE WHEN @PatientVisitID = '1' THEN 500
				ELSE dbo.GetActiveDiet(@PatientVisitID,dbo.dDatePlusNewTime(@Today,W.EndTime))
			END
		FROM 	dbo.tblWave AS W (NOLOCK)
			LEFT JOIN dbo.tblPatientOHD AS P (NOLOCK) ON P.PatientID = @PatientID
			LEFT JOIN dbo.tblOrderOHD AS O (NOLOCK) ON W.WaveID = O.WaveID AND O.OrderType = @OrderType
				AND O.OrderDate BETWEEN @OrderDate2 AND (@OrderDate2 + 1)
				AND O.PatientVisitID = @PatientVisitID
				AND COALESCE(O.Cancelled,0) = 0
	
		SET @DayCount = @DayCount + 1
	END
	
	IF (@LocationClassID IS NOT NULL)
	BEGIN
		-- Modified 7/13/2010 - rab -- REMOVE all waves not valid for this location
		DELETE @MyWaves
		FROM @MyWaves AS W
			LEFT JOIN dbo.tblLocationWave as LW ON W.WaveID = LW.WaveID AND LW.LocationClassID = @LocationClassID
		WHERE (LW.WaveID IS NULL
			OR LW.Active = 0)
			AND W.Description NOT LIKE 'ORDER%'
			AND W.OrderStatus <> 20
	END	

	-- Diet: Make sure waves that are not allowed for this diet are disabled for ordering -- only for PATIENTS (OrderType 1)
	IF (@OrderType = 1)
		UPDATE @MyWaves 
		SET AvailableOrders = 
			CASE WHEN DW.WaveID IS NULL THEN -1
			WHEN DW.Active = 0 THEN -1
			WHEN W.AvailableOrders = 0 THEN -1 -- Added to prevent allowing of an order being placed in a wave that already has the max orders allowed when multiple orders per meal period is enabled
			ELSE AvailableOrders
			END
		FROM @MyWaves AS W
			LEFT JOIN dbo.tblDietWave as DW ON W.WaveID = DW.WaveID AND W.DietID = DW.DietID 
	-- End Diet

	-- NPO: Make sure all NPO items are disabled for ordering
	DELETE @MyWaves WHERE [description] = 'NPO'
	
	-- Set NPO waves for patient order type or for all order types if NPOGuestOrdering flag is set to 0 in overhead table
	IF (@OrderType = 1) OR (@NPOGuestOrdering = 0)
		UPDATE @MyWaves
		SET AvailableOrders = -1,
			[Description] = 'NPO'
		WHERE DietID = 0
			AND AvailableOrders = -1
	-- End NPO

	-- Allow only 1 meal per meal period unless there is an overhead key to override this feature
	IF (@MultipleOrdersPerMealPeriod = 0 AND @OrderType = 1)
	BEGIN
		DECLARE myMealPeriods CURSOR FOR
			SELECT MealPeriodID, WaveID, OrderStatus, DateOffset
			FROM @MyWaves 
			ORDER BY MealPeriodID, WaveID,OrderStatus, DateOffset DESC
	
		OPEN myMealPeriods
		FETCH NEXT FROM myMealPeriods INTO @MealPeriodID, @WaveID, @Status, @DateOffset
	
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			IF (@Status IN (17,18,20))
			BEGIN
				UPDATE @MyWaves SET AvailableOrders = -1
				WHERE MealPeriodID = @MealPeriodID 
					AND WaveID <> @WaveID	
					AND DateOffset = @DateOffset 			
			END
	
			FETCH NEXT FROM myMealPeriods INTO @MealPeriodID, @WaveID, @Status, @DateOffset
		END
		
		CLOSE myMealPeriods
		DEALLOCATE myMealPeriods
	END
	ELSE
	BEGIN
		DECLARE myMealPeriods CURSOR FOR
			SELECT MealPeriodID, WaveID, OrderStatus, DateOffset
			FROM @MyWaves 
			ORDER BY MealPeriodID, WaveID,OrderStatus, DateOffset DESC
	
		OPEN myMealPeriods
		FETCH NEXT FROM myMealPeriods INTO @MealPeriodID, @WaveID, @Status, @DateOffset
	
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			IF (@Status IN (17,18,20))
			BEGIN
				UPDATE @MyWaves SET OrderStatus = 23
				WHERE MealPeriodID = @MealPeriodID 
					AND WaveID <> @WaveID	
					AND DateOffset = @DateOffset 
					AND AvailableOrders > -1	
					AND OrderStatus NOT IN (17, 18, 20)			
			END
	
			FETCH NEXT FROM myMealPeriods INTO @MealPeriodID, @WaveID, @Status, @DateOffset
		END
		
		CLOSE myMealPeriods
		DEALLOCATE myMealPeriods
	END

	-- Construct return message
	SELECT @Count = COUNT(*) from @MyWaves
	SET @ReturnMsg = CAST(@Count as varchar(4)) + char(28)

	DECLARE Temp CURSOR FOR
		SELECT 	WaveID, Description, OrderDate, AvailableOrders, DateOffset, OrderStatus,BeginTime,EndTime
		FROM 	@MyWaves 
		ORDER BY OrderDate, EndTime, WaveID
        
	OPEN Temp
	FETCH NEXT FROM Temp INTO @WaveID, @Description, @OrderDate, @AvailableOrders, @DateOffset, @OrderStatus,@BeginTime,@EndTime

	WHILE ( @@FETCH_STATUS = 0)
	BEGIN
		SET @ReturnMsg = @ReturnMsg + CAST(@WaveID as varchar(5)) + ',' + @Description + ',' + @OrderDate + ',' + CAST(@AvailableOrders as varchar(5)) + ','  + Cast(@DateOffset as varchar(2)) + ','  + Cast(@OrderStatus as varchar(5)) + ','  + @BeginTime + ',' + @EndTime + char(28)
		FETCH NEXT FROM Temp INTO @WaveID, @Description, @OrderDate, @AvailableOrders, @DateOffset, @OrderStatus,@BeginTime,@EndTime
      	END

	CLOSE Temp
	DEALLOCATE Temp

     	IF ( RIGHT( @ReturnMsg,1 ) = char(28))
		SET @ReturnMsg = LEFT(@ReturnMsg, LEN(@ReturnMsg) -1)

	SELECT @ReturnMsg

	RETURN
go

