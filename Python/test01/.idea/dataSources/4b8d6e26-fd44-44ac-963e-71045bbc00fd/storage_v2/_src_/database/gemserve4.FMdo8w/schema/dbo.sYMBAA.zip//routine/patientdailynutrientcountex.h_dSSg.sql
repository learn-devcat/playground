CREATE FUNCTION dbo.PatientDailyNutrientCountEX(@PatientID int, @Today datetime, @FieldSeparator char(1))
RETURNS varchar(255)
BEGIN
	DECLARE @Return 	varchar(255),
		@NutrientID	int,
		@Qty		decimal(10,3)

	SET @Return = ''

	DECLARE @Nutrients TABLE 
	(
		NutrientID	int,
		Qty		decimal(5,2) DEFAULT (0)
	)

	DECLARE @Items TABLE 
	(
		Consumption	decimal (5,2),
		POSMenuItemID	int
	)

	INSERT INTO @Nutrients (NutrientID)
	SELECT NutrientID FROM dbo.cfgNutrients

	INSERT INTO @Items
	SELECT OI.Consumption, POSMenuItemID FROM dbo.tblOrderItems AS OI (NOLOCK) 
		JOIN dbo.tblOrderOHD AS O (NOLOCK) ON OI.OrderID = O.OrderID 
		AND O.PatientID = @PatientID		
		AND O.OrderType = 1
		AND dbo.dDateOnly(O.OrderDate) = dbo.dDateOnly(@Today)
		AND COALESCE(O.Cancelled,0) = 0

	-- Cursor to retrieve all nutrients and dailymax for the diet
	DECLARE Nutrients cursor FOR
		SELECT NutrientID FROM @Nutrients ORDER BY NutrientID

	OPEN Nutrients
	FETCH NEXT FROM Nutrients INTO @NutrientID

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SELECT @Qty = SUM(MN.Qty * (OP.Consumption / CAST(100 as decimal(5,2))))
		FROM @Items AS OP
			JOIN dbo.tblMenuItemOHD AS M (NOLOCK) ON OP.POSMenuItemID = M.POSMenuItemID
			JOIN dbo.tblMenuItemNutrients AS MN (NOLOCK) ON MN.MenuItemID = M.MenuItemID AND MN.NutrientID = @NutrientID

		SET @Return = @Return +@FieldSeparator + CAST(ISNULL(CAST(@Qty * 1000 AS int), 0) AS varchar(10))
		
		FETCH NEXT FROM Nutrients INTO @NutrientID
	END

	CLOSE Nutrients
	DEALLOCATE Nutrients

	IF (LEN(@Return) > 0)
		SET @Return = RIGHT(@Return,LEN(@Return)-1)

	RETURN @Return	
END
go

