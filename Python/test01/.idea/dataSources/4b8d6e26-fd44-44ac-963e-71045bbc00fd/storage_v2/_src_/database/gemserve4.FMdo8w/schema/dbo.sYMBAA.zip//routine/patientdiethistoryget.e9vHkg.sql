CREATE PROCEDURE dbo.PatientDietHistoryGet
@PatientVisitID		varchar(50)
AS
	SET NOCOUNT ON
	
	DECLARE @CurrentPatientDietID	int,
			@Today datetime

	SET @Today = getdate()

	SELECT @CurrentPatientDietID = dbo.GetPatientDietID(@PatientVisitID, @Today, dbo.TimeString(@Today))

	SELECT	ID AS PatientDietID,
		PatientVisitID,
		DietID,
		ActiveDate,
		PostDate,
		Source,
		Notes,
		Cancelled,
		CancelDate,
		TransactionIdentifier,
		CASE WHEN ID = @CurrentPatientDietID THEN 1
			ELSE 0 END AS CurrentDiet
	FROM dbo.tblPatientDiet (NOLOCK)
	WHERE PatientVisitID = @PatientVisitID
	ORDER BY ActiveDate DESC, PostDate DESC
go

