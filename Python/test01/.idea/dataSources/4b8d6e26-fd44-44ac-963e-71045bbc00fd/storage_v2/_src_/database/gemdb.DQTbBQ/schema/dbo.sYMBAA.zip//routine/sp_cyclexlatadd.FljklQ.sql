CREATE PROCEDURE dbo.sp_CycleXLATadd 
	@CoreID		int,
	@XlatID		char(10),
	@NumCycles 	int,
	@Freq 		VarChar(3)
	
AS 
DECLARE @FreqD as char		-- Date Type
DECLARE @FreqV as int 		-- Value of increment
DECLARE @BeginDate as datetime
DECLARE	@EndDate as datetime,
	@TempDate as datetime
DECLARE @CycleNo as int 
	SET @FreqD = upper( substring( @Freq , 1 , 1 ))
	SET @FreqV = CAST( SubString( @Freq , 2 , 2 ) as int )
	SELECT @CycleNo = max(CycleNo) FROM tblCycleXlat WHERE XlatID = @XlatID		
	SELECT @EndDate = max(EndDate) FROM tblCycleXlat WHERE XlatID = @XlatID		
	SET @EndDate   = ISNULL( @EndDate , getdate())		-- This really shouldn't happen AND is really a problem IF it does, since we have no range of frequences to go by.
	SET @CycleNo   = ISNULL( @CycleNo , 1 )
	
	while @NumCycles > 0
	  BEGIN
		
		SET @CycleNo   = @CycleNo + 1				-- Setup our NEXT cycle.
		-- 04-Nov-02 wjs -- Updated the way we are processing the gegin/END dates.  Now, I UPDATE both BEGIN AND END
		-- 		   using the same formula so that we don't loose the times.
		SET @BeginDate = @EndDate --  dateAdd( ss , 1 , @EndDate )			-- Our new BEGIN Date
		SET @EndDate = DATEADD( d ,0 , 
		CASE 					-- Setup our new END DATE
			WHEN @FreqD =  'D' THEN DATEADD(  d,  @FreqV  , @BeginDate )
			WHEN @FreqD = 'W' THEN DATEADD( ww,  @FreqV  , @BeginDate )
			WHEN @FreqD= 'Q' THEN DATEADD(  q,  @FreqV  , @BeginDate )
			WHEN @FreqD = 'M' THEN DATEADD( m , @FreqV , @BeginDate )
			WHEN @FreqD = 'Y' THEN DATEADD( yy,  @FreqV  , @BeginDate )
			WHEN @FreqD = 'A' THEN DATEADD( yy,  @FreqV  , @BeginDate )
			WHEN @FreqD = 'B' AND DAY(@BeginDate) < 14  THEN DATEADD( d , 15 , @BeginDate )
			WHEN @FreqD = 'B' THEN 
				CASE WHEN MONTH(@BeginDate) = 12 THEN '1-' +
					SUBSTRING( @Freq , 2 , 2 ) + '-' +
					CAST(YEAR(@BeginDate)+1 AS varchar(4))
				ELSE CAST(MONTH(@BeginDate)+1 AS varchar(2)) + '-' + 
					SUBSTRING( @Freq , 2 , 2 ) + '-' +
					CAST(YEAR(@BeginDate) AS varchar(4))
				END
		END)
		insert into tblCycleXLAT 
				   ( XlatID, BeginDate, EndDate, CycleNo) 
			VALUES ( @XlatID,@BeginDate,@EndDate,@CycleNo)
	
		SET @NumCycles = @NumCycles - 1		-- So we don't run forever...
		
	  END
go

