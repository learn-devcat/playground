
CREATE FUNCTION dbo.GetLastOrderByPatientDateRange(@PatientID int, @BeginDate datetime, @EndDate datetime)
RETURNS varchar(32)
BEGIN
	DECLARE @OrderDate datetime,
		@Return	varchar(32)
	
	SELECT TOP 1 @OrderDate = OrderDate
	FROM dbo.tblOrderOHD AS O (NOLOCK)
		JOIN dbo.tblWave AS W (NOLOCK) ON O.WaveID = W.WaveID
	WHERE PatientID = @PatientID
		AND OrderDate BETWEEN @BeginDate AND @EndDate
		AND W.MealPeriodID NOT IN (SELECT CAST(KeyIn AS int) FROM dbo.tblXlat WHERE xlatId = 'NoReportMealPeriod')
		AND COALESCE(Cancelled,0) <> 1
	ORDER BY OrderDate DESC
	
	IF(@OrderDate IS NULL)
		SET @Return = 'No order found'
	ELSE
		SET @Return = CAST(@OrderDate as varchar(32))

	RETURN @Return
END
go

