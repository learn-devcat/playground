CREATE TRIGGER AllergenSetLastUpdateDate ON [dbo].[cfgAllergens] FOR INSERT, UPDATE    
AS
      UPDATE    dbo.cfgAllergens
       SET              LastUpdateDate = getdate()
       FROM         Inserted AS I JOIN
                              dbo.cfgAllergens AS A ON I.AllergenID = A.AllergenID
go

