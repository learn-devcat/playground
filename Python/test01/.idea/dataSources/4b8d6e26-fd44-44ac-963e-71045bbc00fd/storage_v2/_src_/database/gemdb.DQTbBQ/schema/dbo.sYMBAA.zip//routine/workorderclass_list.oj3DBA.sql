CREATE     PROCEDURE dbo.WorkorderClass_List
@User   char(10)
AS
	SELECT 		WorkorderClassID,
			Description
			
	FROM		tblWorkorderClass
	ORDER BY	Description
go

