



CREATE   FUNCTION dbo.GetRecurInfo (@RecurID uniqueidentifier, 
					@AccountNo char(10), 
					@Amount money,
					@TransID int,
					@PastDue bit,
					@Minimum bit,
					@Balance bit,
					@TrackSlotNum int,
					@TrackIDNum int,
					@Today datetime) 
RETURNS varchar(32)
AS 
BEGIN 
	DECLARE	@Return		varchar(32)
	SET @Return = ''
	IF @Minimum = 1
		SET @Return = 'Min -'
	IF @Balance = 1 
		SET @Return = @Return + ' Account Balance'
	ELSE
	BEGIN
		IF @PastDue = 1
			SET @Return = @Return + ' Past Due Balance'
		ELSE
		BEGIN
			IF @TrackSlotNum > 0 
				SET @Return = @Return + ' Tracking Slot ' + CAST(@TrackSlotNum as varchar(3)) + ' Balance'
			ELSE
			BEGIN
				IF @TrackIDNum > 0 
					SET @Return = @Return + ' Tracking ID ' + CAST(@TrackIDNum as varchar(3)) + ' Balance'
				ELSE
					SET @Return = CAST(dbo.GetRecurAmount(@AccountNo,
											0,
											@Amount,
											@TransID,
											@PastDue,
											@Minimum,
											@Balance,
											@TrackSlotNum,
											@TrackIDNum,
											0,
											@Today,
											1) 
											 as varchar(10))
			END
		END	
	END
	
	RETURN @Return
		
END
go

