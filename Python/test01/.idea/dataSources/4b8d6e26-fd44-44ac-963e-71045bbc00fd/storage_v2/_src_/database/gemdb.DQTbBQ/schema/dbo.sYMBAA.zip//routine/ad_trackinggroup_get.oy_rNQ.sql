

CREATE PROCEDURE dbo.ad_TrackingGroup_Get
@User			char(10),
@TrackingGrp		int
AS
	SELECT	TrackingGrp,
			Description,
			Status,
			Item1,
			Item2,
			Item3,
			Item4,
			Item5,
			Item6,
			Item7,
			Item8,	
			Item9,
			Item10,
			Item11,
			Item12,
			Item13,
			Item14,
			Item15,
			Item16
	FROM		tblTrackingOHD
	WHERE	TrackingGrp = @TrackingGrp
go

