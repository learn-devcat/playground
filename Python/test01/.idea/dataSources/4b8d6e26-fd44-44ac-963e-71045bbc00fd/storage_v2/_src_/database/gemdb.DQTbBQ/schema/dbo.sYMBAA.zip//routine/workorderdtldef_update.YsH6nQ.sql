
CREATE         PROCEDURE dbo.WorkorderDTLDef_Update
@User			        char(10),
@WorkOrderDTLDefID      int,
@LocationID	            int,
@WorkOrderDTLClassID    int,
@EmployeeClassID        int,
@ShortDescription       varchar(50),
@Description            varchar(250),
@SkillLevel             int,
@Price                  money, 
@Cost                   money, 
@EstimatedHours         money,
@LeadTime               money,
@TransID                int,
@LaborCenterID		int
AS
	UPDATE	tblWorkorderDTLDef
	    SET LocationID          = @LocationID,
		WorkOrderDTLClassID = @WorkOrderDTLClassID,
            	EmployeeClassID     = @EmployeeClassID,
            	ShortDescription    = @ShortDescription,
            	Description         = @Description,
            	SkillLevel          = @SkillLevel,
            	Price               = @Price,
            	Cost                = @Cost,
            	EstimatedHours      = Round(@EstimatedHours,2),
            	LeadTime            = Round(@LeadTime,2),
            	TransID             = @TransID,
		LaborCenterID	    = @LaborCenterID		
	WHERE	WorkorderDTLDefID = @WorkOrderDTLDefID
	
   RETURN
go

