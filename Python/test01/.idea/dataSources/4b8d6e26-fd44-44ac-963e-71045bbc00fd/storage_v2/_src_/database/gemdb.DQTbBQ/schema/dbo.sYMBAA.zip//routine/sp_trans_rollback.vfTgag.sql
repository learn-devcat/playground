
CREATE    PROCEDURE dbo.sp_Trans_RollBack
@User		char(10),
@Filter		VarChar(2000)
AS
	BEGIN TRANSACTION
	
		DECLARE @DetailID	uniqueidentifier,
			@CoreID 	int,
			@AccountNo	char(19),
			@BadgeNo	char(19), 
			@TransDate	datetime, 
			@PostDate	datetime, 
			@CycleNo	int, 
			@Category	char(10),
			@OutletNo	int, 
			@TransID	int, 
			@RefNum		char(6), 
			@ChkNum		char(6), 
			@PaymentNo	smallint, 
			@ServeEmpl	smallint, 
			@Covers		smallint, 
			@RevCntr	smallint,
			@TransTotal	money, 
			@Sales1		money, 
			@Sales2		money,  
			@Sales3		money,  
			@Sales4		money,  
			@Sales5		money,  
			@Sales6		money,  
			@Sales7		money, 
			@Sales8		money,  
			@Sales9		money,  
			@Sales10	money, 
			@Sales11	money,  
			@Sales12	money,  
			@Sales13	money,  
			@Sales14	money,  
			@Sales15	money, 
			@Sales16	money,  
			@Tax1		money,  
			@Tax2		money,   
			@Tax3		money,   
			@Tax4		money,   
			@Dsc		money,   
			@Svc		money,   
	--		@memo		image, 		--image is invalid for local variables, so we will lose this when rolling back.
			@Comment	varchar(40),
			@Flag		bit,
	
			@Return		int,
			@TempData	varchar(1000),
			@SelectItems	NVarChar(4000),
			@FromTables	NVarChar(4000)	,
			@FullCode	NVarChar(4000)	,
			@NFilter	NvarChar(4000)	
			
		SET @NFilter = Cast(@Filter as NVarChar(4000))
		-- IF the EndDate passed in has a 00:00:00 time, then make sure  we are including the entire day
		--IF (@EndDate = dbo.dDatePlusNewTime(@EndDate,'00:00:00'))
		--	SET @EndDate = DATEADD(d, 1, @EndDate)
		--SET @TempData = 'Rollback process started - Begindate:' + CAST(@BeginDate as varchar(25)) + ' | Enddate:' + CAST(@EndDate as varchar(25))
		--EXEC dbo.sp_Logit 0, 1, @User, @TempData
		-- DELETE any existing batch transactions that have already Posted
		DELETE 	tblBatch
		WHERE	BatchID = 'rollback'
			AND Posted = 'p'
		-- Create temp table
		IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE NAME LIKE '#RollbackTemp%')
			DROP TABLE #RollbackTemp
		CREATE TABLE #RollbackTemp (
			[DetailID] [uniqueidentifier] NULL,
			[CoreID] [int] DEFAULT (1) NULL,
			[AccountNo] [char] (19) NULL,
			[BadgeNo] [char] (19) NULL,
			[TransDate] [datetime] NULL,
			[PostDate] [datetime] NULL,
			[CycleNo] [int] NULL,
			[Category] [char] (10) NULL,
			[OutletNo] [int]NULL,
			[TransID] [int] NULL,
			[RefNum] [char] (6) NULL,
			[ChkNum] [char] (6) NULL,
			[PaymentNo] [smallint] NULL,
			[ServeEmpl] [smallint] NULL,
			[Covers] [smallint] NULL,
			[RevCntr] [smallint] NULL,
			[TransTotal] [money] NULL,
			[Sales1] [money] NULL,
			[Sales2] [money] NULL,
			[Sales3] [money] NULL,
			[Sales4] [money] NULL,
			[Sales5] [money] NULL,
			[Sales6] [money] NULL,
			[Sales7] [money] NULL,
			[Sales8] [money] NULL,
			[Sales9] [money] NULL,
			[Sales10] [money] NULL,
			[Sales11] [money] NULL,
			[Sales12] [money] NULL,
			[Sales13] [money] NULL,
			[Sales14] [money] NULL,
			[Sales15] [money] NULL,
			[Sales16] [money] NULL,
			[tax1] [money] NULL,
			[tax2] [money] NULL,
			[tax3] [money] NULL,
			[tax4] [money] NULL,
			[dsc] [money] NULL,
			[svc] [money] NULL,
			[Comment] [varchar] (40) NULL,
			[flag] [bit] NULL
		)
		
		SET @SelectItems = 'D.DetailID,D.CoreID, D.AccountNo, D.BadgeNo,
				D.TransDate, D.PostDate, D.CycleNo, D.Category,
				D.OutletNo, D.TransID, D.RefNum, D.ChkNum,
				D.PaymentNo,D.ServeEmpl, D.Covers, D.RevCntr,
				D.TransTotal, D.Sales1, D.Sales2, D.Sales3, D.Sales4,
				D.Sales5, D.Sales6, D.Sales7,D.Sales8, D.Sales9, D.Sales10,
				D.Sales11, D.Sales12, D.Sales13, D.Sales14, D.Sales15, D.Sales16,
				D.Tax1, D.Tax2, D.Tax3, D.Tax4, D.Dsc, D.Svc, D.Comment, D.Flag'
		
		SET @FromTables =  'tblDetail AS D 
				LEFT JOIN 
				    tblAccountOHD as A ON D.AccountNo = A.AccountNo
				LEFT JOIN
				    tblBadgesOHD as B ON D.BadgeNo = B.BadgeNo AND D.AccountNo = B.AccountNo
				LEFT JOIN
				    tblAccountTTL as T ON A.AccountNo = T.Accountno AND dbo.GetTTLFromTransID(D.TransID) = T.TransClassID
				LEFT JOIN
					tblAccountOutletClassTTL as OC ON A.AccountNo = OC.AccountNo AND OutletClassID = (SELECT OutletClassID FROM tblOutletOHD WHERE OutletNo = D.OutletNo)'
		-- All of this is done so that a WHERE clause can be passed in dynamically FROM the management page.
		Exec ('INSERT INTO #RollbackTemp SELECT ' + @SelectItems + ' FROM ' + @FromTables + ' ' + @Filter)
		
		DECLARE TempTrans CURSOR FOR
		
			SELECT  detailid, CoreID, AccountNo, BadgeNo,
				TransDate, PostDate, CycleNo, Category,
				OutletNo, TransID, RefNum, ChkNum,
				PaymentNo, ServeEmpl, Covers, RevCntr,
				TransTotal, Sales1, Sales2, Sales3, Sales4,
				Sales5, Sales6, Sales7,Sales8, Sales9, Sales10,
				Sales11, Sales12, Sales13, Sales14, Sales15, Sales16,
				Tax1, Tax2, Tax3, Tax4, Dsc, Svc, Comment, Flag
			FROM 	#RollbackTemp
	
		OPEN TempTrans
	
		FETCH NEXT FROM TempTrans INTO
			@DetailID, @CoreID, @AccountNo, @BadgeNo, @TransDate, @PostDate, @CycleNo, @Category,
			@OutletNo, @TransID, @RefNum, @ChkNum, @PaymentNo, @ServeEmpl, @Covers, @RevCntr,
			@TransTotal, @Sales1, @Sales2, @Sales3, @Sales4, @Sales5, @Sales6, @Sales7,
			@Sales8, @Sales9, @Sales10, @Sales11, @Sales12, @Sales13, @Sales14, @Sales15,
			@Sales16, @Tax1, @Tax2, @Tax3, @Tax4, @Dsc, @Svc, @Comment, @Flag
		
		WHILE @@FETCH_status = 0
		BEGIN
			-- This step removes the detail item AND adjusts the balances for the 
			-- transaction we are rolling back
			EXEC @Return = dbo.sp_Trans_RemovePost 'support', @DetailID
	
			-- IF the removal was successful, then insert the item into the batch table to be rePosted later
			IF (@Return = 0)
			BEGIN
				-- insert the transaction into the batch table
				INSERT INTO tblBatch(
						BatchID, CoreID, AccountNo, BadgeNo, 
						TransDate, PostDate, CycleNo, Category,
						OutletNo, TransID, RefNum, ChkNum,
						PaymentNo, ServeEmpl, Covers, RevCntr,
						TransTotal, Sales1, Sales2, Sales3, Sales4,
						Sales5, Sales6, Sales7,Sales8, Sales9, Sales10,
						Sales11, Sales12, Sales13, Sales14, Sales15, Sales16,
						Tax1, Tax2, Tax3, Tax4, Dsc, Svc, Comment, Flag
						)
					VALUES 	(
						'rollback',@CoreID, @AccountNo, @BadgeNo,
						@TransDate, @PostDate, @CycleNo, @Category,
						@OutletNo, @TransID, @RefNum, @ChkNum,
						@PaymentNo, @ServeEmpl, @Covers, @RevCntr,
						@TransTotal, @Sales1, @Sales2, @Sales3, @Sales4,
						@Sales5, @Sales6, @Sales7, @Sales8, @Sales9, @Sales10,
						@Sales11, @Sales12, @Sales13, @Sales14, @Sales15, @Sales16,
						@Tax1, @Tax2, @Tax3, @Tax4, @Dsc, @Svc, @Comment, @Flag
						)
			END
			ELSE
			BEGIN
				-- Add this information to the log table in case we had a problem during the previous removal AND lost the data for 
				-- the detail item completely
				SET @TempData = 'ROLLBACK | acctno=' + @AccountNo + '|BadgeNo=' + @BadgeNo + '|TransDate=' + CAST(@TransDate as varchar(25)) + '|PostDate=' + CAST(@PostDate as varchar(25)) +
						'|OutletNo=' + CAST(@OutletNo as varchar(5)) + '|TransID=' + CAST(@TransID as varchar(5)) + '|RefNum=' + @RefNum + '|ChkNum=' + @ChkNum + 
						'TransTotal=' + CAST(@TransTotal as varchar(14)) + '|Sales1=' + CAST(@Sales1 as varchar(14)) + '|Tax1=' + CAST(@Tax1 as varchar(14))
				EXEC dbo.sp_Logit 0, 1, @User, @TempData
				ROLLBACK TRANSACTION
			END
	
			FETCH NEXT FROM TempTrans INTO
				@DetailID, @CoreID, @AccountNo, @BadgeNo, @TransDate, @PostDate, @CycleNo, @Category,
				@OutletNo, @TransID, @RefNum, @ChkNum, @PaymentNo, @ServeEmpl, @Covers, @RevCntr,
				@TransTotal, @Sales1, @Sales2, @Sales3, @Sales4, @Sales5, @Sales6, @Sales7,
				@Sales8, @Sales9, @Sales10, @Sales11, @Sales12, @Sales13, @Sales14, @Sales15,
				@Sales16, @Tax1, @Tax2, @Tax3, @Tax4, @Dsc, @Svc, @Comment, @Flag
	
		END
	
		CLOSE TempTrans
		DEALLOCATE TempTrans
	
	COMMIT TRANSACTION
go

