CREATE FUNCTION ListToTable (@List varchar(MAX))
   RETURNS @Tbl TABLE (Number int NOT NULL) AS
BEGIN
   DECLARE @POS        int,
           @NextPos    int,
           @ValueLen   int

	IF (@List = '')
		INSERT INTO @Tbl (Number)
		SELECT LocationId FROM dbo.cfgLocations
	ELSE
	BEGIN
	   SELECT @POS = 0, @NextPos = 1

	   WHILE @NextPos > 0
	   BEGIN
		  SELECT @NextPos = CHARINDEX(',', @List, @POS + 1)
		  SELECT @ValueLen = CASE WHEN @NextPos > 0
								  THEN @NextPos
								  ELSE LEN(@List) + 1
							 END - @POS - 1
		  INSERT @Tbl (Number)
			 VALUES (CONVERT(int, SUBSTRING(@List, @POS + 1, @ValueLen)))
		  SELECT @POS = @NextPos
	   END
	END   
   
   RETURN
END
go

