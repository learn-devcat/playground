




CREATE    PROCEDURE dbo.EmployeeClass_List
@User			char(10)
AS
	SELECT		EmployeeClassID,
			EmployeeClassName,
			Description
	FROM		tblEmployeeClass
	ORDER BY 	EmployeeClassID
go

