

CREATE PROCEDURE dbo.sp_CycleNo_CurrentCycleByXREF
@User 		char(10),
@AccountNo	char(19)
AS
	DECLARE	@CycleXREFID	varchar(10)
	SELECT	@CycleXREFID = AC.CycleXREFID
	FROM		tblAccountOHD	AS A
			INNER JOIN
			tblAccountClass AS AC
	ON		A.AccountClassID = AC.AccountClassID
	WHERE	A.AccountNo = @AccountNo
   	
	SELECT	CycleNo, 
			EndDate AS CycleDate
	FROM		tblCycleXlat
	WHERE	getdate() BETWEEN BeginDate AND EndDate
			AND xlatid = @CycleXREFID
go

