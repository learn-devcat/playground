
CREATE  PROCEDURE dbo.WorkorderDTLClass_Update
@User                   char(10),
@WorkOrderDTLClassID    int,
@Description            varchar(50)
AS
	UPDATE  tblWorkorderDTLClass
	SET	    Description = @Description
	WHERE   WorkOrderDTLClassID = @WorkOrderDTLClassID
go

