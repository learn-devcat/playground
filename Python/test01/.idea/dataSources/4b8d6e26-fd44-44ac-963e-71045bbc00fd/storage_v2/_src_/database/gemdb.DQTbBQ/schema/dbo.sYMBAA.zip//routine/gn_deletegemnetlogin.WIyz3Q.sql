

CREATE PROCEDURE dbo.gn_DeleteGEMNetLogin
@LoggedInUserID	varchar(20),
@UserName	varchar(50)
AS
	DELETE	GEMNet..tblAccountLogin
	WHERE	UserName = @UserName
go

