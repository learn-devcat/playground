



CREATE   PROCEDURE dbo.sp_CheckPW
@UserID	varchar(16)
AS
DECLARE @LogEventID	int
DECLARE @LogonDescr	varchar(16)
	SELECT	PW, SecurityLevel, MenuGroup, UserName, LicenseKey,SlotNo,
			UserOptions,dbo.GetOverheadItem('SerialNumber') AS SerialNumber,OutletClass,
			1 AS ProductNo, [Language], DatabaseName
	FROM		cfgUsers
	WHERE	UserID = @UserID
	IF @@ROWCOUNT > 0
		BEGIN
			SET @LogEventID = 100
			SET @LogonDescr = 'Successful Logon for user: '
		END

	DECLARE 	@cMsg  char(255),
				@CoreID	int
	SET @CoreID = dbo.GetCoreIDFromUser(@UserID)
	SET @cMsg = @LogonDescr + '<' + @UserID + '>'
	EXEC dbo.sp_Logit 4 , @CoreID , @UserID , @cMsg, @LogEventID
go

