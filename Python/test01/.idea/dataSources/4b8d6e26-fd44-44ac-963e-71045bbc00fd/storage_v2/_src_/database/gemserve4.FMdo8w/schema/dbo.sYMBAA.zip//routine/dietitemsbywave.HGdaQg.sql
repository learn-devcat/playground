


CREATE PROCEDURE dbo.DietItemsByWave
@DietID	int,
@WaveID	int

AS
	SET NOCOUNT ON

	DECLARE	@NutrientID	int,
		@Qty		int

	DECLARE	@Items TABLE 
		(
		NutrientID	int PRIMARY KEY,
		Description	varchar(50),
		Qty		int,
		ts		timestamp
		)

	IF NOT EXISTS (SELECT DietID FROM dbo.tblDietOHD (NOLOCK) WHERE DietID = @DietID)
	BEGIN
		RAISERROR ('Diet does not exist',16,1)
		RETURN
	END
		
	INSERT INTO @Items (NutrientID,Description)
		SELECT NutrientID, Description
		FROM dbo.cfgNutrients (NOLOCK)


	DECLARE DItems SCROLL CURSOR FOR
		SELECT NutrientID FROM @Items

	OPEN DItems
	
	FETCH NEXT FROM DItems INTO @NutrientID

	WHILE ( @@FETCH_STATUS = 0 )
	BEGIN
		SET @Qty = null

		SELECT 	@Qty = CASE 
				WHEN Qty IS NULL THEN DI.DefaultQty
				ELSE Qty
			END
		FROM	dbo.tblDietDtl AS DD (NOLOCK)
			JOIN dbo.tblDietWave AS DW (NOLOCK) ON DD.DietWaveID = DW.DietWaveID
			LEFT JOIN dbo.cfgNutrients AS DI (NOLOCK) ON DD.NutrientID = DI.NutrientID
		WHERE	DD.NutrientID = @NutrientID
			AND DW.DietID = @DietID
			AND DW.WaveID = @WaveID

		IF (@Qty IS NULL)
			SELECT @Qty = DefaultQty
			FROM dbo.cfgNutrients (NOLOCK)
			WHERE NutrientID = @NutrientID

		UPDATE	@Items
		SET	Qty = ISNULL(@Qty, 0)
		WHERE CURRENT OF DItems

		FETCH NEXT FROM DItems INTO @NutrientID
	END

	CLOSE DItems
	DEALLOCATE DItems	
	
	SELECT NutrientID, Description, Qty FROM @Items
	ORDER BY NutrientID

	RETURN
go

