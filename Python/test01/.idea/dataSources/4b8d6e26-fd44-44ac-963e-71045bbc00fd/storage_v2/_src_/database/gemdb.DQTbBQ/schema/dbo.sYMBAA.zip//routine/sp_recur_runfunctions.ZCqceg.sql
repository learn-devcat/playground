

CREATE PROCEDURE dbo.sp_Recur_RunFunctions
@User		char(10),
@ClassID	int
AS
	SET NOCOUNT ON
	DECLARE	@SQL			nvarchar(255),
			@Delimiter		varchar(10)
	DECLARE	@RecurFuncID		int,
			@NumParms		int,
			@CMD			varchar(250),
			@Parm1		varchar(50),
			@Parm2		varchar(50),
			@Parm3		varchar(50),
			@Parm4		varchar(50),
			@Parm5		varchar(50),
			@Parm6		varchar(50),
			@Parm7		varchar(50),
			@Parm8		varchar(50),
			@Parm9		varchar(50)
	DECLARE	RTemp cursor FOR 
			SELECT RecurFuncID,
				NumParms,
				CMD,
				Parm1,
				Parm2,
				Parm3,
				Parm4,
				Parm5,
				Parm6,
				Parm7,
				Parm8,
				Parm9
			FROM tblRecurFunctions
			WHERE ClassID = @ClassID AND
				 Active <> 0
			ORDER BY Sequence
			--FOR BROWSE
	OPEN RTemp
	FETCH NEXT FROM RTemp 
		INTO 	@RecurFuncID,
			@NumParms,
			@CMD,
			@Parm1,
			@Parm2,
			@Parm3,
			@Parm4,
			@Parm5,
			@Parm6,
			@Parm7,
			@Parm8,
			@Parm9
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		IF ((CHARINDEX('.exe',@CMD) > 0) OR  (CHARINDEX('.bat',@CMD) > 0))
			SET @Delimiter = ''
		ELSE
			SET @Delimiter = ''''
		SET @SQL =  
			CASE @NumParms
				WHEN 0 THEN @CMD
				WHEN 1 THEN @CMD + ' ' + @Delimiter + @Parm1 + @Delimiter
				WHEN 2 THEN @CMD + ' ' + @Delimiter + @Parm1 + @Delimiter + ',' + @Delimiter + @Parm2 + @Delimiter
				WHEN 3 THEN @CMD + ' ' + @Delimiter + @Parm1 + @Delimiter + ',' + @Delimiter + @Parm2 + @Delimiter + ',' + @Delimiter + @Parm3 + @Delimiter
				WHEN 4 THEN @CMD + ' ' + @Delimiter + @Parm1 + @Delimiter + ',' + @Delimiter + @Parm2 + @Delimiter + ',' + @Delimiter + @Parm3 + @Delimiter + ',' + @Delimiter + @Parm4 + @Delimiter
				WHEN 5 THEN @CMD + ' ' + @Delimiter + @Parm1 + @Delimiter + ',' + @Delimiter + @Parm2 + @Delimiter + ',' + @Delimiter + @Parm3 + @Delimiter + ',' + @Delimiter + @Parm4 + @Delimiter + ',' + @Delimiter + @Parm5 + @Delimiter
				WHEN 6 THEN @CMD + ' ' + @Delimiter + @Parm1 + @Delimiter + ',' + @Delimiter + @Parm2 + @Delimiter + ',' + @Delimiter + @Parm3 + @Delimiter + ',' + @Delimiter + @Parm4 + @Delimiter + ',' + @Delimiter + @Parm5 + @Delimiter + ',' + @Delimiter + @Parm6 + @Delimiter
				WHEN 7 THEN @CMD + ' ' + @Delimiter + @Parm1 + @Delimiter + ',' + @Delimiter + @Parm2 + @Delimiter + ',' + @Delimiter + @Parm3 + @Delimiter + ',' + @Delimiter + @Parm4 + @Delimiter + ',' + @Delimiter + @Parm5 + @Delimiter + ',' + @Delimiter + @Parm6 + @Delimiter + ',' + @Delimiter + @Parm7 + @Delimiter
				WHEN 8 THEN @CMD + ' ' + @Delimiter + @Parm1 + @Delimiter + ',' + @Delimiter + @Parm2 + @Delimiter + ',' + @Delimiter + @Parm3 + @Delimiter + ',' + @Delimiter + @Parm4 + @Delimiter + ',' + @Delimiter + @Parm5 + @Delimiter + ',' + @Delimiter + @Parm6 + @Delimiter + ',' + @Delimiter + @Parm7 + @Delimiter +',' + @Delimiter + @Parm8 + @Delimiter
				WHEN 9 THEN @CMD + ' ' + @Delimiter + @Parm1 + @Delimiter + ',' + @Delimiter + @Parm2 + @Delimiter + ',' + @Delimiter + @Parm3 + @Delimiter + ',' + @Delimiter + @Parm4 + @Delimiter + ',' + @Delimiter + @Parm5 + @Delimiter + ',' + @Delimiter + @Parm6 + @Delimiter + ',' + @Delimiter + @Parm7  + @Delimiter+ ',' + @Delimiter + @Parm8 + @Delimiter +  ',' + @Delimiter + @Parm9 + @Delimiter
			END 
		--SELECT @SQL
		IF ((CHARINDEX('.exe',@SQL) > 0) OR  (CHARINDEX('.bat',@SQL) > 0))
			EXEC master.dbo.xp_cmdshell @SQL
		ELSE
			EXEC sp_executesql @SQL
		
--		UPDATE tblRecurFunctions
--		SET	  LastRunDate = getdate()
--		WHERE CURRENT OF RTemp
		FETCH NEXT FROM RTemp 
			INTO 	@RecurFuncID,
				@NumParms,
				@CMD,
				@Parm1,
				@Parm2,
				@Parm3,
				@Parm4,
				@Parm5,
				@Parm6,
				@Parm7,
				@Parm8,
				@Parm9
	END
	CLOSE RTemp
	DEALLOCATE RTemp
go

