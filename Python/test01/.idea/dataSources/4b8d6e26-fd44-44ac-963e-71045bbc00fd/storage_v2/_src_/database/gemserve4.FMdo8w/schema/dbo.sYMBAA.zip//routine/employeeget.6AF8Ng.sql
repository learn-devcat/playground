

CREATE PROCEDURE dbo.EmployeeGet 
@LoginUserID varchar(250)
AS
	SET NOCOUNT ON 
	 
	SELECT	LoginUserID,
		    FirstName,
		    LastName,
		    Department,
		    [Password],
		    IsAdmin,
		    BadgeNo
	FROM	dbo.tblEmployees
	WHERE   LoginUserID = @LoginUserID
	
	RETURN
go

