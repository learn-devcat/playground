


CREATE PROCEDURE dbo.Logit
    @Type           int,
    @Description    varchar(200),
    @LoginUserID	    varchar(250),
    @Computer       varchar(10)=null,
    @EventID        int=null
    
AS
    INSERT INTO dbo.tblSysLog (EventDate, Type, EventID, LoginUserID, Computer, [Description])
        VALUES (getdate(), @Type, @EventID, @LoginUserID, @Computer, @Description)

	RETURN
go

