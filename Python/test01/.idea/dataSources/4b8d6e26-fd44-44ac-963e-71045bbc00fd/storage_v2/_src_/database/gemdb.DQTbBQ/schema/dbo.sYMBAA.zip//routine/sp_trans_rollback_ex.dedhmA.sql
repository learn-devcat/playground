
CREATE	PROCEDURE [dbo].[sp_Trans_RollBack_EX]
    @User char(10),
    @Filter VarChar(2000)
AS 
	SET NOCOUNT ON
	
    DECLARE @DetailID uniqueidentifier,
        @CoreID int,
        @AccountNo char(19),
        @BadgeNo char(19),
        @TransDate datetime,
        @PostDate datetime,
        @CycleNo int,
        @Category char(10),
        @OutletNo int,
        @TransID int,
        @RefNum char(6),
        @ChkNum char(6),
        @PaymentNo int,
        @ServeEmpl int,
        @Covers smallint,
        @RevCntr int,
        @TransTotal money,
        @Sales1 money,
        @Sales2 money,
        @Sales3 money,
        @Sales4 money,
        @Sales5 money,
        @Sales6 money,
        @Sales7 money,
        @Sales8 money,
        @Sales9 money,
        @Sales10 money,
        @Sales11 money,
        @Sales12 money,
        @Sales13 money,
        @Sales14 money,
        @Sales15 money,
        @Sales16 money,
        @Tax1 money,
        @Tax2 money,
        @Tax3 money,
        @Tax4 money,
        @Dsc money,
        @Svc money,   
	--		@memo		image, 		--image is invalid for local variables, so we will lose this when rolling back.
        @Comment varchar(40),
        @Flag bit,
        @Return int,
        @TempData varchar(1000),
        @FromTables varchar(500),
        @ErrorHappened INT,
        @SqlStatement varchar(2000),
        @finishedSql NVARCHAR(4000)
        
        SET @ErrorHappened = 0
			
		-- IF the EndDate passed in has a 00:00:00 time, then make sure  we are including the entire day
		--IF (@EndDate = dbo.dDatePlusNewTime(@EndDate,'00:00:00'))
		--	SET @EndDate = DATEADD(d, 1, @EndDate)
		--SET @TempData = 'Rollback process started - Begindate:' + CAST(@BeginDate as varchar(25)) + ' | Enddate:' + CAST(@EndDate as varchar(25))
		--EXEC dbo.sp_Logit 0, 1, @User, @TempData
		-- DELETE any existing batch transactions that have already Posted
    DELETE  dbo.tblBatch
    WHERE   tblBatch.BatchID = 'rollback'
            AND tblBatch.Posted = 'p'
		-- Create temp table
    IF EXISTS ( SELECT  *
                FROM    tempdb..sysobjects
                WHERE   NAME LIKE '#RollbackTemp%' ) 
        DROP TABLE #RollbackTemp
    CREATE TABLE #RollbackTemp
        (
          [DetailID] [uniqueidentifier] NOT NULL
        )
		
    SET @FromTables = 'tblDetail AS D ' + 
					  'LEFT JOIN tblAccountOHD as A ON D.AccountNo = A.AccountNo ' + 
					  'LEFT JOIN tblBadgesOHD as B ON D.BadgeNo = B.BadgeNo AND D.AccountNo = B.AccountNo ' + 
					  'LEFT JOIN tblAccountTTL as T ON A.AccountNo = T.Accountno AND dbo.GetTTLFromTransID(D.TransID) = T.TransClassID '
/*				    
				LEFT JOIN
					tblAccountOutletClassTTL as OC ON A.AccountNo = OC.AccountNo AND OutletClassID = (SELECT OutletClassID FROM tblOutletOHD WHERE OutletNo = D.OutletNo)'
*/					
		-- All of this is done so that a WHERE clause can be passed in dynamically FROM the management page.
	SET @SqlStatement = 'INSERT INTO #RollbackTemp SELECT D.DetailID FROM ' + @FromTables + ' WHERE ' + @Filter
	SET @finishedSql = CAST(@SqlStatement AS NVARCHAR(4000))
    EXECUTE sp_executesql @finishedSql
	
    BEGIN TRANSACTION
    		
    DECLARE TempTrans CURSOR
        FOR SELECT  d.detailid,
                    d.CoreID,
                    d.AccountNo,
                    d.BadgeNo,
                    d.TransDate,
                    d.PostDate,
                    d.CycleNo,
                    d.Category,
                    d.OutletNo,
                    d.TransID,
                    d.RefNum,
                    d.ChkNum,
                    d.PaymentNo,
                    d.ServeEmpl,
                    d.Covers,
                    d.RevCntr,
                    d.TransTotal,
                    d.Sales1,
                    d.Sales2,
                    d.Sales3,
                    d.Sales4,
                    d.Sales5,
                    d.Sales6,
                    d.Sales7,
                    d.Sales8,
                    d.Sales9,
                    d.Sales10,
                    d.Sales11,
                    d.Sales12,
                    d.Sales13,
                    d.Sales14,
                    d.Sales15,
                    d.Sales16,
                    d.Tax1,
                    d.Tax2,
                    d.Tax3,
                    d.Tax4,
                    d.Dsc,
                    d.Svc,
                    d.Comment,
                    d.Flag
            FROM    #RollbackTemp r
                    LEFT JOIN dbo.tblDetail d ON r.DetailID = d.DetailID
	
    OPEN TempTrans
	
    FETCH NEXT FROM TempTrans INTO @DetailID, @CoreID, @AccountNo, @BadgeNo,
        @TransDate, @PostDate, @CycleNo, @Category, @OutletNo, @TransID,
        @RefNum, @ChkNum, @PaymentNo, @ServeEmpl, @Covers, @RevCntr,
        @TransTotal, @Sales1, @Sales2, @Sales3, @Sales4, @Sales5, @Sales6,
        @Sales7, @Sales8, @Sales9, @Sales10, @Sales11, @Sales12, @Sales13,
        @Sales14, @Sales15, @Sales16, @Tax1, @Tax2, @Tax3, @Tax4, @Dsc, @Svc,
        @Comment, @Flag
		
    WHILE @@FETCH_status = 0
        BEGIN
			-- This step removes the detail item AND adjusts the balances for the 
			-- transaction we are rolling back
            EXEC @Return = dbo.sp_Trans_RemovePost 'support', @DetailID
	
			-- IF the removal was successful, then insert the item into the batch table to be rePosted later
            IF ( @Return = 0 ) 
                BEGIN
				-- insert the transaction into the batch table
                    INSERT  INTO dbo.tblBatch
                            (
                              BatchID,
                              CoreID,
                              AccountNo,
                              BadgeNo,
                              TransDate,
                              PostDate,
                              CycleNo,
                              Category,
                              OutletNo,
                              TransID,
                              RefNum,
                              ChkNum,
                              PaymentNo,
                              ServeEmpl,
                              Covers,
                              RevCntr,
                              TransTotal,
                              Sales1,
                              Sales2,
                              Sales3,
                              Sales4,
                              Sales5,
                              Sales6,
                              Sales7,
                              Sales8,
                              Sales9,
                              Sales10,
                              Sales11,
                              Sales12,
                              Sales13,
                              Sales14,
                              Sales15,
                              Sales16,
                              Tax1,
                              Tax2,
                              Tax3,
                              Tax4,
                              Dsc,
                              Svc,
                              Comment,
                              Flag
						
                            )
                    VALUES  (
                              'rollback',
                              @CoreID,
                              @AccountNo,
                              @BadgeNo,
                              @TransDate,
                              @PostDate,
                              @CycleNo,
                              @Category,
                              @OutletNo,
                              @TransID,
                              @RefNum,
                              @ChkNum,
                              @PaymentNo,
                              @ServeEmpl,
                              @Covers,
                              @RevCntr,
                              @TransTotal,
                              @Sales1,
                              @Sales2,
                              @Sales3,
                              @Sales4,
                              @Sales5,
                              @Sales6,
                              @Sales7,
                              @Sales8,
                              @Sales9,
                              @Sales10,
                              @Sales11,
                              @Sales12,
                              @Sales13,
                              @Sales14,
                              @Sales15,
                              @Sales16,
                              @Tax1,
                              @Tax2,
                              @Tax3,
                              @Tax4,
                              @Dsc,
                              @Svc,
                              @Comment,
                              @Flag
						
                            )
                END
            ELSE 
                BEGIN
					ROLLBACK TRANSACTION
				-- Add this information to the log table in case we had a problem during the previous removal AND lost the data for 
				-- the detail item completely
                    SET @TempData = 'ROLLBACK | acctno=' + @AccountNo
                        + '|BadgeNo=' + @BadgeNo + '|TransDate='
                        + CAST(@TransDate as varchar(25)) + '|PostDate='
                        + CAST(@PostDate as varchar(25)) + '|OutletNo='
                        + CAST(@OutletNo as varchar(5)) + '|TransID='
                        + CAST(@TransID as varchar(5)) + '|RefNum=' + @RefNum
                        + '|ChkNum=' + @ChkNum + 'TransTotal='
                        + CAST(@TransTotal as varchar(14)) + '|Sales1='
                        + CAST(@Sales1 as varchar(14)) + '|Tax1='
                        + CAST(@Tax1 as varchar(14))
                    EXEC dbo.sp_Logit 0, 1, @User, @TempData
                    
					SET @ErrorHappened = 1
                END
	
            FETCH NEXT FROM TempTrans INTO @DetailID, @CoreID, @AccountNo,
                @BadgeNo, @TransDate, @PostDate, @CycleNo, @Category,
                @OutletNo, @TransID, @RefNum, @ChkNum, @PaymentNo, @ServeEmpl,
                @Covers, @RevCntr, @TransTotal, @Sales1, @Sales2, @Sales3,
                @Sales4, @Sales5, @Sales6, @Sales7, @Sales8, @Sales9, @Sales10,
                @Sales11, @Sales12, @Sales13, @Sales14, @Sales15, @Sales16,
                @Tax1, @Tax2, @Tax3, @Tax4, @Dsc, @Svc, @Comment, @Flag
	
        END
	
    CLOSE TempTrans
    DEALLOCATE TempTrans
	
    COMMIT TRANSACTION
	
	SELECT @ErrorHappened
go

