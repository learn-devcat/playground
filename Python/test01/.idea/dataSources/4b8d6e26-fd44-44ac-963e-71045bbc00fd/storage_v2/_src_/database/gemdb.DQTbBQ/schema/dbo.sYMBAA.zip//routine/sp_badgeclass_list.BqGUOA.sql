

CREATE PROCEDURE dbo.sp_BadgeClass_List
AS
	SELECT	BadgeClassID,Description
	FROM		tblBadgeClass
	ORDER BY	BadgeClassID
go

