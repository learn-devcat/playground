

CREATE FUNCTION dbo.zSelect (@f money, @s money) 
RETURNS money AS 
BEGIN 
	IF @f > 0 
		IF @s = 0 
			RETURN @f
		ELSE
			RETURN dbo.fnMin( @f ,@s )
	RETURN @s
END
go

