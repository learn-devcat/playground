
CREATE PROCEDURE [dbo].[sim_Wave_get]
@CoreID 	int,
@LoginUserID	varchar(250),
@PatientVisitID varchar(50),
@OrderType		int
AS
	SET NOCOUNT ON
	
	EXEC dbo.WaveListAvailableEX 99, @PatientVisitID, @OrderType
	
	RETURN
go

