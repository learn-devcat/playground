


CREATE PROCEDURE dbo.ie_AccountDisable
@ImpExpFlag		varchar(1)
AS
UPDATE 	tblBadgesOHD SET Inactive = 1
FROM		tblBadgesOHD AS B
		JOIN
		tblAccountOHD AS A
ON		B.AccountNo = A.AccountNo
WHERE 	A.ImpExpFlag=@ImpExpFlag
		 AND A.AccountClassID < 100
go

