
CREATE  PROCEDURE [dbo].[SystemUpdate_SetOutetClassTTLsAsTransClassTTLs]
AS
    DECLARE @OCid INT,
        @TCid INT,
        @bal MONEY,
        @cnt INT,
        @acctNo VARCHAR(19),
        @dailyBal MONEY,
        @dailyQty INT,
        @qty INT

-- create AND populate a table var with the cartesian product of the 
-- outletclass AND transclass tables
    DECLARE @ttlTable TABLE
        (
          TransClassID int,
          OutletClassID INT,
          Processed bit
        )

    INSERT  INTO @ttlTable
            SELECT  tc.TransClassID,
                    oc.OutletClassID,
                    0
            FROM    dbo.tblTransClass tc,
                    dbo.tblOutletClass oc
            ORDER BY tc.TransClassID
        
--get a cursor of all accounts        
    DECLARE accCursor CURSOR
        FOR SELECT  AccountNo
            FROM    dbo.tblAccountOHD 

    OPEN accCursor

    FETCH NEXT FROM accCursor INTO @acctNo

    WHILE @@FETCH_status = 0
        BEGIN
            WHILE 1 = 1
                BEGIN
				--get the next unique accountclass\outletclass combo
                    SELECT TOP 1
                            @OCid = OutletClassID,
                            @TCid = TransClassID
                    FROM    @ttlTable
                    WHERE   Processed <> 0
		
                    IF ( @@ROWCOUNT = 0 ) 
                        BREAK
                
                --get this account's ttl properties for this transclass
                    SELECT  @bal = Balance,
                            @dailyBal = DailyBalance,
                            @dailyQty = DailyQty,
                            @qty = Qty
                    FROM    dbo.tblAccountTTL
                    WHERE   AccountNo = @acctNo
                            AND TransClassID = @TCid                   
				
				--UPDATE or create new row in outletclass ttl table with the data just gotten FROM this account's
				--ttl for the transclass we are processing
                    IF EXISTS ( SELECT  *
                                FROM    dbo.tblAccountOutletClassTTL
                                WHERE   OutletClassID = @OCid
                                        AND TransClassID = @TCid ) 
                        BEGIN
                            UPDATE  dbo.tblAccountOutletClassTTL
                            SET     Balance = @bal,
                                    DailyBalance = @dailyBal,
                                    DailyQty = @dailyQty,
                                    Qty = @qty
                            WHERE   AccountNo = @acctNo
                                    AND OutletClassID = @OCid
                                    AND TransClassID = @TCid
                        END
                    ELSE 
                        BEGIN
                            INSERT  dbo.tblAccountOutletClassTTL
                                    (
                                      AccountNo,
                                      OutletClassID,
                                      TransClassID,
                                      Balance,
                                      DailyBalance,
                                      Qty,
                                      DailyQty
						        
                                    )
                            VALUES  (
                                      @acctNo,
                                      @OCid,
                                      @acctNo,
                                      @bal,
                                      @dailyBal,
                                      @qty,
                                      @dailyQty
						        
                                    )
                        END
				
				--knock this one of the list
                    UPDATE  @ttlTable
                    SET     Processed = 1
                    WHERE   OutletClassID = @OCid
                            AND TransClassID = @TCid
                END	
        
        --reset the table ready for the next account
            UPDATE  @ttlTable
            SET     Processed = 0            
        
            FETCH NEXT FROM accCursor INTO @acctNo
        END
go

