


CREATE PROCEDURE [dbo].[ProcessTypeUpdate]
@LoginUserID		varchar(250),
@ProcessTypeID	int OUTPUT,
@Description	varchar(50),
@Source		varchar(50)

AS
	IF(@ProcessTypeID <= 0)
	BEGIN
		INSERT INTO dbo.cfgProcessTypes ([Description], Source)
			VALUES(@Description, @Source)

		SELECT @ProcessTypeID = SCOPE_IDENTITY()
	END
	ELSE	
		UPDATE dbo.cfgProcessTypes 
		SET [Description] = @Description,
			Source = @Source
		WHERE ProcessTypeID = @ProcessTypeID
	
	RETURN
go

