CREATE PROCEDURE [dbo].[DietMenuItemDelete]
@LoginUserId VARCHAR (250), @DietMenuItemID INT
AS
DELETE dbo.tblDietMenuItems
	WHERE DietMenuItemID = @DietMenuItemID
go

