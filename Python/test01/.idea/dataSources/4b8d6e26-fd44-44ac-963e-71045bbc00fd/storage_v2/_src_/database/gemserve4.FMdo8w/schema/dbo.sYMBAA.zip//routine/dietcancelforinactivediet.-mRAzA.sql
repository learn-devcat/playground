CREATE PROCEDURE [dbo].[DietCancelForInactiveDiet]
	@LoginUserID varchar(250),
	@DietID int
AS
	DECLARE	@DietName		varchar(50),
			@Today			datetime,
			@Msg			varchar(500)

	SET @Today = getdate()

	--Make sure that Diet ID exists
	SELECT	@DietName = Description
	FROM	dbo.tblDietOHD
	WHERE	DietID = @DietID

	IF (@@ROWCOUNT = 0)
	BEGIN
		SET @Msg = 'Unable to cancel patient diets for Inactive Diet.  Diet ID [' + @DietID + '] not found.' 
		GOTO Finished
	END 

	DECLARE @TempPatientDiet AS TABLE
	(
		ID						int IDENTITY(1,1),
		PatientVisitID			varchar(50),
		TransactionIdentifier	varchar(50)	
	)

	DECLARE @TempOrders AS TABLE
	(
		ID						int IDENTITY(1,1),
		OrderID					int,
		RoomID					int,		
		PatientID				int,
		PatientVisitID			varchar(50)
	)
	
	--Cancel the diet for any patients where this diet is active
	UPDATE	dbo.tblPatientDiet
	SET		CancelDate = @Today,
			UpdateDate = getdate(),
			UpdateID = @LoginUserID
	OUTPUT	INSERTED.PatientVisitID, INSERTED.TransactionIdentifier INTO @TempPatientDiet
	WHERE	(DietID = @DietID)
		AND (Cancelled = 0) 	

	-- If no rows are returned then no patients are actively on that diet
	IF (@@ROWCOUNT = 0)
	BEGIN
		SET @Msg = 'No active patient diets found for Inactive Diet [' + @DietName + '].'
		GOTO Finished
	END

	--Cancel active meal orders placed for diet
	UPDATE	dbo.tblOrderOHD
	SET		Cancelled = 1,
			CancelDate = @Today,
			LastUpdateBy = @LoginUserID
	OUTPUT	INSERTED.OrderID, INSERTED.RoomID, INSERTED.PatientID, INSERTED.PatientVisitID INTO @TempOrders
	WHERE	(DietID = @DietID)
		AND	(ISNULL(Cancelled,0) <> 1)
		AND (COALESCE(Sent,0) <> 1)
		AND (OrderType = 1)
	
	--If orders were cancelled, cancel related items
	IF (@@ROWCOUNT > 0)
	BEGIN
		--Insert a log entry into the OrderLog for all orders that we are cancelling
		INSERT INTO dbo.tblOrderLog (OrderID, ActionID, LoginUserID)
		SELECT	OrderID, 800, @LoginUserID
		FROM	@TempOrders	

		--Delete all nutrient counts for the orders that are being cancelled
		DELETE PNC 
		FROM dbo.tblPatientNutrientCount AS PNC
		JOIN @TempOrders AS O ON PNC.OrderID = O.OrderID

		--Insert a log entry into the tblPatient Log for all orders that we are cancelling
		SET @Msg = 'Order cancelled due to Diet Inactivation [' + @DietName + ']. Order ID: '
		INSERT INTO dbo.tblPatientLog (EventClassID, LoginUserID, PatientID, PatientVisitID, RoomID, [Description], [Date])
		SELECT	7000, @LoginUserID, PatientID, PatientVisitID, RoomID, @Msg + CAST(OrderID AS varchar(30)), @Today
		FROM	@TempOrders

	END

	--Cancel the Patient Notes for the cancelled diets
	UPDATE	PN
	SET		PN.CancelDate = @Today,
			PN.UpdateDate = getdate(),
			PN.UpdateID = @LoginUserID
	FROM	dbo.tblPatientNotes AS PN
	JOIN	@TempPatientDiet AS PD ON PN.TransactionIdentifier = PD.TransactionIdentifier 
		AND	PN.PatientVisitID = PD.PatientVisitID
		AND PN.Source <> 'Manual'

	--Add a patient log entry about the Diet being cancelled
	SET @Msg = 'Diet [' + COALESCE(@DietName,'N/A') + '] cancelled due to Diet Inactivation - effective at [' + CAST(@Today AS varchar(30)) + ']. Transaction identifier ['
	INSERT INTO dbo.tblPatientLog (EventClassID, LoginUserID, PatientID, PatientVisitID, RoomID, [Description], [Date] ) 
	SELECT	7000, @LoginUserID, PV.PatientID, PD.PatientVisitID, PV.RoomID, @Msg + COALESCE(PD.TransactionIdentifier, 'N/A') + '].', @Today
	FROM	@TempPatientDiet AS PD
	LEFT JOIN	dbo.tblPatientVisit AS PV ON PD.PatientVisitID = PV.PatientVisitID

	SET @Msg = 'Diet [' + @DietName + '] cancelled for patients due to Diet Inactivation.'

Finished:

	EXEC dbo.Logit 1, @Msg, @LoginUserID

	RETURN
go

