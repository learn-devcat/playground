

CREATE PROCEDURE dbo.LocationWaveForImport
@LoginUserID		varchar(250)
AS
	SET NOCOUNT ON

	-- Clear previous entries
	DELETE dbo.tblLocationWave

	-- Insert all location/wave combinations
	INSERT INTO dbo.tblLocationWave(LocationClassID, WaveID, Active)
	SELECT 	L.LocationClassID, W.WaveID, 1
	FROM	dbo.tblLocationClass AS L, dbo.tblWave AS W

	RETURN
go

