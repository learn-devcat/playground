
CREATE       PROCEDURE dbo.WorkorderClass_Get
@User               char(10),
@WorkorderClassID   int
AS
	SELECT  WorkorderClassID,
               	Description,
		PostChargeWhenComplete,
		PostChargeAsCompleted,
		PostChargeWhenWOClosed,
		PostAltCharge,
		CloseWorkOrderWhenComplete,
		RequiresInspection,
		PostItemChargesWhenWOClosed
	FROM    tblWorkorderClass
	WHERE	WorkorderClassID = @WorkorderClassID
go

