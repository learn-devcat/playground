CREATE PROCEDURE [dbo].[Micros_IsOnline]
AS
        SET NOCOUNT ON
        DECLARE @Temp int

        SELECT @Temp = COUNT([name]) FROM MicrosFamilyGroupDef

        SELECT @@ERROR AS Online
go

