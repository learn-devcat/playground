CREATE PROCEDURE dbo.pub_AccountGetDetailByCycle
@AccountNo	char(19),
@DesiredCycleNo	int=0
AS
	SET NOCOUNT ON
	DECLARE @User			char(10)
	DECLARE @CycleNo		int
	DECLARE @CoreID		int			
	DECLARE @CycleXrefID 		char(10)
	DECLARE @CycleStartDate 	datetime
	SET @User = 'Public'						-- For our public interface.
	SET @CycleXrefID = dbo.GetXrefID( @AccountNo )					-- Retrieve the Xref ID based on Account #.
	SET @CycleStartDate = dbo.GetCycleStartDateByXRefID( @CycleXrefID , getdate() )	-- Now, get the cycle Start Date.
	SET  @CoreID=dbo.GetCoreIDFromUser(@User	)				-- Ensure we get the cuorrect CORE ID.
	IF (@DesiredCycleNo<=0)								-- IF cycle = 0, calculate the current one based on the Xref ID.
	    SET @CycleNo=(dbo.GetCycleByXref( 1, getdate() , @CycleXrefID )+ @DesiredCycleNo )
	ELSE
	     SET @CycleNo=@DesiredCycleNo
	
	SELECT	DetailID,
			TransDate,
			RefNum, 
			ChkNum, 
			CASE T.Payment
				WHEN 1 THEN -TransTotal
				ELSE TransTotal
			END AS TransTotal,
			OutletName, 
			
			dbo.GetCycleByXREF(D.CycleNo,D.PostDate,@CycleXrefID ) AS CycleNo,
			D.OutletNo,
			O.OutletNo,
			T.Description,
			T.Payment,
			dbo.GetCycleStartDate(@CycleNo) AS CycleDate,
			AccountNo as Account,
			BadgeNo as Badge,
			@CycleXrefID as CycleXrefID,
			@DesiredCycleNo as RequestedCycle
	FROM		tblDetail AS D
			LEFT JOIN tblOutletOHD AS O ON D.OutletNo=O.OutletNo 
			LEFT JOIN  tblTransDef AS T ON D.TransID = T.TransID
			
	WHERE	D.AccountNo=@AccountNo 
			AND dbo.GetCycleByXREF(@CycleNo,dbo.DateOnly(D.PostDate),@CycleXrefID)=@CycleNo
	ORDER BY 	D.TransDate DESC

	DECLARE 	@cMsg  char(255)
	SET @cMsg = 'Retrieved transaction list for Account No <' + RTRIM(@AccountNo) + '>'
	EXEC dbo.sp_Logit 5 , @CoreID , @User , @cMsg, 2010
go

