
CREATE       PROCEDURE dbo.WorkorderOHD_ListByAccount
@User			char(10),
@AccountNo		varchar(19)
AS
		SELECT  WorkOrderID,
		        WorkOrderNumber,
		        LocationID,
		        WorkorderClassID,
		        ShortDescription, 
		        PO,
		        Description,
		        OpenDate,
		        OpeningEmployeeID,
		        ClosingDate,
		        ClosingEmployeeID,
		        Closed,
		        CompletionDate,
		        CompletingEmployeeID,
		        Completed,
		        Inspected,
		        InspectingEmployeeID,
		        EstimatedHours,
		        ActualHours,
		        AccountNo,
		        TransID,
		        Notes,
		        TotalCharge
	    FROM   	 tblWorkOrderOHD
	    WHERE   	AccountNo = @AccountNo
go

