

CREATE PROCEDURE dbo.ad_TransClass_Delete
@User				char(10),
@TransClassID		int
AS 
	DELETE	tblTransClass
	WHERE	TransClassID = @TransClassID
go

