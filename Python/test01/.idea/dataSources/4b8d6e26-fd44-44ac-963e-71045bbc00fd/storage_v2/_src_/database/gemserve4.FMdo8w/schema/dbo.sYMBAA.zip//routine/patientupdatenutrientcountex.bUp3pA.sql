CREATE PROCEDURE [dbo].[PatientUpdateNutrientCountEX]
@PatientID	int,
@OrderID	int

AS
	SET NOCOUNT ON

	BEGIN TRANSACTION
		/*
			1. Delete all existing nutrients in tblPatientNutrientCount for this OrderId
			2. Get all menu items for the specified order
			3. Accumulate the total nutrient values for each nutrient by multiplying the menu item values with the consumption values.
			4. Update the tblPatientNutrientCount table with values for the order
		*/

		DECLARE @NutrientID int,
				@Date datetime

		DECLARE @Nutrients TABLE (
			NutrientID	int,
			Qty			decimal(10,3))

		INSERT INTO @Nutrients (NutrientID)
			SELECT NutrientID
			FROM dbo.cfgNutrients
			ORDER BY NutrientID

		-- Get date for the order
		SELECT @Date = OrderDate
		FROM dbo.tblOrderOHD
		WHERE OrderID = @OrderID

		-- Delete all existing nutrient numbers for this order, since we are going to recalculate them
		DELETE dbo.tblPatientNutrientCount WHERE OrderID = @OrderID

		SET @NutrientID = 0

		WHILE (1=1)
		BEGIN
			-- Process all nutrients
			SELECT @NutrientID = MIN(NutrientID) 
			FROM @Nutrients
			WHERE NutrientID > @NutrientID

			IF (@NutrientID IS NULL)
				BREAK

			-- Insert number for the current nutrient
			INSERT INTO dbo.tblPatientNutrientCount (PatientID, NutrientID, [Date], OrderID, Qty)
			SELECT @PatientID, @NutrientID, @Date, @OrderID, 
				COALESCE(SUM(MN.Qty*OI.Consumption)/100,0)
			FROM dbo.tblOrderItems AS OI (NOLOCK)
				JOIN dbo.tblMenuItemOHD AS M (NOLOCK) ON OI.POSMenuItemID = M.POSMenuItemID
					AND OI.OrderID = @OrderID
				JOIN dbo.tblMenuItemNutrients AS MN (NOLOCK) ON M.MenuItemID = MN.MenuItemID
					AND MN.NutrientID = @NutrientID
		END

	COMMIT TRANSACTION
	
	RETURN
go

