



CREATE PROCEDURE dbo.WaveDelete
@LoginUserID		varchar(250),
@WaveID		int

AS
	SET NOCOUNT ON

	DELETE 	dbo.tblWave 
	WHERE 	WaveID = @WaveID

	RETURN
go

