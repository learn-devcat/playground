


CREATE PROCEDURE dbo.OrderResend
@LoginUserID		varchar(250),
@OrderID	int
AS

	SET NOCOUNT ON

	DECLARE @Msg	varchar(100),
		@PatientID	int,
		@RoomID		int,
		@PatientVisitID varchar(50)

	SELECT @PatientID = PatientID
	FROM dbo.tblOrderOHD (NOLOCK)
	WHERE OrderID = @OrderID

	SELECT @RoomID = PV.RoomID
	FROM dbo.tblOrderOHD AS O (NOLOCK)
	    JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON O.PatientVisitID = PV.PatientVisitID
	WHERE O.OrderID = @OrderID

	UPDATE dbo.tblOrderOHD 
	SET Sent = 0,
		Received = 0,
		Retries = 0,
		SentDate = null
	WHERE OrderID = @OrderID

	SET @Msg = 'RESEND processed for Order #' + CAST(@OrderID as varchar(10))

	EXEC dbo.PatientLogAdd 1000, @LoginUserID, @PatientID, @PatientVisitID, @RoomID, @Msg
	EXEC dbo.Logit 0 ,@Msg, @LoginUserID

	RETURN
go

