CREATE PROCEDURE [dbo].[sp_Chart_DailySnapshot]
	@DayDate DateTime 
AS
	--DECLARE
	--@ChargesSum varchar(30),
	--@ChargesCount int,
	--@DepartmentSum varchar(30),
	--@DepartmentCount int,
	--@DisplayDepartment bit

	----get the normal balances.
	--SELECT      @ChargesSum = SUM(dtl.TransTotal), @ChargesCount = Count(dtl.TransTotal)
	--FROM            tblDetail AS dtl INNER JOIN
	--						 tblTransDef ON dtl.TransID = tblTransDef.TransID AND dtl.TransID = tblTransDef.TransID AND tblTransDef.Payment = 0 INNER JOIN
	--						 tblAccountOHD ON dtl.AccountNo = tblAccountOHD.AccountNo AND dtl.AccountNo = tblAccountOHD.AccountNo INNER JOIN
	--						 tblAccountClass ON tblAccountOHD.AccountClassID = tblAccountClass.AccountClassID AND tblAccountOHD.AccountClassID = tblAccountClass.AccountClassID
	--WHERE        (CAST(dtl.TransDate AS date) = CAST(@DayDate AS date)) AND (COALESCE(tblAccountClass.Department,0) <> 1)

	----find out if there are any departments. 
	--Select @DisplayDepartment = 1 
	--From tblAccountClass
	--WHERE Department = 1

	----get the balance for departments. 
	--SELECT   @DepartmentSum = SUM(dtl.TransTotal), @DepartmentCount = COUNT(dtl.TransTotal)
	--FROM            tblDetail AS dtl INNER JOIN
	--						 tblTransDef ON dtl.TransID = tblTransDef.TransID AND dtl.TransID = tblTransDef.TransID AND tblTransDef.Payment = 0 INNER JOIN
	--						 tblAccountOHD ON dtl.AccountNo = tblAccountOHD.AccountNo AND dtl.AccountNo = tblAccountOHD.AccountNo INNER JOIN
	--						 tblAccountClass ON tblAccountOHD.AccountClassID = tblAccountClass.AccountClassID AND tblAccountOHD.AccountClassID = tblAccountClass.AccountClassID
	--WHERE        (CAST(dtl.TransDate AS date) = CAST(@DayDate AS date)) AND (COALESCE(tblAccountClass.Department,0) = 1)

	

	--Select @ChargesCount as ChargesCount, @ChargesSum as ChargesSum, @DepartmentCount as DepartmentCount, @DepartmentSum as DepartmentSum, @DisplayDepartment as DisplayDepartment

	SELECT 321 AS ChargesCount, 1823.47 AS ChargesSum, 14 AS DepartmentCount, 982.03 AS DepartmentSum, 1 AS DisplayDepartment

RETURN 0
go

