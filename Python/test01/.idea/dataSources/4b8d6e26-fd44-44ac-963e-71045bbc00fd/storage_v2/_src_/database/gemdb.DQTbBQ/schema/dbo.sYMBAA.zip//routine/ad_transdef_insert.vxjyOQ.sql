

CREATE PROCEDURE dbo.ad_TransDef_Insert
@User				char(10),
@TransID			int,
@TransClassID		int,
@SubType			int,
@SourceXfer			int,
@Description		varchar(24),
@glAccount			varchar(16),
@Category			char(10),
@Status				int,
@Payment			bit,
@EnforceSchedule	smallint,
@Preset				money,
@TransLimit			money,
@SlotNo			smallint=0,
@IsMealPlan			bit=0,
@AllSame			bit=0,
@item1				smallint=0,
@item2				smallint=0,
@item3				smallint=0,
@item4				smallint=0,
@item5				smallint=0,
@item6				smallint=0,
@item7				smallint=0,
@item8				smallint=0,
@item9				smallint=0,
@item10				smallint=0,
@item11				smallint=0,
@item12				smallint=0,
@item13				smallint=0,
@item14				smallint=0,
@item15				smallint=0,
@item16				smallint=0,
@item17				smallint=0,
@item18				smallint=0,
@item19				smallint=0,
@item20				smallint=0,
@item21				smallint=0,
@item22				smallint=0,
@item23				smallint=0,
@ResetTtlQty		bit=0
AS 
	IF (@AllSame = 1)
		BEGIN
			SET @item1 = @TransID
			SET @item2 = @TransID
			SET @item3 = @TransID
			SET @item4 = @TransID
			SET @item5 = @TransID
			SET @item6 = @TransID
			SET @item7 = @TransID
			SET @item8 = @TransID
			SET @item9 = @TransID
			SET @item10 = @TransID
			SET @item11 = @TransID
			SET @item12 = @TransID
			SET @item13 = @TransID
			SET @item14 = @TransID
			SET @item15 = @TransID
			SET @item16 = @TransID
			SET @item17 = @TransID
			SET @item18 = @TransID
			SET @item19 = @TransID
			SET @item20 = @TransID
			SET @item21 = @TransID
			SET @item22 = @TransID
			SET @item23 = @TransID
		END
		
	INSERT INTO	tblTransDef (TransID, TransClassID, SubType, SourceXfer, Description, glAccount, 
							Category, Status, Payment, EnforceSchedule, Preset, TransLimit, SlotNo, IsMealPlan, AllSame,
							item1, item2, item3, item4, item5, item6, item7, item8, item9, item10,
							item11, item12, item13, item14, item15, item16, item17, item18, item19,
							item20, item21, item22, item23, ResetTtlQty)
				VALUES		(@TransID, @TransClassID, @SubType, @SourceXfer, @Description, @glAccount, 
							@Category, @Status, @Payment, @EnforceSchedule, @Preset, @TransLimit, @SlotNo, @IsMealPlan, @AllSame,
							@item1, @item2, @item3, @item4, @item5, @item6, @item7, @item8, @item9, @item10,
							@item11, @item12, @item13, @item14, @item15, @item16, @item17, @item18, @item19,
							@item20, @item21, @item22, @item23, @ResetTtlQty)
go

