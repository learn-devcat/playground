
CREATE   PROCEDURE dbo.WorkorderOHD_ListAll
@User			char(10),
@LocationID     int
AS
	
	SELECT  WorkOrderID,
	        WorkOrderNumber,
	        LocationID,
	        WorkorderClassID,
	        ShortDescription, 
	        PO,
	        Description,
	        OpenDate,
	        OpeningEmployeeID,
	        ClosingDate,
	        ClosingEmployeeID,
	        Closed,
	        CompletionDate,
	        CompletingEmployeeID,
	        Completed,
	        Inspected,
	        InspectingEmployeeID,
	        EstimatedHours,
	        ActualHours,
	        AccountNo,
	        TransID,
	        Notes,
	        TotalCharge
    FROM    tblWorkOrderOHD
    WHERE   LocationID IN (SELECT LocationID FROM cfgUserLocations WHERE UserID = @User) 
    RETURN
go

