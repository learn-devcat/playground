


CREATE PROCEDURE dbo.UserSettingsUpdate
	(
	    @LoginUserID	    varchar(250),
	    @SettingName    varchar(100),
	    @SettingValue   varchar(100),
	    @Page           varchar(100)=''
	)
AS
	SET NOCOUNT ON	

	UPDATE  dbo.cfgUserSettings
	SET     SettingValue = @SettingValue
	WHERE   LoginUserID = @LoginUserID
	        AND SettingName = @SettingName
	        AND Page = @Page
	        
	IF ( @@ROWCOUNT = 0 )
	    INSERT INTO dbo.cfgUSerSettings (LoginUserID, SettingName, SettingValue, Page)
	        VALUES (@LoginUserID, @SettingName, @SettingValue, @Page)
	
	RETURN
go

