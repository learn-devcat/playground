

CREATE PROCEDURE dbo.HL7_PatientCancelTransfer
@MedicalRecordID	varchar(30),
@PatientVisitID     varchar(50),
@Source             varchar(50)
AS
	SET NOCOUNT ON
	DECLARE @Msg varchar(200)

	IF EXISTS(SELECT PatientVisitID FROM dbo.tblPatientVisit (NOLOCK) WHERE PatientVisitID = @PatientVisitID)
	BEGIN
		UPDATE dbo.tblPatientVisit
		SET RoomID = PreviousRoomID,
			Bed = PreviousBed
		WHERE PatientVisitID = @PatientVisitID

		SET @Msg = 'Transfer canceled for PatientVisitID: ' + @PatientVisitID
	END
	ELSE
	        SET @Msg = 'Unable to process Cancel Transfer for PatientVisitID: ' + @PatientVisitID + '. Patient does not exist.'
	
	EXEC dbo.Logit 1, @Msg, 'system'

	RETURN
go

