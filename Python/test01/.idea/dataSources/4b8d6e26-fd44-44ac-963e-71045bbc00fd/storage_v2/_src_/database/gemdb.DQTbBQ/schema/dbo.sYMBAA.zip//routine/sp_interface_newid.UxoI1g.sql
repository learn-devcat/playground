


CREATE PROCEDURE dbo.sp_Interface_NewID
AS
	SELECT	ISNULL(MAX(InterfaceID+1),1)
	FROM		cfgInterface
go

