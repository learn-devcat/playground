CREATE FUNCTION [dbo].[GetRecurAmount_EX]
      (
        @AccountNo CHAR(19) ,
        @AccountClassID INT ,
        @Amount MONEY ,
        @TransID INT ,
        @OutletNo INT ,
        @UseOutletClassBal INT ,
        @PastDue BIT ,
        @Minimum BIT ,
        @Balance BIT ,
        @TrackSlotNum INT ,
        @TrackIDNum INT ,
        @CycleNo INT ,
        @Today DATETIME ,
        @AllowNegAmt BIT,
		@BalanceMax MONEY
      )
RETURNS MONEY
AS 
    BEGIN 
    
        /*
            05-Oct-12   wjscott
            Updated quite a bit of this processing -- recommend a change log to see the changes.
        */


        DECLARE @ReturnAmount MONEY ,
                @TransIDAmount MONEY ,
                @PastDueAmount MONEY ,
                @BalanceAmount MONEY ,
                @TrackAmount MONEY ,
                @TransClassID INT ,
                @IsPayment INT ,
                @AllowNegativeRecurring INT ,
                @OutletClassID INT
    
        DECLARE @item1 INT ,
                @item2 INT ,
                @item3 INT ,
                @item4 INT ,
                @item5 INT ,
                @item6 INT ,
                @item7 INT ,
                @item8 INT ,
                @item9 INT ,
                @item10 INT ,
                @item11 INT ,
                @item12 INT ,
                @item13 INT ,
                @item14 INT ,
                @item15 INT ,
                @item16 INT ,
                @Chg1 MONEY ,
                @Chg2 MONEY ,
                @Chg3 MONEY ,
                @Chg4 MONEY ,
                @Chg5 MONEY ,
                @Chg6 MONEY ,
                @Chg7 MONEY ,
                @Chg8 MONEY ,
                @Chg9 MONEY ,
                @Chg10 MONEY ,
                @Chg11 MONEY ,
                @Chg12 MONEY ,
                @Chg13 MONEY ,
                @Chg14 MONEY ,
                @Chg15 MONEY ,
                @Chg16 MONEY
            
        set @ReturnAmount = 0.00				-- ensure this is initialized.

    -- If we are using the new BalanceMax, then we will still need to get the Balance to compare
    IF (@BalanceMax > 0)
		SET @Balance = 1
            
    --Get TransIDAmount total   
        SELECT  @ReturnAmount = Preset ,		-- this will get replaced later if this isn't what we're selecting.
                @isPayment = Payment ,
                @TransClassID = TransClassID
        FROM    tblTransDef
        WHERE   TransID = @TransID
    
        IF ( @@ROWCOUNT = 0 )		-- Oops, this should NEVER happen.
           RETURN 0.00
   
    ----don't get bal info if we aren't processing balances
        IF ( @Balance > 0 ) 
           BEGIN
            --Get the BalanceAmount total (AccountTTL OR AccountOutletClassTTL)
                 IF @UseOutletClassBal > 0 
                    BEGIN
                          SELECT    @BalanceAmount = ao.Balance ,
                                    @OutletClassID = ao.OutletClassID
                          FROM      tblAccountOutletClassTTL ao
                                    RIGHT JOIN dbo.tblTransDef td ON ao.TransClassID = td.TransClassID
                                                                     AND td.TransID = @TransID
                                    RIGHT JOIN dbo.tblOutletOHD o ON ao.OutletClassID = o.OutletClassID
                                                                     AND o.OutletNo = @OutletNo
                          WHERE     AccountNo = @AccountNo   
                          IF ( @@ROWCOUNT = 0 )		-- doesn't have this TTL.
                             RETURN 0                        
                    END
                 ELSE 
                    BEGIN
                          SET @OutletClassID = NULL
                    
                          SELECT    @BalanceAmount = isnull(Balance ,0)
                          FROM      tblAccountTTL
                          WHERE     AccountNo = @AccountNo
                                    AND TransClassID = @TransClassID	
                                        
                          IF ( @@ROWCOUNT = 0 )			-- doesn't have this ttl.
                             RETURN 0
                    END 	
                
                 SET @ReturnAmount = ISNULL(@BalanceAmount, .03)
           END
    
        -- don't set tracking info if we aren't processing tracking info    
        IF ( @TrackIDNum > 0 OR @TrackSlotNum > 0 ) 
           BEGIN
            --Lookup the Class ID if we didn't get one ...
                 IF ISNULL(@AccountClassID, 0) = 0 
                    SELECT  @AccountClassID = AccountClassID
                    FROM    tblAccountOHD
                    WHERE   AccountNo = @AccountNo
                
                 SELECT @item1 = item1 ,
                        @item2 = item2 ,
                        @item3 = item3 ,
                        @item4 = item4 ,
                        @item5 = item5 ,
                        @item6 = item6 ,
                        @item7 = item7 ,
                        @item8 = item8 ,
                        @item9 = item9 ,
                        @item10 = item10 ,
                        @item11 = item11 ,
                        @item12 = item12 ,
                        @item13 = item13 ,
                        @item14 = item14 ,
                        @item15 = item15 ,
                        @item16 = item16
                 FROM   tblTrackingOHD
                        INNER JOIN tblAccountClass ON tblTrackingOHD.TrackingGrp = tblAccountClass.TrackingGrp
                 WHERE  tblAccountClass.AccountClassID = @AccountClassID
                 
                 SELECT @Chg1 = ISNULL(Chg1, 0) ,
                        @Chg2 = ISNULL(Chg2, 0) ,
                        @Chg3 = ISNULL(Chg3, 0) ,
                        @Chg4 = ISNULL(Chg4, 0) ,
                        @Chg5 = ISNULL(Chg5, 0) ,
                        @Chg6 = ISNULL(Chg6, 0) ,
                        @Chg7 = ISNULL(Chg7, 0) ,
                        @Chg8 = ISNULL(Chg8, 0) ,
                        @Chg9 = ISNULL(Chg9, 0) ,
                        @Chg10 = ISNULL(Chg10, 0) ,
                        @Chg11 = ISNULL(Chg11, 0) ,
                        @Chg12 = ISNULL(Chg12, 0) ,
                        @Chg13 = ISNULL(Chg13, 0) ,
                        @Chg14 = ISNULL(Chg14, 0) ,
                        @Chg15 = ISNULL(Chg15, 0) ,
                        @Chg16 = ISNULL(Chg16, 0)
                 FROM   tblTrackingTTL
                 WHERE  tblTrackingTTL.AccountNo = @AccountNo
                        AND tblTrackingTTL.CycleNo = @CycleNo
                        
                -- Only one of these next items will actuall set @BalanceAmount 
                 IF @TrackIDNum = @item1 SET @BalanceAmount = ISNULL(@Chg1, 0)
                 IF @TrackIDNum = @item2 SET @BalanceAmount = ISNULL(@Chg2, 0)
                 IF @TrackIDNum = @item3 SET @BalanceAmount = ISNULL(@Chg3, 0)
                 IF @TrackIDNum = @item4 SET @BalanceAmount = ISNULL(@Chg4, 0)
                 IF @TrackIDNum = @item5 SET @BalanceAmount = ISNULL(@Chg5, 0)
                 IF @TrackIDNum = @item6 SET @BalanceAmount = ISNULL(@Chg6, 0)
                 IF @TrackIDNum = @item7 SET @BalanceAmount = ISNULL(@Chg7, 0)
                 IF @TrackIDNum = @item8 SET @BalanceAmount = ISNULL(@Chg8, 0)
                 IF @TrackIDNum = @item9 SET @BalanceAmount = ISNULL(@Chg9, 0)
                 IF @TrackIDNum = @item10 SET @BalanceAmount = ISNULL(@Chg10, 0)
                 IF @TrackIDNum = @item11 SET @BalanceAmount = ISNULL(@Chg11, 0)
                 IF @TrackIDNum = @item12 SET @BalanceAmount = ISNULL(@Chg12, 0)
                 IF @TrackIDNum = @item13 SET @BalanceAmount = ISNULL(@Chg13, 0)
                 IF @TrackIDNum = @item14 SET @BalanceAmount = ISNULL(@Chg14, 0)
                 IF @TrackIDNum = @item15 SET @BalanceAmount = ISNULL(@Chg15, 0)
                 IF @TrackIDNum = @item16 SET @BalanceAmount = ISNULL(@Chg16, 0) 
                 
                 -- See note above; Only one will set @BalanceAmount
                 IF @TrackSlotNum = 1 SET @BalanceAmount = ISNULL(@Chg1, 0)
                 IF @TrackSlotNum = 2 SET @BalanceAmount = ISNULL(@Chg2, 0)
                 IF @TrackSlotNum = 3 SET @BalanceAmount = ISNULL(@Chg3, 0)
                 IF @TrackSlotNum = 4 SET @BalanceAmount = ISNULL(@Chg4, 0)
                 IF @TrackSlotNum = 5 SET @BalanceAmount = ISNULL(@Chg5, 0)
                 IF @TrackSlotNum = 6 SET @BalanceAmount = ISNULL(@Chg6, 0)
                 IF @TrackSlotNum = 7 SET @BalanceAmount = ISNULL(@Chg7, 0)
                 IF @TrackSlotNum = 8 SET @BalanceAmount = ISNULL(@Chg8, 0)
                 IF @TrackSlotNum = 9 SET @BalanceAmount = ISNULL(@Chg9, 0)
                 IF @TrackSlotNum = 10 SET @BalanceAmount = ISNULL(@Chg10, 0)
                 IF @TrackSlotNum = 11 SET @BalanceAmount = ISNULL(@Chg11, 0)
                 IF @TrackSlotNum = 12 SET @BalanceAmount = ISNULL(@Chg12, 0)
                 IF @TrackSlotNum = 13 SET @BalanceAmount = ISNULL(@Chg13, 0)
                 IF @TrackSlotNum = 14 SET @BalanceAmount = ISNULL(@Chg14, 0)
                 IF @TrackSlotNum = 15 SET @BalanceAmount = ISNULL(@Chg15, 0)
                 IF @TrackSlotNum = 16 SET @BalanceAmount = ISNULL(@Chg16, 0) 
                 
           END
        
       -- return @BalanceAmount
    /* PROCESS THE AMOUNT */		

        IF ( @PastDue = 1 )      -- if we are talking a past due value -- but still allow the other items to process against this balance.
          BEGIN 
           SET @BalanceAmount = dbo.GetPastDue_EX(@AccountNo, @TransID, @Today - 7, @OutletClassID)
           SET @ReturnAmount = @BalanceAmount
          END 

        -- an amount means a min or max value
        IF ( @Amount <> 0 ) 
           BEGIN
                 IF ( @Minimum = 1 ) 
                    BEGIN
                    -- If both of these are negative, calculate positively.
                          IF ( @Amount < 0 ) 
                             BEGIN
                                   SET @ReturnAmount = ABS(@Amount) - ABS(@BalanceAmount)		-- This is the delta between values
                        
                                   IF ( @BalanceAmount > 0 )										-- if balance negative, we're done -- but positive bal reuqires us to drive negative.
                                      SET @ReturnAmount = ( ABS(@ReturnAmount) + ABS(@Amount) )
                             END
                          ELSE
                        -- check for the balance/tracking ttl being less than the minimum, if not, return a 0 amount
                        -- meaning minimums processing isn't required
                             IF ( @BalanceAmount < 0 ) 
                                BEGIN
                                      SET @ReturnAmount = @BalanceAmount - @Amount 
                                END
                             ELSE 
                                BEGIN
                                      SET @ReturnAmount = @Amount - @BalanceAmount		-- Debit Account, reverse sign of payment credits
                                END
                        
                    END		
                 ELSE 
					BEGIN
                    -- if we are processing a balance, the static amount is considered a Maximum, so...
                    -- if the balance is less than the max, send back the balance
                    -- if the balance is over the max OR we aren't processing balances, send back the static amount
					IF (@BalanceMax > 0)
						BEGIN
							SET @BalanceAmount = ABS(@BalanceAmount);

							SELECT @ReturnAmount = 
								CASE 
									WHEN (@BalanceAmount + @Amount) > @BalanceMax THEN @Amount - (ABS(@BalanceMax - (@BalanceAmount + @Amount)))
									ELSE @Amount
								END;

						END
					ELSE
						BEGIN
							IF ( @Amount > @BalanceAmount ) 
								SET @ReturnAmount = @BalanceAmount
							ELSE 
								SET @ReturnAmount = @Amount
						END
                END
           END
     
        IF ( @ReturnAmount < 0 AND @AllowNegAmt = 0 ) 
           SET @ReturnAmount = 0
        
        RETURN @ReturnAmount		
    END
go

