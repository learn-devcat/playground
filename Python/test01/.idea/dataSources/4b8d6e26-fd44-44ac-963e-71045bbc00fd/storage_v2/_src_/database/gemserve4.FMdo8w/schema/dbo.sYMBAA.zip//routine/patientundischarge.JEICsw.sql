CREATE PROCEDURE [dbo].[PatientUnDischarge]
@LoginUserID        varchar(250),
@PatientVisitID     varchar(50)

AS
	DECLARE @Msg		varchar(250),
			@PatientID	int,
			@RoomID		int

	-- If this patient does not exist in our system, then log an error
	IF NOT EXISTS (SELECT PatientVisitID FROM dbo.tblPatientVisit WHERE PatientVisitID = @PatientVisitID) 
	BEGIN
		SET @Msg = 'Unable to process un-discharge for PatientVisitID' + @PatientVisitID + '. PatientVisitID does not exist.'
		GOTO TransError
	END

	-- Update Patient
	UPDATE dbo.tblPatientVisit
	SET DischargeDate = NULL,
		ArchiveDate = NULL,
		LastUpdateBy = @LoginUserID
	WHERE PatientVisitID = @PatientVisitID

	SET @Msg = 'Undischarge processed for PatientVisitID:' + @PatientVisitID
	EXEC dbo.Logit 1, @Msg, @LoginUserID

	-- Values for logging
	SELECT @PatientID = PatientID,
	@RoomID = RoomID
	FROM dbo.tblPatientVisit
	WHERE PatientVisitID = @PatientVisitID

	SET @Msg = 'Un-discharged patient'
	EXEC dbo.PatientLOGAdd 7000, @LoginUserID, @PatientID, @PatientVisitID, @RoomID, @Msg
	EXEC dbo.ProcessLogInsert 'system'

	RETURN
    
TransError:
	IF (@Msg IS NULL)    
        SET @Msg = 'Unable to process Un-discharge for PatientVisitID:' + @PatientVisitID
        
    EXEC dbo.Logit 1, @Msg, 'system'
go

