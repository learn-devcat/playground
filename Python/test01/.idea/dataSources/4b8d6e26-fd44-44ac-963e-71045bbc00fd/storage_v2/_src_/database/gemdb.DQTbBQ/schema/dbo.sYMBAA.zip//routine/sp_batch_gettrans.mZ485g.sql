CREATE PROCEDURE [dbo].[sp_Batch_GetTrans]
@User		char(10),
@DetailID	as uniqueidentifier
AS
	SELECT	DetailID,AccountNo,BadgeNo,TransDate,Category,OutletNo,
			TransID,RefNum,ChkNum,PaymentNo,ServeEmpl,PostEmpl,Covers,RevCntr,TransTotal,
			Sales1,Sales2,Sales3,Sales4,Sales5,Sales6,Sales7,Sales8,Sales9,Sales10,Sales11,
			Sales12,Sales13,Sales14,Sales15,Sales16,Tax1,Tax2,Tax3,Tax4,dsc,svc,Memo,Comment,ExceptionMessage
	FROM		tblBatch
	WHERE	DetailID=@DetailID
	
	DECLARE 	@cMsg  char(255),
				@CoreID	int
	SET @CoreID = dbo.GetCoreIDFromUser(@User)
	SET @cMsg = 'Retrieved transaction FROM Batch - Detail ID <' + CAST(@DetailID as varchar(32))
	EXEC dbo.sp_Logit 4 , @CoreID , @User , @cMsg
go

