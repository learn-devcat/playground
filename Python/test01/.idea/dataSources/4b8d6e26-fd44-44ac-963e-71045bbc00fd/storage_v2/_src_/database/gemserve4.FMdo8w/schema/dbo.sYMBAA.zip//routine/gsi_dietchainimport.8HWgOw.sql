
CREATE PROCEDURE [dbo].[GSI_DietChainImport]
@LoginUserID		varchar(250),
@DietName	varchar(50),
@WaveID		int,
@NextWaveID	int
AS
	SET NOCOUNT ON
	DECLARE @DietID	int

	SELECT @DietID = DietID
	FROM	dbo.tblDietOHD
	WHERE	[Description] = @DietName

	INSERT INTO dbo.tblDietChain(DietID, WaveID, NextWaveID)
		VALUES(@DietID, @WaveID, @NextWaveID)

	RETURN
go

