CREATE PROCEDURE [dbo].[ad_Vending_Delete] @User char(10), @ID int
AS 
    SET NOCOUNT ON
	
    DECLARE @err int ,
        @descr varchar(80)
	
    SELECT  @descr = 'Vending item: ' + [Description] + ' was deleted'
    FROM    dbo.tblVendingDTL
    WHERE   ID = @ID
	
    DELETE  dbo.tblVendingDTL
    WHERE   ID = @ID
    
    SET @err = @@ERROR
    
    IF ( @err = 0 ) 
        EXEC dbo.sp_Logit @LoggingLevel = 0, @CoreID = 0, @User = @User,
            @Cmsg = @descr, @EventID = 1010
		
    
    SELECT @err
go

