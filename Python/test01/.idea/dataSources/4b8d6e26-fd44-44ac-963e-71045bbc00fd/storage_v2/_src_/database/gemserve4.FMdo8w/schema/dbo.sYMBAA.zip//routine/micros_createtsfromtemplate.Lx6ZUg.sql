CREATE PROCEDURE [dbo].[Micros_CreateTSFromTemplate]
@TouchScreen integer,
@TemplateID integer = 1000

AS
	SET NOCOUNT ON

	DECLARE @TemplateSequence integer

	-- Create empty touchscreen
	EXEC dbo.Micros_CreateTSMain @TouchScreen

	-- get the template sequence number
	SELECT @TemplateSequence = ts_scrn_seq FROM MicrosTouchScreenDef WHERE obj_num = @TemplateID

	-- insert static items from the template into our new screen
	INSERT INTO MicrosTouchScreenKeyDef(ts_scrn_seq,ts_key_seq,cfg_sect_ver_seq,row_start,col_start,height,width,font,color_combo,icon_placement,icon_id,legend,key_type,key_num,next,last_updated_by)
	SELECT	@TouchScreen,
			ts_key_seq,
			cfg_sect_ver_seq,
			row_start,
			col_start,
			height,
			width,
			font,
			color_combo,
			icon_placement,
			icon_id,
			legend,
			key_type,
			key_num,
			next,
			last_updated_by 
	FROM	MicrosTouchScreenKeyDef 
	WHERE ts_scrn_seq = @TemplateSequence

	RETURN
go

