CREATE  PROCEDURE dbo.ol_GetAccountMealPlan
@CoreID		int,
@User		varchar(10),
@AccountNo	char(19),
@Slot		int,
@OutletNo	int
AS 
	DECLARE	@CurrentTime 	varchar(10),
			@CurrentDate	datetime,
			@IsActive		char(1),
			@MealPlanID		int,
			@CurrentCount	int,
			@CurrentBalance	money,
			@MealPlan		varchar(32),
			@MealPeriod		varchar(32),
			@TransLimit		money,
			@Equiv			money,
			@PassesAllowed	int,
			@CurrentPasses 	int,
		             @OutletSubType  int,    		-- To see WHERE we're allowed to use this.
			@TotalRows		int,
			@ExpireDate		datetime,
			@LastOutlet		int,
			@OutletName		varchar(60),
			@CurrentPeriodBal	money,
			@ReturnString	varchar(2000),
			@BegTime char(10),
			@EndTime char(10)
	
	SET @CurrentDate = dbo.dDateOnly(getdate())
	SET @CurrentTime = dbo.TimeOnly(getdate())
	SET @TotalRows = 0
	SET @ReturnString = ''
	-- Get the subtype to mask against the meal plans -- this allows us
	-- to restrict certain meal plans to certain outlets... we are going
	-- to AND() the two VALUES, a non-zero results
	                                  
	SELECT 	@OutletSubType = SubType 
	FROM	tblOutletOHD
	WHERE	OutletNo = @OutletNo                          
	DECLARE MealPlans cursor FOR
		SELECT		A.MealPlanID,
					CASE 
						WHEN (PD.Description IS NULL OR ATT.CurrentCount IS NULL) THEN '0'
						ELSE '1'	
					END AS IsActive,
					ISNULL(ATT.CurrentCount,0),
					ISNULL(ATT.CurrentBalance,0),
					ISNULL(P.Name,'') AS MealPlan,
					ISNULL(PD.Description,'') AS MealPeriod,
					ISNULL(PD.TransLimit,0),   
					PD.Equiv,
					CASE PD.CountAllPasses
						WHEN 1 THEN 	ISNULL(PD.PassesAllowed,0)
						ELSE 999
					END AS PassesAllowed,
					dbo.CurrentPasses(A.AccountNo,A.MealPlanID,dbo.dDatePlusNewTime(@CurrentDate,PD.BegTime),dbo.dDatePlusNewTime(@CurrentDate,PD.EndTime)),
					dbo.CurrentPeriodBalance(A.AccountNo,A.MealPlanID,dbo.dDatePlusNewTime(@CurrentDate,PD.BegTime),dbo.dDatePlusNewTime(@CurrentDate,PD.EndTime)),
--					dbo.IsDailyQtyEX (A.CurrentPassCount, A.LastUsed,getdate(),A.LastMealDtl,PD.DtlID),
					ISNULL(ATT.ExpireDate,getdate()),
					dbo.GetLastMPOutlet(A.AccountNo,A.MealPlanID,dbo.dDatePlusNewTime(@CurrentDate,PD.BegTime),dbo.dDatePlusNewTime(@CurrentDate,PD.EndTime)),
					PD.BegTime,
					PD.EndTime
		FROM		tblAccountMeal AS A
		LEFT JOIN 	tblAccountMealTTL AS ATT	ON	A.AccountNo = ATT.AccountNo
													AND A.MealPlanID = ATT.MealPlanID
													AND @CurrentDate BETWEEN dbo.dDateOnly(ATT.ActiveDate) AND dbo.dDateOnly(ATT.ExpireDate)
		LEFT JOIN  tblPlanOHD AS P  ON A.MealPlanID = P.MealPlanID
		LEFT JOIN tblPlanDTL  AS PD ON A.MealPlanID = PD.MealPlanID
										AND (@CurrentTime BETWEEN PD.BegTime AND PD.EndTime)
		WHERE	A.AccountNo = @AccountNo
				AND A.Slot = @Slot
				AND A.Active = 1
				AND (@CurrentTime BETWEEN PD.BegTime AND PD.EndTime)  
				AND ( P.SubType & @OutletSubType ) <> 0
		ORDER BY IsActive DESC
	
	OPEN MealPlans
	FETCH NEXT FROM MealPlans INTO
		@MealPlanID,@IsActive,@CurrentCount,@CurrentBalance,@MealPlan,@MealPeriod,@TransLimit,
		@Equiv,@PassesAllowed, @CurrentPasses, @CurrentPeriodBal, @ExpireDate, @LastOutlet, @BegTime, @EndTime
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @TotalRows = @TotalRows + 1
		-- Get outlet name
		IF ( @LastOutlet > 0 )
			SELECT @OutletName = dbo.GetOutletName(@LastOutlet)
		ELSE
			SET @OutletName = ' '
		-- sim RETURN string
		SET @ReturnString = @ReturnString + CHAR(28) + CAST(@MealPlanID AS varchar(8)) + ',' +
			@IsActive + ',' + 
			CAST(@CurrentCount AS varchar(8)) + ',' +
			CAST(@Equiv - dbo.CurrentPeriodBalance(@AccountNo,@MealPlanID, dbo.dDatePlusNewTime(@CurrentDate,@BegTime), dbo.dDatePlusNewTime(@CurrentDate,@EndTime)) AS varchar(20)) + ',' +
--			CAST(@CurrentBalance AS varchar(16)) + ',' +
			@MealPlan + ',' + @MealPeriod + ',' +
			CAST(@TransLimit AS varchar(16)) + ',' + 
			CAST(@Equiv AS varchar(16)) + ',' +
			CAST(@PassesAllowed AS varchar(8)) + ',' + 
			CAST(@CurrentPasses as varchar(8)) + ',' +
			CAST(@CurrentPeriodBal as varchar(10)) + ',' +
			CAST(dbo.DateFormat(@ExpireDate,'da-sm-yy') as varchar(25)) + ',' +
			CAST(@LastOutlet as varchar(10)) + ',' +
			@OutletName
		FETCH NEXT FROM MealPlans INTO
			@MealPlanID,@IsActive,@CurrentCount,@CurrentBalance,@MealPlan,@MealPeriod,@TransLimit,
			@Equiv,@PassesAllowed, @CurrentPasses, @CurrentPeriodBal, @ExpireDate, @LastOutlet, @BegTime, @EndTime
	END
	CLOSE MealPlans
	DEALLOCATE MealPlans
	IF (@TotalRows > 0)
		SET @ReturnString = 'Success' + CHAR(28) + CAST(@TotalRows AS varchar(8)) +  @ReturnString
	ELSE
		SET @ReturnString = '/No Valid Plans' + CHAR(28) + '0' + CHAR(28)
	
	SELECT @ReturnString
go

