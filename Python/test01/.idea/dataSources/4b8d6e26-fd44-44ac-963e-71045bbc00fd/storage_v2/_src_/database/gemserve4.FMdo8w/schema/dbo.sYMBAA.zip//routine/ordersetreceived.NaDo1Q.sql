

CREATE PROCEDURE dbo.OrderSETReceived
@CoreID int,
@LoginUserID varchar(250),
@OrderID int,
@WorkstationID int,
@SentReceived    int = 1,
@CheckNo	varchar(20) = ''
AS
	SET NOCOUNT ON 

	DECLARE @NonSelectOrder bit,
		@StandingOrder bit,
		@PatientID int,
		@PatientVisitID varchar(50),
		@OrderDate datetime,
		@DietID int,
		@RoomID int,
		@Msg varchar(200)
		
	SELECT 	@PatientID = O.PatientID,
		@PatientVisitID = O.PatientVisitID,
		@OrderDate = O.OrderDate,
		@RoomID = PV.RoomID
	FROM dbo.tblOrderOHD AS O (NOLOCK)
		JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON O.PatientVisitID = PV.PatientVisitID
	WHERE O.OrderID = @OrderID

	SELECT @DietID = dbo.GetActiveDiet(@PatientVisitID, @OrderDate)

	SET @Msg = 'Order sent to kitchen - CheckNo. ['	+ @CheckNo + ']'
        	EXEC dbo.PatientLOGAdd 1000, 'System', @PatientID, @PatientVisitID, @RoomID, @Msg

 	UPDATE dbo.tblOrderOHD
	SET Received = @SentReceived,
		CheckNo = @CheckNo
	WHERE OrderID = @OrderID
   
	IF @@Error = 0
	BEGIN
	    EXEC UpdateOrderLOG 'System' , @OrderID , 'RECEIVED', @DietID, @RoomID
	    
	    SELECT  @SentReceived = ActionID
	    FROM    dbo.tblActions
	    WHERE   ActionKey = 'RECEIVED'
	    
	    EXEC dbo.UpdatePatientOrderStatus @OrderID, @SentReceived    

	    -- If this is a non-select order, run the increment procedure,
	    -- which adds a new order for tomorrow.
  		SELECT @NonSelectOrder = NonSelectOrder,
			@StandingOrder = StandingOrder
		FROM dbo.tblOrderOHD
		WHERE OrderID = @OrderID

	    IF((@NonSelectOrder = 1) OR (@StandingOrder = 1))
		EXEC dbo.OrderIncrement @OrderID
	END
	    
	RETURN
go

