CREATE FUNCTION [dbo].[PatientMealsMissed](@PatientID int,@LastOrder datetime,@Now datetime)
RETURNS INT
AS
BEGIN
	DECLARE	@Total		int,
		@DietID		int,
		@CurrentWave	int,
		@CurrentMealPeriod	int,
		@EndTime	char(5),
		@TempWave	int,
		@TempDate	datetime,
		@Return		int,
		@TotalMealPeriods int,
		@BetweenDays	int,
		@MissedMeals	int,
		@CurrentDate	datetime,
		@EntryDate	datetime,
		@MealCount	int,
		@PatientVisitID	varchar(50),
		@NowDate datetime,
		@NowTime varchar(10)

	SET @NowDate = dbo.dDateOnly(@Now)
	SET @NowTime = dbo.TimeString(@Now)

	SET @CurrentDate = @LastOrder
	SET @LastOrder = dbo.dDateOnly(@LastOrder)

	SET @Total = 0
	
	SELECT TOP 1 @PatientVisitID = PV.PatientVisitID, @EntryDate = EntryDate
	FROM dbo.tblPatientVisit AS PV (NOLOCK)
		JOIN dbo.tblPatientDiet AS PD (NOLOCK) ON PV.PatientVisitID = PD.PatientVisitID
	WHERE PV.PatientID = @PatientID
		AND PV.DischargeDate IS NULL
		AND PD.DietID > -1
	ORDER BY EntryDate DESC

	IF (@PatientVisitID IS NULL)
	BEGIN
		SET @Total = 0
		GOTO Finished
	END

	DECLARE @Temp TABLE (MealPeriodID int, StartTime datetime)

	-- Get meals missed on previous days
	WHILE (dbo.dDateOnly(@CurrentDate) < @NowDate)
	BEGIN
		DELETE @Temp

		-- Get all Meal Periods
		INSERT INTO @Temp
		SELECT DISTINCT MealPeriodID, dbo.MealPeriodStartTime(@CurrentDate, MealPeriodID)
		FROM dbo.tblWave (NOLOCK)
		WHERE [Description] <> 'All Day'
			AND MealPeriodID NOT IN (SELECT CAST(KeyIn AS int) FROM dbo.tblXlat WHERE xlatId = 'NoReportMealPeriod')
			AND dbo.dDatePlusNewTime(@CurrentDate,BeginTime) > @EntryDate

		-- Delete Meal Periods where the patient was on a diet that is not valid in that Meal Period
		-- This includes 'Not Assigned' and 'NPO' diets
		DELETE @Temp
 		FROM @Temp AS T
 		JOIN dbo.tblWave AS W (NOLOCK) ON T.MealPeriodID = W.MealPeriodID
		LEFT JOIN dbo.tblDietWave AS DW (NOLOCK) ON DW.WaveID = W.WaveID 
			AND DW.DietID = dbo.GetActiveDiet(@PatientVisitID, dbo.MealPeriodEndTime(@CurrentDate, W.MealPeriodID))
		WHERE DW.WaveID IS NULL

		-- Calculate the number of meals missed
		SELECT @TotalMealPeriods = COUNT(MealPeriodID) FROM @Temp
				
		SELECT @MissedMeals = @TotalMealPeriods - COUNT(DISTINCT M.MealPeriodID)
		FROM	dbo.tblOrderOHD AS O
			JOIN dbo.tblWave AS W ON O.WaveID = W.WaveID
			JOIN @Temp AS M ON W.MealPeriodID = M.MealPeriodID
		WHERE	dbo.dDateOnly(O.OrderDate) = dbo.dDateOnly(@LastOrder)
			AND O.PatientID = @PatientID
			AND COALESCE(O.OrderType,1) = 1
			AND COALESCE(O.Cancelled,0) <> 1

		IF (@MissedMeals > 0)
			SET @Total = @Total + @MissedMeals

		SET @CurrentDate = DATEADD(d,1,@CurrentDate)
	END

	DELETE @Temp

	-- Processing for the current day
	INSERT INTO @Temp
	SELECT DISTINCT MealPeriodID, dbo.MealPeriodStartTime(@CurrentDate, MealPeriodID)
	FROM dbo.tblWave (NOLOCK)
	WHERE [Description] <> 'All Day'
		AND MealPeriodID NOT IN (SELECT CAST(KeyIn AS int) FROM dbo.tblXlat WHERE xlatId = 'NoReportMealPeriod')
		AND BeginTime <= @NowTime
		AND dbo.dDatePlusNewTime(@CurrentDate,BeginTime) > @EntryDate

	-- Delete Meal Periods where the patient was on a diet that is not valid in that Meal Period
	-- This includes 'Not Assigned' and 'NPO' diets
	DELETE @Temp
		FROM @Temp AS T
		JOIN dbo.tblWave AS W (NOLOCK) ON T.MealPeriodID = W.MealPeriodID
	LEFT JOIN dbo.tblDietWave AS DW (NOLOCK) ON DW.WaveID = W.WaveID 
		AND DW.DietID = dbo.GetActiveDiet(@PatientVisitID, dbo.MealPeriodEndTime(@CurrentDate, W.MealPeriodID))
	WHERE DW.WaveID IS NULL

	SELECT @TotalMealPeriods = COUNT(MealPeriodID) FROM @Temp
	SET @MealCount = 0

	-- Get meals missed on the current day
	SELECT @MealCount =  COUNT(O.OrderID)
	FROM	dbo.tblOrderOHD AS O
		JOIN dbo.tblWave AS W ON O.WaveID = W.WaveID
		JOIN @Temp AS M ON W.MealPeriodID = M.MealPeriodID
	WHERE	M.MealPeriodID IN (SELECT MealPeriodID FROM @Temp)
		AND dbo.dDateOnly(O.OrderDate) = @NowDate
		AND O.OrderDate <= @Now
		AND O.PatientID = @PatientID
		AND COALESCE(O.OrderType,1) = 1
		AND COALESCE(O.Cancelled,0) <> 1

	IF (@TotalMealPeriods > 0)
		SET @MissedMeals = @TotalMealPeriods - @MealCount
	ELSE
		SET @MissedMeals = 0

Finished:
	RETURN ISNULL(@Total + ISNULL(@MissedMeals,0),0)
END
go

