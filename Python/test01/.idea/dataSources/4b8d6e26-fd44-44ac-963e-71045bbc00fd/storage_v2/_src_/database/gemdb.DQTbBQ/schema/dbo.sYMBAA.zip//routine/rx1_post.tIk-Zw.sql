CREATE PROCEDURE [dbo].[rx1_Post]
@CoreID	    integer,
@User		char(10),
@AccountNo	char(19),
@BadgeNo	char(19),
@TransDate	datetime,
@OutletNo	int,
@RefNum	    char(10),
@CheckNum	char(10),
@TransTotal	money,
@Sales1	    money,
@Comment	varchar(40),
@CycleNo	int,
@TransID	int,
@Category 	char(10)=' ',
@PaymentNo	int=0,
@ServeEmpl	int=0,
@PostEmpl	int=0,
@Covers	    smallint=0,
@RevCntr	int=0,
@Sales2	money=0,
@Sales3	money=0,
@Sales4	money=0,
@Sales5	money=0,
@Sales6	money=0,
@Sales7	money=0,
@Sales8	money=0,
@Sales9	money=0,
@Sales10	money=0,
@Sales11	money=0,
@Sales12	money=0,
@Sales13	money=0,
@Sales14	money=0,
@Sales15	money=0,
@Sales16	money=0,
@Tax1		money=0,
@Tax2		money=0,
@Tax3		money=0,
@Tax4		money=0,
@Dsc		money=0,
@Svc		money=0,
@SvcA		money=0,
@Correction	bit=0,
@Auditable	bit=0,
@PostDate	datetime = '',
@MealPlanID	int = 0,
@LocationID int = 0
AS

	set nocount on	

    DECLARE @rVal			as varchar(128),
			@TempOutletNo   as int,
            @Error          as int,
            @TransIDName    as varchar(25),
            @TDate          as varchar(30),
			@ActiveDate as datetime,
			@ExpireDate as datetime,
			@Lost as bit,
			@Stolen as bit,
			@Flagged as bit,
			@Inactive as bit,
			@ReturnCode as int,
			@Message as varchar(255),
			@ID as int,
			@AccountClassID as int,
			@BadgeClassID as int
			   
		
	SELECT @TransIDName=description
    FROM tblTransDef
	WHERE TransID = @TransID

     IF (@@RowCount = 0 )
        BEGIN
            SELECT '/TransID ' + cast( @TransID as varchar(10)) + ' Not Defined' as ReturnMsg
            RETURN
        END
	
	
    SELECT @TempOutletNo = OutletNo
      FROM tblOutletOHD
     WHERE OutletNo = @OutletNo
	
    IF (@@RowCount = 0 )
        BEGIN
            SELECT '/Outlet ' + cast( @OutletNo as varchar(10)) + ' Not Defined' as ReturnMsg
            RETURN
        END

	/* 
		 ensure the badge exists
		do this test BEFORE the other tests so that we can give the lost or stolen flags independantly.
	*/
	select	@ActiveDate = ActiveDate,
			@ExpireDate = ExpireDate,
			@Lost = Lost,
			@Stolen = Stolen,
			@Flagged = Flagged,
			@Inactive = Inactive,
			@BadgeClassID = BadgeClassID
	from	tblBadgesOHD
	where	BadgeNo = @BadgeNo and AccountNO = @AccountNo

	if( @@RowCount = 0 )
	  begin
		select '/Not On File' as ReturnMsg
		return
      end

	if( @ActiveDate > @TransDate )
	  begin
		select '/Badge Not Active Yet' as ReturnMsg
		return
	  end

	if( @ExpireDate < @TransDate )
	  begin
		select '/Badge Has Expired' as ReturnMsg
		return
	  end

	if( @Inactive > 0  )
	  begin
		select '/Badge Is Not Active' as ReturnMsg
		return
	  end

	EXEC @rVal =  dbo.sp_PreChargeAuthorization @AccountNO, @BadgeNo, @TransTotal, @TransID, @OutletNo
	set @ReturnCode = cast( @rVal  as  int)
	IF (@ReturnCode<> 0)
	begin
		select 
			case @ReturnCode 
				when 0 then ''
			WHEN '1' THEN '/Over Account Limit'
			WHEN '2' THEN '/Over Daily Limit'
			WHEN '3' THEN '/Badge Not On File'
			WHEN '4' THEN '/Badge Not Valid'
			WHEN '5' THEN '/Over Daily Qty'
			WHEN '6' THEN '/Over Badge Trans Limit'
			WHEN '7' THEN '/Over Account Trans Limit'
			WHEN '8' THEN '/Inactive Account'
			WHEN '9' THEN '/Over Badge Limit'
			WHEN '10' THEN '/Not Authorized Here'
			WHEN '11' THEN '/Outlet Not Defined'
			ELSE '/Undefined Error #:' +  cast( @ReturnCode as varchar(10))
		end as ReturnMsg
		return
	end

	/*
		Do some TransID Xref testing 15-Feb-11 wjs
	*/

	select @AccountClassID = AccountClassID			-- Gotta have the account class id -- argh!
	from tblAccountOHD
	where @AccountNo = AccountNo

	
	--Select @LocationID as"locationid", @OutletNo as "outletno",@AccountClassID as "@AccountClassID",@BadgeClassID as "@BadgeClassID",@PaymentNo as "@PaymentNo"
	--RETURN

	select  top 1
			@ID = X.ID
	from tblTransXref X	
	where isNull( X.LocationID , @LocationID ) = @LocationID and
          IsNull(X.OutletNo, @OutletNo ) = @OutletNo  and
		  X.AccountClassID = @AccountClassID and				-- if no account class, comment this line
		  X.BadgeClassID = @BadgeClassID and					-- if no badge class, comment this line
		  X.POSTenderKey = @PaymentNo							-- if no trans id, comment this line (watch the commas)

	if( isnull(@ID,0) = 0 )
	  begin
		SELECT '/Not Authorized At This Location' as ReturnMsg
        RETURN
	  end

    /*
        This process will test to see if we've posted this transaction alredy -- If so, well, we're not going
        to post this again, so respond to it just as if we did post it, but of course, we're really not going
        to post it...
    */
    
	SELECT @TDate = dbo.DateOnly( @TransDate )
    
    SELECT @rVal = AccountNO
    FROM   tblDetail
    WHERE  AccountNo  = @AccountNO AND
           BadgeNo    = @BadgeNo AND
           OutletNo   = @OutletNo AND
           ChkNum     = @CheckNum AND
		   RefNum     = @RefNum AND
           TransID    = @TransID AND
           TransTotal = @TransTotal  AND
		   dbo.DateOnly( TransDate ) = @TDate

    if( @@ROWCOUNT > 0 )
        BEGIN
			set @Message = @AccountNo + ' ' + @BadgeNo + ' ' + cast( @TransTotal as varchar(12)) + ' ' + cast( @OutletNo as varchar(5)) + ' Duplicate post attempt'
		    EXEC dbo.sp_Logit 1 , @CoreID , @User , @Message , 926
            SELECT '*' + @TransIDName + ' Posted' as ReturnMSG
            return
        END
	    

	-----------------------------------
	-- We're cool -- let's try to post.
	-----------------------------------
    EXEC @Error =   sp_Trans_Post 
                    @CoreID,@User,@AccountNo,@BadgeNo,@TransDate,@OutletNo,@RefNum,@CheckNum,@TransTotal,
				        @Sales1,@Comment,@CycleNo,@TransID,@Category,@PaymentNo,@ServeEmpl,@PostEmpl,@Covers,
				        @RevCntr,@Sales2,@Sales3,@Sales4,@Sales5,@Sales6,@Sales7,@Sales8,@Sales9,@Sales10,
				        @Sales11,@Sales12,@Sales13,@Sales14,@Sales15,@Sales16,@Tax1,@Tax2,@Tax3,@Tax4,
				        @Dsc,@Svc,@SvcA,@Correction,@Auditable,@PostDate,@MealPlanID

-- Log the Charge Request :: 927 = Transaction Posting

	set @Message = 'RX1 Post Request: ' + 
					@AccountNo + '/' + 
					@BadgeNo + 
					' Outlet:' + cast(@OutletNo as varchar(10)) + 
					' Check # ' + @CheckNum + 
					' Total: ' + cast(@TransTotal as varchar(15)) + 
					'  Code: ' + cast( @Error as varchar(10))

    EXEC dbo.sp_Logit 1 , @CoreID , @User , @Message , 927

    IF (@Error <> 2627 AND @Error <> 0)
       SELECT '/SQL Error ' + CAST(@Error AS varchar(25)) as ReturnMsg
    ELSE 
       SELECT @TransIDName + ' Posted' as ReturnMsg
go

