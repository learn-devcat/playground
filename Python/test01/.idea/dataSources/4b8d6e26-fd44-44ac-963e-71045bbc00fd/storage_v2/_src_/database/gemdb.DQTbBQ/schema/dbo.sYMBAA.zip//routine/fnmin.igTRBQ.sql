

CREATE FUNCTION dbo.fnMin (@f money, @s money) 
RETURNS money AS 
BEGIN 
	IF @f > @s
		RETURN @s
	RETURN @f
END
go

