
CREATE PROCEDURE dbo.MenuItemNutrientList
@MenuItemID	int

AS
	SET NOCOUNT ON

	SELECT @MenuItemID AS MenuItemID, 
		N.NutrientID,
		N.[Description],
		ISNULL(M.Qty,0) AS Qty
	FROM	dbo.cfgNutrients AS N (NOLOCK)
		LEFT JOIN dbo.tblMenuItemNutrients AS M (NOLOCK) ON N.NutrientID = M.NutrientID
			AND M.MenuItemID = @MenuItemID
	ORDER BY N.NutrientID

	RETURN
go

