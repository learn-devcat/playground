
CREATE PROCEDURE dbo.MenuItemNutrientDelete
@LoginUserID		varchar(250),
@MenuItemNutrientID	int,
@MenuItemID		int=0,
@NutrientID		int=0

AS
	SET NOCOUNT ON

	IF(@MenuItemNutrientID > 0)
		DELETE dbo.tblMenuItemNutrients WHERE MenuItemNutrientID = @MenuItemNutrientID
	ELSE
	BEGIN
		IF(@MenuItemID > 0)
		BEGIN
			DELETE dbo.tblMenuItemNutrients WHERE MenuItemID = @MenuItemID
		END
		ELSE
		BEGIN
			DELETE dbo.tblMenuItemNutrients WHERE NutrientID = @NutrientID
		END
	END
	
	RETURN
go

