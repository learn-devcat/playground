

CREATE PROCEDURE [dbo].[sp_Menus_List]
@SecurityLevel	int,
@Group	int
AS
	SELECT	MenuID, Description, SubMenuID, URL, ImageURL
	FROM		cfgMenus 
	WHERE	SecurityLevel <= @SecurityLevel AND (MenuGroup = @Group OR MenuGroup=0)
	ORDER BY	MenuID, SubMenuID
go

