CREATE PROCEDURE [dbo].[Menu_GetUserList]
							@User char(10)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @InitLevel int

	CREATE TABLE #MenuBuildup 
				(MenuID int,
				 SubMenuID int,
				 Description varchar(50),
				 ShortDescription varchar(50),
				 Synopsis varchar(255),
				 URL varchar(250),
				 ActionID int,
				 MenuLevel int,
				 ImageURL Varchar(255))	

	EXEC dbo.BuildMenuTable 0, @User

	SELECT @InitLevel = MIN(MenuLevel) FROM #MenuBuildup
	
	UPDATE	#MenuBuildup
	SET		MenuLevel = (MenuLevel - @InitLevel)

	SELECT * FROM #MenuBuildup
	DROP TABLE #MenuBuildup	
END
go

