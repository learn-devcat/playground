CREATE PROCEDURE [dbo].[sp_Task_GetAll]
	@User char(10)
AS

	DECLARE @UserRole int
	
	-- get the user's max role id
	SELECT @UserRole = MAX(PrivilegeClassId)
	FROM dbo.tblPrivilegeClassMembers
	WHERE UserID = @User;

	SELECT M.Message, O.* 
	FROM dbo.TaskOHD AS O
	LEFT JOIN dbo.tblMessages AS M
		ON M.ID = O.MessageId AND M.PageID = 'Tasks'
	WHERE @UserRole >= O.MinPrivilegeClass
	ORDER BY O.CategoryId, O.TaskType, M.Message;
go

