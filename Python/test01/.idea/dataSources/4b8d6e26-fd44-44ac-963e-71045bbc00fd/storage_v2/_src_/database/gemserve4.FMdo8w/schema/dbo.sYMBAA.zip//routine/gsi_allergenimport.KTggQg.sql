
CREATE PROCEDURE [dbo].[GSI_AllergenImport]
@LoginUserID	varchar(250),
@AllergenID	int,
@Description	varchar(50)

AS
	IF (@AllergenID < 1)
	BEGIN
		INSERT INTO dbo.cfgAllergens ([Description],EnteredBy)
			VALUES (@Description, @LoginUserID)

		SET @AllergenID = SCOPE_IDENTITY()
	END
	ELSE
		UPDATE dbo.cfgAllergens
		SET [Description] = @Description,
			LastUpdateBy = @LoginUserID
		WHERE AllergenID = @AllergenID


	SELECT @AllergenID AS AllergenID
go

