CREATE  PROCEDURE [dbo].[NonSelectOrderGet]

@NonSelectOrderID        int,

@CycleID                           int=0,

@DayOfWeek                   int=0

 

AS

 

               SET NOCOUNT ON

 

               IF (@NonSelectOrderID > 0) 

                              SELECT NonSelectOrderID,

                                             CycleID,

                                             [Description],

                                             MealPeriodID,

                                             DietID,

                                             WaveID,

                                             DayOfWeek

                              FROM    dbo.tblNonSelectOHD

                              WHERE NonSelectOrderID = @NonSelectOrderID

               ELSE

                              SELECT  NS.NonSelectOrderID,

                                             NS.CycleID,

                                             NS.[Description] AS 'NonSelectItemName',

                                             NS.MealPeriodID,

                                             MP.[Description] AS 'MealPeriodName',

                                             NS.DietID,

                                             D.[Description] AS 'DietName',

                                             NS.WaveID,

                                             W.[Description] AS 'WaveName',

                                             DayOfWeek,

                                             (SELECT COUNT(*) FROM tblNonSelectDetail WHERE NonSelectOrderID = NS.NonSelectOrderID AND IsFreeText < 1) AS 'DetailCount'

                              FROM    dbo.tblNonSelectOHD AS NS

                                                            LEFT JOIN

                                             dbo.tblMealPeriods AS MP ON NS.MealPeriodID = MP.MealPeriodID

                                                            LEFT JOIN

                                             dbo.tblDietOHD AS D ON NS.DietID = D.DietID

                                                            LEFT JOIN

                                             dbo.tblWave AS W ON NS.WaveID = W.WaveID

                              WHERE NS.DayOfWeek = @DayOfWeek

                                             AND NS.CycleID = @CycleID

                              ORDER BY NS.MealPeriodID

                              

               RETURN
go

