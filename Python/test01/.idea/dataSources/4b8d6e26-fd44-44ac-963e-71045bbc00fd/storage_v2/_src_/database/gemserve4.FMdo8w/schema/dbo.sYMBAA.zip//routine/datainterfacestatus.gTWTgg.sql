


CREATE PROCEDURE dbo.DataInterfaceStatus

AS
	SET NOCOUNT ON

	DECLARE @IdleIntervalCaution	varchar(20),
		@IdleIntervalWarning	varchar(20),
		@LastIdleEvent		datetime,
		@Now			datetime,
		@CautionMinutes		int,
		@WarningMinutes		int,
		@Hours			int,
		@Minutes		int,
		@Seconds		int,
		@Return			int,
		@Last			char(10),
		@Hide			varchar(1)

	SET @Now = getdate()
	SET @IdleIntervalCaution = dbo.GetOverheadValue('IdtIntervalCaution')
	SET @IdleIntervalWarning = dbo.GetOverheadValue('IdtIntervalWarning')
	SET @Hide = dbo.GetOverheadValue('HideIDTStatus')

	SET @Hide = ISNULL(@Hide,'0')

	IF (ISNULL(@IdleIntervalCaution,'0') = '0')
		SET @CautionMinutes = '15'

	IF (ISNULL(@IdleIntervalWarning,'0') = '0')
		SET @WarningMinutes = '30'

	SET @CautionMinutes = CAST(@IdleIntervalCaution AS int)
	SET @WarningMinutes = CAST(@IdleIntervalWarning AS int)

	SELECT TOP 1 @LastIdleEvent = LastIdleEvent
	FROM dbo.tblWorkstation
	WHERE WorkStationID LIKE 'Idt%'
	ORDER BY LastIdleEvent DESC

	IF (@LastIdleEvent IS NULL)
		SET @LastIdleEvent = '1/1/1980 00:00:00'

	SET @Hours = 0
	SET @Minutes = 0
	SET @Seconds = 0

	SET @Seconds = DATEDIFF(ss,@LastIdleEvent,@Now)
	SET @Minutes = @Seconds / 60
	SET @Seconds = @Seconds % 60
	SET @Hours = @Minutes / 60
	SET @Minutes = @Minutes % 60

	IF (@Hours > 24)
		SET @Last = '> 24 hours'
	ELSE
		SET @Last = dbo.LPAD(CAST(@Hours AS varchar(2)),2,'0') + 
			':' + dbo.LPAD(CAST(@Minutes AS varchar(2)),2,'0') + 
			':' + dbo.LPAD(CAST(@Seconds AS varchar(2)),2,'0')

	IF (DATEDIFF(mi, @LastIdleEvent, @Now) > @WarningMinutes)
	BEGIN
		SET @Return = 2
		GOTO ReturnStatus
	END			

	IF (DATEDIFF(mi, @LastIdleEvent, @Now) > @CautionMinutes)
	BEGIN
		SET @Return = 1
		GOTO ReturnStatus
	END			

	SET @Return = 0

ReturnStatus:
	SELECT @Return AS Status, @Last AS LastEvent, @Hide AS Hide
go

