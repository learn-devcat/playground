

CREATE PROCEDURE [dbo].[ad_MealPlanDTL_Update]
@DtlID			int,
@MealPlanID		int,
@Description		varchar(10),
@BegTime		char(5),
@EndTime		char(5),
@NumPasses		char(7),
@TransLimit		money,
@Equiv			money,
@CountAllPasses	bit
AS
	UPDATE	tblPlanDtl
	SET		MealPlanID = @MealPlanID,
			Description = @Description, 
			BegTime = @BegTime,
			EndTime = @EndTime,
			NumPasses = @NumPasses,
			TransLimit = @TransLimit,
			Equiv = @Equiv,
			CountAllPasses = @CountAllPasses
	WHERE	DtlID = @DtlID
go

