
CREATE PROCEDURE [dbo].[MenuListForUser]
@LoginUserID		varchar(250)

AS
	SET NOCOUNT ON

	DECLARE @MenuPointSize	varchar(10)

	SELECT @MenuPointSize = dbo.GetOverheadValue('MenuPointSize')
	IF (@MenuPointSize = '')
		SET @MenuPointSize = '10'

	IF EXISTS (SELECT 1 FROM dbo.cfgOverhead WHERE KeyID = 'ImagesDirectory')
		UPDATE dbo.cfgWebMenus SET IsDisabled = 0 WHERE Description = 'Manage Private Images'
	ELSE
		UPDATE dbo.cfgWebMenus SET IsDisabled = 1 WHERE Description = 'Manage Private Images'

	-- Root menus
	SELECT DISTINCT	M.MenuID,
		M.ParentID,
		ISNULL(M.Description,'') AS Description,
		ISNULL(M.MenuAction,'') AS MenuAction,
		ISNULL(M.MenuImage,'') AS MenuImage,
		ISNULL(M.MenuHoverImage,'') AS MenuHoverImage,
		M.Sequence,
		ISNULL(M.IsSeparator,0) AS IsSeparator,
		ISNULL(M.IsDisabled,0) AS IsDisabled,
		ISNULL(M.IsChecked,0) AS IsChecked,
		M.MenuGroup
	FROM	GEM.dbo.tblUserDatabases AS D (NOLOCK)
		JOIN GEM.dbo.tblRoleActions AS RA (NOLOCK) ON RA.RoleID = D.RoleID
		JOIN GEM.dbo.tblActions AS A (NOLOCK) ON RA.ActionID = A.ActionID
		JOIN GEM.dbo.cfgMenus AS M (NOLOCK) ON A.ActionID = M.ActionID			
                JOIN GEM.dbo.tblUsers AS U (NOLOCK) ON D.UserID = U.UserID
	WHERE	U.LoginUserID = @LoginUserID 
	ORDER BY M.[Sequence], M.ParentID

	RETURN
go

