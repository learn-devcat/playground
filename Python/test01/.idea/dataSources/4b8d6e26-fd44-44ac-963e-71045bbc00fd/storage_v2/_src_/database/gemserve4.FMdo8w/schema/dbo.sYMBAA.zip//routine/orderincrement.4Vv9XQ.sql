

CREATE PROCEDURE dbo.OrderIncrement
@OrderID	int,
@IncrementDays	int=1

AS
	SET NOCOUNT ON
	
	DECLARE @NewOrderID	int,
		@Message	varchar(200)

	BEGIN TRANSACTION
		INSERT INTO dbo.tblOrderOHD (WaveID, SubLevel, OrderDate, PostDate, PatientID, NonSelectOrder, StandingOrder, EnteredBy)
			SELECT WaveID, DATEPART(dw,OrderDate + @IncrementDays), OrderDate + @IncrementDays, getdate(), PatientID, NonSelectOrder, StandingOrder, 'OrderDTLGetAll'
			FROM dbo.tblOrderOHD WHERE OrderID = @OrderID

		IF(@@ERROR <> 0)
			GOTO InsertError

		SET @NewOrderID = SCOPE_IDENTITY()
		
		INSERT INTO dbo.tblOrderDtl (OrderID, OrderDetail)
			SELECT @NewOrderID, OrderDetail
			FROM dbo.tblOrderDtl WHERE OrderID = @OrderID

		IF(@@ERROR <> 0)
			GOTO InsertError

	COMMIT TRANSACTION
	GOTO ExitProcedure

InsertError:
	ROLLBACK TRANSACTION

	SET @Message = 'Error incrementing order #' + CAST(@OrderID as integer) + ' (non-select or standing order)'
	EXEC dbo.Logit 2, @Message, 'system'

ExitProcedure:
	RETURN
go

