

CREATE PROCEDURE dbo.sp_GiftCard_ListTrans
@User		char(10),
@AccountNo	char(19)
AS
	SELECT	DetailID,
			TransDate,
			RefNum,
			TransTotal,
			OutletName,
			D.CycleNo,
			T.Payment
	FROM		tblDetail AS D
			LEFT JOIN tblOutletOHD AS O
	ON		D.OutletNo = O.OutletNo
			LEFT JOIN tblTransDef AS T
	ON		T.TransID = D.TransID
	WHERE	D.AccountNo = @AccountNo
	ORDER BY 	D.TransDate
	
	DECLARE 	@cMsg  	char(255),
				@CoreID	int
	SET @CoreID = dbo.GetCoreIDFromUser(@User)
	
	SET @cMsg = 'Retrieved transaction list for GiftCard No <' + RTRIM(@AccountNo) + '>'
	EXEC dbo.sp_Logit 5 , @CoreID , @User , @cMsg
go

