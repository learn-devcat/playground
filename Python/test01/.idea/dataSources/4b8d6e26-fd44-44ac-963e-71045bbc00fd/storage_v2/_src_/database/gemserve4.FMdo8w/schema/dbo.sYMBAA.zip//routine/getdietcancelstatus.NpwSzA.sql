CREATE FUNCTION [dbo].[GetDietCancelStatus](@CancelDate datetime, @Now datetime)
RETURNS bit
AS
BEGIN
	DECLARE @Return	bit

	IF (@CancelDate IS NULL)
		SET @Return = 0
	ELSE
		SELECT @Return = CASE WHEN @CancelDate < @Now THEN 1
			ELSE 0
		END

	RETURN @Return
END
go

