CREATE	FUNCTION [dbo].[GetNutrientTotalsForOrder](@OrderID as int)
RETURNS varchar(1000)
AS
BEGIN
	DECLARE @myNutrients TABLE (NutrientName varchar(50),
				    Qty int,
				    Processed int default 0)

	DECLARE @Return varchar(1000),
			@NutrientName varchar(50)

	SET		@Return = ''

	-- create a temporary table and sum up nutrient totals
	INSERT INTO @myNutrients
		SELECT	N.[Description],
			SUM(MN.Qty * OI.Consumption) AS Qty,
			0	 
		FROM	dbo.tblOrderItems AS OI (NOLOCK)
			JOIN dbo.tblMenuItemOHD AS M (NOLOCK) ON OI.POSMenuItemID = M.POSMenuItemID
			LEFT JOIN dbo.tblMenuItemNutrients AS MN (NOLOCK) ON M.MenuItemID = MN.MenuItemID
			LEFT JOIN dbo.cfgNutrients AS N (NOLOCK) ON MN.NutrientID = N.NutrientID
		WHERE	OI.OrderID = @OrderID AND MN.NutrientID IS NOT NULL
		GROUP BY N.[Description]
		ORDER BY N.[Description]

	
	-- change unprocessed records (0) to processed record (1)
		WHILE 1 = 1
		BEGIN
			SELECT TOP 1 @NutrientName = NutrientName, 
				     @Return = @Return + NutrientName + ' - ' + Cast(Qty as varchar(8)) + '|'
			FROM	@myNutrients
			WHERE 	Processed = 0

			IF (@@RowCount < 1)
				BREAK	

			UPDATE 	@myNutrients
			SET	Processed = 1
			WHERE	NutrientName = @NutrientName
		END

	
	-- if nutrient information is blank then return "No Nutrients Defined"

	SET @Return = CASE @Return 
					WHEN '' THEN ', No Nutients Defined' 
					ELSE @Return 
				  END

        RETURN LEFT(@Return,LEN(@Return) - 1)

END
go

