
CREATE   PROCEDURE dbo.WorkorderOHD_Delete
@User			char(10),
@WorkorderID		int
AS
DECLARE @Err	int,
	@WOnum	VarChar(50)
	
	-- get the WO number for logging, which is more relevent because it prints on workorder printouts
	SELECT 	@WOnum = WorkorderNumber
	FROM	tblWorkorderOHD
	WHERE   WorkorderID = @WorkorderID	
	DELETE	tblWorkorderOHD
	WHERE   WorkorderID = @WorkorderID
	SET @Err = @@Error
	
	DECLARE 	@cMsg  char(255),
			@CoreID	int
		SET @CoreID = dbo.GetCoreIDFromUser(@User)
		
		IF( @@Error = 0 )
  			SET @cMsg = 'Deleted Workorder Number:  <' + RTRIM(@WOnum) + '>, The logged on user was: ' + @User
 		ELSE
  			SET @cMsg = 'WorkorderOHD_Delete FAILED - Workorder ID <' + RTRIM(CAST(@WorkorderID as varchar(16))) + '>' 
	EXEC dbo.sp_Logit 0 , 0 , 'SYSTEM' , @cMsg, 900
	
	RETURN
go

