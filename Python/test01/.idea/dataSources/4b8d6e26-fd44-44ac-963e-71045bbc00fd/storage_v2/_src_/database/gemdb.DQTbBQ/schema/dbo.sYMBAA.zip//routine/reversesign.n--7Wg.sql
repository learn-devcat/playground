

CREATE FUNCTION dbo.ReverseSign (@Amt money, @IsPmt bit) 
RETURNS money
AS 
BEGIN 
	DECLARE	@Amount	money
	IF (@IsPmt = 1)
		SET @Amount = -@Amt
	ELSE
		SET @Amount = @Amt
	RETURN @Amount
END
go

