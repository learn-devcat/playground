CREATE PROCEDURE dbo.tt5_GetBadge
@CoreID	int,
@User		varchar(10),
@BadgeNo	char(19),
@OutletNo	int,
@TerminalID	int,
@CashierID	int,
@NameLen	int	
AS
	DECLARE @Today 	datetime,
		@ID           	int,
		@PostReturn	int,
		@ReturnCode  	int,
		@SP_Return	int,
		@OutletSubType int
	
	DECLARE @RTable table ( AccountNo  varchar(19),
			 Name  varchar(30))

	SET NOCOUNT ON

	-- Removes badge swipe character if it exists in @BadgeNo
	SET @BadgeNo = dbo.RemoveBadgeSwipePrefix(@BadgeNo);

    SET  @ReturnCode = 0
    SET @Today = getdate()

	IF (@NameLen <= 0)					-- Default to 11 IF the calling app would like to defer this AND add a bit
		SET @NameLen = 11				-- of bullet proofing ...

	IF (ISNULL(@BadgeNo,'') = '')				--  Need one of these dudes to continue ...
	BEGIN
		SELECT '/Badge # Required' as ReturnMsg
		RETURN
	END

	IF (LEFT( @BadgeNo,1) = '~')				-- The TT5 may need some configuration.
		SET @BadgeNo = RIGHT( @BadgeNo , LEN( @BadgeNo) - 1)

	SELECT @OutletSubType = SubType  FROM tblOutletOHD WHERE OutletNo = @OutletNo

	IF (@OutletSubType) IS NULL
	    BEGIN
		SELECT '/Outlet ' + CAST( @OutletNo as varchar(10)) +' Not Defined' as ReturnMsg
		RETURN
	    END
	-- The TT5 can only handle up to 4 items on the screen, so limit this selection to the TOP 4.
	INSERT INTO @RTable 
             SELECT         --Top 4
		           ISNULL(B.AccountNo ,'')           as AccountNo,
	                        ISNULL(LEFT(B.LastName , @NameLen),'') as Name
	FROM              tblBadgesOHD B
             INNER JOIN       tblAccountOHD A on A.AccountNo = B.AccountNo   AND A.ActiveDate <= @Today AND A.ExpireDate >= @Today
	      INNER JOIN       tblAccountClass AC on A.AccountClassID = AC.AccountClassID AND  (dbo.IsAllowed(@OutletNo, AC.AccountClassID, -1) <> 0)
	 --inner  JOIN       tblAccountClass AC on A.AccountClassID = AC.AccountClassID AND  ( ( @OutletSubType &  AC.SubType ) <> 0)
             WHERE           B.badgeNo = @BadgeNo
	                 AND B.ActiveDate <= @Today
	                 AND B.ExpireDate >= @Today 
	                 AND B.inactive = 0 
		   
	ORDER BY B.AccountNo
	
 	IF (@@RowCount = 0)
 		SELECT  '/Not On File Or Allowed'  AS ReturnMsg
	ELSE
		SELECT * FROM @RTable
go

