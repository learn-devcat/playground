CREATE PROCEDURE dbo.sim_GCPost 
@CoreID	int,
@User		char(10),
@AccountNo    char(19),
@BadgeNo	char(19),
@PostTTL	money,
@CheckNo	varchar(6),
@EmplNo	int,
@TID		int,
@RVC		int,
@Location	varchar(50)='',
@Source 	varchar(20)=''
AS
DECLARE @Today 	datetime
DECLARE @ReturnCode  int
DECLARE @rVal varchar(10),
		@Swiped bit

	-- Gets flag for badge swipe	
	SET @Swiped = dbo.BadgeSwiped(@BadgeNo);
	-- Removes badge swipe character if it exists in @BadgeNo
	SET @BadgeNo = dbo.RemoveBadgeSwipePrefix(@BadgeNo);
	
	SET @Today = getdate()					-- Define here cauz can't use it in an EXEC call ...
	SET @ReturnCode = 0
	IF @AccountNo = ''					-- IF no account # passed in, look it up.
	    BEGIN
		SELECT @AccountNo = AccountNo 
		FROM   dbo.tblBadgesOHD
		WHERE badgeNo = @BadgeNo
		           AND ActiveDate <= Getdate() 
		          AND ExpireDate >= Getdate()
		          AND inactive = 0
		IF @@rowcount = 0 
		    BEGIN
			SELECT '/Not On File' as ReturnMsg
			RETURN
              	    END
	            ELSE
		    IF @@RowCount > 1 
	  		BEGIN
			    SELECT '/Too Many Matching Badges' as ReturnMsg
			    RETURN
			END
	    END
		   
	EXEC @rVal =  dbo.sp_PreChargeAuthorization '', @BadgeNo, @PostTTL, @TID, @RVC 
	SET @ReturnCode = CAST( @rVal  as  int)
	IF (@ReturnCode<> 0)
	BEGIN
		SELECT 
			case @ReturnCode 
				when 0 then ''
			WHEN '1' THEN '/Over Account Limit'
			WHEN '2' THEN '/Over Daily Limit'
			WHEN '3' THEN '/Badge Not On File'
			WHEN '4' THEN '/Badge Not Valid'
			WHEN '5' THEN '/Over Daily Qty'
			WHEN '6' THEN '/Over Badge Trans Limit'
			WHEN '7' THEN '/Over Account Trans Limit'
			WHEN '8' THEN '/Inactive Account'
			WHEN '9' THEN '/Over Badge Limit'
			WHEN '10' THEN '/Not Authorized Here'
			WHEN '11' THEN '/Outlet Not Defined'
			ELSE '/Undefined Error #:' +  CAST( @ReturnCode as varchar(10))
		END as ReturnMsg
		RETURN
	END
	-- Try the posting ...
	 EXEC dbo.sp_Trans_Post  @CoreID, @User,  @AccountNo, @BadgeNo , @Today , @Rvc, 'GCAUTO', @CheckNo, @PostTTL , @PostTTL, @Location, -1 , @TID,
		@BadgeSwiped = @Swiped
	
	-- Not sure what ther RETURN code is here...
	SELECT 'success' as returnmsg
go

