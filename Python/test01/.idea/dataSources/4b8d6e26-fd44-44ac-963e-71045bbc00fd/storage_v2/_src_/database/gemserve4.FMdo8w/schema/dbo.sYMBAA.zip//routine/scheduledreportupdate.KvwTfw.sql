


CREATE PROCEDURE [dbo].[ScheduledReportUpdate]
@LoginUserID		varchar(250),
@ScheduledReportID	int,
@DefName		varchar(50),
@ReportTitle		varchar(50),
@ReportFile		varchar(50),
@ReportSQL		varchar(4000),
@DefXML		varchar(4000),
@PrinterName		varchar(200),
@NextDate		datetime,
@Frequency		varchar(10)

AS
	SET NOCOUNT ON

	IF (@ScheduledReportID <= 0)
		INSERT INTO dbo.tblScheduledReports (DefName, ReportTitle, ReportFile, ReportSQL, DefXML, PrinterName, NextDate, Frequency)
			VALUES (@DefName, @ReportTitle, @ReportFile, @ReportSQL, @DefXML, @PrinterName, @NextDate, @Frequency)
	ELSE
		UPDATE dbo.tblScheduledReports
		SET DefName = @DefName,
			ReportTitle = @ReportTitle,
			ReportFile = @ReportFile,
			ReportSQL = @ReportSQL,
			DefXML = @DefXML,
			PrinterName = @PrinterName,
			NextDate = @NextDate,
			Frequency = @Frequency
		WHERE ScheduledReportID = @ScheduledReportID

	RETURN
go

