

CREATE PROCEDURE dbo.ad_DeleteMenus
AS
DELETE cfgMenus WHERE UPPER(Source) <> 'CUSTOM'
go

