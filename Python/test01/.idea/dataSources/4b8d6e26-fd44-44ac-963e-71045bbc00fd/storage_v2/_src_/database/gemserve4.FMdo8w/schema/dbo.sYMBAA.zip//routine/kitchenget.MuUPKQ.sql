CREATE PROCEDURE [dbo].[KitchenGet]
	@KitchenId			int=0,
	@IncludeInactive	bit=0
AS
	SET NOCOUNT ON	
	
	SET @IncludeInactive = ~@IncludeInactive
	
	IF (@KitchenId > 0)
		SELECT	KitchenId,
				Description,
				OrderTypeId,
				OfflineRuleId,
				AlternateKitchenId,
				Active,
				LicenseKey,
				CSValue
		FROM dbo.tblKitchens (NOLOCK)
		WHERE KitchenId = @KitchenId
	ELSE
		SELECT	KitchenId,
				Description,
				OrderTypeId,
				OfflineRuleId,
				AlternateKitchenId,
				Active,
				LicenseKey,
				CSValue
		FROM dbo.tblKitchens (NOLOCK)
		WHERE Active IN (1, @IncludeInactive)
		ORDER BY Description

	RETURN 0
go

