

CREATE PROCEDURE [dbo].[ad_Menus_Get]
@MenuID	int
AS 
	SELECT	@MenuID AS MenuID,
			SubMenuID,
			Description,
			URL,
			SecurityLevel,
			MenuGroup,
			Source,
			ActionID,
			ShortDescription,
			Synopsis,
			ImageURL
	FROM	cfgMenus 
	WHERE	MenuID = @MenuID
go

