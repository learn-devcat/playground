CREATE PROCEDURE [dbo].[ad_AccountClass_Get_EX]
@User			char(10),
@AccountClassID	int
AS
	SELECT	AccountClassID,
			Name,
			Status,
			Category,
			Flags,
			AccountType,
			ExpireDays,
			TrackingGrp,
			DailyLimit,
			DailyQtyLimit,
			Limit,
			Xref,
			importmodule,
			exportmodule,
			CycleXREFID,
			SubType,
			IncludeAtTerm,
			EnableTimepay,
			GlobalLimit,
			EnableWeb,
			ReceiptTransProfileDisplay,
			SelectedTransProfilesOnReceipt,
			Department
	FROM		tblAccountClass
	WHERE	AccountClassID = @AccountClassID
go

