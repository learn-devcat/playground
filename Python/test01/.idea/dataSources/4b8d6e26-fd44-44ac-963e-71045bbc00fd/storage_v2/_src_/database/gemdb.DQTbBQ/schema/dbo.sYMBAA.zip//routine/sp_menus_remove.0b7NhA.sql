

CREATE PROCEDURE dbo.sp_Menus_Remove
AS
	TRUNCATE TABLE cfgMenus
go

