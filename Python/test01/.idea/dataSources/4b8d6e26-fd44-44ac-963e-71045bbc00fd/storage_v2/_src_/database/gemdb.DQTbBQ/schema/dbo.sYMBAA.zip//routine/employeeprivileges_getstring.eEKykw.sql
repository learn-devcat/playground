







CREATE       PROCEDURE dbo.EmployeePrivileges_GetString
@User			char(10),
@EmployeeID		int
AS
DECLARE @PrivStr	varchar(128)
    	SELECT      @PrivStr = 	Cast(C.CanCreateWorkOrder as varchar(1))	+ 
                		Cast(C.CanDeleteWorkOrder as varchar(1)) 	+ 
               		 	Cast(C.CanCloseWorkOrder as varchar(1)) 	+ 
                		Cast(C.CanPrintWorkOrder as varchar(1)) 	+ 
                		Cast(C.CanCompleteWorkOrderDTL as varchar(1)) 	+ 
                		Cast(C.CanAddWorkOrderDTL as varchar(1)) 	+ 
                		Cast(C.CanDeleteWorkOrderDTL as varchar(1)) 	+ 
				Cast(C.ViewAllWorkorders as varchar(1)) 	+ 
				Cast(C.ViewWorkordersInClass as varchar(1)) 	+ 
				Cast(C.AdjustWorkorderCharge as varchar(1))
	
        FROM	tblEmployeeOHD E
	    		LEFT JOIN 
		tblEmployeeClass C on C.EmployeeClassID = E.EmployeeClassID
	WHERE   E.EmployeeID = @EmployeeID           
	SELECT @PrivStr
go

