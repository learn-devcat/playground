

CREATE PROCEDURE dbo.ad_MealPlanDTL_Get
@DtlID	int
AS
	SELECT	DtlID,
			MealPlanID,
			Description,
			BegTime,
			EndTime,
			NumPasses,
			TransLimit,
			Equiv,
			CountAllPasses,	
			PassesAllowed
	FROM		tblPlanDtl
	WHERE	DtlID = @DtlID
go

