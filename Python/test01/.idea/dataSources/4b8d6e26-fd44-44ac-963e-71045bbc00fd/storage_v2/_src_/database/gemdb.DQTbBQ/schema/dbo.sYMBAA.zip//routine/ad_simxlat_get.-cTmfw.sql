CREATE  PROCEDURE dbo.ad_SIMXlat_Get
@SimID	char(24)
AS 
	IF @SimID = ''
	BEGIN
		SELECT	Active,
			Locked,
			[Description],
			Category,
			CoreID,
			SimID,
			sp,
			Status,
			NumParms,
			ActiveDate,
			[ExpireDate],
			LocationBlock			
		FROM	dbo.cfgSIMXlat
		ORDER BY SimID
	END
	ELSE
	BEGIN
		SELECT	Active,
			Locked,
			[Description],
			Category,
			CoreID,
			SimID,
			sp,
			Status,
			NumParms,
			ActiveDate,
			[ExpireDate],
			LocationBlock			
		FROM	dbo.cfgSIMXlat
		WHERE	SimID = @SimID
	END
go

