CREATE PROCEDURE [dbo].[sp_Dashboard_ShowHide]
	@User			char(10),
	@DashboardID    int,
	@Hide			bit

AS
	DECLARE @ExistingID int

	Select @ExistingID = ID
	FROM tblDashboardPages
	WHERE UserID = @User
	AND ID = @DashboardID

		INSERT INTO tblDashboardPages(Name, UserID, SerializedRequestData, PageURL, UserHidden, SortPosition, PrivilegeActionID,GoToURL,AllowInteraction)
	   	SELECT Top 1 Name,@User,SerializedRequestData, PageURL ,@Hide,SortPosition,PrivilegeActionID,GoToURL,AllowInteraction
		FROM tblDashboardPages
		WHERE ID = @DashboardID

	IF (Not @ExistingID IS NULL)
	BEGIN
		DELETE tblDashboardPages
		WHERE UserID = @User
		AND ID = @DashboardID
	END
go

