CREATE PROCEDURE [dbo].[sim140_CustomTrailer1]
@CoreID smallint,
@user char(10),
@Location int,                -- Where is this charge coming from?
@BadgeNo char(19),
@AccountNo char(19),          -- Who is this charge coming from?
@TransID int,                 -- Not used here...
@RevenueCenter int,           -- Revenue center of the inquire
@CheckNumber varchar(20),     -- Not used here...
@AmountTendered money,         -- Not used here...
@WorkstationID int
AS

	SET NOCOUNT ON

	DECLARE @Message as varchar(max),
			@ReturnMessage varchar(max)

	----------------------------------------------------------
	--
	--    You are allowed 6 lines of 30 characters for 
	--    Trailer rows.
	--
	--    Any result > 11 lines will automatically be printed
	--    and printer output is limited to 32 or 40 colums
	--    depending on the setting in the device file
	--
	--    The very first value is the # of entries in this
	--    data set.
	-- 
	----------------------------------------------------------

   	-- Removes badge swipe character if it exists in @BadgeNo
	SET @BadgeNo = dbo.RemoveBadgeSwipePrefix(@BadgeNo);

	SELECT @Message=RTRIM(A.Reference)
	FROM dbo.tblBadgesOHD as B
	JOIN dbo.tblAccountOHD as A on A.accountno = B.accountno
	WHERE B.badgeno = @BadgeNo

	SELECT @ReturnMessage = COALESCE(@ReturnMessage + '^','')+Content
	FROM dbo.WrapTextToTableRows(@Message,30) --Wrap the @Message into 20 character width.


	--set @Message = 
	-- 12345678901234567890123456789012345678901234567890
	-- 'Special Account Inquiry^' +
	-- '================================================' + '^' + 
	-- ' Account: ' + RTRIM(@AccountNo) + '^' + 
	--' Badge: ' + RTRIM(@BadgeNo) + '^' + 
	-- ' ^' + 
	-- ' Balance: 34.19 Balance: 34.19' + '^' + 
	-- ' Balance: 34.19 Balance: 34.19' + '^' + 
	-- ' Balance: 34.19 Balance: 34.19' + '^' + 
	-- ' Balance: 34.19 Balance: 34.19' + '^' + 
	-- ' Balance: 34.19 Balance: 34.19' + '^' + 
	-- '================================================' 

	SELECT CAST(LEN(@ReturnMessage)-LEN(REPLACE( @ReturnMessage, '^', '' ))+1 as varchar(5)) + '^' + @ReturnMessage
go

