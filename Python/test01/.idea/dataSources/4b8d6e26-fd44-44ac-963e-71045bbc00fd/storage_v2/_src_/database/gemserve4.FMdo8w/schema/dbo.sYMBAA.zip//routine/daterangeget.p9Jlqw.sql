CREATE     PROCEDURE [dbo].[DateRangeGet]
@DateRangeID int = -1
AS
	SET NOCOUNT ON
	
	IF (@DateRangeID = -1)
	BEGIN
	              SELECT  DateRangeID,
                             [Description],
                             BeginCode,
                             EndCode
	              FROM    dbo.tblDateRange
	
	END
	ELSE
	BEGIN
	              SELECT  [Description],
                             BeginCode,
                             EndCode
	              FROM    dbo.tblDateRange
	              WHERE   DateRangeID = @DateRangeID
	END
	
	RETURN
go

