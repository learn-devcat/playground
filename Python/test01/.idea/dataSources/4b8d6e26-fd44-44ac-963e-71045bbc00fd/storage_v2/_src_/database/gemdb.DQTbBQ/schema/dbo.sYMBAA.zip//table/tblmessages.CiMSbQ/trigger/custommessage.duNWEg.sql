CREATE TRIGGER CustomMessage ON
dbo.tblMessages 
FOR UPDATE
AS
	IF (columns_updated() &4 ) <> 0
	BEGIN
		UPDATE [dbo].[tblMessages] SET Custom = 1
		FROM [dbo].[tblMessages] , inserted
		WHERE [dbo].[tblMessages].ID = inserted.ID
	END
go

