CREATE PROCEDURE [dbo].[CCS_MovePatientVisit_v4]
@MedicalRecordID varchar(50),
@PatientVisitID	varchar(50),
@Source			varchar(50),
@OrderType		varchar(50)='NW',
@ConnectionName	varchar(50)=''

AS

	SET NOCOUNT ON
	
	/* WARNING: Allergens for the Patient Visit cannot be moved */

	DECLARE @PatientID	int,
			@OldPatientID	int,
			@Msg varchar(250)

	IF NOT EXISTS (SELECT 1 FROM dbo.tblPatientVisit WHERE PatientVisitID = @PatientVisitID)
	BEGIN
		SET @Msg = 'Move Visit ignored. Patient Visit ID [' + @PatientVisitID + '] not found.'
		GOTO Finished
	END
	
	-- Get old Patient ID from PatientVisitID
	SELECT @OldPatientID = PatientID
	FROM dbo.tblPatientVisit
	WHERE PatientVisitID = @PatientVisitID

	-- Get New Patient ID from MRN
	SELECT @PatientID = PatientID
	FROM dbo.tblPatientOHD
	WHERE MedicalRecordID = @MedicalRecordID

	--Log an error if the new patient id is not found
	IF (@@Rowcount = 0)
	BEGIN
		SET @Msg = 'Move Visit ignored. No Patient ID found for Medical Record [' + @MedicalRecordID + '].'
		GOTO Finished
	END

	IF (@OrderType <> '')
	BEGIN
		IF EXISTS (SELECT 1 FROM dbo.tblXlat WHERE xlatId = 'ORMOrderType')
		BEGIN
			IF NOT EXISTS (SELECT 1 FROM dbo.tblXlat WHERE KeyIn = @OrderType AND xlatId = 'ADTOrderType')
			BEGIN
				SET @PatientID = -1
				SET @Msg = 'Move Visit ignored for non-processed order type [' + @OrderType + ']. PatientVisitID [' + @PatientVisitID + '].'
				GOTO Finished
			END
		END
	END

	--Update tables with new patientid
	UPDATE dbo.tblPatientVisit SET PatientID = @PatientID 
	WHERE PatientVisitID = @PatientVisitID

	UPDATE dbo.tblOrderOHD SET PatientID = @PatientID
	WHERE PatientVisitID = @PatientVisitID

	UPDATE dbo.tblPatientLog SET PatientID = @PatientID
	WHERE PatientVisitID = @PatientVisitID

	UPDATE dbo.tblPatientNutrientCount SET PatientID = @PatientID
	WHERE PatientID = @OldPatientID
		AND OrderID IN (SELECT OrderID FROM dbo.tblOrderOHD WHERE PatientVisitID = @PatientVisitID)

	UPDATE dbo.tblPatientMealPeriodNutrientOverride SET PatientID = @PatientID 
	WHERE PatientID = @OldPatientID
		AND PatientDietID IN (SELECT [ID] FROM dbo.tblPatientDiet WHERE PatientVisitID = @PatientVisitID)

	UPDATE dbo.tblPatientDailyNutrientOverride SET PatientID = @PatientID 
	WHERE PatientID = @OldPatientID
		AND PatientDietID IN (SELECT [ID] FROM dbo.tblPatientDiet WHERE PatientVisitID = @PatientVisitID)

	SET @Msg = 'Patient Visit ID [' + @PatientVisitID + '] moved from PatientID [' + CAST(@OldPatientID AS varchar(25)) + '] to PatientID [' + CAST(@PatientID AS varchar(25)) + '].'

Finished:
	IF NOT (@Msg IS NULL)
	  	EXEC dbo.Logit 1, @Msg, 'system'

	SET @ConnectionName = 'Idt' + @ConnectionName
	EXEC dbo.WorkstationUpdateByID @ConnectionName

	SELECT @PatientID AS PatientID

	RETURN

go

