CREATE PROCEDURE dbo.ol_GetBadge
@CoreID		smallint = 1,
@User		char(10),
@BadgeNo 	char (19)
AS
	DECLARE @LogLevel int
	DECLARE @Today datetime

	SET @BadgeNo = dbo.RemoveBadgeSwipePrefix(@BadgeNo);
	
	SET @LogLevel = 3		-- Default to Read/Access Level	
	SET @Today = getdate()
	SELECT	B.BadgeNo, B.AccountNo, b.Status, b.PrimaryBadge, dbo.DateOnly(b.ActiveDate) as ActiveDate,
			dbo.DateOnly(b.ExpireDate) as ExpireDate,b.BadgeClassID, 
			b.Title, b.FirstName, b.LastName, dbo.Description_FullNameWithMiddle( a.Description, b.firstname, b.lastname, b.MiddleName, 1) AS Name, b.Limit, b.DailyLimit, b.ImagePath,
			a.description, dbo.FullNameWithMiddle( a.title, a.firstname, a.lastname, a.MiddleName, 1) AS AcctName, b.flagged, b.msg
	FROM  		dbo.tblBadgesOHD B
			RIGHT JOIN dbo.tblAccountOHD A on a.AccountNo = b.AccountNo
	WHERE   	b.BadgeNo = @BadgeNo 
			AND b.activedate <= @Today 
			AND b.expiredate >= @Today 
			AND b.BadgeClassID > 0
			
	DECLARE @cMsg  char(255)
	
	IF( @@rowcount = 0 ) 
		BEGIN
			SET @cMsg = 'ol_GetBadge Badge # ' + RTRIM(@BadgeNo) + ' <No Match>'
			SET @LogLevel = @LogLevel - 1		-- drop logging level to catch failure.
		END
	ELSE
		SET @cMsg = 'ol_GetBadge Badge # ' + RTRIM(@BadgeNo)
	EXEC dbo.sp_Logit @LogLevel , @CoreID , @User , @cMsg, 925
go

