

CREATE PROCEDURE [dbo].[sp_Recur_ProcessCharges]
@User	char(10)
AS 
	SET NOCOUNT ON
	
	DECLARE	@ReturnCode		int,
			@ClassID		int,
			@Description	char(24),
			@Active			bit,
			@NextDate		datetime,
			@Frequency		char(3),
			@Today			datetime
			
	SET @Today = getdate()
	
	BEGIN TRANSACTION
	
		/*	Create a cursor to loop through the recurring class table
				The cursor only includes those recurring items that have a NextDate that is
				equal to or earlier than the current date.
		*/
		DECLARE sRecur cursor FOR
				SELECT 	ClassID, Description, Active, NextDate, Frequency
				FROM	tblRecurChgClass
				WHERE	Active = 1 AND
						NextDate <= @Today
		OPEN sRecur
		
		FETCH NEXT FROM sRecur INTO @ClassID, @Description, @Active, @NextDate, @Frequency
	
		--Loop through the recurring class items
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--Call the stored procedure that posts current recurring charges to the tblBatch table by account
			EXEC @ReturnCode = dbo.sp_Recur_PostCharges_EX @User, @ClassID 
			
			FETCH NEXT FROM sRecur INTO @ClassID, @Description, @Active, @NextDate, @Frequency
		END
		--Free resources 
		CLOSE sRecur
		DEALLOCATE sRecur
		
		--UPDATE the frequencies
	    EXEC dbo.sp_Recur_UpdateFreq @User
	    
	 COMMIT TRANSACTION
go

