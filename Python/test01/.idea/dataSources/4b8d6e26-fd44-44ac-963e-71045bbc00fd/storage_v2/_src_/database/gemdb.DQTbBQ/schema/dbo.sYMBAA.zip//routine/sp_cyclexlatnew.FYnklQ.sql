


CREATE PROCEDURE dbo.sp_CycleXLATnew
@CoreID	int,
@XlatID	char(10),
@BeginDate	datetime,
@NumCycles	int,
@Freq		varchar(3),
@CycleNo	int = 1
AS
	DECLARE	@EndDate	datetime,
			@FreqD	char(1),
			@FreqV		int
	SET @NumCycles = @NumCycles - 1
	-- Calculate the enddate
	SET @EndDate = @BeginDate
	SET @FreqD = UPPER( SUBSTRING( @Freq , 1 , 1 ))
	SET @FreqV = CAST( SUBSTRING( @Freq , 2 , 2 ) AS int )
	SET @EndDate = DATEADD( d ,0 , 
		CASE 					-- Setup our new END DATE
			WHEN @FreqD =  'D' THEN DATEADD(  d,  @FreqV  , @BeginDate )
			WHEN @FreqD = 'W' THEN DATEADD( ww,  @FreqV  , @BeginDate )
			WHEN @FreqD= 'Q' THEN DATEADD(  q,  @FreqV  , @BeginDate )
			WHEN @FreqD = 'M' THEN DATEADD( m , @FreqV , @BeginDate )
			WHEN @FreqD = 'Y' THEN DATEADD( yy,  @FreqV  , @BeginDate )
			WHEN @FreqD = 'A' THEN DATEADD( yy,  @FreqV  , @BeginDate )
			WHEN @FreqD = 'B' AND DAY(@BeginDate) < 14  THEN DATEADD( d , 15 , @BeginDate )
			WHEN @FreqD = 'B' THEN 
				CASE WHEN MONTH(@BeginDate) = 12 THEN '1-' +
					SUBSTRING( @Freq , 2 , 2 ) + '-' +
					CAST(YEAR(@BeginDate)+1 AS varchar(4))
				ELSE CAST(MONTH(@BeginDate)+1 AS varchar(2)) + '-' + 
					SUBSTRING( @Freq , 2 , 2 ) + '-' +
					CAST(YEAR(@BeginDate) AS varchar(4))
				END
		END)
	-- insert the initial row
	INSERT INTO	tblCycleXLAT ( XlatID, BeginDate, EndDate, CycleNo) 
			VALUES ( @XlatID,@BeginDate,@EndDate,@CycleNo)
	-- adds the remaining rows to the cycleXLAT table
	EXEC	sp_CycleXLATadd     @CoreID, @XlatID, @NumCycles, @Freq
go

