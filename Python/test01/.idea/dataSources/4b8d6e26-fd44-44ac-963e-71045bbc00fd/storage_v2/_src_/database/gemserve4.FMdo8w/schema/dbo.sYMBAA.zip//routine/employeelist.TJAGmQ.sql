

CREATE PROCEDURE dbo.EmployeeList
AS
	SET NOCOUNT ON

	SELECT	LoginUserID,
		FirstName,
		LastName,
		Department,
		[Password],
		IsAdmin,
		BadgeNo
	FROM	dbo.tblEmployees
	ORDER BY LastName, FirstName

	RETURN
go

