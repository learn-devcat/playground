CREATE PROCEDURE [dbo].[ad_TransDef_Delete_Wrapper]
    @User char(10) ,
    @TransID int ,
	@VendingID int

AS 
	SET NOCOUNT ON 
	
    DECLARE @err1 int ,
			@err2 int		
		
    BEGIN TRANSACTION 
	
    EXEC dbo.ad_TransDef_Delete @User, @TransID
    SET @err1 = @@ERROR
	

    EXEC dbo.ad_Vending_Delete @User, @VendingID
    SET @err2 = @@ERROR
	
    IF ( @err1 <> 0 ) 
        BEGIN
            ROLLBACK TRANSACTION
            SET @err1 = 1
        END
    ELSE 
        IF ( @err2 <> 0 ) 
            BEGIN
                ROLLBACK TRANSACTION
                SET @err1 = 2
            END	
        ELSE 
            COMMIT TRANSACTION
	
    SELECT @err1
go

