CREATE PROCEDURE [dbo].[sim_RetrieveOrderByCheckNumber]
@CoreID as int,
@LoginUserID 	varchar(250),
@WorkstationID int,
@CheckNum	int
AS
    SET NOCOUNT ON
            
    DECLARE @RoomNumber as varchar(20),
        @SubLevel int,
        @PatientName varchar(50),
        @DietName varchar(50),
        @OrderWorkstationID int,
        @Sent int,
        @Received int,
        @Detail as varchar(4000),
        @Msg as varchar(2200),
        @PatientInfoOnOrder as char(1),
        @PatientLocationFlag as char(1),
        @PatientNotesFlag 		int,
        @AppendBed		varchar(10),
        @OrderDate datetime,
        @StandingOrder bit,
        @DietMenuLevel int,
        @ItemType int,
        @MenuItemID int,
        @POSMenuItemID int,
        @IsDiet bit,
        @OrderType	int,
        @OrderedFor varchar(20),
		@OrderId Int,
		@Today datetime,
		@Msg2 varchar(1000),
		@WaveID int,
		@WaveDescription varchar(100),
		@PatientVisitId varchar(50),
		@PatientId varchar(50),
		@PatientDietNotes	varchar(500),
        @PatientOHDNotes	varchar(500),
		@PatientNotes varchar(MAX),
		@PatientNotesLength int,
		@PatientLocation varchar(100),
		@PatientAllergens	varchar(500)
		
		SET @PatientNotesLength = 240

		SELECT @PatientInfoOnOrder = dbo.GetOverheadValue('PatientInfoOnOrder')
        SET @PatientLocationFlag = dbo.GetOverheadValue('PatientLocationOnOrder')
        SET @PatientNotesFlag = dbo.GetOverheadValue('PatientNotesOnOrder')
        SELECT @AppendBed = COALESCE(dbo.GetOverheadValueNull('AppendBed'),NULL)

    IF ( @PatientInfoOnOrder = '' )
        SET @PatientInfoOnOrder = '0'

    SELECT @Today = getdate();

    SELECT TOP 1 @RoomNumber = R.RoomNumber + CASE WHEN @AppendBed IS NULL THEN '-' + COALESCE(PV.Bed,'')
            ELSE '' END,
        @SubLevel = O.SubLevel,
        @PatientName = P.LastName + ',' + P.Firstname, 
		@OrderWorkstationID = O.WorkstationID,
		@Sent = O.Sent,
		@Received = O.Received,
		@DietName = DT.Description,
		@OrderDate = O.OrderDate,
		@StandingOrder = O.StandingOrder,
		@DietMenuLevel = COALESCE(DT.MenuLevel,1),
		@OrderType = O.OrderType,
		@OrderedFor = O.OrderedFor,
		@OrderId = o.OrderID,
		@WaveID = o.WaveID, 
		@CheckNum = o.CheckNo,
		@WaveDescription = W.Description,
		@PatientVisitId = PV.PatientVisitID,
		@PatientId = P.PatientID,
		@PatientLocation = CASE WHEN O.OrderType <> 1 THEN O.OrderedFor
		 ELSE
		  CASE WHEN @PatientLocationFlag = 1 THEN ISNULL(L.Description,'')
		   WHEN @PatientLocationFlag = 2 THEN dbo.DateStringMMDDYYYY(ISNULL(P.BirthDate,''))
		   WHEN @PatientLocationFlag = 3 THEN CAST(PV.PatientVisitID AS varchar(20))
		   ELSE ''
		  END
		 END,
		 @PatientDietNotes = CASE
                        WHEN (@PatientNotesFlag & 1) > 0 THEN ISNULL(dbo.GetActiveDietNotesEX(O.PatientVisitID,O.OrderDate,O.WaveID),'') 
                        ELSE ''
         END ,
         @PatientOHDNotes = CASE
                        WHEN (@PatientNotesFlag & 2) > 0 THEN CAST(ISNULL(P.Notes,'') AS varchar(500))
                        ELSE ''
         END,
         @PatientAllergens = dbo.PatientAllergens(O.PatientID)
    FROM    dbo.tblOrderOHD O
        LEFT JOIN dbo.tblPatientOHD AS P (NOLOCK) ON O.PatientID = P.Patientid
        LEFT JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON O.PatientVisitID = PV.PatientVisitID
            AND PV.MergedTo IS NULL
            AND PV.DischargeDate IS NULL
        LEFT JOIN dbo.tblPatientDiet AS PD (NOLOCK) 
            ON PD.[ID] = dbo.GetActivePatientDietID(PV.PatientVisitId, O.OrderDate)
        LEFT JOIN dbo.tblDietOHD AS DT (NOLOCK) ON PV.DietID = DT.DietID
        LEFT JOIN dbo.tblRoomOHD AS R (NOLOCK) ON PV.RoomID = R.RoomID
        LEFT JOIN dbo.tblLocationClass as L (NOLOCK) ON r.LocationClassID = l.LocationClassID
        LEFT JOIN dbo.tblWave as W (NOLOCK) ON O.WaveID = W.WaveID  
	WHERE   O.CheckNo = @CheckNum
	ORDER BY O.OrderID DESC
                     
    IF( @@ROWCOUNT = 0)
    BEGIN
        SELECT '/Order Not On File' AS rMsg
        RETURN
    END
    
    SET @PatientAllergens = 'Allergies: ' + @PatientAllergens
    
    --get patient notes.
	SET @PatientNotes = @PatientDietNotes
	
    IF ((@PatientNotesFlag & 2) > 0)
		SET @PatientNotes = @PatientNotes + ' ' + @PatientOHDNotes
		
    IF ((@PatientNotesFlag & 4) > 0)
        SET @PatientNotes = @PatientNotes + ' ' + @PatientAllergens
        
    SET @PatientNotes = LEFT(@PatientNotes,@PatientNotesLength) 

    
    -- Get Detail
    SELECT @Msg = 'RETRIEVE' + char(28) + CAST(@CheckNum as varchar(10)) + '^' + @RoomNumber + '^' + 
	   @PatientName 
			+ '^' + CAST(@SubLevel as varchar(5)) + '^' +
			@DietName + '^' + dbo.DateString(@OrderDate) + ' ' + dbo.TimeString(@OrderDate) + '^' 
	    
		-- SET @Msg = @Msg + dbo.GetOrderDetail(@OrderID, @OrderType, 0) -- comment this out because we don't need this information just to reprint a check. If these procedure is expanded to do more things then we can uncomment this.

	SET @Msg = @Msg + '^' + CAST(@DietMenuLevel AS varchar(10)) + '^' +
		CAST(@OrderType as varchar(10)) + '^' + @OrderedFor + '^' +
		@PatientNotes
		+ '^' +
		@PatientLocation
		+ '^' +
		@WaveDescription
		+ '^' +
		@PatientId + 
		char(28) + CAST(@StandingOrder AS char(1)) 

    IF(@Msg IS NULL)
            SELECT '/Unable To Retrieve Order' as rMsg
    ELSE
            SELECT @Msg AS rMsg
go

