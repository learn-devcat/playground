
CREATE PROCEDURE [dbo].[ie_AccountImport_v3_4_1]
@Module		varchar(100)
AS
	DECLARE	@AccountTTL		varchar(100),
		@AddBadge		int,
		@ImportAccountClass	int,
		@ImportBadgeClass	int,
		@DefaultCreditLimit	money,
		@PrimaryAddressID	int,
		@InactivateNotInFile	int,
		@InactivateNewAccts	int,
		@InactivateInFile	int,
		@InactivateOldBadges	int,
		@StripZeros		int,
		@UpdateGEMDesktop	int,
		@ModuleAccountClass	varchar(100),
		@Msg			varchar(255),
		@PreProc		varchar(255),
		@PostProc		varchar(255),
		@ClassCount		int,
		@cnt					int,
		@DefaultLocation INT,
		@LocationID int,
		@BadgeLocationID int,
		@IgnoreManuallyEditedAccounts int,
		@SetInactive int,
		@ReactivateInFile varchar(200),
		@ImportSource varchar(50),
		@ModuleAccountClassID int,
		@XrefIds varchar(100)

	/*
		Changes since v1_80:
		RBeverly 4/17/2008
			* Added code to create OutletClassTTLs 
			* Refactored all code that processes delimited multiple VALUES to use new functions AND procs
				that process or create delimited strings
			* Added quick read headers to all major processes
		RBeverly 10/7/2009
			* Added LocationID import for account
		RBeverly 3/24/2010
			* Added locationID to imported badges (has new module key for badge location)
			* Added module key to allow NOT ignoring manually edited accounts
		RBeverly 10/24/2011 v3.4
			* Changed import status to be based on new field in tblAccountOHD, tblAccountImport and in the import script params module
			  called: "ImportSource" that identifies the source of the import (typically a file),
			  and now accounts will be actived and deactivated based, not on the account profile, but the
			  import source they belong to.
			* Now, only ONE accountclassid should be in the module. NO comma delimited lists will be accepted.
			* If the accountclass module field is blank or missing, the accountclassid field in the import table
			  MUST be populated with a valid accountclassid or xref value.
			* Moved the code that clears the accountimport table to the top of the script
			* Accounts will not be imported if: 
				- accountno is null
				- accountno is empty string
				- there is no accountclassid value AND there is no accountclassid defined in the module
			  In these cases, these records in the import table will have a 'E' in the impexpflag field, indicating an Error
			* Changed logic in the code that deactivates old badges for imported accounts. The old logic failed
			  when badges became attached to new, different accounts.
		RBeverly 9/15/2014 v3.4_1 (custom Kisco version)
			* Added the ability to have the same xref in multiple account classes and 
				have them resolve properly by filtering on an accountclassid(s) specified in a new module key: "AccountClassXrefIds"
			* Fixed Bug in Badges update where all badges would updated, even if they weren't in the import, resulting in loss of 
				first and last name, and wrong locationid
			* Added sorting to the Pre and Post Proc calls, so you could number the names of the proc to ensure the proper sequence
			
	*/
	
			
	
	--************************************************************
	--			DELETE all records in the tblAccountImport table
	--************************************************************

	DELETE	tblAccountImport WHERE Processed = 1
	
	-- Don't try to run IF nothing in import table
	IF NOT EXISTS (SELECT TOP 1 * FROM tblAccountImport)
	RETURN	

	--****************************************************************
	--				Run any Pre-procedures
	--****************************************************************
	DECLARE Prerun cursor FOR 
		SELECT sValue FROM cfgScriptParams
		WHERE sModule = @Module 
		AND KeyName LIKE 'preproc%'
		ORDER BY sValue
	OPEN Prerun
	FETCH NEXT FROM Prerun INTO @PreProc
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC ('EXEC ' + @PreProc)
		FETCH NEXT FROM Prerun INTO @PreProc
	END
	CLOSE Prerun
	DEALLOCATE Prerun	


	--****************************************************************
	--	Get critical module data - if not found, stop script
	--****************************************************************
	SET @AccountTTL = dbo.GetScriptParamEX('AccountTTL',@Module,'')
	IF ( @AccountTTL = '' )
	BEGIN
		-- Fatal error - log AND exit
		SET @Msg = 'Import - No Account TTL found in Module ' + @Module
		EXEC sp_Logit 0, 1, 'system', @Msg, 1000
		RAISERROR (@Msg, 16, 1)
		RETURN
	END
	
	SET @ImportBadgeClass = dbo.GetScriptParamEX('ImportBadgeClass',@Module,'0')
	IF ( @ImportBadgeClass = '0' )
	BEGIN
		-- Fatal error - log AND exit
		SET @Msg = 'Import - No Import Badge Class found in Module ' + @Module
		EXEC sp_Logit 0, 1, 'system', @Msg, 1000
		RAISERROR (@Msg, 16, 1)
		RETURN
	END
	
	SET @ImportSource = dbo.GetScriptParamEX('ImportSource',@Module, NULL)
	IF ( @ImportSource IS NULL )
	BEGIN
		-- Fatal error - log AND exit
		SET @Msg = 'Import - script param [ ImportSource ] must be provided' + @Module
		EXEC sp_Logit 0, 1, 'system', @Msg, 1000
		RAISERROR (@Msg, 16, 1)
		RETURN
	END
	
	--****************************************************************
	--				Get module data
	--****************************************************************	
		
	SELECT TOP 1 @DefaultLocation = LocationID FROM dbo.cfgLocations ORDER BY LocationID
	
	SET @PrimaryAddressID = CAST(dbo.GetScriptParamEX('PrimaryAddressID',@Module,'100') as int)
	SET @AddBadge = CAST(dbo.GetScriptParamEX('AddBadgeOnImport',@Module,'1') as int)
	SET @StripZeros = CAST(dbo.GetScriptParamEX('StripBadgeZeros',@Module,'0') as int)
	SET @InactivateNotInFile = CAST(dbo.GetScriptParamEX('InactivateNotInFile',@Module,'1') as int)
	SET @InactivateInFile = CAST(dbo.GetScriptParamEX('InactivateInFile',@Module,'0') as int)
	SET @InactivateNewAccts = CAST(dbo.GetScriptParamEX('InactivateNewAccts',@Module,'0') as int)
	SET @DefaultCreditLimit = CAST(dbo.GetScriptParamEX('DefaultCreditLimit',@Module,'999999') as money)
	SET @UpdateGEMDesktop = CAST(dbo.GetScriptParamEX('UpdateGEMDesktop',@Module,'0') as int)
	SET @InactivateOldBadges = CAST(dbo.GetScriptParamEX('InactivateOldBadges',@Module,'1') as int)
	SET @LocationID = CAST(dbo.GetScriptParamEX('LocationID',@Module, @DefaultLocation) as int)
	SET @BadgeLocationID = CAST(dbo.GetScriptParamEX('BadgeLocationID',@Module, @LocationID) as int)
	SET @IgnoreManuallyEditedAccounts = CAST(dbo.GetScriptParamEX('IgnoreManuallyEditedAccounts',@Module, '1') as int)
	SET @ReactivateInFile = dbo.GetScriptParamEX('ReActivateInFile',@Module, NULL)
	SET @ModuleAccountClass = dbo.GetScriptParamEX('ImportAcctClass',@Module, NULL)
	SET @ModuleAccountClassID = dbo.AccountClassLU_EX(@ModuleAccountClass)
	SET @XrefIds = dbo.GetScriptParamEX('AccountClassXrefIds',@Module, NULL)
	
	--this item is being reversed to be semantically correct. IF 1, it should be a 0, otherwise null
	SET @SetInactive = CAST(CASE WHEN @ReactivateInFile = '1' THEN 0 ELSE NULL END AS int)
	

	--****************************************************************
	--				Inactivate Accounts IF specified
	--****************************************************************
	-- IF the InactivateInFile flag is SET, then everyone in the file will be SET to inactive.
	-- No other processing matters, so SET them AND get out.
	IF ( @InactivateInFile = 1 )
	BEGIN
		UPDATE 	tblAccountOHD
		SET 	Inactive = 1
		WHERE	AccountNo IN (SELECT AccountNo FROM tblAccountImport)
		RETURN
	END
	
	/****************************************************************
					ImpExpFlag values:
						Import Table:
							* N = New
							* X = eXisting
							* E = Error
						Account OHD table:
							* M = manually activated\deactivated
							* U = unprocessed
							* P = processed
	****************************************************************/
	
	
	--****************************************************************
	--	Prepare import table - determine rows that are in error
	--****************************************************************
	/*
		current error conditions:
			* if the module accountclassid isn't resolvable and there isn't a resolvable classid for the import row
			* if the accountno is null or an empty string
	*/
	IF (@ModuleAccountClassID IS NULL)
		UPDATE dbo.tblAccountImport 
		SET ImpExpFlag = 'E'
		WHERE AccountNo IS NULL
			  OR AccountNo = ''
			  OR dbo.AccountClassLU_EX(AccountClassID) IS NULL 
	ELSE 
		UPDATE dbo.tblAccountImport 
		SET ImpExpFlag = 'E'
		WHERE AccountNo IS NULL
			  OR AccountNo = ''
	

	--****************************************************************
	--				Prepare existing accounts for updates
	--****************************************************************
	
	--set ALL account impexpflag fields to 'U' for unprocessed
	IF(@IgnoreManuallyEditedAccounts = 1)
		UPDATE dbo.tblAccountOHD SET ImpExpFlag = 'U'
	ELSE
		UPDATE dbo.tblAccountOHD SET ImpExpFlag = 'U' WHERE ImpExpFlag <> 'M'


	--****************************************************************
	--				UPDATE existing accounts
	--**************************************************************** 
	
	--Update ALL records in the tblAccountOHD table that exist in the import table and do not have the 'M' impexpflag
	UPDATE	tblAccountOHD
	SET	Description = ISNULL(I.Description, A.Description),
		AccessID = ISNULL(I.AccessID, A.AccessID),
		Status = ISNULL(I.Status, A.Status),
		Title = ISNULL(I.Title, A.Title),
		FirstName = ISNULL(I.FirstName, A.FirstName),
		LastName = ISNULL(I.LastName, A.LastName),
		Phone = ISNULL(I.Phone, A.Phone),
		Fax = ISNULL(I.Fax, A.Fax),
		email = ISNULL(I.email, A.email),
		AccountClassID = COALESCE(dbo.AccountClassLU_FilterByValidIds(I.AccountClassID, @XrefIds),@ModuleAccountClassID, A.AccountClassID),
		PIN = ISNULL(I.PIN, A.PIN),
		ActiveDate = ISNULL(I.ActiveDate, A.ActiveDate),
		ExpireDate = ISNULL(I.ExpireDate, A.ExpireDate),
		Process = ISNULL(I.Process, A.Process),
		Reference = ISNULL(I.Reference, A.Reference),
		ImpExpFlag = 'P',
		Inactive = COALESCE(I.Inactive, @SetInactive, A.Inactive),
		NoStatements = ISNULL(I.NoStatements, A.NoStatements),
		NoAging = ISNULL(I.NoAging, A.NoAging),
		NoFinanceChg = ISNULL(I.NoFinanceChg, A.NoFinanceChg),
		NoVerify = ISNULL(I.NoVerify, A.NoVerify),
		NoDetail = ISNULL(I.NoDetail, A.NoDetail),
		Bump200 = ISNULL(I.Bump200, A.Bump200),
		AutoOverpost = ISNULL(I.AutoOverpost, A.AutoOverpost),
		PublicID = ISNULL(I.PublicID, A.PublicID),
		User1 = ISNULL(I.User1, A.User1),
		User2 = ISNULL(I.User2, A.User2),
		User3 = ISNULL(I.User3, A.User3),
		User4 = ISNULL(I.User4, A.User4),
		LocationID = COALESCE(@LocationID, I.LocationID, A.LocationID),
		ImportSource = @ImportSource
	FROM	tblAccountOHD AS A
			JOIN 
			tblAccountImport AS I ON A.AccountNo = I.AccountNo
	WHERE A.ImpExpFlag <> 'M'

	
	-- initialize the all rows (not in error) as new
	UPDATE 	tblAccountImport
	SET	ImpExpFlag = 'N'	
	WHERE ISNULL(ImpExpFlag, '') <> 'E'
	
	--flag the accounts that have been updated as eXisting
	UPDATE 	tblAccountImport
	SET	ImpExpFlag = 'X'
	FROM	tblAccountImport AS I
		JOIN tblAccountOHD AS A ON I.AccountNo = A.AccountNo
	WHERE ISNULL(I.ImpExpFlag, '') <> 'E'
		
		
	--********************************************************************************
	--				Inactivate accounts for this import source 
	--				that are NOT in the import table (do not deactivate
	--				accounts in error, just in case the errors are due
	--				to a problem with the import file)
	--********************************************************************************

	IF ( @InactivateNotInFile = 1 )
	BEGIN
		UPDATE dbo.tblAccountOHD 
		SET Inactive = 1
		WHERE ImportSource = @ImportSource
			  AND ImpExpFlag = 'U'
	END
	
			
	--****************************************************************
	--				Create new accounts
	--****************************************************************
	--Insert remaining (new) items in the import table into the tblAccountOHD table 
	--Use distinct AND only import the account numbers in case a file has a duplicate
	--account number.
	INSERT INTO 	tblAccountOHD (AccountNo, AccountClassID, ImpExpFlag)
	SELECT DISTINCT I.AccountNo, COALESCE(dbo.AccountClassLU_FilterByValidIds(I.AccountClassID, @XrefIds),@ModuleAccountClassID), 'P'
	FROM	tblAccountImport AS I
	WHERE	I.ImpExpFlag = 'N'

	--UPDATE the new accounts that were just added with the other information from the import table
	UPDATE	tblAccountOHD
	SET	Description = ISNULL(I.Description, A.Description),
		AccessID = ISNULL(I.AccessID, A.AccessID),
		Status = ISNULL(I.Status, A.Status),
		Title = ISNULL(I.Title, A.Title),
		FirstName = ISNULL(I.FirstName, A.FirstName),
		LastName = ISNULL(I.LastName, A.LastName),
		Phone = ISNULL(I.Phone, A.Phone),
		Fax = ISNULL(I.Fax, A.Fax),
		email = ISNULL(I.email, A.email),
		PIN = ISNULL(I.PIN, A.PIN),
		ActiveDate = ISNULL(I.ActiveDate, A.ActiveDate),
		ExpireDate = ISNULL(I.ExpireDate, A.ExpireDate),
		Process = ISNULL(I.Process, A.Process),
		Reference = ISNULL(I.Reference, A.Reference),
		Inactive = ISNULL(I.Inactive, @InactivateNewAccts),
		NoStatements = ISNULL(I.NoStatements, A.NoStatements),
		NoAging = ISNULL(I.NoAging, A.NoAging),
		NoFinanceChg = ISNULL(I.NoFinanceChg, A.NoFinanceChg),
		NoVerify = ISNULL(I.NoVerify, A.NoVerify),
		NoDetail = ISNULL(I.NoDetail, A.NoDetail),
		Bump200 = ISNULL(I.Bump200, A.Bump200),
		AutoOverpost = ISNULL(I.AutoOverpost, A.AutoOverpost),
		PublicID = ISNULL(I.PublicID, A.PublicID),
		User1 = ISNULL(I.User1, A.User1),
		User2 = ISNULL(I.User2, A.User2),
		User3 = ISNULL(I.User3, A.User3),
		User4 = ISNULL(I.User4, A.User4),
		LocationID = COALESCE(@LocationID, I.LocationID),
		ImportSource = @ImportSource
	FROM	tblAccountOHD AS A
		JOIN tblAccountImport AS I ON A.AccountNo = I.AccountNo
	WHERE	I.ImpExpFlag = 'N'

	--****************************************************************
	--	Add Account TTLs (multiple, if csv string - New accounts ONLY)
	--****************************************************************
	SET @ClassCount = dbo.DelimitedStringFieldCount ( @AccountTTL, ',' )

	WHILE @ClassCount > 0
	BEGIN
		INSERT INTO	tblAccountTTL (AccountNo, TransClassID)
		SELECT  DISTINCT I.AccountNo, CAST(dbo.GetDelimitedStringField( @AccountTTL, ',', @ClassCount) AS int)
		FROM	tblAccountImport AS I
		WHERE	I.ImpExpFlag = 'N'

		SET @ClassCount = @ClassCount - 1
	END
	

	--****************************************************************
	--		Add Outlet Class TTLs
	--****************************************************************
	-- Add an OutletClassTTL for each TransClass\OutletClass combo in the system 
	-- for each new acccount AND missing TTLs for ALL existing accounts that are ACTIVE. This way,
	-- new TransClass\OutletClass combos that surface will be added to all active accounts in the system

	DECLARE	@TempAcct	varchar(19)

	-- get all active accounts in the system
	DECLARE OutletClassAccounts cursor FOR 
		SELECT	AccountNo 
		FROM	tblAccountOHD
		WHERE	Inactive = 0

	OPEN OutletClassAccounts
	FETCH NEXT FROM OutletClassAccounts INTO @TempAcct
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC dbo.sp_Account_InsertNewOutletClassTTLs 'system', @TempAcct
		
		FETCH NEXT FROM OutletClassAccounts INTO @TempAcct
	END
	CLOSE OutletClassAccounts
	DEALLOCATE OutletClassAccounts

	--****************************************************************
	--				Add\UPDATE Badges
	--****************************************************************
	-- Strip leading zeros for NEW badges
	IF ( @StripZeros = 1 )
	BEGIN
		UPDATE  tblAccountImport
		SET	BadgeNo = CASE
				WHEN LEFT(BadgeNo,1) = '0' THEN dbo.StripLeadingZeros(BadgeNo)
				ELSE BadgeNo
			END
	END

	--Create Badges for ones that don't exist AND UPDATE existing badges
	IF (@AddBadge <> 0)
	BEGIN 
		--UPDATE existing badges
		UPDATE	tblBadgesOHD
		SET	FirstName = ISNULL(I.FirstName,''),
			LastName = ISNULL(I.LastName,''),
			Limit = ISNULL(I.CreditLimit,B.Limit),
			Inactive = ISNULL(I.Inactive, 0),
			LocationID = COALESCE(@BadgeLocationID, I.LocationID, B.LocationID) 
		FROM tblAccountImport AS I
			LEFT JOIN tblBadgesOHD AS B ON B.AccountNo = I.AccountNo
			AND B.BadgeNo = I.BadgeNo

		--Inactivate existing badges that WHERE not imported for accounts that were imported
		IF (@InactivateOldBadges = 1)
			UPDATE	tblBadgesOHD
			SET	Inactive = 1
			WHERE	AccountNo IN (SELECT AccountNo FROM tblAccountImport)
                    AND AccountNo + Badgeno NOT IN (SELECT AccountNo + BadgeNo FROM tblAccountImport)
									
		--Insert new badges into the tblBadgesOHD table for new and existing accounts
		INSERT INTO tblBadgesOHD (AccountNo, BadgeNo, FirstName, LastName, BadgeClassID,Limit, Inactive, LocationID)
		SELECT	I.AccountNo AS Acct, 
			I.BadgeNo AS Badge, 
			ISNULL(I.FirstName,''), 
			ISNULL(I.LastName,''),
			@ImportBadgeClass,
			ISNULL(I.CreditLimit,@DefaultCreditLimit),
			0,
			COALESCE(@BadgeLocationID, I.LocationID)
		FROM	tblAccountImport AS I
		WHERE  I.BadgeNo NOT IN (SELECT BadgeNo FROM tblBadgesOHD WHERE AccountNo = I.AccountNo)
	END


	--****************************************************************
	--				Add\UPDATE addresses
	--****************************************************************
	--UPDATE existing records in the tblAccountAddress table
	UPDATE 	tblAccountAddress
	SET	Address1 = ISNULL(I.Address1,AD.Address1),
		Address2 = ISNULL(I.Address2,AD.Address2),
		Address3 = ISNULL(I.Address3,AD.Address3),
		Address4 = ISNULL(I.Address4,AD.Address4),
		Address5 = ISNULL(I.Address5,AD.Address5)
	FROM	tblAccountAddress AS AD
		JOIN tblAccountImport AS I ON AD.AccountNo = I.AccountNo AND
			UPPER(AD.AddressID) = @PrimaryAddressID

	--Insert the remaining (new) items into the tblAccountAddress table (non-NULL items only)
	INSERT INTO	tblAccountAddress (AccountNo, AddressID, Address1, Address2, Address3,
						Address4, Address5)
	SELECT	AccountNo,
		@PrimaryAddressID,
		ISNULL(Address1,''),
		ISNULL(Address2,''),
		ISNULL(Address3,''),
		ISNULL(Address4,''),
		ISNULL(Address5,'')
	FROM	tblAccountImport
	WHERE	AccountNo NOT IN (SELECT  a.AccountNo
								FROM    dbo.tblAccountAddress a
										JOIN dbo.tblAccountImport i ON a.AccountNo = i.AccountNo
																	   AND a.AddressID = @PrimaryAddressID )
		    AND ISNULL(ImpExpFlag, '') <> 'E'
	

	--************************************************************
	--				UPDATE GEMdesktop
	--************************************************************
	--IF ( @UpdateGEMDesktop = 1 )
	--BEGIN
	--	EXEC pub_CreateLoginsFromAccounts
	--END


	--************************************************************
	--				Run any Post-procedures
	--************************************************************
	DECLARE PostRun cursor FOR 
		SELECT sValue FROM cfgScriptParams
		WHERE sModule = @Module 
		AND KeyName LIKE 'postproc%'
		ORDER BY sValue
	OPEN PostRun
	FETCH NEXT FROM PostRun INTO @PostProc
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC ('EXEC ' + @PostProc)
		FETCH NEXT FROM PostRun INTO @PostProc
	END
	CLOSE PostRun
	DEALLOCATE PostRun	

	--************************************************************
	--		Log import stats
	--************************************************************
	
	DECLARE @ttlRecords int,
			@ttlInError int,
			@ttlNew int
			
	SELECT @ttlRecords = COUNT(*) FROM dbo.tblAccountImport
	SELECT @ttlInError = COUNT(*) FROM dbo.tblAccountImport WHERE ISNULL(ImpExpFlag, '') = 'E'
	SELECT @ttlNew = COUNT(*) FROM dbo.tblAccountImport WHERE ISNULL(ImpExpFlag, '') = 'N'

	SET @Msg = 'Import Stats: src-[' + CAST(@ImportSource AS varchar(50)) 
				+ '] #accts-[' + CAST(@ttlRecords AS varchar(10)) 
				+ '] #Errors-[' + CAST(@ttlInError  AS varchar(10)) 
				+ '] #New-[' + CAST(@ttlNew AS varchar(10)) + ']'
	EXEC sp_Logit 0, 1, 'system', @Msg, 1000
	
	--************************************************************
	--	Prepare table for next run by setting all rows to Processed = 1
	--************************************************************
	
	UPDATE dbo.tblAccountImport SET Processed = 1
go

