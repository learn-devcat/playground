CREATE PROCEDURE [dbo].[StatusFlagsDashboardGet]
@LoginUserID VARCHAR (250)
AS
SET NOCOUNT ON

	SELECT dbo.GetStatusFlagsForDashboard()

	RETURN
go

