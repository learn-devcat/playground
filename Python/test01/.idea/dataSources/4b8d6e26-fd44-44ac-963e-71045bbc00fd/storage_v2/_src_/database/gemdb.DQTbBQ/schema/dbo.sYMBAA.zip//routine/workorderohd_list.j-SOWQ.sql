
CREATE     PROCEDURE dbo.WorkorderOHD_List
@User			char(10),
@LocationID     	int,
@LaborCtr		int = 0
AS
DECLARE	@ViewAllWorkorders	bit,
	@ViewWorkordersInClass	bit,
	@EmployeeID		int,
	@LaborCenterID		int
--Get logged on user's Employee ID
SELECT 	@EmployeeID = E.EmployeeID
FROM	tblEmployeeOHD as E
		LEFT JOIN
	cfgUsers as U On U.EmployeeNumber = E.EmployeeNumber
WHERE 	U.UserID = @User
--Get privs FROM employee class table
SELECT 	@ViewAllWorkorders 	= C.ViewAllWorkorders,
	@ViewWorkordersInClass	= C.ViewWorkordersInClass, -- this is actually filtered for Labor Center
	@LaborCenterID	= E.LaborCenterID
FROM	tblEmployeeOHD as E
		LEFT JOIN
	tblEmployeeClass as C ON C.EmployeeClassID = E.EmployeeClassID
WHERE	E.EmployeeID = @EmployeeID
--use labor center filter is labor center is passed in
IF (@LaborCtr > 0)
BEGIN
	SET @ViewAllWorkorders 		= 0
	SET @ViewWorkordersInClass 	= 1
	SET @LaborCenterID		= @LaborCtr
END
IF (@ViewAllWorkorders > 0)
	BEGIN
		--Get recordset filtered only by location AND closed status
		SELECT  WorkOrderID,
		        WorkOrderNumber,
		        LocationID,
		        WorkorderClassID,
		        ShortDescription, 
		        PO,
		        Description,
		        OpenDate,
		        OpeningEmployeeID,
		        ClosingDate,
		        ClosingEmployeeID,
		        Closed,
		        CompletionDate,
		        CompletingEmployeeID,
		        Completed,
		        Inspected,
		        InspectingEmployeeID,
		        EstimatedHours,
		        ActualHours,
		        AccountNo,
		        TransID,
		        Notes,
		        TotalCharge
	    FROM   	 tblWorkOrderOHD
	    WHERE   	LocationID IN (SELECT LocationID FROM cfgUserLocations WHERE UserID = @User) AND
	            	Closed = 0
	END
ELSE IF (@ViewWorkordersInClass > 0)
	BEGIN
		--Get recordset filtered by location, closed status AND WorkorderClass
		SELECT  WorkOrderID,
		        WorkOrderNumber,
		        LocationID,
		        WorkorderClassID,
		        ShortDescription, 
		        PO,
		        Description,
		        OpenDate,
		        OpeningEmployeeID,
		        ClosingDate,
		        ClosingEmployeeID,
		        Closed,
		        CompletionDate,
		        CompletingEmployeeID,
		        Completed,
		        Inspected,
		        InspectingEmployeeID,
		        EstimatedHours,
		        ActualHours,
		        AccountNo,
		        TransID,
		        Notes,
		        TotalCharge,
			LaborCenterID
	    FROM    	tblWorkOrderOHD
	    WHERE   	LocationID IN (SELECT LocationID FROM cfgUserLocations WHERE UserID = @User) AND
	           	 Closed = 0 AND
			LaborCenterID = @LaborCenterID
	END
ELSE
	-- Employee doesn't have view permissions, so RETURN an empty recordset
 	SELECT 	'NoPrivs' as WorkorderNumber
		
    	RETURN
go

