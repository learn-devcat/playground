

CREATE PROCEDURE dbo.ad_MealPlanDTL_List
@MealPlanID	int
AS
	SELECT	DtlID,
			MealPlanID,
			Description,
			BegTime,
			EndTime,
			NumPasses,
			TransLimit,
			Equiv,
			CountAllPasses,	
			PassesAllowed
	FROM		tblPlanDtl
	WHERE	MealPlanID = @MealPlanID
	ORDER BY	BegTime
go

