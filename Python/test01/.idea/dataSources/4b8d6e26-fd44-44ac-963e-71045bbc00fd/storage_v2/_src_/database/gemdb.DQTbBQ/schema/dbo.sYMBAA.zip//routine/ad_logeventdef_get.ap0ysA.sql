CREATE  PROCEDURE dbo.ad_LogEventDef_Get
@EventID	int = -1
AS 
	IF @EVENTID = -1
	BEGIN
		SELECT	EventID,
			[Description]
		FROM	dbo.tblLogEventDEF
		ORDER BY [Description]
	END
	ELSE
	BEGIN
		SELECT	EventID,
			[Description]
		FROM	dbo.tblLogEventDEF
		WHERE	EventID = @EventID
	END
go

