
----------------------------------------------------------------------------------
--
--  dDateOnly                  13-Aug-03 w.j.scott
--
--  Return strictly the date portion of the passed in date.
--  This is required when checking fields that may also
--  have a time.  
--
--      NOTE: If a date/time field is created without a 
--            time value, it defaults to 00:00, so any
--            datetime field that contains a time will be 
--            GREATER than one without a time attached. 
--
-----------------------------------------------------------------------------------

CREATE FUNCTION dbo.dDateOnly (@WholeDate as datetime)
RETURNS datetime
AS 
BEGIN 
	RETURN
	CAST(DATEPART(year,@WholeDate) AS varchar(4)) + '/' +
	CAST(DATEPART(month,@WholeDate) AS varchar(2)) + '/' + CAST(DATEPART(day,@WholeDate) AS varchar(2))
	 
END
go

