CREATE PROCEDURE [dbo].[ad_Vendors_List]
AS
	SELECT		[ID],
				[Description],
				[Notes]
	FROM		dbo.tblVendors
	ORDER BY	[Description]
go

