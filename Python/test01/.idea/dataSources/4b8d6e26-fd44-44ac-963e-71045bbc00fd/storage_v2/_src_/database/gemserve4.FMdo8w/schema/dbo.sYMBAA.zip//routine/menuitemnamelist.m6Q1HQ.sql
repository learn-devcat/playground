CREATE PROCEDURE [dbo].[MenuItemNameList]
AS
SET NOCOUNT ON

	SELECT	POSMenuItemID,
			[Description]
	FROM	dbo.tblMenuItemOHD
	WHERE	POSMenuItemID > 0
	ORDER BY [Description]
	
	RETURN
go

