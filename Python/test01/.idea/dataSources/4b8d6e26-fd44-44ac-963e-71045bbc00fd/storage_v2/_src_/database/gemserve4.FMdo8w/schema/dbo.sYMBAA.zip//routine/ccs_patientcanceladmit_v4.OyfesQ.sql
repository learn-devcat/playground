

CREATE PROCEDURE [dbo].[CCS_PatientCancelAdmit_v4]
@PatientVisitID varchar(50),
@Source         varchar(50),
@ConnectionName	varchar(50)=''

AS
    DECLARE @PatientID	int,
	@Msg varchar(250),
            @Today datetime,
	@RoomID int

    SET @Today = getdate()

    -- If this patient does not exist in our system, then log an error
    IF NOT EXISTS (SELECT 1 FROM dbo.tblPatientVisit WHERE PatientVisitID = @PatientVisitID) 
    BEGIN
        SET @Msg = 'Unable to process Cancel Admit for PatientVisitID:' + @PatientVisitID + '. Patient Visit does not exist.'
        GOTO TransError
    END

	SELECT @PatientID = PatientID,
		@RoomID = RoomID
	FROM dbo.tblPatientVisit
	WHERE PatientVisitID = @PatientVisitID
        
    -- Archive the Patient Visit
	UPDATE dbo.tblPatientVisit
	SET ArchiveDate = @Today,
		DischargeDate = @Today,
		LastUpdateBy = @Source
	WHERE PatientVisitID = @PatientVisitID
	    
	EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, @PatientVisitID, @RoomID, 'Admit canceled.'
	EXEC dbo.ProcessLogInsert @Source

    RETURN
    
TransError:
	IF (@Msg IS NULL)    
	SET @Msg = 'Unable to process Cancel Admit for PatientID: ' + CAST(@PatientID AS varchar(20))
	
	SET @ConnectionName = 'Idt' + @ConnectionName
	EXEC dbo.WorkstationUpdateByID @ConnectionName

	EXEC dbo.Logit 1, @Msg, 'system'


go

