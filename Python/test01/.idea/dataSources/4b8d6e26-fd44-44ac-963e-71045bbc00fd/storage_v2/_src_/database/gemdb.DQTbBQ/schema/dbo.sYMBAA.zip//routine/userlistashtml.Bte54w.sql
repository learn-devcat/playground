CREATE PROCEDURE [dbo].[UserListAsHTML] 
AS
BEGIN
	SET NOCOUNT ON;
    DECLARE @UserID varchar(50)
DECLARE @UserName varchar(50)
DECLARE @MenuGroup int
DECLARE @Results varchar(7000)

	SET @Results = '<table border="1"><thead><tr><td>User ID</td><td>User Name</td><td>Menu Group</td></tr></thead>'

	DECLARE sUsers cursor FOR
		SELECT 	UserID,UserName,MenuGroup
				FROM	cfgUsers
				order by SlotNo
				
		OPEN sUsers
		
		FETCH NEXT FROM sUsers INTO @UserID, @UserName, @MenuGroup
	
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			SET @Results = @Results + '<tr><td>' +  @UserID + '</td><td>' + @UserName + '</td><td>' + CAST( @MenuGroup as varchar(5)) + '</td></tr>'
			
			FETCH NEXT FROM sUsers INTO @UserID , @UserName, @MenuGroup
		END
		CLOSE sUsers
		DEALLOCATE sUsers

	SET @Results = @Results + '</table>'

	SELECT @Results

END
go

