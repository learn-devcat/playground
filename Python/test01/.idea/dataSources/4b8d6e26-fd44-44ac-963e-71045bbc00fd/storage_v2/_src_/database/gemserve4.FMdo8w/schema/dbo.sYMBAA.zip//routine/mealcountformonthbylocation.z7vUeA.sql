
CREATE FUNCTION [dbo].[MealCountForMonthByLocation](@WhatMonth as int, @WhatYear as int, @LocationID as int)
RETURNS int
BEGIN
	DECLARE @Return int

	-- Patient Orders
	SELECT @Return = COUNT([Date])
	FROM dbo.tblOrderLOG AS L (NOLOCK)
	JOIN dbo.tblOrderOHD AS O (NOLOCK) ON L.OrderID = O.OrderID
	WHERE MONTH([Date]) = @WhatMonth
		AND YEAR([Date]) = @WhatYear
		AND COALESCE(L.RoomID, -1) IN (SELECT RoomID FROM dbo.tblRoomOHD WHERE LocationClassID = @LocationID)
		AND dbo.GetActionID('RECEIVED') = ActionID
		AND COALESCE(O.OrderType,1) = 1

--	SELECT @Return = @Return + COUNT(L.[Date])
--	FROM dbo.tblArchive_OrderLOG AS L (NOLOCK)
--	JOIN dbo.tblArchive_PatientOHD AS P (NOLOCK) ON P.PatientArchiveID = L.PatientArchiveID
--	WHERE MONTH(L.[Date]) = @WhatMonth
--		AND YEAR(L.[Date]) = @WhatYear
--		AND COALESCE(P.RoomID, -1)  IN (SELECT RoomID FROM dbo.tblRoomOHD WHERE LocationClassID = @LocationID)
--		AND dbo.GetActionID('RECEIVED') = ActionID

	RETURN COALESCE(@Return, 0)
END
go

