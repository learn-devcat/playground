



CREATE  PROCEDURE dbo.ad_Application_Get
@User		char(10),
@ApplicationID	int = -1
AS 
	IF @ApplicationID = -1
	BEGIN
		SELECT	ApplicationID,
			[Description]
		FROM	dbo.cfgApplications
		ORDER BY [Description]
	END
	ELSE
	BEGIN
		SELECT	ApplicationID,
			[Description]
		FROM	dbo.cfgApplications
		WHERE	ApplicationID = @ApplicationID
	END
go

