CREATE PROCEDURE [dbo].[ad_Vending_ListByTransID] @TransID int
AS 
    SELECT  ID ,
            [Description] ,
            VendorID ,
            MachineTAG ,
            AccountClassID ,
            BadgeClassID ,
            OutletNo ,
            TransID ,
            LocationID ,
            InActive ,
            RefundAllowed ,
            MaxItemPrice ,
            Comment
    FROM    dbo.tblVendingDTL
    WHERE   TransID = @TransID
go

