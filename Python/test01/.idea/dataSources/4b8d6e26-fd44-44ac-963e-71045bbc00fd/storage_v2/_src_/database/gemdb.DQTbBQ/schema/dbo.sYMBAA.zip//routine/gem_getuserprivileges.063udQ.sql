

CREATE PROCEDURE dbo.gem_GetUserPrivileges
@UserID		char(10),
@Application	int = 1,
@Category	int = 0
AS
	SET NOCOUNT ON
	SELECT DISTINCT	A.ActionID, A.ActionKey
	FROM	tblPrivilegeClassMembers AS M
		JOIN tblPrivilegeLinks AS PL ON M.PrivilegeClassID = PL.PrivilegeClassID
		JOIN tblPrivilegeActions AS A ON PL.ActionID = A.ActionID
	WHERE	M.UserID = @UserID
		AND PL.Application = @Application
go

