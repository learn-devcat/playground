CREATE PROCEDURE [dbo].[LocationMenuItemDelete]
@LoginUserId VARCHAR (250), @LocationMenuItemID INT
AS
DELETE dbo.[tblLocationMenuItems]
	WHERE [LocationMenuItemID] = @LocationMenuItemID
go

