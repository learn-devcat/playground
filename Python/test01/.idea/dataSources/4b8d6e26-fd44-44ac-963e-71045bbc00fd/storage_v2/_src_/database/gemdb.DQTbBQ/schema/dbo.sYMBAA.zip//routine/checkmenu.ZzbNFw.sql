

CREATE FUNCTION dbo.CheckMenu (@MenuID int) 
RETURNS bit 
AS 
BEGIN 
	DECLARE	@Test 	int,
			@Ret	bit
	SELECT 	@Test = SecurityLevel
	FROM		cfgMenus
	WHERE	MenuID = @MenuID
	IF (@Test IS NULL)
		SET @Ret = 0
	ELSE
		SET @Ret = 1
	RETURN @Ret		
END
go

