

CREATE PROCEDURE dbo.sp_CycleNo_CurrentCycle
@User 		char(10),
@Offset		int=0
AS
	DECLARE @CoreID	int
	SELECT @CoreID=dbo.GetCoreIDFromUser(@User) 
	EXEC dbo.sp_CycleNo_GetCycle @CoreID,@Offset
go

