

CREATE FUNCTION dbo.GetTSRow(@Location as int)
RETURNS int
AS
BEGIN
	DECLARE @Return	int,
		@Temp	varchar(50)

	SELECT @Temp = KeyOut
	FROM	dbo.tblXlat
	WHERE	KeyIn = CAST(@Location AS varchar(10))
		AND xlatID = 'Touchscreen'

	RETURN CAST(ISNULL(@Temp,0) AS int)
END
go

