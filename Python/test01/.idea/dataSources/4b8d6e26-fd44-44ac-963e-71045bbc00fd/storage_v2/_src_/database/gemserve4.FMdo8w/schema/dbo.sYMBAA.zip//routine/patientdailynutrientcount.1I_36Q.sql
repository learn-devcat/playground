CREATE FUNCTION dbo.PatientDailyNutrientCount(@PatientID int, @Today datetime, @FieldSeparator char(1))
RETURNS varchar(255)
BEGIN

	DECLARE @Return 	varchar(255),
		@NutrientID	int,
		@Qty		decimal(10,3)

	SET @Return = ''

	-- Cursor to retrieve all nutrients and dailymax for the diet
	DECLARE Nutrients cursor FOR
		SELECT N.NutrientID, SUM(P.Qty) AS Qty
		FROM dbo.cfgNutrients AS N (NOLOCK)
			LEFT JOIN dbo.tblPatientNutrientCount AS P (NOLOCK) ON P.PatientID = @PatientID
				AND N.NutrientID = P.NutrientID
				AND dbo.dDateOnly([Date]) = dbo.dDateOnly(@Today)
				AND P.OrderID IN (SELECT OrderID FROM dbo.tblOrderOHD
					WHERE PatientID = @PatientID
					AND dbo.dDateOnly(OrderDate) = dbo.dDateOnly(@Today)	
					AND COALESCE(Cancelled,0) = 0)
		GROUP BY N.NutrientID
		ORDER BY N.NutrientID

	OPEN Nutrients
	FETCH NEXT FROM Nutrients INTO @NutrientID, @Qty

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @Return = @Return +@FieldSeparator + CAST(ISNULL(CAST(@Qty * 1000 AS int), 0) AS varchar(10))
		
		FETCH NEXT FROM Nutrients INTO @NutrientID, @Qty
	END

	CLOSE Nutrients
	DEALLOCATE Nutrients

	IF (LEN(@Return) > 0)
		SET @Return = RIGHT(@Return,LEN(@Return)-1)

	RETURN @Return	
END
go

