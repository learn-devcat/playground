
CREATE PROCEDURE dbo.MenuItemAllergenList
@MenuItemID	int

AS
	SET NOCOUNT ON

	SELECT A.AllergenID,
		A.[Description],
		CASE WHEN M.AllergenID IS NOT NULL THEN 1
			ELSE 0
		END AS Checked
	FROM	dbo.cfgAllergens AS A (NOLOCK)
		LEFT JOIN dbo.tblMenuItemAllergens AS M (NOLOCK) ON A.AllergenID = M.AllergenID
			AND M.MenuItemID = @MenuItemID
	ORDER BY A.[Description]

	RETURN
go

