

CREATE PROCEDURE dbo.DietMaxNutrientsGet
@DietID	int
AS
	SET NOCOUNT ON

	SELECT	N.NutrientID,
		N.[Description],
		COALESCE(D.DailyMax,N.DefaultQty) AS MaxQty,
		CASE 
			WHEN D.DailyMax IS NULL THEN 1
			ELSE 0
		END AS IsDefault
	FROM	dbo.cfgNutrients AS N (NOLOCK) 
		LEFT JOIN dbo.tblDietDailyNutrients AS D (NOLOCK) ON D.NutrientID = N.NutrientID
			AND D.DietID = @DietID
	ORDER BY N.NutrientID

	RETURN
go

