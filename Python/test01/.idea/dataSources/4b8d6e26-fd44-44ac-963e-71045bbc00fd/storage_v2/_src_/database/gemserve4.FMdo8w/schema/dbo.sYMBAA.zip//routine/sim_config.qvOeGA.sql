
CREATE PROCEDURE [dbo].[sim_Config]
@CoreID		int,
@LoginUserID	varchar(250)
AS

	SET NOCOUNT ON

	DECLARE @ReturnMsg	varchar(8000),
			@KeyID		varchar(100),
			@Value		varchar(100),
			@Count		int

	SELECT @Count = COUNT(KeyID) FROM dbo.cfgSIMOverhead
	SET @ReturnMsg = CAST(@Count as varchar(4)) + char(28)

	DECLARE Items CURSOR FOR
		SELECT KeyID, Value
		FROM dbo.cfgSIMOverhead
		ORDER BY SimID

	OPEN Items

	FETCH NEXT FROM Items INTO @KeyID, @Value

	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @ReturnMsg = @ReturnMsg + @KeyID + ',' + @Value + char(28)

		FETCH NEXT FROM Items INTO @KeyID, @Value
	END

	CLOSE Items
	DEALLOCATE Items

	IF ( RIGHT( @ReturnMsg,1 ) = char(28))
		SET @ReturnMsg = LEFT(@ReturnMsg, LEN(@ReturnMsg) -1)

	SELECT @ReturnMsg

	RETURN
go

