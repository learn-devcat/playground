

CREATE PROCEDURE dbo.MenuItemTouchscreenDelete
@LoginUserID		varchar(250),
@MenuItemID	int,
@DietID		int,
@MenuCategoryID	int
AS
	SET NOCOUNT ON

	--DELETE	dbo.tblMenuItem_TouchScreen
	UPDATE	dbo.tblMenuItem_TouchScreen
		SET	RowStart = 0,
			ColStart = 0,
			Modified = 1
	WHERE	MenuItemID = @MenuItemID
		AND DietID = @DietID
		AND MenuCategoryID = @MenuCategoryID

	RETURN
go

