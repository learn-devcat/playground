

CREATE PROCEDURE [dbo].[gem2go_1_GetNextTransaction]
    @CoreID int = 1,
    @User char(10) = '',
    @BatchID varchar(50) = 'g2g'
AS

    SET NOCOUNT ON 

declare @ID  uniqueidentifier

   -- If we either send in a NULL or leave it blank, we will default to g2g -- 
   if( isNull( @BatchID , '' ) = '' )
      set @BatchID = 'g2g'
      

   -- Let's see if we have any transactions that need our attention... We're looking in the 
   -- g2g batch;  This can be retrieved from the calling routine, if desired;
   select top 1 @ID = DetailID
         from tblBatch
        where BatchID = @BatchID
              and posted = ' '
   order by   TransDate, AccountNo, BadgeNo


   -- Did we get a hit from the our search above?  If so, let's set the flag to I, meaning "in process" 
   -- and then get the entire record for the voyage home.

   if @@ROWCOUNT > 0
     begin
       update tblBatch
          set Posted = 'I'
        where DetailID = @ID

       select * 
        from tblBatch
       where DetailID = @ID
     end

go

