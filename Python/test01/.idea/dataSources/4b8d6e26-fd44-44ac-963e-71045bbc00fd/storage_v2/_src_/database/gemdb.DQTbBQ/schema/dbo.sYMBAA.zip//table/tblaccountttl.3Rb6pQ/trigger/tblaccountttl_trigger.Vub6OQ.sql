CREATE TRIGGER [dbo].[tblAccountTTL_Trigger]
	   ON  [dbo].[tblAccountTTL]
	   AFTER INSERT, DELETE
	AS 
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		DECLARE @CurDateTime as DateTime;
		set @CurDateTime = GETDATE();

		-- Insert statements for trigger here
			Update t
			Set t.LastUpdateDate = @CurDateTime
			FROM dbo.tblAccountOHD as t
			INNER JOIN 
			(SELECT * from INSERTED
			UNION
			SELECT * from DELETED)
			as a
			ON t.AccountNo = a.AccountNo
			;
		
	END
go

