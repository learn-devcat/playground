CREATE PROCEDURE [dbo].[ScheduledReportsIncrement]
@ScheduledReportID	int

AS   
	--local variables
   	DECLARE	@TempFrequency		char(1),
		@TempValue		int,
		@NextDate		datetime,
		@Frequency		char(3)

	SELECT @NextDate = NextDate,
		@Frequency = Frequency
	FROM dbo.tblScheduledReports
	WHERE ScheduledReportID = @ScheduledReportID

	WHILE (@NextDate < getdate())
	BEGIN
		--get the frequency values FROM the current record
		SET @TempFrequency = SUBSTRING(@Frequency, 1, 1)
		IF(LEN(@Frequency) = 1)
			SET @TempValue = 1
		ELSE
			SET @TempValue = CAST(SUBSTRING(@Frequency, 2, 2) as int)
	
		--UPDATE the frequency based on the current frequency values
		IF (@TempFrequency = 'D')		-- Daily
			SET @NextDate = DATEADD(d, @TempValue, @NextDate)
		ELSE
		BEGIN
			IF (@TempFrequency = 'W')	-- Weekly
				SET @NextDate = DATEADD(wk, @TempValue, @NextDate)
			ELSE
			BEGIN
				IF (@TempFrequency = 'M')	-- Monthly
					SET @NextDate = DATEADD(m, @TempValue, @NextDate)
				ELSE
				BEGIN
					IF (@TempFrequency = 'X' OR @TempFrequency = 'Y')
					BEGIN
						-- X,Y values are used to set up 2 months on, 1 month off pattern
						-- If the value is X, it is the first month, so increment 1 month and set value to Y
						-- If the value is Y, increment the date 2 months and set back to X
						IF (@TempFrequency = 'Y')
						BEGIN
							SET @TempValue = 2
							SET @Frequency = 'X' + RIGHT(@Frequency, LEN(@Frequency) - 1)
						END
						ELSE
						BEGIN
							SET @TempValue = 1
							SET @Frequency = 'Y' + RIGHT(@Frequency, LEN(@Frequency) - 1)
						END

						SET @NextDate = DATEADD(m, @TempValue, @NextDate)
					END
					ELSE
					BEGIN
						IF(@TempFrequency = 'Q')	-- Quarterly
							SET @NextDate = DATEADD(q, @TempValue, @NextDate)
						ELSE
						BEGIN
							IF (@TempFrequency = 'A')	-- Annually
								SET @NextDate = DATEADD(yy, @TempValue, @NextDate)
							ELSE
							BEGIN
								IF (@TempFrequency = 'T')	-- Bimonthly, 1-13th and 15 days afterward. Example: T06 would be on the 6th and 21st of each month
								BEGIN
									--if the day is less than 14, then add 15 days and UPDATE
									IF (day(@NextDate) < 14)
										SET @NextDate = DATEADD(d, 15, @NextDate)
									ELSE
									BEGIN
										--since the day is more than 13, roll it to the tempvalue date
										--increment by one month
										SET @NextDate = DATEADD(m, 1, @NextDate)
										--set the day of the month to 1st
										SET @NextDate = CAST(MONTH(@NextDate) as varchar(2)) + 
											'/' + CAST(@TempValue as varchar(2)) + 
											'/' + CAST(year(@NextDate) as varchar(4))											
									END
								END
								ELSE
								BEGIN
									IF (@TempFrequency = 'H') --Hourly
									BEGIN
										SET @NextDate = DATEADD(hh, @TempValue, @NextDate)
									END
									ELSE
									BEGIN
										IF (@TempFrequency = 'N') -- Minutes
										BEGIN
											SET @NextDate = DATEADD(n, @TempValue, @NextDate)
										END	
									END
								END
							END
						END
					END
				END
			END
		END
	END    

	-- Update table
	UPDATE dbo.tblScheduledReports
	SET NextDate = @NextDate
	WHERE ScheduledReportID = @ScheduledReportID
go

