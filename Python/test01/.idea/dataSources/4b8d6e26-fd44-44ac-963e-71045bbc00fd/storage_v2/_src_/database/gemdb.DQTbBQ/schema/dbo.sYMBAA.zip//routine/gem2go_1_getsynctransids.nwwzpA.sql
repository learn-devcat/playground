

CREATE PROCEDURE [dbo].[gem2go_1_GetSyncTransIds]
    @CoreID int ,
    @User char(10)
AS
    SET NOCOUNT ON 

		Select TransClassId,
				TransId,
				[Description],
				Payment
		From dbo.tblTransDef      
         
    return
go

