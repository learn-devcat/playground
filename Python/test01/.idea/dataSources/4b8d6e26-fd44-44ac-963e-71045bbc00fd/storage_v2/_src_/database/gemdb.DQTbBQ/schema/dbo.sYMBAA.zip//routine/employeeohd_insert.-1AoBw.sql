






CREATE      PROCEDURE dbo.EmployeeOHD_Insert
@User			char(10),
@EmployeeNumber		varchar(50),
@LocationID		int, 
@FirstName		char(15), 
@LastName		char(20),
@PhoneNumber		varchar(50),
@PagerNumber		varchar(50),
@CellNumber		varchar(50),
@eMail			varchar(128),
@EmployeeClassID	int,
@SkillLevel		int,
@UserID			varChar(128),
@Password		varchar(100),
@PasswordQuestion	varchar(128),
@PasswordAnswer		varchar(128),
@LastLogonDate		datetime,
@ExpireDate		datetime,
@ActiveDate		datetime,
@Notes			varchar(250),
@LaborCenterID		int
AS 
	INSERT INTO tblEmployeeOHD(EmployeeNumber, LocationID, FirstName, LastName, PhoneNumber,
				   PagerNumber, CellNumber, eMail, EmployeeClassID, SkillLevel, UserID, Password,
				   PasswordQuestion, PasswordAnswer, LastLogonDate, ExpireDate, ActiveDate, Notes,LaborCenterID)
				 VALUES(@EmployeeNumber, @LocationID, @FirstName, @LastName, @PhoneNumber,
					@PagerNumber, @CellNumber, @eMail, @EmployeeClassID, @SkillLevel, @UserID, @Password,
					@PasswordQuestion, @PasswordAnswer, @LastLogonDate, @ExpireDate, @ActiveDate, @Notes, @LaborCenterID)
go

