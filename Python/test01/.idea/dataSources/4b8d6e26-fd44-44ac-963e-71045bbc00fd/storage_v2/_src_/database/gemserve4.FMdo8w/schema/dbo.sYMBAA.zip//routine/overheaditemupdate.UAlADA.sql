


CREATE PROCEDURE dbo.OverheadItemUpdate
@LoginUserID		varchar(250),
@KeyID		varchar(50),
@Value		varchar(50),
@Description	varchar(128),
@Sequence	int=0

AS

	SET NOCOUNT ON

	IF (@Sequence = 0)
		SELECT @Sequence = MAX([Sequence]) + 1 FROM dbo.cfgOverhead

	UPDATE dbo.cfgOverhead 
	SET Value = @Value,
	[Description] = @Description,
	[Sequence] = @Sequence
	WHERE KeyID = @KeyID

	IF (@@ROWCOUNT = 0)
		INSERT INTO dbo.cfgOverhead (KeyID, Value, [Description], [Sequence])
		VALUES (@KeyID, @Value, @Description, @Sequence)
go

