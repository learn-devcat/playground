CREATE PROCEDURE [dbo].[MicrosIsActive]
@MicrosServer	varchar(50) = 'Micros'
AS
	SET NOCOUNT ON

	DECLARE @SQL	nvarchar(1000),
		@ReturnValue bit
	 
	SET @SQL = 'osql -S(local) -dMaster -Ugemuser -Pdiamonds2 -Q"SELECT 1 FROM ' + @MicrosServer + '..micros.mi_def"' 

	CREATE TABLE #TempMicros (dbname SYSNAME NULL) 
	 
	INSERT #TempMicros 
	    EXEC master..xp_cmdshell @SQL
	 
	IF EXISTS (SELECT 1 FROM #TempMicros WHERE LTRIM(RTRIM(dbname)) = N'master')
		SET @ReturnValue = 1
	ELSE 
		SET @ReturnValue = 0
	 
	DROP TABLE #TempMicros

	SELECT @ReturnValue AS Active

	RETURN @ReturnValue
go

