CREATE PROCEDURE [dbo].[Micros_SetDietSeqOverhead]
AS
SET NOCOUNT ON

DECLARE	@POSDietPrefix			varchar(50),
		@DietFamilyGroupSeq		varchar(50),
		@DietMajorGroupSeq		varchar(50),
		@DietMenuItemGroupSeq	varchar(50),
		@DietMenuItemTypeSeq	varchar(50),
		@DietMenuLevelClassSeq	varchar(50),
		@DietPrinterDefClassSeq	varchar(50),
		@MicrosServerName		varchar(50),
		@POSMenuEditing			varchar(50),
		@Msg					varchar(1000)

	--Get the overhead keys
	SELECT @POSMenuEditing = COALESCE(dbo.GetOverheadValueNull('POSMenuEditing'),'0')
	SELECT @MicrosServerName = COALESCE(dbo.GetOverheadValueNull('MicrosServerName'),'micros')
	SELECT @POSDietPrefix = COALESCE(dbo.GetOverheadValueNull('POSDietPrefix'),'9000000')

	--Verify that the Micros editing is allowed
	IF (@POSMenuEditing = '0')
	BEGIN
		SET @Msg = 'Micros_SetDietSeqOverhead Error: POSMenuEditing must be set to 1 to update the diet settings.'
		GOTO Finished
	END
	
	--Verify that the linked micros server exists
	IF NOT EXISTS(SELECT 1 from sys.servers where name = @MicrosServerName)	
	BEGIN
		SET @Msg = 'Micros_SetDietSeqOverhead Error: No linked Micros Server found for ' + @MicrosServerName + '.'
		GOTO Finished
	END
		
	SELECT	@DietFamilyGroupSeq = fam_grp_seq,
			@DietMajorGroupSeq = maj_grp_seq,
			@DietMenuItemGroupSeq = mi_grp_seq,
			@DietMenuItemTypeSeq = mi_type_seq,
			@DietMenuLevelClassSeq = mlvl_class_seq,
			@DietPrinterDefClassSeq = prn_def_class_seq
	FROM MicrosMenuItems
	WHERE obj_num = (@POSDietPrefix + 500)

	--Update Overhead table with settings
	UPDATE dbo.cfgOverhead
	SET Value = CASE KeyID
		WHEN 'DietFamilyGroupSeq' THEN COALESCE(@DietFamilyGroupSeq, Value)
		WHEN 'DietMajorGroupSeq' THEN COALESCE(@DietMajorGroupSeq, Value)
		WHEN 'DietMenuItemGroupSeq' THEN COALESCE(@DietMenuItemGroupSeq, Value)
		WHEN 'DietMenuItemTypeSeq' THEN COALESCE(@DietMenuItemTypeSeq, Value)
		WHEN 'DietMenuLevelClassSeq' THEN COALESCE(@DietMenuLevelClassSeq, Value)
		WHEN 'DietPrinterDefClassSeq' THEN COALESCE(@DietPrinterDefClassSeq, Value)
	END
	WHERE KeyID IN ('DietFamilyGroupSeq', 'DietMajorGroupSeq', 'DietMenuItemGroupSeq', 'DietMenuItemTypeSeq', 'DietMenuLevelClassSeq', 'DietPrinterDefClassSeq')

	--Log any of the values that return null from the MICROS
	SET @Msg = 'Micros_SetDietSeqOverhead Error: Could not set the values for the following keys in cfgOverhead because they were not found on the MICROS - ' 
	IF (@DietFamilyGroupSeq IS NULL)
		SET @Msg = @Msg + '[DietFamilyGroupSeq] '
	IF (@DietMajorGroupSeq IS NULL)
		SET @Msg = @Msg + '[DietMajorGroupSeq] '
	IF (@DietMenuItemGroupSeq IS NULL)
		SET @Msg = @Msg + '[DietMenuItemGroupSeq] '
	IF (@DietMenuItemTypeSeq IS NULL)
		SET @Msg = @Msg + '[DietMenuItemTypeSeq] '
	IF (@DietMenuLevelClassSeq IS NULL)
		SET @Msg = @Msg + '[DietMenuLevelClassSeq] '
	IF (@DietPrinterDefClassSeq IS NULL)
		SET @Msg = @Msg + '[DietPrinterDefClassSeq]'
	IF (LEN(@Msg)= 139)
		SET @Msg = 'Micros_SetDietSeqOverhead: Diet values for the cfgOverhead table set successfully!'
		
	--Display the new settings to the user	
	SELECT * 
	FROM cfgOverhead 	
	WHERE KeyID IN ('DietFamilyGroupSeq', 'DietMajorGroupSeq', 'DietMenuItemGroupSeq', 'DietMenuItemTypeSeq', 'DietMenuLevelClassSeq', 'DietPrinterDefClassSeq')
    
Finished:
    IF ( @Msg IS NOT NULL )
    BEGIN    
		SELECT @Msg AS [Message]
		EXEC dbo.Logit 1, @Msg, 'support'
    END
go

