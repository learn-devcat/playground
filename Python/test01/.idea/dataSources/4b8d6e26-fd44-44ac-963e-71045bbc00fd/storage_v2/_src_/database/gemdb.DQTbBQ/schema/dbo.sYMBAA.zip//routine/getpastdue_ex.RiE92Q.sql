CREATE FUNCTION [dbo].[GetPastDue_EX]
      (
        @AccountNo VARCHAR(19) ,
        @TransID INT ,
        @CalcDate DATETIME ,
        @OutletClassID INT = NULL
      )
RETURNS MONEY
AS 
    BEGIN
        DECLARE @Return AS MONEY ,
                @Balance AS MONEY ,
                @PastDue AS MONEY ,
                @myTransClassID AS INT ,
                @cutoffDate AS DATETIME ,
                @CurrentCharges AS MONEY ,
                @PastCharges AS MONEY ,
                @CurrentPayments AS MONEY ,
                @PastPayments AS MONEY
        
        /*
            05-Oct-12  wjs  
            Updated the entire processing routine.  Sorry!
        */

        SET @cutoffDate = CAST(MONTH(@CalcDate) AS VARCHAR(2)) + '-01-' + CAST(YEAR(@CalcDate) AS VARCHAR(4))

    -- Lets get the ClassID from the passed in TRANS id; a little backwards, I know.
        SELECT  @myTransClassID = TransClassID
        FROM    tblTransDef
        WHERE   TransID = @TransID

    -- get the current balance based on our Outlet TTL Preferences.
        IF @OutletClassID IS NULL 
           BEGIN
                 SELECT @Balance = Balance
                 FROM   tblAccountTTL
                 WHERE  AccountNo = @AccountNo
                        AND TransClassID = @myTransClassID
           END
        ELSE 
           BEGIN
                 SELECT @Balance = Balance
                 FROM   tblAccountOutletClassTTL
                 WHERE  AccountNo = @AccountNo
                        AND OutletClassID = @OutletClassID
           END

        IF ( @Balance = 0 )				-- if the balance is zero, we're assuming the account is current.
           RETURN 0

    
        IF @OutletClassID IS NULL 
           BEGIN
                 SELECT @PastCharges = SUM(CASE WHEN td.payment = 0 THEN Transtotal
                                                ELSE 0
                                           END) ,
                        @PastPayments = SUM(CASE WHEN td.payment = 1 THEN Transtotal
                                                 ELSE 0
                                            END)
                 FROM   tblDetail D
                        LEFT JOIN tblTransDef TD ON D.transid = TD.transid
                 WHERE  d.accountno = @AccountNo
                        AND d.transdate < @cutoffDate

                 SELECT @CurrentCharges = SUM(CASE WHEN td.payment = 0 THEN Transtotal
                                                   ELSE 0
                                              END) ,
                        @CurrentPayments = SUM(CASE WHEN td.payment = 1 THEN Transtotal
                                                    ELSE 0
                                               END)
                 FROM   tblDetail D
                        LEFT JOIN tblTransDef TD ON D.transid = TD.transid
                 WHERE  d.accountno = @AccountNo
                        AND d.transdate >= @cutoffDate
           END
        ELSE 
           BEGIN
                 SELECT @PastCharges = SUM(CASE WHEN td.payment = 0 THEN Transtotal
                                                ELSE 0
                                           END) ,
                        @PastPayments = SUM(CASE WHEN td.payment = 1 THEN Transtotal
                                                 ELSE 0
                                            END)
                 FROM   tblDetail D
                        LEFT JOIN tblTransDef TD ON D.transid = TD.transid
                        LEFT JOIN tblOutletOHD AS O ON D.OutletNo = O.OutletNo
                 WHERE  d.accountno = @AccountNo
                        AND O.OutletClassID = @OutletClassID
                        AND d.transdate < @cutoffDate

                 SELECT @CurrentCharges = SUM(CASE WHEN td.payment = 0 THEN Transtotal
                                                   ELSE 0
                                              END) ,
                        @CurrentPayments = SUM(CASE WHEN td.payment = 1 THEN Transtotal
                                                    ELSE 0
                                               END)
                 FROM   tblDetail D
                        LEFT JOIN tblTransDef TD ON D.transid = TD.transid
                        LEFT JOIN tblOutletOHD AS O ON D.OutletNo = O.OutletNo
                 WHERE  d.accountno = @AccountNo
                        AND O.OutletClassID = @OutletClassID
                        AND d.transdate >= @cutoffDate		
           END

        SET @PastDue = @PastCharges - ( @PastPayments + @CurrentPayments )
        SET @Return = @PastDue
        
    -- SET @Return = @myBalance - @currentCharges
    
        IF ( @Return < 0 ) 
           SET @Return = 0
        
        RETURN @Return
    END
go

