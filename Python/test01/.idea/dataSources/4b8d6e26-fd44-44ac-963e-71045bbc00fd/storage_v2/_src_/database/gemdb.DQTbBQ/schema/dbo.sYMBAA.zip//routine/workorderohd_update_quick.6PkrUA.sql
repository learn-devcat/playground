
CREATE	PROCEDURE dbo.WorkorderOHD_Update_Quick
@User			char(10),
@LocationID	        int,	
@WorkOrderID	    	int,
@WorkorderClassID	int,
@AccountNo          	char(19)	= '',
@WorkOrderNumber	varchar(25)	= '',
@ShortDescription	varchar(50)	= '',
@Description	    	varchar(250)	= '',
@LaborCenterID		int
AS
SET NOCOUNT ON
DECLARE @ErrorNum	int,
	@UserEmpID	int
	UPDATE	tblWorkorderOHD
	SET     LocationID	      	= @LocationID,	    	        
	        WorkorderClassID	= @WorkorderClassID,	
	        AccountNo             	= @AccountNo,
	        WorkOrderNumber		= @WorkOrderNumber,
	        ShortDescription	= @ShortDescription,	               
	        Description		= @Description,
		LaborCenterID		= @LaborCenterID
   	WHERE   WorkOrderID = @WorkOrderID 
	IF @@Error <> 0 
	BEGIN
		SET @ErrorNum = @@Error
		SELECT @ErrorNum
		-- TODO: Log the error here AND exit.
		RETURN
	END
    SET @ErrorNum = @@Error
    SELECT @ErrorNum
    RETURN
go

