

CREATE PROCEDURE dbo.MealPeriodDelete
@LoginUserID		varchar(250),
@MealPeriodID	int

AS

	SET NOCOUNT ON

	DELETE dbo.tblMealPeriods WHERE MealPeriodID = @MealPeriodID

	RETURN
go

