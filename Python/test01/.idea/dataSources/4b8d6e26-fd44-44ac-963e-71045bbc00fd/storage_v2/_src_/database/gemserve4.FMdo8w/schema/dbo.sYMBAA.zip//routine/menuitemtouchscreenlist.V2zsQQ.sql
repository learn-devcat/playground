

CREATE PROCEDURE dbo.MenuItemTouchscreenList
@MenuItemID	int
AS
	SET NOCOUNT ON

	DECLARE @SQL nvarchar(4000),
		@Count int

	CREATE TABLE #TS (DietID int,
			DietName varchar(50),
			MenuItemID int,
			POSMenuItemID int,
			POSMenuItemSEQ int,
			POSLegend varchar(16),
			Category1 int NOT NULL DEFAULT(0),
			Category2 int NOT NULL DEFAULT(0),
			Category3 int NOT NULL DEFAULT(0),
			Category4 int NOT NULL DEFAULT(0),
			Category5 int NOT NULL DEFAULT(0),
			Category6 int NOT NULL DEFAULT(0),
			Category7 int NOT NULL DEFAULT(0),
			Category8 int NOT NULL DEFAULT(0),
			Category9 int NOT NULL DEFAULT(0),
			Category10 int NOT NULL DEFAULT(0),
			Category11 int NOT NULL DEFAULT(0),
			Category12 int NOT NULL DEFAULT(0),
			Category13 int NOT NULL DEFAULT(0),
			Category14 int NOT NULL DEFAULT(0),
			Category15 int NOT NULL DEFAULT(0),
			Category16 int NOT NULL DEFAULT(0),
			Category17 int NOT NULL DEFAULT(0),
			Category18 int NOT NULL DEFAULT(0),
			Category19 int NOT NULL DEFAULT(0),
			Category20 int NOT NULL DEFAULT(0),
			Category21 int NOT NULL DEFAULT(0),
			Category22 int NOT NULL DEFAULT(0),
			Category23 int NOT NULL DEFAULT(0),
			Category24 int NOT NULL DEFAULT(0),
			Category25 int NOT NULL DEFAULT(0),
			Category26 int NOT NULL DEFAULT(0),
			Category27 int NOT NULL DEFAULT(0),
			Category28 int NOT NULL DEFAULT(0),
			Category29 int NOT NULL DEFAULT(0),
			Category30 int NOT NULL DEFAULT(0),
			NextScreen1 int NOT NULL DEFAULT(0),
			NextScreen2 int NOT NULL DEFAULT(0),
			NextScreen3 int NOT NULL DEFAULT(0),
			NextScreen4 int NOT NULL DEFAULT(0),
			NextScreen5 int NOT NULL DEFAULT(0),
			NextScreen6 int NOT NULL DEFAULT(0),
			NextScreen7 int NOT NULL DEFAULT(0),
			NextScreen8 int NOT NULL DEFAULT(0),
			NextScreen9 int NOT NULL DEFAULT(0),
			NextScreen10 int NOT NULL DEFAULT(0),
			NextScreen11 int NOT NULL DEFAULT(0),
			NextScreen12 int NOT NULL DEFAULT(0),
			NextScreen13 int NOT NULL DEFAULT(0),
			NextScreen14 int NOT NULL DEFAULT(0),
			NextScreen15 int NOT NULL DEFAULT(0),
			NextScreen16 int NOT NULL DEFAULT(0),
			NextScreen17 int NOT NULL DEFAULT(0),
			NextScreen18 int NOT NULL DEFAULT(0),
			NextScreen19 int NOT NULL DEFAULT(0),
			NextScreen20 int NOT NULL DEFAULT(0),
			NextScreen21 int NOT NULL DEFAULT(0),
			NextScreen22 int NOT NULL DEFAULT(0),
			NextScreen23 int NOT NULL DEFAULT(0),
			NextScreen24 int NOT NULL DEFAULT(0),
			NextScreen25 int NOT NULL DEFAULT(0),
			NextScreen26 int NOT NULL DEFAULT(0),
			NextScreen27 int NOT NULL DEFAULT(0),
			NextScreen28 int NOT NULL DEFAULT(0),
			NextScreen29 int NOT NULL DEFAULT(0),
			NextScreen30 int NOT NULL DEFAULT(0),
			Name1 varchar(32) NOT NULL DEFAULT('NONE'),
			Name2 varchar(32) NOT NULL DEFAULT('NONE'),
			Name3 varchar(32) NOT NULL DEFAULT('NONE'),
			Name4 varchar(32) NOT NULL DEFAULT('NONE'),
			Name5 varchar(32) NOT NULL DEFAULT('NONE'),
			Name6 varchar(32) NOT NULL DEFAULT('NONE'),
			Name7 varchar(32) NOT NULL DEFAULT('NONE'),
			Name8 varchar(32) NOT NULL DEFAULT('NONE'),
			Name9 varchar(32) NOT NULL DEFAULT('NONE'),
			Name10 varchar(32) NOT NULL DEFAULT('NONE'),
			Name11 varchar(32) NOT NULL DEFAULT('NONE'),
			Name12 varchar(32) NOT NULL DEFAULT('NONE'),
			Name13 varchar(32) NOT NULL DEFAULT('NONE'),
			Name14 varchar(32) NOT NULL DEFAULT('NONE'),
			Name15 varchar(32) NOT NULL DEFAULT('NONE'),
			Name16 varchar(32) NOT NULL DEFAULT('NONE'),
			Name17 varchar(32) NOT NULL DEFAULT('NONE'),
			Name18 varchar(32) NOT NULL DEFAULT('NONE'),
			Name19 varchar(32) NOT NULL DEFAULT('NONE'),
			Name20 varchar(32) NOT NULL DEFAULT('NONE'),
			Name21 varchar(32) NOT NULL DEFAULT('NONE'),
			Name22 varchar(32) NOT NULL DEFAULT('NONE'),
			Name23 varchar(32) NOT NULL DEFAULT('NONE'),
			Name24 varchar(32) NOT NULL DEFAULT('NONE'),
			Name25 varchar(32) NOT NULL DEFAULT('NONE'),
			Name26 varchar(32) NOT NULL DEFAULT('NONE'),
			Name27 varchar(32) NOT NULL DEFAULT('NONE'),
			Name28 varchar(32) NOT NULL DEFAULT('NONE'),
			Name29 varchar(32) NOT NULL DEFAULT('NONE'),
			Name30 varchar(32) NOT NULL DEFAULT('NONE'))

	-- Changed to only retrieve locations for a single diet, since menu items now must appear at the same location for all diets
	INSERT INTO #TS (DietID, DietName)
		SELECT TOP 1 POSDietID, POSDescription FROM dbo.tblDietOHD (NOLOCK) WHERE POSDietID > 0 AND Active <> 0 AND NPO <> 1 ORDER BY DietID

	UPDATE #TS
	SET 	MenuItemID = M.MenuItemID,
		POSMenuItemID = M.POSMenuItemID, 
		POSMenuItemSEQ = M.POSMenuItemSEQ,
		POSLegend = M.POSLegend
	FROM dbo.tblMenuItemOHD AS M (NOLOCK)
	WHERE M.MenuItemID = @MenuItemID

	SET @Count = 1
	
	WHILE (@Count <= 30)
	BEGIN
		SET @SQL = 'UPDATE #TS SET Category' + CAST(@Count as varchar(10)) + 
			' = ISNULL((SELECT TOP 1 dbo.GetTSLocation(T.RowStart,T.ColStart) ' +
			'FROM dbo.tblMenuItem_TouchScreen AS T (NOLOCK) ' +
			' WHERE T.MenuItemID = ' + CAST(@MenuItemID as varchar(10)) + 
			' AND T.MenuCategoryID = ' + CAST(@Count as varchar(10)) +
			' ORDER BY dbo.GetTSLocation(T.RowStart,T.ColStart) DESC),0)'

		EXEC sp_executesql @SQL

		SET @SQL = 'UPDATE #TS SET NextScreen' + CAST(@Count as varchar(10)) + 
			' = ISNULL(T.NextScreen,0) ' +
			'FROM dbo.tblMenuItem_TouchScreen AS T (NOLOCK) ' +
			' WHERE T.MenuItemID = ' + CAST(@MenuItemID as varchar(10)) + 
			' AND T.MenuCategoryID = ' + CAST(@Count as varchar(10))

		EXEC sp_executesql @SQL

		SET @SQL = 'UPDATE #TS SET Name' + CAST(@Count as varchar(10)) + ' = Description ' +
			'FROM dbo.tblMenuItemCategory (NOLOCK) ' +
			'WHERE MenuItemCategoryID = ' + CAST(@Count as varchar(10)) 

		EXEC sp_executesql @SQL

		SET @Count = @Count + 1
	END

	SELECT * FROM #TS ORDER BY DietName
	DROP TABLE #TS

	RETURN
go

