


CREATE PROCEDURE dbo.EmployeeClass_Delete
@User			char(10),
@EmployeeClassID	int
AS
	DELETE	tblEmployeeClass
	WHERE	EmployeeClassID = @EmployeeClassID
go

