
CREATE PROCEDURE [dbo].[GSI_RoomImport]
@LoginUserID		varchar(250),
@RoomID		int,
@RoomNumber	varchar(10),
@LocationClass	varchar(50),
@RoomClassID	int = 0,
@PhoneNumber	varchar(25) = null,
@IP		varchar(25) = null
AS
	SET NOCOUNT ON

	DECLARE @LocationClassID	int

	SELECT 	@LocationClassID = LocationClassID
	FROM	dbo.tblLocationClass
	WHERE	[Description] = @LocationClass

	IF (@RoomID > 0)
		UPDATE	dbo.tblRoomOHD
		SET RoomNumber = @RoomNumber,
		LocationClassID = COALESCE(@LocationClassID, R.LocationClassID),
		PhoneNumber = COALESCE(@PhoneNumber, R.PhoneNumber),
		IP = COALESCE(@IP, R.IP)
		FROM dbo.tblRoomOHD AS R
		WHERE R.RoomID = @RoomID
	ELSE
		INSERT INTO dbo.tblRoomOHD (RoomNumber, LocationClassID, RoomClassID, PhoneNumber, IP)
			VALUES (@RoomNumber, @LocationClassID, @RoomClassID, @PhoneNumber, @IP)

	RETURN
go

