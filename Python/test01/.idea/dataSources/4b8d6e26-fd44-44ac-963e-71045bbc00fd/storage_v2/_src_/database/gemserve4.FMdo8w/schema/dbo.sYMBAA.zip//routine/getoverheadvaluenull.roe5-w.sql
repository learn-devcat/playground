
CREATE FUNCTION dbo.GetOverheadValueNull(@KeyID varchar(50))
RETURNS varchar(50)
AS
	BEGIN
	    declare @Value varchar(50)
	    
	    Select @Value = Value 
	      from dbo.cfgOverhead
	     where KeyID = @KeyID
	        
	    RETURN @Value  	    
	END
go

