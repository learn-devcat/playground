






CREATE PROCEDURE dbo.sp_Recur_PostCharges
@User		char(10),
@ClassID	int
AS             
	DECLARE @AccountNo		char(19),
			@AccountClassID	int,
			@TransID		int,
			@Description	char(24),
			@Amount			money,
			@Percent		smallmoney,
			@Minimum		bit,
			@Balance		bit,
			@PastDue		bit,
			@TrackSlotNum	int,
			@TrackIDNum		int,
			@TAmount		money, 
			@T2Amount		money,
			@CheckMin		money,
			@TransAmount	money,
			@CoreID			int,
			@TransDate		datetime,
			
			@BadgeNo		char(19),
			@OutletNo		int,
			@RefNum			char(6),
			@ChkNum			char(6),
			@Comment		varchar(40),
			@DateOffset		int,
			
			@DoTax1			bit,
			@DoTax2			bit,
			@DoTax3			bit,
			@DoTax4			bit,
			@Tax1			money,
			@Tax2			money,
			@Tax3			money,
			@Tax4			money,
			
			@CycleNo		int,
			
			@Sales1			money,
			@TempNumber		int,
			@AllowNegAmt		bit,
			@BatchID		char(10),		
			@ExpiredAccountsOnly	bit,
			@PostToAltAccount	bit,
			@AltAccountNo		varchar(19),
			@AltBadgeNo		varchar(19),
			@AltTransID		int,
			@OKtoProcess		bit,
			@ExpireDate		datetime,
			@Comment2		varchar(40)
			
	
	SET @OKtoProcess = 1
	SET @CycleNo = dbo.CurrentCycleNo(1)			
	SET @TempNumber = 0
 	DECLARE sRecur1 cursor FOR   
    			SELECT	R.AccountNo, 
    					R.AcctClassID, 
    					R.TransID, 
    					R.Description,
    			    	R.Amount, 
    			    	R.[Percent], 
    			    	R.Minimum, 
    			    	R.Balance, 
    			    	R.PastDue,
    			    	R.TrackSlotNum, 
    			    	R.TrackIDNum, 
    			    	R.tax1,
    			    	R.tax2,
    			    	R.tax3,
    			    	R.tax4,
    			    	T.Preset,
				T2.Preset,
    			    	C.Dtl_ChkNum, 
    			    	C.Dtl_RefNum, 
    			    	C.Dtl_Comment,
				C.NextDate - C.DateOffset,
				R.AllowNegAmt,
				R.BatchID,
				R.ExpiredAccountsOnly,
				R.PostToAltAccount,
				R.AltAccountNo,
				R.AltBadgeNo,
				R.AltTransID
				
    			FROM	tblRecurChg AS R 
					LEFT JOIN
    				tblTransDef AS T ON R.TransID = T.TransID 
					LEFT JOIN
				tblTransDef as T2 on R.AltTransID = T2.TransID 
					LEFT JOIN
    				tblRecurChgClass AS C ON R.ClassID = C.ClassID

    			WHERE	R.ClassID = @ClassID
				AND R.Active = 1
    					
    			
	OPEN sRecur1  
	
	FETCH NEXT FROM sRecur1 INTO @AccountNo, @AccountClassID, @TransID, @Description,
					@Amount, @Percent, @Minimum, @Balance, @PastDue,
					@TrackSlotNum, @TrackIDNum, 
					@DoTax1, @DoTax2, @DoTax3, @DoTax4, @TAmount, @T2Amount,
					@RefNum, @ChkNum, @Comment, @TransDate,@AllowNegAmt,@BatchID, 
					@ExpiredAccountsOnly, @PostToAltAccount, @AltAccountNo, @AltBadgeNo, @AltTransID
	
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		--Post the amount to the tblBatch table 
		SET @CoreID = dbo.GetCoreIDFromUser(@User)
		--SET @TransDate = getdate()
	
		--IF AccountNo = "" then process for the AccountClass
		IF (@AccountNo = '')
		BEGIN
			DECLARE sAClass cursor FOR
							SELECT	AccountNo, ExpireDate
							FROM	tblAccountOHD
							WHERE	AccountClassID = @AccountClassID
									--AND Inactive = 0
							
			OPEN sAClass
			
			FETCH NEXT FROM sAClass INTO @AccountNo, @ExpireDate
			
			WHILE (@@FETCH_STATUS = 0)
			BEGIN
				-- IF account hasn't expired AND "Expired Only" is flagged then don't process
				IF (@ExpiredAccountsOnly = 1)
				BEGIN
					IF (@ExpireDate <= getdate())
						SET @OKtoProcess = 1
					ELSE
						SET @OKtoProcess = 0
				END
				
				--Get the amount to process for posting	
				SET @TransAmount = ISNULL(dbo.GetRecurAmount(@AccountNo, @AccountClassID,
							@Amount, @TransID, @PastDue, @Minimum,
							@Balance, @TrackSlotNum, @TrackIDNum, @CycleNo,getdate(),@AllowNegAmt),0)
				--IF the Percent field is greater than 0, multiply times the posting amount
				IF (@TransAmount > 0 AND @Percent > 0)
					SET @TransAmount = @TransAmount * (@Percent/100)
	
				SET @BadgeNo = ISNULL(dbo.GetFirstBadge(@AccountNo),@AccountNo)
				SET @OutletNo = ISNULL(dbo.GetOverheadItem('SystemOutlet'), 1000)
				SET @RefNum = ISNULL(@RefNum, CAST(@BatchID as char(6)))
				--SET @ChkNum = ISNULL(@ChkNum, '')
				SET @ChkNum = CAST(DATEPART(s,getdate()) AS varchar(2)) + CAST(DATEPART(ms,getdate()) AS varchar(3)) + CAST(@TempNumber AS char(1))
			
				SET @Comment = ISNULL(@Comment, @Description)
			
				IF (@TransAmount <> 0)
				BEGIN 
					IF (@DoTax1 = 1)
						BEGIN
							SET @Tax1 = CAST(dbo.GetOverheadItem('tax1') AS money)
							IF (@Tax1 > 0)
								SET @Tax1 = ROUND(((@Tax1 / 100) * @TransAmount),2)
							ELSE
								SET @Tax1 = 0
						END
					ELSE
						SET @Tax1 = 0
					IF (@DoTax2 = 1)
						BEGIN
							SET @Tax2 = CAST(dbo.GetOverheadItem('tax2') AS money)
							IF (@Tax2 > 0)
								SET @Tax2 = ROUND(((@Tax2 / 100) * @TransAmount),2)
							ELSE
								SET @Tax2 = 0
						END
					ELSE
						SET @Tax2 = 0
						
					IF (@DoTax3 = 1)
						BEGIN
							SET @Tax3 = CAST(dbo.GetOverheadItem('tax3') AS money)
							IF (@Tax3 > 0)
								SET @Tax3 = ROUND(((@Tax3 / 100) * @TransAmount),2)
							ELSE
								SET @Tax3 = 0
						END
					ELSE
						SET @Tax3 = 0
						
					IF (@DoTax4 = 1)
						BEGIN
							SET @Tax4 = CAST(dbo.GetOverheadItem('tax4') AS money)
							IF (@Tax4 > 0)
								SET @Tax4 = ROUND(((@Tax4 / 100) * @TransAmount),2)
							ELSE
								SET @Tax4 = 0
						END
					ELSE
						SET @Tax4 = 0
					SET @Sales1 = @TransAmount
					SET @TransAmount = @TransAmount + @Tax1 + @Tax2 + @Tax3 + @Tax4
					IF (LTRIM(@AccountNo) <> '') And (@OKtoProcess = 1)
					BEGIN
						--post to alternate account IF flag is SET				
						IF (@PostToAltAccount = 1 And @AltAccountNo <> '')
						BEGIN
							SET @Comment2 = RTRIM(@AltAccountNo) + ' - ' + dbo.GetAccountName(@AccountNo)
							SET @Comment = RTRIM(@AltAccountNo) + ' - ' + dbo.GetAccountName(@AltAccountNo)
							
							EXEC dbo.sp_Batch_Insert @CoreID, @User, @BatchID, @AltAccountNo,
								@AltBadgeNo, @TransDate, @OutletNo, @RefNum, @ChkNum,
								@TransAmount, @Sales1, @Comment2 , 0, @AltTransID, 0,
								' ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
								0, 0, 0, 0, 0, @Tax1, @Tax2, @Tax3, @Tax4, 0, 0
						END

						-- Post to evaluated account
					 	EXEC dbo.sp_Batch_Insert @CoreID, @User, @BatchID, @AccountNo,
								@BadgeNo, @TransDate, @OutletNo, @RefNum, @ChkNum,
								@TransAmount, @Sales1, @Comment , 0, @TransID, 0,
								' ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
								0, 0, 0, 0, 0, @Tax1, @Tax2, @Tax3, @Tax4, 0, 0
						
						
					END
						
				END
								
				FETCH NEXT FROM sAClass INTO @AccountNo, @ExpireDate	
			END
			
			CLOSE 		sAClass
			DEALLOCATE 	sAClass			
		END
		ELSE
		BEGIN  
			-- IF account hasn't expired AND "Expired Only" is flagged then don't process
			IF (@ExpiredAccountsOnly = 1)
			BEGIN
				IF (@ExpireDate <= getdate())
					SET @OKtoProcess = 1
				ELSE
					SET @OKtoProcess = 0
			END

			--Get the amount to process for posting	
			SET @TransAmount = ISNULL(dbo.GetRecurAmount(@AccountNo, @AccountClassID,
							@Amount, @TransID, @PastDue, @Minimum,
							@Balance, @TrackSlotNum, @TrackIDNum, @CycleNo,getdate(), @AllowNegAmt),0)
			--IF the Percent field is greater than 0, multiply times the posting amount
			IF (@TransAmount > 0 AND @Percent > 0)
				SET @TransAmount = @TransAmount * (@Percent/100) 
			
			SET @BadgeNo = ISNULL(dbo.GetFirstBadge(@AccountNo),@AccountNo)
			SET @OutletNo = ISNULL(dbo.GetOverheadItem('SystemOutlet'), 1000)
			SET @RefNum = ISNULL(@RefNum, CAST(@BatchID AS char(6)))
			--SET @ChkNum = ISNULL(@ChkNum, '')
			SET @ChkNum = CAST(DATEPART(s,getdate()) AS varchar(2)) + CAST(DATEPART(ms,getdate()) AS varchar(3)) + CAST(@TempNumber AS char(1))
			SET @Comment = ISNULL(@Comment, @Description)
		 
			IF (@TransAmount <> 0)
				BEGIN 
					IF (@DoTax1 = 1)
						BEGIN
							SET @Tax1 = CAST(dbo.GetOverheadItem('tax1') AS money)
							IF (@Tax1 > 0)
								SET @Tax1 = ROUND(((@Tax1 / 100) * @TransAmount),2)
							ELSE
								SET @Tax1 = 0
						END
					ELSE
						SET @Tax1 = 0
					IF (@DoTax2 = 1)
						BEGIN
							SET @Tax2 = CAST(dbo.GetOverheadItem('tax2') AS money)
							IF (@Tax2 > 0)
								SET @Tax2 = ROUND(((@Tax2 / 100) * @TransAmount),2)
							ELSE
								SET @Tax2 = 0
						END
					ELSE
						SET @Tax2 = 0
						
					IF (@DoTax3 = 1)
						BEGIN
							SET @Tax3 = CAST(dbo.GetOverheadItem('tax3') AS money)
							IF (@Tax3 > 0)
								SET @Tax3 = ROUND(((@Tax3 / 100) * @TransAmount),2)
							ELSE
								SET @Tax3 = 0
						END
					ELSE
						SET @Tax3 = 0
						
					IF (@DoTax4 = 1)
						BEGIN
							SET @Tax4 = CAST(dbo.GetOverheadItem('tax4') AS money)
							IF (@Tax4 > 0)
								SET @Tax4 = ROUND(((@Tax4 / 100) * @TransAmount),2)
							ELSE
								SET @Tax4 = 0
						END
					ELSE
						SET @Tax4 = 0
				
					SET @Sales1 = @TransAmount
					SET @TransAmount = @TransAmount + @Tax1 + @Tax2 + @Tax3 + @Tax4
				
					IF (@OKtoProcess = 1)
					BEGIN
						--post to alternate account IF flag is SET
						IF (@PostToAltAccount = 1 And @AltAccountNo <> '')
						BEGIN
							SET @Comment2 = RTRIM(@AltAccountNo) + ' - ' + dbo.GetAccountName(@AccountNo)
							SET @Comment = RTRIM(@AltAccountNo) + ' - ' + dbo.GetAccountName(@AltAccountNo)
							
							EXEC dbo.sp_Batch_Insert @CoreID, @User, @BatchID, @AltAccountNo,
								@AltBadgeNo, @TransDate, @OutletNo, @RefNum, @ChkNum,
								@TransAmount, @Sales1, @Comment2 , 0, @AltTransID, 0,
								' ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
								0, 0, 0, 0, 0, @Tax1, @Tax2, @Tax3, @Tax4, 0, 0
						END
						
						-- Post to evaluated account
					 	EXEC dbo.sp_Batch_Insert @CoreID, @User, @BatchID, @AccountNo,
								@BadgeNo, @TransDate, @OutletNo, @RefNum, @ChkNum,
								@TransAmount, @Sales1, @Comment , 0, @TransID, 0,
								' ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
								0, 0, 0, 0, 0, @Tax1, @Tax2, @Tax3, @Tax4, 0, 0
						
					END
							
				END
	END
	-- Increment our tempnumber, which is used to guarantee a unique transaction key
	IF (@TempNumber = 9)
		SET @TempNumber = 0
	ELSE
		SET @TempNumber = @TempNumber + 1
		--Get the next record FROM the cursor
	FETCH NEXT FROM sRecur1 INTO @AccountNo, @AccountClassID, @TransID, @Description,
					@Amount, @Percent, @Minimum, @Balance, @PastDue,
					@TrackSlotNum, @TrackIDNum, 
					@DoTax1, @DoTax2, @DoTax3, @DoTax4, @TAmount, @T2Amount,
					@RefNum, @ChkNum, @Comment, @TransDate,@AllowNegAmt,@BatchID,
					@ExpiredAccountsOnly, @PostToAltAccount, @AltAccountNo, @AltBadgeNo, @AltTransID
	END
	 
	CLOSE 		sRecur1
	DEALLOCATE 	sRecur1
go

