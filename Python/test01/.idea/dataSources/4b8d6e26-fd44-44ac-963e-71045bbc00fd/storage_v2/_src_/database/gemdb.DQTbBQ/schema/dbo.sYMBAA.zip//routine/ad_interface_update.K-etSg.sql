

CREATE PROCEDURE dbo.ad_Interface_Update
@User			char(10),
@CoreID		int,
@InterfaceID		int,
@Active		bit,
@Description		varchar(32),
@Category		char(10),
@Contact		varchar(200),
@myIP			char(15),
@ExceptionIP		char(15),
@GatewayIP		char(15),
@PrinterIP		char(15),
@SysOptions		char(10)
AS
	UPDATE	cfgInterface
	SET		CoreID = @CoreID,
			Active = @Active,
			Description = @Description,
			Category = @Category,
			Contact = @Contact,
			myIP = @myIP,
			ExceptionIP = @ExceptionIP,
			GatewayIP = @GatewayIP,
			PrinterIP = @PrinterIP,
			SysOptions = @SysOptions
	WHERE	InterfaceID = @InterfaceID
go

