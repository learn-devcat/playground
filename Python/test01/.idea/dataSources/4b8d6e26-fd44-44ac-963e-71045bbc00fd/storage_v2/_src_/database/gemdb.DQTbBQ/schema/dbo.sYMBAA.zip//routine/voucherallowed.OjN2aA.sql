

CREATE FUNCTION dbo.VoucherAllowed(@MealPlanID int)
RETURNS bit
AS 
BEGIN 
	DECLARE 	@Return 	bit,
			@Temp		varchar(10)
	
	SELECT	@Temp = sValue
	FROM 		cfgOverhead
	WHERE	RIGHT(oKey,LEN(oKey) - 2) = CAST(@MealPlanID AS varchar(5))
	IF (@@ROWCOUNT = 0)
		SET @Return = 0
	ELSE
		SET @Return = 1
	RETURN @Return
	
END
go

