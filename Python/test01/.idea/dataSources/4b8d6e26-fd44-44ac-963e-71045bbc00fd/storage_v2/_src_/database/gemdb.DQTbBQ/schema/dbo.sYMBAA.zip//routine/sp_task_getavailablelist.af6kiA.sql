CREATE PROCEDURE [dbo].[sp_Task_GetAvailableList]
	@User char(10)
AS
	DECLARE @UserRole int
	
	-- get the user's max role id
	SELECT @UserRole = MAX(PrivilegeClassId)
	FROM dbo.tblPrivilegeClassMembers
	WHERE UserID = @User;

	SELECT O.TaskId, M.Message AS TaskName, O.CategoryId  
	FROM dbo.TaskOHD AS O
	LEFT JOIN dbo.tblMessages AS M
		ON M.ID = O.TaskName AND M.PageID = 'Tasks'
	WHERE @UserRole >= O.MinPrivilegeClass
		AND O.TaskId NOT IN (
			SELECT TaskId	
			FROM dbo.Tasks
			WHERE EntryId = @User)
	ORDER BY O.CategoryId, O.Sequence, O.TaskType, M.Message
go

