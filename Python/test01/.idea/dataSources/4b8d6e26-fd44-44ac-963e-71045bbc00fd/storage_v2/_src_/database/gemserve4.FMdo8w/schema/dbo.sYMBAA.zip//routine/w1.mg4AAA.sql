

CREATE PROCEDURE w1 @p1 [varchar] (50),@p2 [varchar] (50),@p3 [varchar] (50),@p4 [varchar] (50)
AS
IF NOT EXISTS (SELECT 1 FROM dbo.tblXlat WHERE xlatID = @p1 AND KeyIn = @p2)
	INSERT INTO [dbo].[tblXlat] (xlatID, KeyIn, KeyOut, Description)
	VALUES (@p1,@p2,@p3,@p4)
go

