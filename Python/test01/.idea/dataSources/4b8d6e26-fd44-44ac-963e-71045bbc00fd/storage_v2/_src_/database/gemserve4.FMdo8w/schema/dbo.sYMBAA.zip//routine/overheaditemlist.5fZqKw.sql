


CREATE PROCEDURE dbo.OverheadItemList
@LoginUserID		varchar(250)

AS
	SET NOCOUNT ON

	SELECT KeyID, Value, Sequence, Description
	FROM dbo.cfgOverhead (NOLOCK)
	ORDER BY Sequence

	RETURN
go

