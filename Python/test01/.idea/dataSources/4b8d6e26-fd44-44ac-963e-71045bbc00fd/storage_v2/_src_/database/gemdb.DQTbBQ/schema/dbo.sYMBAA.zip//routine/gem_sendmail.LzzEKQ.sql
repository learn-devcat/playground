

CREATE PROCEDURE dbo.gem_SendMail
@sFrom		nvarchar(100),
@sFromName	nvarchar(100),
@sTo		nvarchar(100),
@sSubject	nvarchar(100),
@sMessage	nvarchar(2000),
@sType	nvarchar(50) = 'text/plain'
AS
	DECLARE @rc 		int,
		@MailServer	nvarchar(200)
	SELECT @MailServer = sValue
	FROM	cfgOverhead
	WHERE	oKey = 'MailServer'
	IF ( ISNULL(@MailServer,'0') <> '0' )
	BEGIN
		EXEC @rc = master.dbo.xp_smtp_sendmail
			@FROM			= @sFrom,
			@FROM_NAME		= @sFromName,
			@TO			= @sTo,
			@subject		= @sSubject,
			@message		= @sMessage,
			@type			= @sType,
			@server 		= @MailServer
	
		RETURN @rc
	END
	ELSE
		RETURN -2
go

