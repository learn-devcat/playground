

CREATE PROCEDURE dbo.sp_Users_List
AS
	SELECT	UserID,UserName
	FROM		cfgUsers
--	WHERE 	UserID<>'support'
	ORDER BY 	UserID
go

