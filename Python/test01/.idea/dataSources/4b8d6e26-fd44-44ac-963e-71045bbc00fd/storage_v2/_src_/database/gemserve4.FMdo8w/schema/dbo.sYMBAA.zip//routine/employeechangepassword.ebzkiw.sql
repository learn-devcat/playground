

CREATE PROCEDURE dbo.EmployeeChangePassword
@LoginUserID     varchar(250),
@Password   varchar(200),
@NewPassword    varchar(200)

AS
	SET NOCOUNT ON 
	
	DECLARE @Return int
	
	IF EXISTS (SELECT LoginUserID FROM dbo.tblEmployees WHERE LoginUserID = @LoginUserID AND [Password] = @Password)
	BEGIN
	    UPDATE dbo.tblEmployees
	        SET [Password] = @NewPassword
		WHERE   LoginUserID = @LoginUserID
		
		SET @Return = 0
	END
	ELSE
	    SET @Return = 1
	    
	SELECT @Return
	RETURN
go

