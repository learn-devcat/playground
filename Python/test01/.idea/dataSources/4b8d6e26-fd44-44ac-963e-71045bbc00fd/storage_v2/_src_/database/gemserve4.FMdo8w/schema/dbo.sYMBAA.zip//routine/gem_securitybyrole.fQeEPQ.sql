CREATE PROCEDURE [dbo].[GEM_SecurityByRole]
AS
        DECLARE @Count int,
                @Role varchar(50),
                @RoleID int,
                @SQL nvarchar(1000)
        
        CREATE TABLE #Temp (ActionID int,
                             ActionKey varchar(50),
                             [Description] varchar(50),
                             Category varchar(100),
                             Marker int)
        
        INSERT INTO #Temp (ActionID, ActionKey, [Description], Category, Marker)
                SELECT A.ActionID, A.ActionKey, A.[Description], C.[Description], 0 
		FROM dbo.tblSecurityActions AS A
                JOIN dbo.tblSecurityCategories AS C ON A.CategoryID = C.CategoryID
                ORDER BY C.SortOrder, C.[Description],A.ActionKey
        
        SET @Count = 1
        
        DECLARE role CURSOR FOR
                SELECT RoleID, [Description] FROM GEM.dbo.tblRoles
        
        OPEN role
        FETCH NEXT FROM ROLE INTO @RoleID, @Role
        
        WHILE (@@FETCH_STATUS=0)
        BEGIN
                SET @SQL = 'ALTER TABLE #Temp ADD RoleID' + CAST(@Count as varchar(10)) + ' int, Role' + CAST(@Count as varchar(10)) + ' varchar(50), Value' + CAST(@Count as varchar(10)) + ' bit'
                EXEC sys.sp_executesql @SQL 
        
                SET @SQL = 'UPDATE #Temp SET RoleID' + CAST(@Count as varchar(10)) + '=' + CAST(@RoleID as varchar(10)) + 
                        ',Role' + CAST(@Count as varchar(10)) + '=''' + @Role + ''',Value'  + CAST(@Count as varchar(10)) + '=0'
                EXEC sys.sp_executesql @SQL 
        
                SET @SQL = 'UPDATE #Temp SET Value' + CAST(@Count as varchar(10)) + ' = CASE WHEN RA.RoleID IS NULL THEN 0 ELSE 1 END
                FROM #Temp AS T 
                JOIN GEM.dbo.tblRoles AS R ON R.[Description] = T.Role' + CAST(@Count as varchar(10)) + 
                ' JOIN dbo.tblSecurityRoleActions AS RA ON RA.RoleID = R.RoleID AND RA.ActionID = T.ActionID'
        
                EXEC sys.sp_executesql @SQL 
        
                SET @Count = @Count + 1
        
                FETCH NEXT FROM ROLE INTO @RoleID, @Role
        END
        
        CLOSE role
        DEALLOCATE role


        WHILE (@Count < 13)
        BEGIN
               SET @SQL = 'ALTER TABLE #Temp ADD RoleID' + CAST(@Count as varchar(10)) + ' int, Role' + CAST(@Count as varchar(10)) + ' varchar(50), Value' + CAST(@Count as varchar(10)) + ' bit'
                EXEC sys.sp_executesql @SQL 

                SET @SQL = 'UPDATE #Temp SET Value'  + CAST(@Count as varchar(10)) + '=0'
                EXEC sys.sp_executesql @SQL 

                SET @Count = @Count + 1
        END

        SELECT * FROM #Temp ORDER BY Category, [Description]
        DROP TABLE #Temp

        RETURN
go

