




CREATE    PROCEDURE dbo.ad_SIMXlat_Edit
@User			char(10),
@Active			bit,
@Locked			bit,
@Description		varchar(50),
@Category		char(10),
@CoreID			int,
@ExistingSimID		char(24),
@NewSimID		char(24),
@sp			varchar(250),
@Status			int,
@NumParms		smallint,
@ActiveDate		datetime,
@ExpireDate		datetime,
@LocationBlock		varchar(128),
@DELETE			bit = 0

AS 
	DECLARE @SimID char(24),
		@Message varchar(255)

	IF @DELETE = 1
		GOTO DODELETE

	IF (@NewSimID > '' AND @ExistingSimID = '')
	BEGIN
		INSERT dbo.cfgSIMXlat
		VALUES(@Active,
			@Locked,
			@Description,
			@Category,
			@CoreID,
			@NewSimID,
			@sp,
			@Status,
			@NumParms,
			@ActiveDate,
			@ExpireDate,
			@LocationBlock)

		SELECT @Message = 	'New SIMXlat Item Added: (' + SimID + ') ' +  [Description]
					FROM	dbo.cfgSIMXlat
					WHERE	SimID = @NewSimID
	END
	ELSE
	BEGIN

		SET @SimID = CASE 
				WHEN @NewSimID > ''
				THEN @NewSimID
				ELSE @ExistingSimID
			     END
		UPDATE	dbo.cfgSIMXlat
		SET	Active = @Active,
			Locked = @Locked,
			[Description] = @Description,
			Category = @Category,
			CoreID = @CoreID,
			SimID = @SimID,
			sp = @sp,
			Status = @Status,
			NumParms = @NumParms,
			ActiveDate = @ActiveDate,
			[ExpireDate] = @ExpireDate,
			LocationBlock = @LocationBlock
		WHERE	SimID = @ExistingSimID

		SELECT @Message = 	('Edit of SimID (' + @SimID + ') ' + 
					CASE WHEN (SELECT SimID FROM dbo.cfgSIMXlat WHERE SimID = @SimID) IS NULL
					     THEN 'FAILED'
					     ELSE 'SUCCEDED'
					     END)
	END

	EXEC dbo.sp_Logit 9, 1, @User, @Message, 1010	
	SELECT @Message AS 'Rtn'

	RETURN

	DODELETE:
	DELETE	dbo.cfgSIMXlat
	WHERE	SimID = @ExistingSimID

	IF EXISTS (SELECT * FROM dbo.cfgSIMXlat WHERE SimID = @ExistingSimID)
		SELECT @Message = 'DELETE Sim Item (' + @ExistingSimID + ') Failed'
	ELSE
		SELECT @Message = 'DELETE Sim Item (' + @ExistingSimID + ') Succeded'

	
	EXEC dbo.sp_Logit 9, 1, @User, @Message, 1010	
	SELECT @Message AS 'Rtn'
go

