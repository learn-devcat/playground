

CREATE PROCEDURE dbo.DietMaxNutrientDelete
@LoginUserID		varchar(250),
@DietID		int,
@NutrientID	int
AS
	SET NOCOUNT ON

	DELETE dbo.tblDietDailyNutrients
	WHERE	DietID = @DietID
		AND NutrientID = @NutrientID

	RETURN
go

