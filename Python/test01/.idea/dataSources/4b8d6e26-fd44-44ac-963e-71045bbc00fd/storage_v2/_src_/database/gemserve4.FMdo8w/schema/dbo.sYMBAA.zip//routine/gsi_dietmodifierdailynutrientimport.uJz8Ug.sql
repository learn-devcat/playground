
CREATE PROCEDURE [dbo].[GSI_DietModifierDailyNutrientImport]
@LoginUserID		varchar(250),
@DietModifierCode	varchar(100),
@NutrientName	varchar(50),
@DailyMax	decimal(10,3)
AS
	SET NOCOUNT ON

	DECLARE @NutrientID int,
			@Return		int
			
	SET @Return = -1

	SELECT 	@NutrientID = NutrientID
	FROM	dbo.cfgNutrients
	WHERE	[Description] = @NutrientName

	-- Return -1 if nutrient doesn't exist
	IF (@@RowCount = 0)
	BEGIN
		SET @Return = -1
		GOTO Finished
	END

	IF NOT EXISTS (SELECT 1 FROM dbo.tblXLAT WHERE xlatID = 'ModifierNutrientID' AND KeyIn = @DietModifierCode AND KeyOut = CAST(@NutrientID AS varchar(100)))
	BEGIN
		INSERT INTO dbo.tblXLAT (xlatID, KeyIn, KeyOut, Description)
			VALUES ('ModifierNutrientID', @DietModifierCode, CAST(@NutrientID AS varchar(100)), @DailyMax)

		SELECT @Return = SCOPE_IDENTITY()
	END
	ELSE
	BEGIN
		-- Return -3 if XLAT entry already exists
		SET @Return = -3
	END

Finished:
	-- Return -1 if Nutrient doesn't exist, -3 if XLAT entry already exists,  otherwise return id
	SELECT @Return AS ErrorMessage
	RETURN
go

