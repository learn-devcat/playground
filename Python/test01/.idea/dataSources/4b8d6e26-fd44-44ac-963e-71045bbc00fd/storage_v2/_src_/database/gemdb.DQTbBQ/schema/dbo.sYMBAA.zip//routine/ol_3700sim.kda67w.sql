




CREATE PROCEDURE dbo.ol_3700SIM
@CoreID	smallint = 1,
@User 		varchar(10),
@SIMid		char(24),
@Parms	varchar(8000)
as
	SET NOCOUNT ON
DECLARE @sp 	varchar(250)
DECLARE @Cmd    varchar(8000)
	SELECT 	@sp = sp
	FROM 	cfgSIMxlat
	WHERE 	SIMid = @SIMid AND
		Active = 1 AND
		Locked = 0 AND
		(CoreID = 0 or CoreID = @CoreID) AND 
		expiredate >= getdate() AND
		activeDate <= getdate()
	IF @@rowcount = 0 		-- Not found.
	BEGIN
		SET @sp = 'SIM ID: ' + RTRIM(@SIMid) + ' Not Found'
		EXEC dbo.sp_logit 0,@CoreID,@User,@sp, 950
		SELECT '/SIM ID:' + RTRIM(@SIMid) + ' Not Found'  as ReturnMsg	-- Must use the SELECT to create a recordset 
		RETURN  
	END
	IF(len(RTRIM(@Parms)) > 0 )
		--SET @Parms = ' '''+REPLACE(RTRIM(@Parms),char(28),''',''')  + ' '''
		SET @Parms = REPLACE(RTRIM(@Parms), char(28), CHAR(44) ) 
		SET @Parms = REPLACE(@Parms,char(34), char(39) )
	
	--SET  @Cmd = RTRIM( @sp )
	SET  @Cmd = RTRIM(RTRIM( @sp ) + ' ' + CHAR(39) + CAST(@CoreID as varchar(5)) + CHAR(39) + CHAR(44) + CHAR(39) + @User + CHAR(39) + CHAR(44) + @Parms )
	EXEC dbo.sp_logit 0,1,'SIM3700',@cmd, 950
	EXEC (@Cmd)
go

