





CREATE    PROCEDURE dbo.ad_CycleOHD_Get
@xlatID		char(10) = ''
AS 
	IF @xlatID = ''
	BEGIN
		-- Retrieve a list of all cycle OHD items
		SELECT	*
		FROM	dbo.tblCycleOHD
		ORDER BY xlatID
	END
	ELSE
	BEGIN
		-- Retrieve exact cycleOHD item
		SELECT	*
		FROM	dbo.tblCycleOHD
		WHERE	xlatID = @xlatID
	END
go

