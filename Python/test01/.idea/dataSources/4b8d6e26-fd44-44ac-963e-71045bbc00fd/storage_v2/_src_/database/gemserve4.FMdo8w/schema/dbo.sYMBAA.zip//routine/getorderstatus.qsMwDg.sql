

CREATE FUNCTION dbo.GetOrderStatus(@OrderID int)
RETURNS int
AS
BEGIN
	DECLARE @Return int

	SELECT @Return = MAX(ACTIONID)
	FROM dbo.tblOrderLOG
	WHERE OrderID = @OrderID

	RETURN COALESCE(@Return, 0)
END
go

