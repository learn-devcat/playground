
CREATE FUNCTION dbo.GetUserRoles(@Roles varchar(1000))
RETURNS @Role TABLE (RoleID int)
AS
BEGIN
        DECLARE @Start int,
                @TempRole varchar(10)

        SET @Start = 1
        IF (CHARINDEX(',',@Roles) = 0)
                INSERT INTO @Role (RoleID)
                        VALUES (CAST(@Roles AS int))
        ELSE
        BEGIN   
                WHILE (1=1)
                BEGIN
                        SET @TempRole = LEFT(@Roles,CHARINDEX(',',@Roles)-1)
                        INSERT INTO @Role (RoleID)
                                VALUES (CAST(@TempRole AS int))

                        SET @Roles = RIGHT(@Roles, LEN(@Roles) - (LEN(@TempRole) + 1))

                        IF (CHARINDEX(',',@Roles) = 0)
                                BREAK
                END   
                
                INSERT INTO @Role (RoleID)
                        VALUES (CAST(@Roles AS int)) 
                           
        END
        
        RETURN
END
go

