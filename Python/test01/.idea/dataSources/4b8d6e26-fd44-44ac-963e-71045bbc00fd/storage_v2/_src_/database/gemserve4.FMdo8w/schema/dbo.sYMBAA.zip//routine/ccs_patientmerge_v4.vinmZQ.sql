

CREATE PROCEDURE [dbo].[CCS_PatientMerge_v4]
@MedicalRecordID	varchar(32),
@MedicalRecordID2	varchar(32),
@Source			varchar(32),
@PatientVisitID		varchar(50)='',
@PatientVisitID2	varchar(50)='',
@ConnectionName		varchar(50)=''
AS
	SET NOCOUNT ON
	DECLARE @PatientID	int,
		@RoomID		int,
		@Msg		varchar(100),
		@Msg2		varchar(200),
		@Processed	bit,
		@Today	datetime

	SET @Today = getdate()

	SELECT @PatientID = PatientID
	FROM dbo.tblPatientOHD
	WHERE MedicalRecordID = @MedicalRecordID2

	IF (@PatientID IS NOT NULL AND @MedicalRecordID <> @MedicalRecordID2)
	BEGIN
		IF NOT EXISTS (SELECT PatientID FROM dbo.tblPatientOHD WHERE MedicalRecordID = @MedicalRecordID)
		BEGIN
			SET @Msg = 'Unable to process Merge for MedicalRecordID: ' + @MedicalRecordID + '. Patient not found.'
			EXEC dbo.Logit 1, @Msg, 'system'
		END
		ELSE
		BEGIN
			UPDATE dbo.tblPatientOHD
			SET MergedTo = @MedicalRecordID,
				LastUpdateBy = @Source
			WHERE MedicalRecordID = @MedicalRecordID2

			SET @Msg2 = 'Merged patient information for ' + @MedicalRecordID2 + ' to ' + @MedicalRecordID + '.'
			EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, '', 0, @Msg2
	    		EXEC dbo.ProcessLogInsert @Source

			SET @Processed = 1
		END
	END

	-- Check for PatientVisit merge
	IF (@PatientVisitID <> '' AND @PatientVisitID <> @PatientVisitID2) 
	BEGIN
		UPDATE dbo.tblPatientVisit
		SET MergedTo = @PatientVisitID,
			LastUpdateBy = @Source
		WHERE PatientVisitID = @PatientVisitID2

		SET @Msg2 = 'Merged patient visit information for Patient Visit ' + @PatientVisitID2 + ' to ' + @PatientVisitID + '.'

		------------------------------
		-- BEGIN PATIENT MERGE HISTORY
		------------------------------
		-- Update tblOrderOHD
		INSERT INTO dbo.tblPatientVisitMergeHistory (TableID, PatientVisitID, OldPatientVisitID)
			SELECT 1, @PatientVisitID, PatientVisitID
			FROM dbo.tblOrderOHD
			WHERE PatientVisitID = @PatientVisitID2

		UPDATE dbo.tblOrderOHD
		SET PatientVisitID = @PatientVisitID
		WHERE PatientVisitID = @PatientVisitID2

		-- Update tblPatientDiet
		INSERT INTO dbo.tblPatientVisitMergeHistory (TableID, PatientVisitID, OldPatientVisitID)
			SELECT 2, @PatientVisitID, PatientVisitID
			FROM dbo.tblPatientDiet
			WHERE PatientVisitID = @PatientVisitID2

		UPDATE dbo.tblPatientDiet
		SET PatientVisitID = @PatientVisitID
		WHERE PatientVisitID = @PatientVisitID2

		-- Update tblPatientLog
		INSERT INTO dbo.tblPatientVisitMergeHistory (TableID, PatientVisitID, OldPatientVisitID)
			SELECT 3, @PatientVisitID, PatientVisitID
			FROM dbo.tblPatientLog
			WHERE PatientVisitID = @PatientVisitID2

		UPDATE dbo.tblPatientLog
		SET PatientVisitID = @PatientVisitID
		WHERE PatientVisitID = @PatientVisitID2
		------------------------------
		-- END PATIENT MERGE HISTORY	
		------------------------------			

		SELECT @PatientID = PatientID
		FROM dbo.tblPatientVisit
		WHERE PatientVisitID = @PatientVisitID

		IF (@PatientID IS NULL)
			SELECT @PatientID = PatientID
			FROM dbo.tblPatientVisit
			WHERE PatientVisitID = @PatientVisitID2



		SELECT @PatientID = PatientID
		FROM dbo.tblPatientVisit
		WHERE PatientVisitID = @PatientVisitID

		EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, '', 0, @Msg2
		EXEC dbo.ProcessLogInsert @Source

		SET @Processed = 1
	END


	IF (COALESCE(@Processed, 0) = 0)
	BEGIN
		SET @Msg = 'Unable to process Merge for MedicalRecordID:' + @MedicalRecordID2
		EXEC dbo.Logit 1, @Msg, 'system'
	END

	SET @ConnectionName = 'Idt' + @ConnectionName
	EXEC dbo.WorkstationUpdateByID @ConnectionName


	RETURN


go

