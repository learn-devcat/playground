


CREATE  PROCEDURE [dbo].[ad_Application_Edit]
    @User char(10),
    @ExistingApplicationID int,
    @NewApplicationID int,
    @Description varchar(24),
    @DELETE bit = 0
AS 
    DECLARE @AppID int,
        @Message varchar(255),
        @ErrNum int

    IF @DELETE = 1 
        GOTO DODELETE

    IF ( @NewApplicationID > -1
         AND @ExistingApplicationID = -1
       ) 
        BEGIN
            INSERT  dbo.cfgApplications
            VALUES  (
                      @NewApplicationID,
                      @Description
                    )
		
            SET @ErrNum = @@ERROR
            SET @Message = CASE WHEN @ErrNum <> 0
                                THEN 'New Application Item Added: ('
                                     + CAST(@NewApplicationID as varchar(8))
                                     + ') ' + @Description
                                ELSE 'Error inserting new application item: ('
                                     + +CAST(@NewApplicationID as varchar(8))
                                     + ') ' + @Description
                           END
        END
    ELSE 
        BEGIN

            SET @AppID = CASE WHEN @NewApplicationID > -1
                              THEN @NewApplicationID
                              ELSE @ExistingApplicationID
                         END
            UPDATE  dbo.cfgApplications
            SET     ApplicationID = @AppID,
                    [Description] = @Description
            WHERE   ApplicationID = @ExistingApplicationID
		
            SET @ErrNum = @@ERROR

            SELECT  @Message = ( 'Edit of ApplicationID ('
                                 + CAST(@AppID as varchar) + ') '
                                 + CASE WHEN @ErrNum <> 0 THEN 'FAILED'
                                        ELSE 'SUCCEDED'
                                   END )
        END

    EXEC dbo.sp_Logit 9, 1, @User, @Message, 1010	
    SELECT  @Message AS 'Rtn'

    RETURN

    DODELETE:
    DELETE  dbo.cfgApplications
    WHERE   ApplicationID = @ExistingApplicationID
    
    SET @ErrNum = @@ERROR

    IF EXISTS ( SELECT  *
                FROM    dbo.cfgApplications
                WHERE   ApplicationID = @ExistingApplicationID ) 
        SELECT  @Message = 'DELETE Application ID ('
                + CAST(@ExistingApplicationID as varchar(8)) + ') Failed'
    ELSE 
        SELECT  @Message = 'DELETE Application ID ('
                + CAST(@ExistingApplicationID as varchar(8)) + ') Succeded'

	
    EXEC dbo.sp_Logit 9, 1, @User, @Message, 1010	
    SELECT  @ErrNum AS 'Rtn'
go

