


----------------------------------------------------------------------------------
--
--  OrderDTLGet                  13-Aug-03 w.j.scott
--
--  Get ONE detail record for a specific OrderID -- The overhead is NOT checked
--  and we do a simple select against the DTL table (tblOrderDTL) for anything
--  that matches OrderID AND the DetailID.  
--
--      NOTE: The OrderID and DetailID are 'system generated' when the order 
--            is inserted into the table.
--
-----------------------------------------------------------------------------------

CREATE PROCEDURE dbo.OrderDTLGet
@OrderID as int,
@DetailID as int
as
	SET NOCOUNT ON
	
	select OrderID, DetailID,Description, OrderDetail
      from dbo.tblOrderDTL 
     where OrderID  = @OrderID and
           DetailID = @DetailID
	
	RETURN
go

