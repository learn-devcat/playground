
CREATE  PROCEDURE [dbo].[Cycles_MakeAllCurrent]
@Force int=0
AS
	SET NOCOUNT ON
	
	DECLARE @TempTable  TABLE (XlatID char(10), Processed bit)
	DECLARE	@Count int,
		@MyXlat char(10),
		@Today	datetime,
		@chkDate varchar(50)
		
	SET @Today = GETDATE()		
	
	-- the "LastCycleUpdate" key will be the last day that all cycles were updated
	-- by this script. If that day is today, return, because we only need to update on a daily basis 
	IF NOT EXISTS (SELECT * FROM dbo.cfgOverhead WHERE oKey = 'LastCycleUpdate')
	BEGIN
		INSERT dbo.cfgOverhead ( oKey , sValue , dType , Sequence , CategoryID )
		VALUES  ( 'LastCycleUpdate' , dbo.DateOnly(@Today) ,  0 , 9999 , 0 )		
	END
	ELSE
	BEGIN
		SET @chkDate = dbo.GetOverheadItem('LastCycleUpdate')
		
		IF (ISDATE(@chkDate) = 1) AND (COALESCE(@Force,0) <> 1)
		BEGIN
			IF dbo.DateOnly(@chkDate) = dbo.DateOnly(@Today)
				RETURN
			ELSE 
				UPDATE dbo.cfgOverhead
				SET sValue = dbo.DateOnly(@Today)
				WHERE oKey = 'LastCycleUpdate'
		END
		ELSE
			UPDATE dbo.cfgOverhead
			SET sValue = dbo.DateOnly(@Today)
			WHERE oKey = 'LastCycleUpdate'
	END

	-- continue processing if this is a new day for frequency codes that do not have an * in the first character
	INSERT INTO @TempTable
	SELECT  XlatID,
		0
	FROM	tblCycleOHD
	WHERE LEFT(FrequencyCode,1) <> '*' AND Active > 0
	
	-- failsafe to prevent an endless loop
	SELECT @Count = Count(*) FROM @TempTable
	
	WHILE @Count > 0
	BEGIN

		SELECT 	TOP 1 @MyXlat = XlatID
		FROM	@TempTable
		WHERE	Processed = 0
	
		IF @@ROWCOUNT < 1
			BREAK
		
		UPDATE 	@TempTable
		SET	Processed = 1
		WHERE	XlatID = @MyXlat
		
		EXEC dbo.ad_Cycle_MakeCurrent 'system', @MyXlat, @Today

		SET @Count = @Count - 1
	END
go

