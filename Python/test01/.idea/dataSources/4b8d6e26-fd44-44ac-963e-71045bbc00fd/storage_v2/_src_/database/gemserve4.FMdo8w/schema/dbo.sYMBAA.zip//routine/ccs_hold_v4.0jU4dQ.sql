CREATE PROCEDURE [dbo].[CCS_Hold_v4]
@PatientID				int,
@PatientVisitID			varchar(50),
@Source					varchar(100),
@RoomID					int,
@HoldActiveTime			varchar(50)='',
@HoldReleaseTime		varchar(50)='',
@OrderType				varchar(50)

AS
	SET NOCOUNT ON

	DECLARE	@Msg					varchar(500),
			@HoldStatus				varchar(50),
			@dHoldActiveTime		datetime,
			@dHoldReleaseTime		datetime,
			@Today					datetime
			
	-- Get the current datetime
	SET @Today = GETDATE()

	-- Determine if hold is a hold set (1) or a hold release (0)
	SELECT @HoldStatus = KeyOut
	FROM dbo.tblXLAT
	WHERE (xlatID = 'HoldType') AND (KeyIn = @OrderType)
	
	-- Determine if Hold Status is valid
	IF (@HoldStatus NOT IN ('0', '1'))
	BEGIN
		-- Invalid Hold Status
		SET @Msg = 'Hold/Release status ['+ @HoldStatus + '] not valid for PatientVisitID: [' + @PatientVisitID + '].'
		GOTO TransError
	END
	
	-- Patient is being placed on hold
	IF (@HoldStatus = '1')
	BEGIN
		-- Set the Hold Active Time
		IF (ISDATE(@HoldActiveTime) = 0)
			SET @dHoldActiveTime = @Today
		ELSE
			SET @dHoldActiveTime = CAST(@HoldActiveTime AS datetime)
			
		-- Set the Hold Release Time
		IF (ISDATE(@HoldReleaseTime) = 0)
			SET @dHoldReleaseTime = '01/01/2050 00:00'
		ELSE
			SET @dHoldReleaseTime = CAST(@HoldReleaseTime AS datetime)	

		-- Set the on hold message for the patient log
		SET @Msg = ' Hold placed on Patient Visit ID: [' + @PatientVisitID + '] at ' + CAST(@dHoldActiveTime AS varchar(50))
	END
	ELSE
	BEGIN
	-- Patient hold is being released	
		-- Set the hold release message for the patient log
		SET @Msg = ' Hold released for Patient Visit ID: [' + @PatientVisitID + '] at ' + CAST(@Today AS varchar(50))	
	END
	
	-- Update the hold/release times in the tblPatientOHD table
	UPDATE dbo.tblPatientOHD
	SET HoldActiveTime = @dHoldActiveTime, HoldReleaseTime = @dHoldReleaseTime
	WHERE PatientID = @PatientID
	
	-- Insert a log entry into the Patient Log for the hold/release status
	INSERT INTO dbo.tblPatientLog (EventClassID, LoginUserID, PatientID, PatientVisitID, RoomID, [Description], [Date])
	VALUES( 7000, @Source, @PatientID, @PatientVisitID, @RoomID, @Msg, getdate())		

	RETURN
	
TransError:
       
    EXEC dbo.Logit 1, @Msg, 'system'

	RETURN
go

