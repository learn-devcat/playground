




CREATE   PROCEDURE [dbo].[ad_CycleXlat_Get]
@xlatID		char(10) = '',
@findCycle 	int = 0,
@findDate	datetime = '1-1-1981',
@CycleNo 	int = -1
AS 
	IF @findCycle < 1
	BEGIN
		IF @xlatID = ''
		BEGIN
			-- Retrieve a list of all cycle items
			SELECT	xlatID,
				BeginDate,
				EndDate,
				CycleNo
			FROM	dbo.tblCycleXlat
			ORDER BY xlatID, CycleNo
		END
		ELSE IF @CycleNo = -1
		BEGIN
			-- Retrieve a list of all cycle items matching the xlat ID
			SELECT	xlatID,
				BeginDate,
				EndDate,
				CycleNo
			FROM	dbo.tblCycleXlat
			WHERE	xlatID = @xlatID
			ORDER By CycleNo DESC
		END
		ELSE
		BEGIN
			-- Retrieve exact cycle
			SELECT	xlatID,
				BeginDate,
				EndDate,
				CycleNo
			FROM	dbo.tblCycleXlat
			WHERE	xlatID = @xlatID AND
				CycleNo = @CycleNo
		END
	END
	ELSE
	BEGIN
			-- Retrieve exact cycle
			SELECT	xlatID,
				BeginDate,
				EndDate,
				CycleNo
			FROM	dbo.tblCycleXlat
			WHERE	xlatID = @xlatID AND
				CycleNo = dbo.GetCycleByXREF( -1 , @findDate , @xlatID)
	END
go

