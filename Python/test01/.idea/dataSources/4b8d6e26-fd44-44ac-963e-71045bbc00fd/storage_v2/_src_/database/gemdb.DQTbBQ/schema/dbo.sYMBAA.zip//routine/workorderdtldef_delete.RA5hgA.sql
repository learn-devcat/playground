
CREATE   PROCEDURE dbo.WorkorderDTLDef_Delete
@User			    char(10), 
@WorkOrderDTLDefID  int
AS
    DELETE  tblWorkOrderDTLDef
    WHERE   WorkOrderDTLDefID = @WorkorderDTLDefID
    IF @@Error <> 0 
      BEGIN
        RETURN
      END
    RETURN
go

