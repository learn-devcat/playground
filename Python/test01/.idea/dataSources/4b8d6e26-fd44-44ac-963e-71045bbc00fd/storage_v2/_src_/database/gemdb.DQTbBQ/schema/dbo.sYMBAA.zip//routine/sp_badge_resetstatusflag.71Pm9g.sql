

CREATE PROCEDURE dbo.sp_Badge_ResetStatusFlag
@User			char(10),
@AccountNo		char(10),
@BadgeNo		char(19),
@StatusBit		int,
@TempStatus		int=0
AS
	SELECT	@TempStatus=Status
	FROM		tblBadgesOHD
	WHERE	AccountNo=@AccountNo AND BadgeNo=@BadgeNo
	UPDATE	tblBadgesOHD
	SET		Status=(Status&~@StatusBit) 
	WHERE	AccountNo=@AccountNo AND BadgeNo=@BadgeNo
	-- Log table entry
	INSERT INTO tblLog (UserID,CoreID,Description) VALUES(@User,'1','SET Status Bit <' + @StatusBit + '> for Badge No <' + 
		RTRIM(@BadgeNo) + '>, Account No <' + RTRIM(@AccountNo) + '> to OFF')
go

