

CREATE PROCEDURE [dbo].[sp_AccountMeal_Delete_EX]
@AccountNo		char(19),
@MealPlanID		int,
@ActiveDate		datetime
AS
	IF (SELECT COUNT(*) FROM tblAccountMealTTL WHERE AccountNo = @AccountNo AND MealPlanID = @MealPlanID) <= 1
		DELETE	tblAccountMeal
		WHERE	AccountNo = @AccountNo
			AND MealPlanID = @MealPlanID
	ELSE
		DELETE	tblAccountMealTTL
		WHERE	AccountNo = @AccountNo
				AND MealPlanID = @MealPlanID
				AND ActiveDate = @ActiveDate
go

