CREATE PROCEDURE [dbo].[sp_Task_Add]
	@User			char(10),
	@TaskName		varchar(50),
	@TaskNameMsg	varchar(255),
	@MessageId		varchar(50),
	@Message		varchar(255),
	@CategoryId		varchar(50),
	@CategoryMsg	varchar(255),
	@TaskType		varchar(50)='query',
	@Detail			varchar(max),
	@Sequence		int=9999,
	@MinPrivilegeClass int=9999	

AS

	DECLARE @UserRole	int,
			@Msg		varchar(255)

	-- Get the user's max role id
	SELECT @UserRole = MAX(PrivilegeClassId)
	FROM dbo.tblPrivilegeClassMembers
	WHERE UserID = @User;

	-- Must be a user with support privileges to add task
	IF (@UserRole >= '9999')
	BEGIN
	
		SET @Msg = 'The Task [' + @TaskName + '] has been added successfully'

		-- Insert task
		IF NOT EXISTS (SELECT 1 FROM dbo.TaskOHD WHERE TaskName = @TaskName)
			INSERT INTO dbo.TaskOHD (TaskName, MessageId, CategoryId, TaskType, Detail, Sequence, EntryId, EntryDate, MinPrivilegeClass)
			VALUES (@TaskName, @MessageId, @CategoryId, @TaskType, @Detail, @Sequence, @User, GETDATE(), @MinPrivilegeClass)

		IF (@@ROWCOUNT > 0)
		BEGIN
			--Task added successfully

			--Remove exsisting Messages
			DELETE FROM dbo.tblMessages
			WHERE ID IN (@TaskName, @MessageId, @CategoryId)
				AND PageID = 'Tasks'

			--Add the Messages
			INSERT INTO dbo.tblMessages (ID, Message, Language, Custom, PageID)
			--Add the Task Name
			SELECT @TaskName, @TaskNameMsg, 1033, 0, 'Tasks'
			UNION ALL
			--Add the Category Name
			SELECT @CategoryId, @CategoryMsg, 1033, 0, 'Tasks'
			UNION ALL
			--Add the Task Detailed Description Message and include any control placeholders
			SELECT @MessageId, @Message, 1033, 0, 'Tasks'

		END
		ELSE
			SET @Msg = 'The Task [' + @TaskName + '] was not added'
	END
		ELSE 
			SET @Msg = 'Error: User [' + @User + '] must have support privileges to add a task'

	-- Log the task
	EXEC dbo.sp_LogIt 0, 1, @User, @Msg, 2100

	SELECT @Msg AS [Msg]
go

