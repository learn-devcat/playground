CREATE PROCEDURE [dbo].[ol_AddBulkCards]
    @CoreID			int = 1,
    @User			char(10),
	@CardType		varchar(10),
	@AccountNo		char(19),
	@BadgeClassID	int,
    @CardBeginNo	char(19),
	@CardEndNo		char(19),
    @TransTotal		money = 0,
	@SkipExisting	int = 0
AS 
    DECLARE @ReturnCode		int,
			@AccountClassID int,
			@TransID		int,
			@TransClassID	int,
			@CurrentCardNo	char(19),
			@OutletNo		int,
			@LocationID		int,
			@ActiveDate		datetime, 
			@ExpireDate		datetime, 
			@TransDate		datetime, 
			@ExpireDays		int,
			@CheckNum		char(6),
			@FirstName		char(15),
			@MiddleName		char(15),
			@LastName		char(20),
			@Phone			char(15),
			@RefNum			char(6),
			@Address1		varchar(40),
			@Address2		varchar(40),
			@Address3		varchar(40),
			@Address4		varchar(40),
			@Address5		varchar(40),
			@Comment		varchar(40),
			@Category		char(10),
			@PaymentNo		int,
			@ServeEmpl		int,
			@Msg			varchar(250)

	--stop sp messages from being returned
    SET NOCOUNT ON

	-- Set default values
	SET	@CheckNum = ''
	SET @LastName = 'Valued Customer'
	SET @Phone = ''
	SET @FirstName = ''
	SET @MiddleName = ''
	SET @RefNum = ''
	SET @Address1 = ''
	SET @Address2 = ''
	SET @Address3 = ''
	SET @Address4 = ''
	SET @Address5 = ''
	SET @Comment = ''
	SET @PaymentNo = 1
	SET @ServeEmpl = 0
    SET @ActiveDate = GETDATE()

	SELECT TOP 1 @LocationID = COALESCE(LocationID,0)
	FROM dbo.cfgLocations 
	ORDER BY LocationID

	--Get overhead settings
	SET @AccountClassID = COALESCE(NULLIF(dbo.GetOverheadItem('GCAcctClass'),''), '3000')
	SET @ExpireDays = COALESCE(NULLIF(dbo.GetOverheadItem('GCEXPIREDAYS'),''),'365')
	SET @TransID = COALESCE(NULLIF(dbo.GetOverheadItem('GCTransID'),''),'3000')
	SET @TransClassID = COALESCE(NULLIF(dbo.GetOverheadItem('GCTransClass'),''),'3000')
	SET @OutletNo = COALESCE(NULLIF(dbo.GetOverheadItem('GCOutletNo'),''),'3000')
    
	--Set the date for the expiration of the gift card
    SET @ExpireDate = GETDATE() + CAST(@ExpireDays AS int)

	--Process Debit/Gift Cards
	BEGIN TRANSACTION

		-- Make sure there is a valid beginning gift card number
		IF (ISNUMERIC(@CardBeginNo) = 0)
		BEGIN
			SET @Msg = 'Beginning ' + @CardType + ' Card Number is not a valid number' 
			GOTO AddFailed
		END

		--Set the end gift card number if it does not exist
		IF (ISNUMERIC(@CardEndNo) = 0)
			SET @CardEndNo = @CardBeginNo

		--Assign the Current Card for looping purposes
		SET @CurrentCardNo = @CardBeginNo
			
		--Determine if debit cards or gift cards
		IF (@CardType = 'Debit')
		BEGIN
			--Process as a Debit Card and add all badges to an existing account
			SET @Category = 'DEBITCARD'

			--Verify that the Account Number exists
			IF NOT EXISTS (SELECT 1 FROM dbo.tblAccountOHD WHERE AccountNo = @AccountNo)
			BEGIN
				SET @Msg = 'Account Number [' + RTRIM(@AccountNo) + '] does not exist'
				GOTO AddFailed
			END
			
			-- Create the badges for the account
			WHILE (@CurrentCardNo <= @CardEndNo)
			BEGIN
				--Create the badge if it doesn't exist
				IF NOT EXISTS (SELECT 1 FROM dbo.tblBadgesOHD WHERE BadgeNo = @CurrentCardNo AND AccountNo = @AccountNo)
				BEGIN		
					--Create the badge
					EXEC @ReturnCode = dbo.sp_Badge_Insert @User, @CurrentCardNo, @AccountNo
					IF ( @ReturnCode <> 0 ) 
					BEGIN
						SET @Msg = 'Cannot insert ' + @CardType + ' Card Number ' + RTRIM(@CurrentCardNo)
						GOTO AddFailed
					END
		
					EXEC @ReturnCode = dbo.sp_Badge_Update @User, @CurrentCardNo, @CurrentCardNo, @AccountNo,
						0, 1, @ActiveDate, @ExpireDate, @BadgeClassID, '', @FirstName, @MiddleName, @LastName,
						999999, 999999, '', 0, 0, 0, 999999, @LocationID

					IF ( @ReturnCode <> 0 )
					BEGIN 
						SET @Msg = 'Cannot update ' + @CardType + ' Card Number ' + RTRIM(@CurrentCardNo)
						GOTO AddFailed
					END
				END
				ELSE
				BEGIN
					SET @Msg = 'No ' + @CardType + ' cards created because cards already exist' 
					GOTO AddFailed
				END

				SET @CurrentCardNo = @CurrentCardNo + 1
			END
		END
		ELSE IF (@CardType = 'Gift')
		BEGIN
			-- Process as a Gift Card
			SET @Category = 'GIFTCARD'

			--Set Gift Card Badge Class
			IF (@BadgeClassID <= 0)
				SET @BadgeClassID = 3000

			-- Create an account using the badge number
			WHILE (@CurrentCardNo <= @CardEndNo)
			BEGIN
				
				--See if Account already exists
				SELECT TOP 1
						@AccountNo = B.AccountNo
				FROM    tblBadgesOHD AS B
						LEFT JOIN tblAccountTTL AS T ON T.AccountNo = B.AccountNo
				WHERE   B.BadgeNo = @CurrentCardNo
						AND T.TransClassID = @TransClassID
				ORDER BY B.PrimaryBadge,
						 B.AccountNo DESC
				
				IF (@@ROWCOUNT = 0)
				BEGIN

					SET @AccountNo = @CurrentCardNo
				
					--Account does not exist so create it
					EXEC @ReturnCode = dbo.sp_Account_Insert @User, @AccountNo, @AccountClassID
					IF ( @ReturnCode <> 0 )
					BEGIN 
						SET @Msg = 'Insert failed for Account Number ' + RTRIM(@AccountNo)
						GOTO AddFailed
					END
		
					EXEC @ReturnCode = dbo.sp_Account_Update @User, @AccountNo, '', 0, '',
						@FirstName, @MiddleName, @LastName, @Phone, '', '', @AccountClassID, '', @ActiveDate,
						@ExpireDate, 0, 0, 0, 0, 0, 0, 0, 0, @LocationID

					IF ( @ReturnCode <> 0 ) 
					BEGIN
						SET @Msg = 'Cannot update Account Number ' + RTRIM(@AccountNo)
						GOTO AddFailed
					END

					--Create the badge
					EXEC @ReturnCode = dbo.sp_Badge_Insert @User, @CurrentCardNo, @AccountNo
					IF ( @ReturnCode <> 0 ) 
					BEGIN
						SET @Msg = 'Cannot insert Gift Card Number ' + RTRIM(@CurrentCardNo)
						GOTO AddFailed
					END
		
					EXEC @ReturnCode = dbo.sp_Badge_Update @User, @CurrentCardNo, @CurrentCardNo, @AccountNo,
						0, 1, @ActiveDate, @ExpireDate, @BadgeClassID, '', @FirstName, @MiddleName, @LastName,
						999999, 999999, '', 0, 0, 0, 999999, @LocationID

					IF ( @ReturnCode <> 0 )
					BEGIN 
						SET @Msg = 'Cannot update Gift Card Number ' + RTRIM(@CurrentCardNo)
						GOTO AddFailed
					END
		
						--Insert account TTL     
					EXEC @ReturnCode = dbo.sp_AccountTTL_Insert @User, @AccountNo, @TransClassID
					IF ( @ReturnCode <> 0 )
					BEGIN
						SET @Msg = 'Cannot create AccountTTL for Account Number ' + RTRIM(@AccountNo)
						GOTO AddFailed
					END

						--Insert and update account address
					EXEC @ReturnCode = dbo.sp_Address_Insert @User, 10, @AccountNo
					IF ( @ReturnCode <> 0 )
					BEGIN
						SET @Msg = 'Cannot insert address for Account Number ' + RTRIM(@AccountNo)
						GOTO AddFailed
					END

					EXEC @ReturnCode = dbo.sp_Address_Update @User, 10, 10, @AccountNo,
						@Address1, @Address2, @Address3, @Address4, @Address5
					IF ( @ReturnCode <> 0 ) 
					BEGIN
						SET @Msg = 'Cannot update address for Account Number ' + RTRIM(@AccountNo)
						GOTO AddFailed	
					END						
				END
				ELSE
				BEGIN
					--Account exists so determine if it should be skipped
					IF (@SkipExisting = 1)
					BEGIN
						SET @CurrentCardNo = @CurrentCardNo + 1
						CONTINUE
					END
				END 

				--Insert the transaction
				SET @TransDate = GETDATE()
				EXEC @ReturnCode = dbo.sp_Trans_Post @CoreID, @User, @AccountNo, @CurrentCardNo,
					@TransDate, @OutletNo, @RefNum, @CheckNum, @TransTotal, @TransTotal,
					@Comment, 0, @TransID, @Category, @PaymentNo, @ServeEmpl       

				IF ( @ReturnCode <> 0 )
				BEGIN
					SET @Msg = 'Cannot add ' + CAST(@TransTotal AS varchar(30)) + ' to Gift Card Number ' + RTRIM(@CurrentCardNo) 
					GOTO AddFailed
				END

				SET @CurrentCardNo = @CurrentCardNo + 1
			END
		END
		ELSE
		BEGIN
			SET @Msg = 'Invalid Card Type [' + @CardType + '] selected'
			GOTO AddFailed
		END		

		--Add succeeded, so commit and return
		COMMIT TRANSACTION

		--Send back success message
		IF (@CardBeginNo = @CardEndNo)
			SET @Msg = 'Successfully added ' + @CardType + ' Card Number ' + RTRIM(@CardBeginNo)
		ELSE
			SET @Msg = 'Successfully added ' + @CardType + ' Card Numbers ' + RTRIM(@CardBeginNo) + ' to ' + RTRIM(@CardEndNo)

		SELECT @Msg
		RETURN
		
AddFailed:
		
	--Add failed, so return failure message		
    ROLLBACK TRANSACTION
	SELECT @Msg
	RETURN
go

