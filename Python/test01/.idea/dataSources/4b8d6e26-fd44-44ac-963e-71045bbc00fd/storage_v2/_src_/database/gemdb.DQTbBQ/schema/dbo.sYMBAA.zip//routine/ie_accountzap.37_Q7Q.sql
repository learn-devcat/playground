


CREATE PROCEDURE dbo.ie_AccountZap
@User			char(10),
@ImpExpFlag		char(1),
@AccountClassID	int
AS
	DELETE	tblAccountOHD
	WHERE	ImpExpFlag=@ImpExpFlag AND AccountClassID<@AccountClassID
	
	DECLARE 	@cMsg  char(255),
			@CoreID	int
	SET @CoreID = dbo.GetCoreIDFromUser(@User)
	SET @cMsg = 'Accounts in class ID: ' + @AccountClassID + ' were deleted based on impexp flag'
	EXEC dbo.sp_Logit 2 , @CoreID , @User , @cMsg, 1000
go

