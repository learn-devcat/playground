

CREATE PROCEDURE dbo.DietMaxNutrientUpdate
@LoginUserID		varchar(250),
@DietID		int,
@NutrientID	int,
@DailyMax	decimal(10,3)
AS
	SET NOCOUNT ON

	IF(@DailyMax >= 9999)
		DELETE dbo.tblDietDailyNutrients
		WHERE DietID = @DietID
		AND NutrientID = @NutrientID
	ELSE
	BEGIN
		UPDATE dbo.tblDietDailyNutrients
		SET DailyMax = @DailyMax
		WHERE DietID = @DietID
		AND NutrientID = @NutrientID

		IF(@@ROWCOUNT = 0)
			INSERT INTO dbo.tblDietDailyNutrients (DietID, NutrientID, DailyMax)
				VALUES (@DietID, @NutrientID, @DailyMax)
	END
	RETURN
go

