CREATE PROCEDURE dbo.pub_ActivateGiftCard
@CoreID		int,
@UserID		char(10),
@TransID		int,
@OutletNo		int,
@AccountNo 		char(19),
@TransTotal		money = 0,
@LastName		char(20) = '' ,
@Phone 		char(15) = '',
@RefNum		char(6) = '',
@ChkNum		char(6) = '',
@FirstName		char(15) = '',
@Address1		varchar(40) = '',
@Address2		varchar(40) = '',
@Address3		varchar(40) = '',
@Address4		varchar(40) = '',
@Address5		varchar(40) = '',
@Comment		varchar(40) = '',
@Category 		char(10) = '',
@PaymentNo		int=1,
@ServeEmpl		int=0
AS 
	DECLARE @Return 	int
	EXEC @Return =  ol_AddGiftCard @CoreID,@UserID,@AccountNo,@TransTotal,@RefNum,@ChkNum,@FirstName,@LastName,@Phone,@Address1,@Address2,@Address3,@Address4,@Address5,
									@Comment,@Category,@PaymentNo,@ServeEmpl,@TransID,@OutletNo
	SELECT @Return AS Field1
go

