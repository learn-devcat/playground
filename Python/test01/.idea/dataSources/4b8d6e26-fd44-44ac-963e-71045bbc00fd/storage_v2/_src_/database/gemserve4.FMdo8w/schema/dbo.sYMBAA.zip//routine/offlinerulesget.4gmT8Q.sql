CREATE PROCEDURE [dbo].[OfflineRulesGet]
AS
	SET NOCOUNT ON
	
	SELECT OfflineRuleId,
			Description
	FROM dbo.cfgOfflineRules
	ORDER BY Description
	
	RETURN
go

