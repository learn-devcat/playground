

CREATE FUNCTION dbo.XLATvalue(@XlatID char(10) , @InValue varchar(50), @Default varchar(50))
RETURNS varchar(50)
AS
BEGIN
DECLARE @OutValue varchar(50)
	 SELECT @Outvalue=OutChar FROM tblXlat WHERE InChar=@Invalue AND XlatID=@XlatID
RETURN ISNULL(RTRIM(@OutValue),@Default)
END
go

