




CREATE  PROCEDURE dbo.ad_TransDef_GetName
@TransID	int
AS
	SELECT	[Description]
	FROM	tblTransDef
	WHERE	TransID = @TransID
go

