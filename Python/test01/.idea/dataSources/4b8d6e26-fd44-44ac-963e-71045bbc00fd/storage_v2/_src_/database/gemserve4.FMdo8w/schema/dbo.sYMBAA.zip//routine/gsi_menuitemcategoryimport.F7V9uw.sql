
CREATE PROCEDURE [dbo].[GSI_MenuItemCategoryImport]
@LoginUserID			varchar(10),
@MenuItemCategoryID	int,
@Description 		varchar(50)
AS
	SET NOCOUNT ON

	UPDATE dbo.tblMenuItemCategory
	SET [Description] = @Description
	WHERE MenuItemCategoryID = @MenuItemCategoryID

	IF (@@ROWCOUNT = 0)
		INSERT INTO dbo.tblMenuItemCategory (MenuItemCategoryID, [Description])
			VALUES (@MenuItemCategoryID, @Description)

	RETURN

go

