CREATE PROCEDURE dbo.ol_GetAccount
@CoreID		smallint = 1,
@User		char(10),
@AccountNo 	char (19)
AS
	DECLARE @LogLevel int
	
	SET @LogLevel = 3		-- Default to Read/Access Level	
	SELECT  AccountNo,Description,AccessID, Status, 
		Title,FirstName,LastName, Phone, Fax, email,AccountClassID,
		dbo.DateOnly(ActiveDate) as ActiveDate,
		dbo.DateOnly(ExpireDate) as ExpireDate, 
		Inactive,NoVerify,Bump200,AutoOverpost,NoDetail
	FROM tblAccountOHD 
	WHERE AccountNo = @AccountNo 
		AND activedate <= getdate() 
		AND expiredate >= getdate() 
		AND AccountClassID > 0
		
	DECLARE @cMsg  char(255)
	
	IF( @@rowcount = 0 ) 
		BEGIN
			SET @cMsg = 'ol_GetAccount Account # ' + RTRIM(@AccountNo) + ' <No Match>'
			SET @LogLevel = @LogLevel - 1		-- drop logging level to catch failure.
		END
	ELSE
		SET @cMsg = 'ol_GetAccount Account # ' + RTRIM(@AccountNo)
	EXEC dbo.sp_Logit @LogLevel , @CoreID , @User , @cMsg, 925
go

