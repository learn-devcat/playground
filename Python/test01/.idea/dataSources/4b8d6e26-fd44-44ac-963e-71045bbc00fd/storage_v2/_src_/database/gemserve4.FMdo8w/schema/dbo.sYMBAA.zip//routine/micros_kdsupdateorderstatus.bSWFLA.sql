CREATE PROCEDURE [dbo].[Micros_KDSUpdateOrderStatus]
AS
	DECLARE @ColdKDS	varchar(10),
		@HotKDS		varchar(10),
		@ExpoKDS	varchar(10),
		@Today		datetime,
		@Now		datetime,
		@PrepareDate	datetime,
		@OrderID	int,
		@LastIdleEvent	datetime,
		@Interval	int,
		@SQL nvarchar(4000)
		
	DECLARE @Orders TABLE (OrderID int, CheckNo int)

	SET @Now = getdate()	
	SET @Today = dbo.dDateOnly(@Now)
	SET @Interval = COALESCE(dbo.GetOverheadValueNULL('KDSInterval'), 30)

	IF EXISTS (SELECT 1 FROM dbo.tblWorkstation WHERE [Date] = @Today AND WorkstationID = 'kds1001')
		UPDATE dbo.tblWorkstation SET LastIdleEvent = @Now WHERE [Date] = @Today AND WorkstationID = 'kds1001'
	ELSE
		INSERT INTO dbo.tblWorkstation(Date, WorkstationID, LastIdleEvent)
		VALUES (dbo.DateString(@Today), 'kds1001', @Now)
	
	SELECT @ColdKDS = dbo.GetOverheadValueNULL('KDSColdActionID')
	SELECT @HotKDS = dbo.GetOverheadValueNULL('KDSHotActionID')
	SELECT @ExpoKDS = dbo.GetOverheadValueNULL('KDSExpoActionID')
	
	INSERT INTO @Orders(OrderID, CheckNo)
	SELECT OrderID, CheckNo
	FROM dbo.tblOrderOHD
	WHERE dbo.dDateOnly(OrderDate) = @Today
	 	AND Sent = 1
	 	AND Received = 1
	 	AND Prepared = 0

	IF (@ColdKDS IS NOT NULL)
		INSERT INTO dbo.tblOrderLog (OrderID, [Date], ActionID, LoginUserID)
		SELECT O.OrderID, K.done_time, @ColdKDS, 'system'
		FROM @Orders AS O
		JOIN MicrosCheckDetail AS C ON O.CheckNo = C.chk_num 
		JOIN MicrosTransactionDetail AS T ON C.chk_seq = T.chk_seq
		JOIN MicrosKdsDetail AS K ON T.kds_trans_id = K.kds_trans_id
		JOIN MicrosOrderDeviceDef AS D ON K.ord_dvc_seq = D.ord_dvc_seq 
		LEFT JOIN dbo.tblOrderLog AS L (NOLOCK) ON L.OrderID = O.OrderID AND L.ActionID = @ColdKDS
		WHERE dbo.dDateOnly(C.chk_open_date_time) = @Today
			AND D.[Name] = 'COLD KDS'
			AND L.OrderID IS NULL
			
	IF (@HotKDS IS NOT NULL)
		INSERT INTO dbo.tblOrderLog (OrderID, [Date], ActionID, LoginUserID)
		SELECT O.OrderID, K.done_time, @HotKDS, 'system'
		FROM @Orders AS O
		JOIN MicrosCheckDetail AS C ON O.CheckNo = C.chk_num 
		JOIN MicrosTransactionDetail AS T ON C.chk_seq = T.chk_seq
		JOIN MicrosKdsDetail AS K ON T.kds_trans_id = K.kds_trans_id
		JOIN MicrosOrderDeviceDef AS D ON K.ord_dvc_seq = D.ord_dvc_seq 
		LEFT JOIN dbo.tblOrderLog AS L (NOLOCK) ON L.OrderID = O.OrderID AND L.ActionID = @HotKDS
		WHERE dbo.dDateOnly(C.chk_open_date_time) = @Today
			AND D.[Name] = 'HOT KDS'
			AND L.OrderID IS NULL
			
	IF (@ExpoKDS IS NOT NULL)
	BEGIN
		WHILE (1=1)
		BEGIN
			-- Get the next order id and bump date/time
			SELECT @OrderID = OrderID, @PrepareDate = K.done_time
			FROM @Orders AS O
			JOIN MicrosCheckDetail AS C ON O.CheckNo = C.chk_num 
			JOIN MicrosTransactionDetail AS T ON C.chk_seq = T.chk_seq
			JOIN MicrosKdsDetail AS K ON T.kds_trans_id = K.kds_trans_id
			JOIN MicrosOrderDeviceDef AS D ON K.ord_dvc_seq = D.ord_dvc_seq 
			WHERE OrderID = (SELECT MIN(OrderID) FROM @Orders)
				AND D.[Name] = 'EXPO KDS'

			IF NOT (@OrderID IS NULL)
			BEGIN				
				EXEC dbo.OrderSETPrepared 'system', @OrderID, @PrepareDate		
			END
	
			DELETE @Orders WHERE OrderID = (SELECT MIN(OrderID) FROM @Orders)
	
			IF NOT EXISTS (SELECT 1 FROM @Orders)
				BREAK
		END
	END

Finish:
	RETURN
go

