


CREATE    PROCEDURE dbo.sp_CycleXLATnew_Pattern
@CoreID		int,
@XlatID		char(10),
@NumPatterns	int,
@Pattern	varchar(120),
@BeginDate	datetime = '1-1-1980',
@CycleNo	int = 0
AS
	DECLARE	@EndDate	datetime,
		@TempDate	datetime,
		@PatType	char(1),
		@PatNum		int,
		@Place		int,
		@Start		int,
		@BeginCycle	int
IF dbo.Pattern_FindNext_Verify( 1, @Pattern, 'V') < 0 -- Exit IF pattern doesn't contain valid date types (i.e. 'D', 'W', etc.)
BEGIN
	PRINT 'ERROR: Cycle Pattern incorrectly formatted. pattern must be entered in a format similar to the following:' + char(13) + 
		'"7D1M1Y" <--- this pattern specifies 7 days then 1 month then 1 year' + char(13) + 'Allowable date types are: ' +
		'"D" (Day), "W" (Week), "M" (Month) AND "Y" (Year)'
	RETURN
END 
IF @BeginDate = '1-1-1980' -- IF BEGIN date not passed in, either the user forgot or this is an append operation AND it should be
			   -- SET by the END date of the last row of the existing cycle
BEGIN
	SELECT @TempDate =  MAX(EndDate) FROM tblCycleXLAT WHERE XLATID = @XlatID
	
	IF @TempDate IS NULL
	BEGIN
		PRINT 'ERROR: BeginDate was not SET AND the cycle: ' + RTRIM(@XlatID) + ' does not exist. Operation aborted.'
		RETURN
	END
	ELSE
	BEGIN
		SET @BeginDate = @TempDate
	END
END
IF @CycleNo = 0 -- IF not SET, SET to highest cycle numcer plus one, IF cycle doesn't exist, default to one
BEGIN
	SELECT @CycleNo = MAX(CycleNo) + 1 FROM tblCycleXLAT WHERE XLATID = @XlatID
	SET @CycleNo = ISNULL(@CycleNo, 1)	
END
SET @BeginCycle = @CycleNo -- keep initial cycle no for potetial rollback
While @NumPatterns > 0 -- outer loop repeats pattern the specified number of times
BEGIN
	--initialize variables
	SET @Place = 1
	SET @Start = 1
	SET @Place = dbo.Pattern_FindNext_Verify( @Start, @Pattern, 'F') -- Find first date type character
	WHILE @PLACE <> 0 -- Inner loop creates the pattern once
	BEGIN
		SET @PatType = LOWER( SUBSTRING( @Pattern , @Place , 1 ))
		SET @PatNum  = CAST( SUBSTRING( @Pattern , @Start , (@Place - @Start)) AS INT )
		
		SET @EndDate = DATEADD( d, 0, case 	-- Setup our next END DATE
		   			When @PatType =  'd' then DateAdd( d, @PatNum , @BeginDate)
					When @PatType =  'w' then DateAdd( ww, @PatNum , @BeginDate)	
					When @PatType =  'm' then DateAdd( m, @PatNum , @BeginDate)
					When @PatType =  'y' then DateAdd( yy, @PatNum , @BeginDate)
					When @PatType =  'q' then DateAdd(  q,  @PatNum  , @BeginDate )
					WHEN @PatType =  'b' AND DAY(@BeginDate) = 1  THEN DATEADD( d , 15 , @BeginDate )
					WHEN @PatType =  'b' AND DAY(@BeginDate) > 1 THEN DATEADD( m , 1 , DATEADD( d , - (DAY( @BeginDate )-1) , @BeginDate ))
					END)
	
		INSERT INTO TBLCYCLEXLAT ( XLATID, BEGINDATE, ENDDATE, CYCLENO) 
		        	  VALUES ( @XLATID,@BEGINDATE,@ENDDATE,@CYCLENO)
		
		IF @@ERROR <> 0 -- IF error occured, rollback AND exit
		BEGIN
			DELETE tblCycleXLAT WHERE XlatID = @XlatID AND CycleNo >= @BeginCycle
			PRINT 'ERROR: An error occured inserting the new cycle. Operation aboted AND rolled back'
			RETURN
		END
		SET @PatNum = @PatNum - 1
		SET @BEGINDATE = @ENDDATE
		SET @CycleNo = @CycleNo + 1
		SET @Start = @Place + 1
		SET @Place = dbo.Pattern_FindNext_Verify( @Start, @Pattern, 'F') -- Find next date type character
	END
SET @NumPatterns = @NumPatterns - 1
END
go

