

CREATE PROCEDURE dbo.MenuItemList
@SearchString	varchar(50) = ''

AS
	SET NOCOUNT ON

	IF (@SearchString = 'XYZ') 
		SELECT 	MenuItemID,
			[Description],
			ISNULL(Cost,0) AS Cost,
			ISNULL(Price, 0) AS Price,
			POSMenuItemID,
			POSMenuItemSEQ,
			POSLegend, 
			MajorGroupSequence, 
			FamilyGroupSequence, 
			MenuItemGroupSequence,
			MenuItemTypeSequence, 
			MenuLevelClassSequence, 
			PrinterDefClassSequence,
			CrossReference1, 
			CrossReference2
		FROM	dbo.tblMenuItemOHD WHERE [Description] LIKE 'X%'
		UNION ALL
		SELECT 	MenuItemID,
			[Description],
			ISNULL(Cost,0) AS Cost,
			ISNULL(Price, 0) AS Price,
			POSMenuItemID,
			POSMenuItemSEQ,
			POSLegend, 
			MajorGroupSequence, 
			FamilyGroupSequence, 
			MenuItemGroupSequence,
			MenuItemTypeSequence, 
			MenuLevelClassSequence, 
			PrinterDefClassSequence,
			CrossReference1, 
			CrossReference2
		FROM	dbo.tblMenuItemOHD WHERE [Description] LIKE 'Y%'
		UNION ALL
		SELECT 	MenuItemID,
			[Description],
			ISNULL(Cost,0) AS Cost,
			ISNULL(Price, 0) AS Price,
			POSMenuItemID,
			POSMenuItemSEQ,
			POSLegend, 
			MajorGroupSequence, 
			FamilyGroupSequence, 
			MenuItemGroupSequence,
			MenuItemTypeSequence, 
			MenuLevelClassSequence, 
			PrinterDefClassSequence,
			CrossReference1, 
			CrossReference2
		FROM	dbo.tblMenuItemOHD WHERE [Description] LIKE 'Z%'
		ORDER BY [Description]		
	ELSE
		SELECT 	MenuItemID,
			[Description],
			ISNULL(Cost,0) AS Cost,
			ISNULL(Price, 0) AS Price,
			POSMenuItemID,
			POSMenuItemSEQ,
			POSLegend, 
			MajorGroupSequence, 
			FamilyGroupSequence, 
			MenuItemGroupSequence,
			MenuItemTypeSequence, 
			MenuLevelClassSequence, 
			PrinterDefClassSequence,
			CrossReference1, 
			CrossReference2
		FROM	dbo.tblMenuItemOHD WHERE [Description] LIKE @SearchString + '%'
		ORDER BY [Description]		
	
	RETURN
go

