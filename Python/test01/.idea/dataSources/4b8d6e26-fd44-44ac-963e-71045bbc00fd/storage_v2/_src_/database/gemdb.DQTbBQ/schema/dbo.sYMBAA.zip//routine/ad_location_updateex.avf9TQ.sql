


CREATE PROCEDURE [dbo].[ad_Location_UpdateEX]
@User		char(10),
@LocationID	int,
@Description	varchar(50),
@DefaultChargeOutlet int,
@DefaultPaymentOutlet int,
@DefaultWorkOrderOutlet int,
@TimeZone varchar(50),
@UserCode1 varchar(50),
@UserCode2 varchar(50),
@UserCode3 varchar(50),
@UserCode4 varchar(50),
@UserCode5 varchar(50)
AS 
	UPDATE cfgLocations
	SET Description = @Description,
		DefaultChargeOutlet = @DefaultChargeOutlet,
		DefaultPaymentOutlet = @DefaultPaymentOutlet,
		DefaultWorkOrderOutlet = @DefaultWorkOrderOutlet,
		TimeZone = @TimeZone,
		UserCode1 = @UserCode1,
		UserCode2 = @UserCode2,
		UserCode3 = @UserCode3,
		UserCode4 = @UserCode4,
		UserCode5 = @UserCode5
	WHERE LocationID = @LocationID
go

