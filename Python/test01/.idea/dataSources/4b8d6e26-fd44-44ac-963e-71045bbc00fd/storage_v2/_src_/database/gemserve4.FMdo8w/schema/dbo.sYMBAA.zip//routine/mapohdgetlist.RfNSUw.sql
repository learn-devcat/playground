
----------------------------------------------------------------------------------
--
--  MapOHDGetList                  09-Sep-03 w.j.scott
--
--  Returns a list of active map overhead entries, indicating which maps
--  are available and defined.
--
--  NOTE:  If a map overhead entry is flagged as inactive, the entry will NOT
--         be included in this list.
--
--  TODO:  include the security class verification in this list so that we can
--         enforce the security of which users are allowed to see these maps.
--
-----------------------------------------------------------------------------------
CREATE PROCEDURE dbo.MapOHDGetList
AS

     SELECT MapNumber,
           	Description,
            Notes
     FROM   dbo.tblMapOHD
     WHERE  Inactive = 0
go

