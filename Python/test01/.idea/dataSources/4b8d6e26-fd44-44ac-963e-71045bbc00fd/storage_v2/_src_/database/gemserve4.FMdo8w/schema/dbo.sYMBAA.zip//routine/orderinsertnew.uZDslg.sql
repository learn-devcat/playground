
CREATE PROCEDURE dbo.OrderInsertNew 
(
    @OrderID  int output,
    @PatientVisitID int,
    @WaveID int,
    @OrderDetail varchar(2000),
    @LocationID int,
    @WorkstationID int = 0,
    @OutletNo int = 0,
    @OrderEmployee int = 0,
    @OrderEmployeeName varchar(30),
    @OrderDate datetime = NULL,           -- if this is null, the database defaults to now.
    @SubLevel int = 0,
    @StandingOrder bit = 0,
    @CheckNo varchar(20) = '',
    @Subtotal money = 0,
    @DeliveryCharge Money = 0,
    @Tip money = 0
  )
AS
	SET NOCOUNT ON

--
-- We need both the Overhead AND Detail to succeed -- one without the other isn't
-- much use.
--

	DECLARE @Rush	bit,
		@BeginTime varchar(5)

	IF(@OrderDate IS NULL)            -- ensure we have a valid order date.
	    SET @OrderDate = getdate()

BEGIN TRANSACTION
    DECLARE @PatientID int
    
    SELECT @PatientVisitID = COALESCE(MergedTo, PatientVisitID)
	FROM dbo.tblPatientVisit
	WHERE PatientVisitID = @PatientVisitID

    SELECT @PatientID = PatientID 
    FROM dbo.tblPatientVisit
    WHERE PatientVisitID = @PatientVisitID

	IF (CHARINDEX('458774',@OrderDetail) > 0)
		SET @Rush = 1
	ELSE
		SET @Rush = 0
		    
    INSERT INTO dbo.tblOrderOHD (LocationID, WorkstationID, OutletNo, WaveID, OrderEmployee, 
				OrderEmployeeName, OrderDate, CheckNo, PatientID, PatientVisitID, SubLevel, 
				Subtotal, DeliveryCharge, Tip, StandingOrder, Rush) 
    VALUES  (@LocationID,@WorkstationID,@OutletNo,@WaveID,@OrderEmployee,
			    @OrderEmployeeName,@OrderDate,@CheckNo,@PatientID,@PatientVisitID,@SubLevel,
				@SubTotal,@DeliveryCharge,@Tip, @StandingOrder, @Rush)

    IF(@@ERROR = 0)
      BEGIN
        -- Send the new orderID back to the caller.
        SET @OrderID = SCOPE_IDENTITY()
        
        INSERT INTO dbo.tblOrderDTL (OrderID ,  OrderDetail) 
           VALUES (@OrderID , @OrderDetail )
      END
                     
    EXEC dbo.UpdateOrderLog @OrderEmployeeName, @OrderID , 'ADDORDER'
  
    IF(@@Error <> 0)                      -- could get a bit fancier here but
        ROLLBACK TRANSACTION                -- for now, any error aborts...
    ELSE                    
        COMMIT TRANSACTION
     
	RETURN
go

