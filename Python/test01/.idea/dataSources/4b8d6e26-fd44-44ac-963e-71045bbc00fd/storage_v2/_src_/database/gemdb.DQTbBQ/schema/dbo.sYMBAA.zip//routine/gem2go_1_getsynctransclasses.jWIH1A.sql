

CREATE PROCEDURE [dbo].[gem2go_1_GetSyncTransClasses]
    @CoreID int ,
    @User char(10)
AS
    SET NOCOUNT ON 

		Select TransClassId,
				[Description],
				DeclBalMode as 'DecliningBalance',
				EnableTimePay
		From dbo.tblTransClass      
         
    return
go

