CREATE FUNCTION [dbo].[RemoveBadgeSwipePrefix] (@BadgeNo char(19))  
	RETURNS char(19)
	AS
	BEGIN 
		DECLARE @Return char(19), 
				@BadgeSwipePrefix varchar(10)

		SET @BadgeSwipePrefix = dbo.GetOverheadItem('BadgeSwipePrefix')

		IF (@BadgeSwipePrefix <> '')
		BEGIN
			IF (LEFT(@BadgeNo, 1) = @BadgeSwipePrefix)
			BEGIN
				SET @BadgeNo = RIGHT(@BadgeNo, 18)
			END
			ELSE
				SET @Return = @BadgeNo
		END
		ELSE
			SET @Return = @BadgeNo
	
		RETURN @Return
	END
go

