

CREATE PROCEDURE dbo.ad_GetOrdersByRoom
@RoomNumber varchar(10),
@Bed varchar(10) = '%'
AS

	DECLARE @RoomID as int
	DECLARE @PatientVisitID as varchar(50)

	SELECT @RoomID = RoomID FROM dbo.tblRoomOHD (NOLOCK) WHERE RoomNumber = @RoomNumber

	SELECT @PatientVisitID = PatientVisitID
	FROM dbo.tblPatientVisit (NOLOCK) 
	WHERE RoomID = @RoomID AND Bed LIKE @Bed
		AND DischargeDate IS NULL
		AND MergedTo IS NULL

	SELECT @RoomNumber AS RoomNumber, PV.Bed,  O.OrderID, O.WaveID, O.OrderDate, O.SentDate, 
	        O.PostDate, O.Sent, O.Received, O.Retries, P.FullName, P.MedicalRecordID
	FROM dbo.tblOrderOHD O (NOLOCK)
	    LEFT JOIN dbo.tblPatientVisit PV (NOLOCK) ON PV.PatientVisitID = @PatientVisitID
			AND O.PatientVisitID = @PatientVisitID
			AND PV.DischargeDate IS NULL
	    LEFT JOIN dbo.tblPatientOHD AS P (NOLOCK) ON P.PatientID = PV.PatientID
	WHERE O.PatientVisitID = @PatientVisitID

	RETURN
go

