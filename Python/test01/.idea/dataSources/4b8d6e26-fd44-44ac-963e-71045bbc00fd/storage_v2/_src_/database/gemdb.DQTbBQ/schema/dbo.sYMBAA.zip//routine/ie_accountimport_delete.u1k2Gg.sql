

CREATE PROCEDURE dbo.ie_AccountImport_Delete
@ImportID	int
AS
	DELETE tblAccountImport WHERE ImportID = @ImportID
go

