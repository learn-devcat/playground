
CREATE PROCEDURE dbo.HL7_DietUpdate
@MedicalRecordID    varchar(30),
@PatientVisitID     varchar(50),
@DietName           varchar(50),
@IsSecondary        varchar(10),
@Source             varchar(50),
@TempActiveDate     varchar(30)='',
@Notes              varchar(500)=''
AS
    BEGIN TRANSACTION
        DECLARE @Msg        varchar(250),
                @DietID     int,
                @PatientID  int,
                @DietType   varchar(10),
                @RoomID     int,
                @Primary    int,
                @OldDiet    varchar(50),
                @OldDietID  int,
                @NewDiet    varchar(50),
                @ActiveDate datetime,
                @WaveID     int,
                @Period     varchar(100),
                @BeginTime  char(5)
                
        SELECT @PatientID = PV.PatientID,
            @RoomID = PV.RoomID,
            @OldDietID = PV.DietID,
            @OldDiet = D.Description
        FROM dbo.tblPatientVisit AS PV (NOLOCK) 
                JOIN dbo.tblPatientOHD AS P (NOLOCK) ON PV.PatientID = P.PatientID
                LEFT JOIN dbo.tblDietOHD AS D (NOLOCK) ON PV.DietID = D.DietID
                LEFT JOIN dbo.tblRoomOHD AS R (NOLOCK) ON PV.RoomID = R.RoomID
        WHERE PV.PatientVisitID = @PatientVisitID 
            AND P.MedicalRecordID = @MedicalRecordID
            
        IF (@PatientID IS NULL)
        BEGIN
            SET @Msg = 'Unable to process Diet Order for MedicalRecordID:' + @MedicalRecordID + '. PatientVisitID or MedicalRecordID not found.'
		    GOTO TransError
        END             

        IF ( UPPER(@IsSecondary) = 'Y' )
            SET @Primary = 0
        ELSE
            SET @Primary = 1
    
        -- Find diet
        IF ( @Primary = 1 )
        BEGIN
            SELECT @DietID = KeyOut
            FROM    dbo.tblXLAT (NOLOCK)
            WHERE   KeyIn = @DietName
                    AND xlatID = 'Diet'
            
            IF ( @DietID IS NULL )
            BEGIN
                SET @Msg = 'Unable to process Diet Order for MedicalRecordID:' + @MedicalRecordID + '. Diet:' + @DietName + ' not found.'
			    GOTO TransError
            END 
           
           SET @DietType = 'Primary'
           SELECT @NewDiet = D.Description
           FROM dbo.tblXLAT AS X (NOLOCK)
                LEFT JOIN dbo.tblDietOHD AS D (NOLOCK) ON CAST(X.KeyOut as integer) = D.DietID
           WHERE X.KeyIn = @DietName
                AND xlatID = 'Diet'
        END
        
        IF ( @Primary = 1 )
        BEGIN
            
            -- Adds the diet to the tblPatientDiet table
            -- We have to calculate the active date in order to do this entry
            IF ( LEN(@TempActiveDate) < 8 )
                SET @ActiveDate = getdate()
            ELSE
            BEGIN
                -- Since the message coming from HL7 has an indicator for the meal period (i.e., B, L, D), we have to
                -- do a transalation and stuff the beginning of the wave time into the ActiveDate field we are writing.
                SET @ActiveDate = CAST(LEFT(@TempActiveDate,4) + '-' + SUBSTRING(@TempActiveDate,5,2) + '-' + SUBSTRING(@TempActiveDate,7,2) as datetime)
                
                SET @TempActiveDate = RIGHT(@TempActiveDate, LEN(@TempActiveDate)-8)
                SELECT @WaveID = KeyOut
                FROM    dbo.tblXLAT (NOLOCK)
                WHERE   KeyIn = @TempActiveDate
                        AND xlatID = 'Diet'    
                        
                SELECT @Period = KeyOut
                FROM    dbo.tblXLAT (NOLOCK)
                WHERE   KeyIn = @TempActiveDate
                        AND xlatID = 'Diet2'    
            
                SELECT @BeginTime = BeginTime
                FROM dbo.tblWave
                WHERE   WaveID = @WaveID
           
                SET @ActiveDate = dbo.dDatePlusNewTime(@ActiveDate,@BeginTime)
            END
            
            INSERT INTO dbo.tblPatientDiet(PatientVisitID, DietID, ActiveDate, Source, Notes)
                VALUES (@PatientVisitID, @DietID, ISNULL(@ActiveDate,getdate()), @Source, @Notes)

	    -- Deletes all nutrient counts for orders that are being canceled
	    DELETE dbo.tblPatientNutrientCount 
	    WHERE ORDERID IN (SELECT OrderID FROM dbo.tblOrderOHD AS O (NOLOCK)
                        JOIN dbo.tblPatientVisit AS P (NOLOCK) ON (O.PatientVisitID = P.PatientVisitID OR O.PatientVisitID = P.MergedTo)
	                WHERE O.OrderDate > getdate()
	                        AND O.Cancelled <> 1)
	            
            -- Insert a log entry into the Order Log for all orders that we are cancelling
            INSERT INTO dbo.tblOrderLOG ( OrderID ,  ActionID , LoginUserID )
                SELECT OrderID, 700, 'HL7'
                FROM    dbo.tblOrderOHD AS O (NOLOCK)
                        JOIN dbo.tblPatientVisit AS P (NOLOCK) ON (O.PatientVisitID = P.PatientVisitID OR O.PatientVisitID = P.MergedTo)
                WHERE OrderDate > getdate() 
                        AND O.Cancelled <> 1
                                                
            -- Insert a log entry into the Patient Log for all orders that we are cancelling
            INSERT INTO dbo.tblPatientLog (EventClassID, LoginUserID, PatientID, RoomID, [Description], [Date])
                SELECT 7000, @Source, P.PatientID, P.RoomID, @Msg, getdate()
                FROM    dbo.tblOrderOHD AS O (NOLOCK)
                        JOIN dbo.tblPatientVisit AS P (NOLOCK) ON (O.PatientVisitID = P.PatientVisitID OR O.PatientVisitID = P.MergedTo)
                WHERE O.OrderDate > getdate() 
                        AND O.Cancelled <> 1                        

            -- Set the cancelled flag to 1 for any orders in future waves
            UPDATE  dbo.tblOrderOHD
            SET Cancelled = 1,
                CancelDate = getdate()
            FROM    dbo.tblOrderOHD AS O (NOLOCK)
                    JOIN dbo.tblPatientVisit AS P (NOLOCK) ON (O.PatientVisitID = P.PatientVisitID OR O.PatientVisitID = P.MergedTo)
	WHERE O.OrderDate > ISNULL(@ActiveDate,getdate())
	                AND ISNULL(O.Cancelled,0) <> 1
		  AND O.PatientVisitID = @PatientVisitID
        END
        ELSE
    BEGIN
            SET @DietType = 'Secondary'
        END
     
        IF ( @DietType = 'Primary' )
            SET @Msg = ISNULL(UPPER(@NewDiet),'NOT FOUND') + ' diet added for ' + dbo.DateString(@ActiveDate) + ' by ' + ISNULL(@Notes,'[UNKNOWN]') + ' (starts at: ' + ISNULL(@Period,'') + ')'
        ELSE
            SET @Msg = 'Secondary Diet ' + ISNULL(UPPER(@NewDiet),'NOT FOUND') + ' added for ' + dbo.DateString(@ActiveDate) + ' by ' + ISNULL(@Notes,'[UNKNOWN]') + ' (starts at:' + ISNULL(@Period,'') + ')'
            
        EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, @PatientVisitID, @RoomID, @Msg
        EXEC dbo.ProcessLogInsert @Source            
	COMMIT TRANSACTION
    
	RETURN 
	
TransError:
	ROLLBACK TRANSACTION

	IF ( @Msg IS NULL )
		SET @Msg = 'Unable to process Diet Order for MedicalRecordID:' + @MedicalRecordID + '. Diet:' + ISNULL(UPPER(@NewDiet),'NOT FOUND')

	    EXEC dbo.Logit 1, @Msg, 'system'
go

