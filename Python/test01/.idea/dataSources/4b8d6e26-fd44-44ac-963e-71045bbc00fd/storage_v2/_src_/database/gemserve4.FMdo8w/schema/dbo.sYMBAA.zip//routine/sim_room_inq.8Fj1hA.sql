CREATE PROCEDURE [dbo].[sim_Room_INQ]
@CoreID INT, @LoginUserID VARCHAR (250), @RoomNumber VARCHAR (10), @OrderType INT = 1
AS
SET NOCOUNT ON

	DECLARE @ReturnMsg		 	varchar(8000),
		    @Room			varchar(10),
		    @Count			int,
		    @PatientInfo		varchar(8000),
		    @PatientInfoOnInquire 	char(1),
		    @PatientVisitID		varchar(50),
		    @PatientRoom		varchar(20),
		    @PatientName		varchar(50),
		    @DietID			int,
		    @SpecialPatientIndicator	int,
		    @PatientID			int,
		    @POSRoomLookup		int,
		    @PatientCount		int,
			@AppendBed			varchar(10)
		    
	 DECLARE @MyPatients TABLE (
		PatientVisitID		varchar(50),
		PatientRoom		varchar(20),
		Room			varchar(10),
		PatientName		varchar(50),
		DietID			int DEFAULT(-1))

	SELECT @POSRoomLookup = COALESCE(dbo.GetOverheadValueNull('POSRoomLookup'),0)
	SELECT @AppendBed = COALESCE(dbo.GetOverheadValueNull('AppendBed'),'')

	SET @SpecialPatientIndicator = COALESCE(dbo.GetOverheadValue('SpecialPatientIndicator'),0)

	SET @PatientInfo = ''
	SELECT @PatientInfoOnInquire = dbo.GetOverheadValue('PatientInfoOnInquire')

	IF ( @PatientInfoOnInquire = '' )
		SET @PatientInfoOnInquire = '0'

	IF (@POSRoomLookup = 1)
		SET @RoomNumber = @RoomNumber + '%'


	IF NOT EXISTS (SELECT 1 FROM dbo.tblRoomOHD (NOLOCK) WHERE RoomNumber LIKE @RoomNumber)
		SET @ReturnMsg = '/Room Not Found'
    ELSE
        BEGIN
		-- Count rows being returned
		SELECT @PatientCount = COUNT(PV.PVID) 
		FROM dbo.tblRoomOHD AS R (NOLOCK)
		JOIN dbo.tblRoomClass AS RC (NOLOCK) ON R.RoomClassID = RC.RoomClassID
		JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON R.RoomID = PV.RoomID
		JOIN dbo.tblPatientOHD AS P ON PV.PatientID = P.PatientID
		LEFT JOIN dbo.tblDietOHD AS D ON D.DietID = PV.DietID
		WHERE R.RoomNumber LIKE  @RoomNumber
		AND PV.DischargeDate IS NULL
		AND PV.MergedTo IS NULL		

		IF (@PatientCount > 50)
			INSERT INTO @MyPatients (PatientVisitID, PatientRoom, Room, PatientName, DietID)
		             SELECT TOP 50 CAST(PV.PatientVisitID AS varchar(50)),
				CAST(R.RoomNumber + ISNULL(PV.bed,'') AS varchar(20)),
					CAST(R.RoomNumber AS varchar(10)),
	             			CAST((R.RoomNumber + '-' + P.FullName) AS varchar(18)),
	             			CAST(D.POSDietID AS varchar(5))
		             FROM dbo.tblRoomOHD AS R (NOLOCK)
			     JOIN dbo.tblRoomClass AS RC (NOLOCK) ON R.RoomClassID = RC.RoomClassID
			     JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON R.RoomID = PV.RoomID
		             JOIN dbo.tblPatientOHD AS P ON PV.PatientID = P.PatientID
		             JOIN dbo.tblDietOHD AS D ON D.DietID = PV.DietID
		             WHERE R.RoomNumber LIKE @RoomNumber
				AND PV.DischargeDate IS NULL
				AND PV.MergedTo IS NULL
					ORDER BY R.RoomNumber
		ELSE
			INSERT INTO @MyPatients (PatientVisitID, PatientRoom, Room, PatientName, DietID)
		             SELECT CAST(PV.PatientVisitID AS varchar(50)),
				CAST(R.RoomNumber + ISNULL(PV.bed,'') AS varchar(20)),
					CAST(R.RoomNumber AS varchar(10)),
	             			CAST((R.RoomNumber + '-' + COALESCE(P2.FullName, P.FullName)) AS varchar(18)),
	             			CAST(D.POSDietID AS varchar(5))
		             FROM dbo.tblRoomOHD AS R (NOLOCK)
			     JOIN dbo.tblRoomClass AS RC (NOLOCK) ON R.RoomClassID = RC.RoomClassID
			     JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON R.RoomID = PV.RoomID
		             JOIN dbo.tblPatientOHD AS P ON PV.PatientID = P.PatientID
					 LEFT JOIN dbo.tblPatientOHD AS P2 ON P.MergedTo = P2.MedicalRecordID
		             JOIN dbo.tblDietOHD AS D ON D.DietID = PV.DietID
		             WHERE R.RoomNumber LIKE @RoomNumber
				AND PV.DischargeDate IS NULL
				AND PV.MergedTo IS NULL
					ORDER BY R.RoomNumber

		IF @@ROWCOUNT = 0
		BEGIN
			SET @ReturnMsg = '/Room Not Occupied'
		END
		ELSE
		BEGIN
			-- Get the Num of Records            
			SELECT @Count = COUNT(DietID) FROM @MyPatients

			IF (NOT EXISTS (SELECT DietID FROM @MyPatients WHERE DietID <> -1) AND @OrderType = 1)
			BEGIN
				SET @ReturnMsg = '/No Diet Assigned'
			END
			
			ELSE
			BEGIN
				DECLARE Temp CURSOR FOR
				SELECT PatientVisitID, PatientRoom, Room, PatientName,DietID
				FROM 	@MyPatients
				ORDER BY PatientName, PatientRoom, PatientVisitID, DietID
	        
				OPEN Temp
				FETCH NEXT FROM Temp INTO @PatientVisitID, @PatientRoom, @Room, @PatientName, @DietID
	
				WHILE ( @@FETCH_STATUS = 0)
				BEGIN
					SELECT @PatientID = PatientID
					FROM dbo.tblPatientVisit
					WHERE PatientVisitID = @PatientVisitID

					IF (@SpecialPatientIndicator <> 0) 
						AND EXISTS(SELECT 1 FROM dbo.tblPatientStatusFlags WHERE PatientID = @PatientID AND StatusFlagID = @SpecialPatientIndicator)
							SET @PatientName = '*' + @PatientName
						
					SET @PatientInfo = @PatientInfo + char(28) + Cast(@PatientVisitID as varchar(50)) + '^'

					IF (@AppendBed = '')
							SET @PatientInfo = @PatientInfo + @PatientRoom + '^' + Cast(@PatientName as varchar(50)) + '^' +Cast(COALESCE(@DietID,-1) as varchar(10)) 
					ELSE
							SET @PatientInfo = @PatientInfo + @Room + '^' + Cast(@PatientName as varchar(50)) + '^' + Cast(COALESCE(@DietID,-1) as varchar(10)) 
	
					FETCH NEXT FROM Temp INTO @PatientVisitID, @PatientRoom, @Room, @PatientName, @DietID
			      	END
		
				CLOSE Temp
				DEALLOCATE Temp
	
			     	IF ( LEN( @PatientInfo ) > 0)
					SET @PatientInfo = RIGHT(@PatientInfo, LEN(@PatientInfo) -1)
	  
				SET @ReturnMsg = @RoomNumber + char(28) + @PatientInfoOnInquire + char(28) + Cast(@Count as varchar(10)) + char(28) + @PatientInfo
			END
		END
	END

Finished:
	SELECT @ReturnMsg
go

