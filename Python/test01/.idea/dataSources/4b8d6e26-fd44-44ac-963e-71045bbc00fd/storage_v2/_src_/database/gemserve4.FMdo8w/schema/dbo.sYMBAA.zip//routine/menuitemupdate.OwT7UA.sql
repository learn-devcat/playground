

CREATE PROCEDURE dbo.MenuItemUpdate
@LoginUserID				varchar(250),
@MenuItemID			int,
@Description			varchar(50),
@Cost				money,
@Price				money,
@POSMenuItemID			int=null,
@POSMenuItemSEQ			int=null,
@POSLegend			varchar(16)=null,
@MajorGroupSequence		int=null,
@FamilyGroupSequence		int=null,
@MenuItemGroupSequence		int=null,
@MenuItemTypeSequence		int=null,
@MenuLevelClassSequence		int=null,
@PrinterDefClassSequence	int=null,
@CrossReference1		varchar(50)=null,
@CrossReference2		varchar(50)=null

AS
	SET NOCOUNT ON
	DECLARE @POSMenuEditing	varchar(10),
		 @TempLegend	varchar(16)

	SET @POSMenuEditing = dbo.GetOverheadValue('POSMenuEditing')

	IF(@MenuItemID < 1)
	BEGIN
		INSERT INTO dbo.tblMenuItemOHD([Description], Cost, Price, POSMenuItemID, POSMenuItemSEQ,
			POSLegend, MajorGroupSequence, FamilyGroupSequence, MenuItemGroupSequence,
			MenuItemTypeSequence, MenuLevelClassSequence, PrinterDefClassSequence,
			CrossReference1, CrossReference2)
		VALUES(@Description, @Cost, @Price, @POSMenuItemID, @POSMenuItemSEQ,
			@POSLegend, @MajorGroupSequence, @FamilyGroupSequence, @MenuItemGroupSequence,
			@MenuItemTypeSequence, @MenuLevelClassSequence, @PrinterDefClassSequence,
			@CrossReference1, @CrossReference2)

		SELECT @MenuItemID = SCOPE_IDENTITY()
	END
	ELSE
		UPDATE dbo.tblMenuItemOHD 
		SET [Description] = @Description,
			Cost = @Cost,
			Price = @Price,
			POSMenuItemID = @POSMenuItemID,
			POSMenuItemSEQ = @POSMenuItemSEQ,
			POSLegend = @POSLegend,
			MajorGroupSequence = @MajorGroupSequence,	
			FamilyGroupSequence = @FamilyGroupSequence,
			MenuItemGroupSequence = @MenuItemGroupSequence,
			MenuItemTypeSequence = @MenuItemTypeSequence,
			MenuLevelClassSequence = @MenuLevelClassSequence,
			PrinterDefClassSequence = @PrinterDefClassSequence,
			CrossReference1 = @CrossReference1,
			CrossReference2 = @CrossReference2
		WHERE MenuItemID = @MenuItemID

	IF(@POSMenuEditing = '1')
	BEGIN
		IF (@POSLegend IS NULL)
		BEGIN
			IF (LEN(@Description) > 16)
				SET @POSLegend = LEFT(@Description,16)
			ELSE
				SET @POSLegend = @Description
		END

		EXEC @POSMenuItemSEQ = dbo.Micros_MenuItemUpdate @POSMenuItemID OUTPUT, 
			@POSLegend, @MajorGroupSequence, @FamilyGroupSequence,
			@MenuItemGroupSequence, @MenuItemTypeSequence, @MenuLevelClassSequence, 
			@PrinterDefClassSequence, @CrossReference1, @Cost, @Price

		SELECT @TempLegend = Legend
		FROM dbo.tblMenuItem_Touchscreen
		WHERE MenuItemID = @MenuItemID

		IF (@TempLegend <> @POSLegend)
			UPDATE dbo.tblMenuItem_Touchscreen 
			SET Legend = @POSLegend,
				Modified = 1
			WHERE MenuItemID = @MenuItemID

		-- Update the menu item sequence number using the value returned from the Micros
		UPDATE dbo.tblMenuItemOHD
		SET POSMenuItemSEQ = @POSMenuItemSEQ,
			POSMenuItemID = @POSMenuItemID
		WHERE MenuItemID = @MenuItemID
	END

    SELECT @MenuItemID AS MenuItemID

	RETURN
go

