
CREATE      PROCEDURE dbo.WorkorderDTL_PostCharge
@User           char(10),
@WorkOrderID    int,
@WorkOrderDTLID int,
@EmployeeID     int,
@CDate          dateTime
AS
DECLARE @TransDate      datetime,
@WorkOrderNumber varchar(50),
@AccountNo      char(19),
@BadgeNo        char(19),
@OutletNo       int,
@DTLTransID     int,
@CheckNo        varchar(6),
@DTLTransTotal  money,
@PostResult     int
SET @TransDate = ISNULL( @CDate , getdate())
-- Retrieve the Transaction Details  
SELECT  @DTLTransTotal = DTL.Price,
   	@DTLTransID    = DEF.TransID,
   	@AccountNo     = O.AccountNo,
	@OutletNo      = L.DefaultWorkOrderOutlet,
   	@WorkOrderNumber = O.WorkOrderNumber
FROM 	tblWorkOrderDTL DTL
	LEFT JOIN tblWorkOrderOHD O      on DTL.WorkOrderID = O.WorkOrderID
	LEFT JOIN cfgLocations L         on O.LocationID = L.LocationID
	LEFT JOIN tblWorkOrderDTLDEF DEF on DTL.WorkOrderDTLDEFID = DEF.WorkOrderDTLDEFID
WHERE 	DTL.WorkOrderID    = @WorkOrderID AND
   	DTL.WorkOrderDTLID = @WorkOrderDTLID
-- Now, resolve the Badge Number, since we need one of these...
SELECT  Top 1
    	@BadgeNo = BadgeNo
FROM  	tblBadgesOHD
WHERE  	AccountNo = @AccountNo AND
    	ActiveDate <= @TransDate AND
   	ExpireDate >= @TransDate AND
    	Inactive = 0
ORDER BY PrimaryBadge 
-- SET the checkno to the wonumber AND wodtlid (trimed)
SET @CheckNo = Cast(@WorkOrderDTLID as VarChar(2))
SET @CheckNo = Right(RTRIM(@WorkOrderNumber), (5 - LEN(@CheckNo))) + '\' + @CheckNo
-- Now, we should have all our detail -- so let's try to post this thing.
EXEC @PostResult =  dbo.sp_Trans_Post 0, @User, @AccountNo, @BadgeNo, @TransDate, @OutletNo, 
                                     'WO' , @CheckNo, @DTLTransTotal, @DTLTransTotal, @WorkOrderNumber, 
                                      0 , @DTLTransID , '', 0 , 0, @EmployeeID 
SELECT @PostResult as ReturnMessage
RETURN
go

