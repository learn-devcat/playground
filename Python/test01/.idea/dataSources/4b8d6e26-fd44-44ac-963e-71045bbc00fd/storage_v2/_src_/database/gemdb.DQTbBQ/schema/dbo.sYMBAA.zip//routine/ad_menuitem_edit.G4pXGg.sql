




CREATE    PROCEDURE [dbo].[ad_MenuItem_Edit]
@User			char(10),
@ExistingMenuID		int,
@NewMenuID		int,
@ParentID		int,
@Description		varchar(128),
@URL			varchar(255),
@ActionID		int,
@ShortDescription VARCHAR(50),
@Synopsis	VARCHAR(255),
@DELETE			bit = 0

AS 
	DECLARE @MenuID int,
		@Message	varchar(255),
		@EditErr	int	

	IF @DELETE = 1
		GOTO DODELETE

	IF (@NewMenuID > -1 AND @ExistingMenuID = -1)
	BEGIN
		INSERT dbo.cfgMenus
		VALUES(@NewMenuID,@ParentID,@Description,@URL,9,0,'',@ActionID, @ShortDescription, @Synopsis,'')

		SELECT @Message = 	'New Menu Item Added: (' + CAST(MenuID as varchar(8)) + ') ' +  [Description]
					FROM	dbo.cfgMenus
					WHERE	MenuID = @NewMenuID
	END
	ELSE
	BEGIN

		SET @MenuID = CASE 
				WHEN @NewMenuID > -1 
				THEN @NewMenuID
				ELSE @ExistingMenuID 
			     END
		UPDATE	dbo.cfgMenus
		SET	MenuID = @MenuID,
			SubMenuID = @ParentID,
			[Description] = @Description,
			URL = @URL,
			ActionID = @ActionID,
			ShortDescription = @ShortDescription,
			Synopsis = @Synopsis
		WHERE	MenuID = @ExistingMenuID

		SET @EditErr = @@Error

		SELECT @Message = 	('Edit of MenuID (' + CAST(@MenuID as varchar) + ') ' + 
					CASE WHEN (SELECT MenuID FROM dbo.cfgMenus WHERE MenuID = @MenuID) IS NULL
					     THEN 'FAILED'  + ' | Err Num: ' + CAST(@EditErr as varchar(50))
					     ELSE 'SUCCEDED'
					     END)
	END

		SET @Message = 'MenuID: ' +  CAST(@MenuID as varchar(50)) + ' SubMenuID: ' + CAST(@ParentID as varchar(50)) + ' [Description]: ' + @Description + 'ExistsID: ' + CAST(@ExistingMenuID as varchar(50))

	EXEC dbo.sp_Logit 9, 1, @User, @Message, 1010	
	SELECT @Message AS 'Rtn'

	RETURN

	DODELETE:
	DELETE	dbo.cfgMenus
	WHERE	MenuID = @ExistingMenuID

	IF EXISTS (SELECT * FROM dbo.cfgMenus WHERE MenuID = @ExistingMenuID)
		SELECT @Message = 'DELETE Menu ID (' + CAST(@ExistingMenuID as varchar(8)) + ') Failed'
	ELSE
		SELECT @Message = 'DELETE Menu ID (' + CAST(@ExistingMenuID as varchar(8)) + ') Succeded'

	
	EXEC dbo.sp_Logit 9, 1, @User, @Message, 1010	
	SELECT @Message AS 'Rtn'
go

