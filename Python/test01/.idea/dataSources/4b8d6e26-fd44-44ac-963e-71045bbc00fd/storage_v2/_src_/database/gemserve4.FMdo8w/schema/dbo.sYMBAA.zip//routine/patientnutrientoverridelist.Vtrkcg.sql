
CREATE PROCEDURE [dbo].[PatientNutrientOverrideList]
@PatientDietID  int

AS
	SET NOCOUNT ON

	DECLARE @MealPeriodID	int,
		@MealPeriodName	varchar(50),
		@EndTime	char(5),
		@DietID		int,
		@SQL		nvarchar(1000),
		@Update		nvarchar(1000),
		@CounterString	varchar(10),
		@Counter	int,
		@Return		varchar(1000),
		@MaxQty		decimal(10,3),
        @PatientID      int
	
	CREATE TABLE #Nutrients (
				NutrientID 	int,
				Nutrient 	varchar(50),
				Daily_Max	decimal(10,3),
				Daily_Max1	int
				)
	SET @Counter = 1
	
    SELECT @PatientID = PV.PatientID 
		FROM dbo.tblPatientDiet AS PD (NOLOCK)
		JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON PD.PatientVisitID = PV.PatientVisitID

	SELECT @DietID = DietID FROM dbo.tblPatientDiet WHERE [ID] = @PatientDietID
	
	INSERT INTO #Nutrients (NutrientID, Nutrient, Daily_Max, Daily_Max1)
	SELECT 	N.NutrientID,
		N.[Description],
		COALESCE(PD.Qty, DN.DailyMax, N.DefaultQty),
		CASE
			WHEN PD.Qty IS NOT NULL THEN 1
			WHEN DN.DailyMax IS NOT NULL THEN 2
			ELSE 0
		END
	FROM	dbo.cfgNutrients AS N
		LEFT JOIN dbo.tblPatientDailyNutrientOverride AS PD ON PD.PatientDietID = @PatientDietID
		    AND PD.NutrientID = N.NutrientID
		LEFT JOIN dbo.tblDietDailyNutrients AS DN ON DN.DietID = @DietID AND DN.NutrientID = N.NutrientID
	
	DECLARE MealPeriods cursor FOR
		SELECT 	DISTINCT M.MealPeriodID, '_' + REPLACE(M.[Description],')','_'),dbo.MealPeriodEndTime(getdate(), M.MealPeriodID)
		FROM 	dbo.tblMealPeriods AS M (NOLOCK)
		ORDER BY M.MealPeriodID, '_' + REPLACE(M.[Description],')','_'),dbo.MealPeriodEndTime(getdate(), M.MealPeriodID)

	OPEN MealPeriods
	FETCH NEXT FROM MealPeriods INTO @MealPeriodID, @MealPeriodName, @EndTime
	
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @MealPeriodName = REPLACE(@MealPeriodName,' ','_')
		SET @MealPeriodName = REPLACE(@MealPeriodName,'-','__')
		SET @MealPeriodName = REPLACE(@MealPeriodName,':','___')
		SET @MealPeriodName = REPLACE(@MealPeriodName,'/','____')

		SET @SQL = 'ALTER TABLE #Nutrients ADD ' + @MealPeriodName + ' decimal(10,3)'
		EXEC sys.sp_executesql @SQL

		SET @SQL = 'ALTER TABLE #Nutrients ADD ' + @MealPeriodName + '1 int'
		EXEC sys.sp_executesql @SQL

		SET @CounterString = CAST(@Counter AS varchar(10))


		SET @Update = 'UPDATE #Nutrients SET ' +  @MealPeriodName 
		SET @Update = @Update + ' = COALESCE(PW.Qty, DM.Qty, 99999.000),'
		SET @Update = @Update + ' ' + @MealPeriodName + '1 = CASE WHEN PW.Qty IS NOT NULL THEN 1'
		SET @Update = @Update + ' WHEN DM.Qty IS NOT NULL THEN 2 ELSE 0 END FROM #Nutrients AS N' 
		SET @Update = @Update + ' LEFT JOIN dbo.tblPatientMealPeriodNutrientOverride AS PW ON PW.PatientDietID = @myPatientDietID '
		SET @Update = @Update + ' AND PW.NutrientID = N.NutrientID AND PW.MealPeriodID = @myMealPeriodID'
		SET @Update = @Update + ' LEFT JOIN dbo.tblDietMealPeriodNutrients AS DM ON DM.MealPeriodID = @myMealPeriodID'
		SET @Update = @Update + ' AND DM.NutrientID = N.NutrientID AND DM.DietID = @myDietID '

		EXEC sys.sp_executesql @Update, N'@myPatientDietID int, @myDietID int, @myMealPeriodID int, @Qty decimal(10,3)', @PatientDietID, @DietID, @MealPeriodID, @MaxQty

		SET @Counter = @Counter + 1
	
		FETCH NEXT FROM MealPeriods INTO @MealPeriodID, @MealPeriodName, @EndTime
	END
	
	CLOSE MealPeriods
	DEALLOCATE MealPeriods
	
	SELECT * FROM #Nutrients ORDER BY NutrientID
	
	DROP TABLE #Nutrients
go

