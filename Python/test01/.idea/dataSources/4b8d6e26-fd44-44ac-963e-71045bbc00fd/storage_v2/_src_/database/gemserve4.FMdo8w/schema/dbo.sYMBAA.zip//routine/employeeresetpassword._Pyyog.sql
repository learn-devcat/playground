

CREATE PROCEDURE dbo.EmployeeResetPassword
@LoggedOnUser	varchar(20),
@LoginUserID     varchar(250)

AS
	SET NOCOUNT ON 
	
	DECLARE @Return int
	
	UPDATE dbo.tblEmployees
        	SET [Password] = '5f4dcc3b5aa765d61d8327deb882cf99'
		WHERE   LoginUserID = @LoginUserID
		
	RETURN
go

