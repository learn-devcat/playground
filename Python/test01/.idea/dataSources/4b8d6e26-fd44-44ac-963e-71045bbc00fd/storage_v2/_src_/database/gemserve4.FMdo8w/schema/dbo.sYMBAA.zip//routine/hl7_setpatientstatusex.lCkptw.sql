CREATE PROCEDURE [dbo].[HL7_SetPatientStatusEX]
@PatientID	varchar(50),
@PatientDietID	varchar(50),
@Modifier	varchar(50),
@Source		varchar(100)

AS
	SET NOCOUNT ON
	
	DECLARE @KeyOut 	varchar(50),
		@Description	varchar(50),
		@Start		int,
		@Temp		char(1),
		@Msg 		varchar(300),
		@iPatientID	int,
		@iPatientDietID	int,
		@RoomID		int,
		@Overhead	varchar(200),
		@Count		int,
		@Start2		int,
		@Message	varchar(50)		,
		@PatientVisitID varchar(50)

	DECLARE @Status TABLE (StatusID int, Description varchar(50))
	SET @Start2 = 1
	SET @Count = 1

	SELECT @Overhead = dbo.GetOverheadValue('PatientStatusFields')
	IF (@Overhead <> '')
	BEGIN
		WHILE (1=1)
		BEGIN
			
			IF (CHARINDEX(',',@Overhead, @Start2) > 0)
			BEGIN
				INSERT INTO @Status
				VALUES (@Count, SUBSTRING(@Overhead, @Start2, CHARINDEX(',',@Overhead, @Start2) - @Start2))

				SET @Start2 = CHARINDEX(',',@Overhead, @Start2) + 1

				IF (@Start2 > LEN(@Overhead))
					GOTO FinishStatus

				SET @Count = @Count + 1
			END
			ELSE
			BEGIN
				INSERT INTO @Status
				VALUES (@Count, SUBSTRING(@Overhead, @Start2, LEN(@Overhead) - @Start2))

				GOTO FinishStatus
			END
		END
	END

FinishStatus:

	IF (COALESCE(@PatientID,0) > 0)
	BEGIN
		SET @iPatientID = CAST(@PatientID AS int)

		SELECT 	@RoomID = PV.RoomID,
			@PatientVisitID = PD.PatientVisitID
		FROM dbo.tblPatientDiet AS PD (NOLOCK)
		JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON PD.PatientVisitID = PV.PatientVisitID
		WHERE PV.PatientID = @iPatientID
			AND DischargeDate IS NULL
	END
	ELSE
	BEGIN
		SET @iPatientDietID = CAST(@PatientDietID AS int)

		SELECT @iPatientID = PV.PatientID,
			@RoomID = PV.RoomID,
			@PatientVisitID = PD.PatientVisitID
		FROM dbo.tblPatientDiet AS PD (NOLOCK)
		JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON PD.PatientVisitID = PV.PatientVisitID
		WHERE PD.[ID] = @iPatientDietID
	END				

	SELECT @KeyOut = KeyOut, 
		@Description = Description
	FROM dbo.tblxlat 
	WHERE KeyIn = @Modifier AND xlatId = 'OptionalStatus'

	IF (@KeyOut IS NOT NULL)
    	BEGIN
		SET @Start = 1
	
		WHILE (1=1)
		BEGIN
			SELECT @Temp = SUBSTRING(@Description,@Start,1)
			
			SELECT @Message = Description
			FROM @Status 
			WHERE StatusID = @Start
	
				IF (@Temp <> 'x')
			BEGIN
				IF (@Start = 1)
				BEGIN
					IF NOT EXISTS (SELECT 1 FROM dbo.tblPatientOHD WHERE PatientID = @PatientID AND OptionalStatus1 = CAST(@Temp AS int))
					BEGIN
					                UPDATE dbo.tblPatientOHD SET OptionalStatus1 = CAST(@Temp AS int) WHERE PatientID = @iPatientID
						SET @Msg = 'Patient Status [' + @Message + '] set to ' +
							CASE WHEN @Temp = '1' THEN '[ON].'
								ELSE '[OFF].'
							END
	
						EXEC dbo.PatientLOGAdd 7000, 'HL7', @iPatientID, @PatientVisitID, @RoomID, @Msg
					END
				END
			
			        IF (@Start = 2)
				BEGIN
					IF NOT EXISTS (SELECT 1 FROM dbo.tblPatientOHD WHERE PatientID = @PatientID AND OptionalStatus2 = CAST(@Temp AS int))
					BEGIN
					                UPDATE dbo.tblPatientOHD SET OptionalStatus2 = CAST(@Temp AS int) WHERE PatientID = @iPatientID
							SET @Msg = 'Patient Status [' + @Message + '] set to ' +
								CASE WHEN @Temp = '1' THEN '[ON].'
									ELSE '[OFF].'
								END
		
							EXEC dbo.PatientLOGAdd 7000, 'HL7', @iPatientID, @PatientVisitID, @RoomID, @Msg				
					END
				END
		
			        IF (@Start = 3)
				BEGIN
					IF NOT EXISTS (SELECT 1 FROM dbo.tblPatientOHD WHERE PatientID = @PatientID AND OptionalStatus3 = CAST(@Temp AS int))
					BEGIN
					                UPDATE dbo.tblPatientOHD SET OptionalStatus3 = CAST(@Temp AS int) WHERE PatientID = @iPatientID
						SET @Msg = 'Patient Status [' + @Message + '] set to ' +
							CASE WHEN @Temp = '1' THEN '[ON].'
								ELSE '[OFF].'
							END

						EXEC dbo.PatientLOGAdd 7000, 'HL7', @iPatientID, @PatientVisitID, @RoomID, @Msg				
					END
				END
			
				IF (@Start = 4)
				BEGIN
					IF NOT EXISTS (SELECT 1 FROM dbo.tblPatientOHD WHERE PatientID = @PatientID AND OptionalStatus4 = CAST(@Temp AS int))
					BEGIN
					                UPDATE dbo.tblPatientOHD SET OptionalStatus4 = CAST(@Temp AS int) WHERE PatientID = @iPatientID
						SET @Msg = 'Patient Status [' + @Message + '] set to ' +
							CASE WHEN @Temp = '1' THEN '[ON].'
								ELSE '[OFF].'
							END
	
						EXEC dbo.PatientLOGAdd 7000, 'HL7', @iPatientID, @PatientVisitID, @RoomID, @Msg				
					END
				END				
			END

			SET @Start = @Start + 1

			IF (@Start > 4)
				BREAK
		END
	END

	RETURN
go

