CREATE FUNCTION [dbo].[GetStatusFlagsForDashboard]()
RETURNS VARCHAR(200)
AS
BEGIN
	DECLARE	@Return VARCHAR(200),
	@StatusCount int

	-- Get the top four statuses with the OnDashboard flag set
	SELECT	TOP 4 @Return = COALESCE(@Return + ',', '') + CONVERT(VARCHAR(50), [Description])
	FROM	dbo.tblStatusFlags
	WHERE	(OnDashBoard = 1)
	ORDER BY StatusFlagID

	SET @StatusCount = @@ROWCOUNT

	--Always return four comma-separated statuses even if they are blank 
	WHILE @StatusCount < 4
	BEGIN
		SET @Return = @Return + ','
		SET @StatusCount = @StatusCount + 1
	END

	RETURN	@Return
END
go

