CREATE PROCEDURE [dbo].[sp_Recur_PostCharges_EX]
      @User CHAR(10) ,
      @RecurringClassID INT,
	  @DefaultTransDate DATETIME = null
AS 
      DECLARE @AccountNo CHAR(19) ,
              @AccountClassID INT ,
              @TransID INT ,
              @OutletNo INT ,
              @Description CHAR(24) ,
              @Amount MONEY ,
              @Percent SMALLMONEY ,
              @Minimum BIT ,
              @Balance BIT ,
              @PastDue BIT ,
              @TrackSlotNum INT ,
              @TrackIDNum INT ,
              @TAmount MONEY ,
              @T2Amount MONEY ,
              @CheckMin MONEY ,
              @TransAmount MONEY ,
              @CoreID INT ,
              @TransDate DATETIME ,
              @BadgeNo CHAR(19) ,
              @RefNum CHAR(6) ,
              @ChkNum CHAR(6) ,
              @Comment VARCHAR(40) ,
              @DateOffset INT ,
              @DoTax1 BIT ,
              @DoTax2 BIT ,
              @DoTax3 BIT ,
              @DoTax4 BIT ,
              @Tax1 MONEY ,
              @Tax2 MONEY ,
              @Tax3 MONEY ,
              @Tax4 MONEY ,
              @CycleNo INT ,
              @Sales1 MONEY ,
              @TempNumber INT ,
              @AllowNegAmt BIT ,
              @BatchID CHAR(10) ,
              @ExpiredAccountsOnly BIT ,
              @PostToAltAccount BIT ,
              @AltAccountNo VARCHAR(19) ,
              @AltBadgeNo VARCHAR(19) ,
              @AltTransID INT ,
              @AltOutletNo INT ,
              @OKtoProcess BIT ,
              @ExpireDate DATETIME ,
              @Comment2 VARCHAR(40) ,
              @Formula VARCHAR(500) ,
              @UseOutletClassBal BIT,
			  @BalanceMax MONEY


   /*
         05-Oct-12   wjscott
         Update various selectors to enable more of the individual items to work with each other instead of exclusive.
   */            
    
      SET @OKtoProcess = 1
        -- SET @CycleNo = dbo.CurrentCycleNo(1)			
        SET @CycleNO = -1						-- 14-Jan-13, wjs -- this needs to get resolved later!

      SET @TempNumber = 0
    
      DECLARE sRecur1 CURSOR
      FOR
              SELECT    R.AccountNo ,
                        R.AcctClassID ,
                        R.TransID ,
                        R.OutletNo ,
                        R.Description ,
                        R.Amount ,
                        R.[Percent] ,
                        R.Minimum ,
                        R.Balance ,
                        R.PastDue ,
                        R.TrackSlotNum ,
                        R.TrackIDNum ,
                        R.tax1 ,
                        R.tax2 ,
                        R.tax3 ,
                        R.tax4 ,
                        T.Preset ,
                        T2.Preset ,
                        C.Dtl_ChkNum ,
                        C.Dtl_RefNum ,
                        C.Dtl_Comment ,
                        C.NextDate - C.DateOffset ,
                        R.AllowNegAmt ,
                        CASE WHEN RTRIM(ISNULL(R.BatchID, '')) = '' THEN 'recur'
                             ELSE R.BatchID
                        END ,
                        R.ExpiredAccountsOnly ,
                        R.PostToAltAccount ,
                        R.AltAccountNo ,
                        R.AltBadgeNo ,
                        R.AltTransID ,
                        R.AltOutletNo ,
                        R.Formula ,
                        R.UseOutletClassBal,
						R.BalanceMax
              FROM      tblRecurChg AS R
                        LEFT JOIN tblTransDef AS T ON R.TransID = T.TransID
                        LEFT JOIN tblTransDef AS T2 ON R.AltTransID = T2.TransID
                        LEFT JOIN tblRecurChgClass AS C ON R.ClassID = C.ClassID
              WHERE     R.ClassID = @RecurringClassID
                        AND R.Active = 1
                        
                
      OPEN sRecur1  
    
      FETCH NEXT FROM sRecur1 INTO @AccountNo, @AccountClassID, @TransID, @OutletNo, @Description, @Amount, @Percent, @Minimum, @Balance, @PastDue, @TrackSlotNum, @TrackIDNum, @DoTax1, @DoTax2, @DoTax3, @DoTax4, @TAmount, @T2Amount, @RefNum, @ChkNum, @Comment, @TransDate, @AllowNegAmt, @BatchID, @ExpiredAccountsOnly, @PostToAltAccount, @AltAccountNo, @AltBadgeNo, @AltTransID, @AltOutletNo, @Formula, @UseOutletClassBal, @BalanceMax
    
      WHILE ( @@FETCH_STATUS = 0 ) 
            BEGIN
				--Post the amount to the tblBatch table 
                SET @CoreID = dbo.GetCoreIDFromUser(@User)

				-- Allows a transdate to be passed in to the procedure
				-- This is needed for the "Run Now" feature added in version 4.00
				SET @TransDate = COALESCE(@DefaultTransDate, @TransDate)
    
				--If AccountNo = "" then process for the AccountClass
                  IF ( @AccountNo = '' ) 
                     BEGIN
                           DECLARE sAClass CURSOR
                           FOR
                                   SELECT   AccountNo ,
                                            ExpireDate
                                   FROM     tblAccountOHD
                                   WHERE    AccountClassID = @AccountClassID
                            
                           OPEN sAClass
            
                           FETCH NEXT FROM sAClass INTO @AccountNo, @ExpireDate
            
                           WHILE ( @@FETCH_STATUS = 0 ) 
                                 BEGIN
                                       -- If account hasn't expired and "Expired Only" is flagged then don't process
                                       IF ( @ExpiredAccountsOnly = 1 ) 
                                          BEGIN
                                                IF ( @ExpireDate <= @TransDate )		-- 14-Jan-13 wjs -- replaced Getdate() with @TransDate
                                                   SET @OKtoProcess = 1
                                                ELSE 
                                                   SET @OKtoProcess = 0
                                          END
										ELSE
										  BEGIN
										  SET @OKtoProcess = 1
										  END
                                          
                                            -- 14-Jan-13 Added the cycle resolution here to enable proper lookup for when we're posting by tracking.
                                            SELECT		@CycleNo = X.CycleNo
                                            FROM		tblAccountOHD	AS A
                                            INNER JOIN 	tblAccountClass AS AC ON A.AccountClassID = AC.AccountClassID
                                            INNER JOIN  tblCycleXlat AS X ON AC.CycleXRefID = X.xlatid
                                            WHERE		@TransDate BETWEEN X.BeginDate AND X.EndDate
                                                    AND A.AccountNo = @AccountNo

                                       --Get the amount to process for posting	   -- 14-Jan-13, wjs ( replaced Getdate() with @TransDate )
                                       SET @TransAmount = ISNULL(dbo.GetRecurAmount_EX(@AccountNo, @AccountClassID, @Amount, @TransID, @OutletNo, @UseOutletClassBal, @PastDue, @Minimum, @Balance, @TrackSlotNum, @TrackIDNum, @CycleNo, @TransDate, @AllowNegAmt, @BalanceMax), 0)		

                                       -- If we are using formulas, we now have the ability to do a "fixed" rate calculation.
                                       IF ( @Formula <> '' ) BEGIN
										  IF( substring( @Formula , 1 , 6 ) = 'FIXED:' ) 
										  BEGIN
											SET @TransAmount = dbo.GetPercentageFromBreakpointString( SubString( @Formula,7, 500) , @TransAmount)
										  END 
										  ELSE 
										  BEGIN
											SET @TransAmount = @TransAmount * ( dbo.GetPercentageFromBreakpointString(@Formula, @TransAmount) / 100 )
										  END
									   END	  
                         
                                       IF ( @Percent > 0 ) 
                                          SET @TransAmount = @TransAmount * ( @Percent / 100 )
                         
                                       SET @BadgeNo = ISNULL(dbo.GetFirstBadge(@AccountNo), @AccountNo)
                                       SET @RefNum = ISNULL(@RefNum, CAST(@BatchID AS CHAR(6)))
                                       SET @ChkNum = CAST(DATEPART(s, GETDATE()) AS VARCHAR(2)) + CAST(DATEPART(ms, @TransDate) AS VARCHAR(3)) + CAST(@TempNumber AS CHAR(1))  -- 14-Jan-13 wjs, replaced getdate() with @TransDate
                                       SET @Comment = ISNULL(@Comment, @Description)
            
                                       IF ( @TransAmount <> 0 ) 
                                          BEGIN 
                                                IF ( @DoTax1 = 1 ) 
                                                   BEGIN
                                                         SET @Tax1 = CAST(dbo.GetOverheadItem('tax1') AS MONEY)
                                                         IF ( @Tax1 > 0 ) 
                                                            SET @Tax1 = ROUND(( ( @Tax1 / 100 ) * @TransAmount ), 2)
                                                         ELSE 
                                                            SET @Tax1 = 0
                                                   END
                                                ELSE 
                                                   SET @Tax1 = 0
                                                IF ( @DoTax2 = 1 ) 
                                                   BEGIN
                                                         SET @Tax2 = CAST(dbo.GetOverheadItem('tax2') AS MONEY)
                                                         IF ( @Tax2 > 0 ) 
                                                            SET @Tax2 = ROUND(( ( @Tax2 / 100 ) * @TransAmount ), 2)
                                                         ELSE 
                                                            SET @Tax2 = 0
                                                   END
                                                ELSE 
                                                   SET @Tax2 = 0
                        
                                                IF ( @DoTax3 = 1 ) 
                                                   BEGIN
                                                         SET @Tax3 = CAST(dbo.GetOverheadItem('tax3') AS MONEY)
                                                         IF ( @Tax3 > 0 ) 
                                                            SET @Tax3 = ROUND(( ( @Tax3 / 100 ) * @TransAmount ), 2)
                                                         ELSE 
                                                            SET @Tax3 = 0
                                                   END
                                                ELSE 
                                                   SET @Tax3 = 0
                        
                                                IF ( @DoTax4 = 1 ) 
                                                   BEGIN
                                                         SET @Tax4 = CAST(dbo.GetOverheadItem('tax4') AS MONEY)
                                                         IF ( @Tax4 > 0 ) 
                                                            SET @Tax4 = ROUND(( ( @Tax4 / 100 ) * @TransAmount ), 2)
                                                         ELSE 
                                                            SET @Tax4 = 0
                                                   END
                                                ELSE 
                                                   SET @Tax4 = 0
                                        
                                                SET @TransAmount = ROUND(@TransAmount, 2)
                                                SET @Sales1 = @TransAmount
                                                SET @TransAmount = @TransAmount + @Tax1 + @Tax2 + @Tax3 + @Tax4
                                        
                                                IF ( LTRIM(@AccountNo) <> '' )
                                                   AND ( @OKtoProcess = 1 ) 
                                                   BEGIN
                                                        --post to alternate account if flag is set				
                                                         IF ( @PostToAltAccount = 1
                                                              AND @AltAccountNo <> ''
                                                            ) 
                                                            BEGIN
                                                                  SET @Comment2 = RTRIM(@AltAccountNo) + ' - ' + dbo.GetAccountName(@AccountNo)
                                                                  SET @Comment = RTRIM(@AltAccountNo) + ' - ' + dbo.GetAccountName(@AltAccountNo)
                            
                                                                  EXEC dbo.sp_Batch_Insert @CoreID, @User, @BatchID, @AltAccountNo, @AltBadgeNo, @TransDate, @AltOutletNo, @RefNum, @ChkNum, @TransAmount, @Sales1, @Comment2, 0, @AltTransID, 0, ' ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, @Tax1, @Tax2, @Tax3, @Tax4, 0, 0
                                                            END

                                                         -- Post to evaluated account
                                                         EXEC dbo.sp_Batch_Insert @CoreID, @User, @BatchID, @AccountNo, @BadgeNo, @TransDate, @OutletNo, @RefNum, @ChkNum, @TransAmount, @Sales1, @Comment, 0, @TransID, 0, ' ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, @Tax1, @Tax2, @Tax3, @Tax4, 0, 0
                                                   END
                        
                                          END
                                
                                       FETCH NEXT FROM sAClass INTO @AccountNo, @ExpireDate	
                                 END
            
                           CLOSE sAClass
                           DEALLOCATE sAClass			
                     END
                  ELSE 
                     BEGIN  
                            -- If account hasn't expired and "Expired Only" is flagged then don't process
                           IF ( @ExpiredAccountsOnly = 1 ) 
                              BEGIN
                                    IF ( @ExpireDate <= GETDATE() ) 
                                       SET @OKtoProcess = 1
                                    ELSE 
                                       SET @OKtoProcess = 0
                              END
							ELSE
								BEGIN
								SET @OKtoProcess = 1
								END

                            -- 14-Jan-13 Added the cycle resolution here to enable proper lookup for when we're posting by tracking.
                            SELECT		@CycleNo = X.CycleNo
                            FROM		tblAccountOHD	AS A
                            INNER JOIN 	tblAccountClass AS AC ON A.AccountClassID = AC.AccountClassID
                            INNER JOIN  tblCycleXlat AS X ON AC.CycleXRefID = X.xlatid
                            WHERE		@TransDate BETWEEN X.BeginDate AND X.EndDate
                                    AND A.AccountNo = @AccountNo

                            --Get the amount to process for posting	
                           SET @TransAmount = ISNULL(dbo.GetRecurAmount_EX(@AccountNo, @AccountClassID, @Amount, @TransID, @OutletNo, @UseOutletClassBal, @PastDue, @Minimum, @Balance, @TrackSlotNum, @TrackIDNum, @CycleNo, @TransDate, @AllowNegAmt, @BalanceMax), 0)    -- 14-Jan-13 wjs replace getdate() with TransDate
                           
                          -- If we are using formulas, we now have the ability to do a "fixed" rate calculation.
                           IF ( @Formula <> '' ) BEGIN
							  IF( substring( @Formula , 1 , 6 ) = 'FIXED:' ) BEGIN
								SET @TransAmount = dbo.GetPercentageFromBreakpointString( SubString( @Formula,7, 500) , @TransAmount)
							  END ELSE BEGIN
                              SET @TransAmount = @TransAmount * ( dbo.GetPercentageFromBreakpointString(@Formula, @TransAmount) / 100 )
							  END
						   END	 

                           --If the Percent field is greater than 0, multiply times the posting amount
                           IF ( @Percent > 0 ) 
                              SET @TransAmount = @TransAmount * ( @Percent / 100 )

                           SET @BadgeNo = ISNULL(dbo.GetFirstBadge(@AccountNo), @AccountNo) 
                           SET @RefNum = ISNULL(@RefNum, CAST(@BatchID AS CHAR(6)))
                           SET @ChkNum = CAST(DATEPART(s, GETDATE()) AS VARCHAR(2)) + CAST(DATEPART(ms, @TransDate ) AS VARCHAR(3)) + CAST(@TempNumber AS CHAR(1))	-- 14-Jan-13 wjs -- replaced getdate() with TransDate
                           SET @Comment = ISNULL(@Comment, @Description)
         
                           IF ( @TransAmount <> 0 ) 
                              BEGIN 
                                    IF ( @DoTax1 = 1 ) 
                                       BEGIN
                                             SET @Tax1 = CAST(dbo.GetOverheadItem('tax1') AS MONEY)
                                             IF ( @Tax1 > 0 ) 
                                                SET @Tax1 = ROUND(( ( @Tax1 / 100 ) * @TransAmount ), 2)
                                             ELSE 
                                                SET @Tax1 = 0
                                       END
                                    ELSE 
                                       SET @Tax1 = 0
                                    IF ( @DoTax2 = 1 ) 
                                       BEGIN
                                             SET @Tax2 = CAST(dbo.GetOverheadItem('tax2') AS MONEY)
                                             IF ( @Tax2 > 0 ) 
                                                SET @Tax2 = ROUND(( ( @Tax2 / 100 ) * @TransAmount ), 2)
                                             ELSE 
                                                SET @Tax2 = 0
                                       END
                                    ELSE 
                                       SET @Tax2 = 0
                        
                                    IF ( @DoTax3 = 1 ) 
                                       BEGIN
                                             SET @Tax3 = CAST(dbo.GetOverheadItem('tax3') AS MONEY)
                                             IF ( @Tax3 > 0 ) 
                                                SET @Tax3 = ROUND(( ( @Tax3 / 100 ) * @TransAmount ), 2)
                                             ELSE 
                                                SET @Tax3 = 0
                                       END
                                    ELSE 
                                       SET @Tax3 = 0
                        
                                    IF ( @DoTax4 = 1 ) 
                                       BEGIN
                                             SET @Tax4 = CAST(dbo.GetOverheadItem('tax4') AS MONEY)
                                             IF ( @Tax4 > 0 ) 
                                                SET @Tax4 = ROUND(( ( @Tax4 / 100 ) * @TransAmount ), 2)
                                             ELSE 
                                                SET @Tax4 = 0
                                       END
                                    ELSE 
                                       SET @Tax4 = 0
                    
                                    SET @TransAmount = ROUND(@TransAmount, 2)
                                    SET @Sales1 = @TransAmount
                                    SET @TransAmount = @TransAmount + @Tax1 + @Tax2 + @Tax3 + @Tax4
                
                                    IF ( @OKtoProcess = 1 ) 
                                       BEGIN
                        --post to alternate account if flag is set
                                             IF ( @PostToAltAccount = 1
                                                  AND @AltAccountNo <> ''
                                                ) 
                                                BEGIN
                                                      SET @Comment2 = RTRIM(@AltAccountNo) + ' - ' + dbo.GetAccountName(@AccountNo)
                                                      SET @Comment = RTRIM(@AltAccountNo) + ' - ' + dbo.GetAccountName(@AltAccountNo)
                            
                                                      EXEC dbo.sp_Batch_Insert @CoreID, @User, @BatchID, @AltAccountNo, @AltBadgeNo, @TransDate, @AltOutletNo, @RefNum, @ChkNum, @TransAmount, @Sales1, @Comment2, 0, @AltTransID, 0, ' ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, @Tax1, @Tax2, @Tax3, @Tax4, 0, 0
                                                END
                        
                        -- Post to evaluated account
                                             EXEC dbo.sp_Batch_Insert @CoreID, @User, @BatchID, @AccountNo, @BadgeNo, @TransDate, @OutletNo, @RefNum, @ChkNum, @TransAmount, @Sales1, @Comment, 0, @TransID, 0, ' ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, @Tax1, @Tax2, @Tax3, @Tax4, 0, 0
                        
                                       END
                            
                              END
                     END
    -- Increment our tempnumber, which is used to guarantee a unique transaction key
                  IF ( @TempNumber = 9 ) 
                     SET @TempNumber = 0
                  ELSE 
                     SET @TempNumber = @TempNumber + 1
        --Get the next record from the cursor
                  FETCH NEXT FROM sRecur1 INTO @AccountNo, @AccountClassID, @TransID, @OutletNo, @Description, @Amount, @Percent, @Minimum, @Balance, @PastDue, @TrackSlotNum, @TrackIDNum, @DoTax1, @DoTax2, @DoTax3, @DoTax4, @TAmount, @T2Amount, @RefNum, @ChkNum, @Comment, @TransDate, @AllowNegAmt, @BatchID, @ExpiredAccountsOnly, @PostToAltAccount, @AltAccountNo, @AltBadgeNo, @AltTransID, @AltOutletNo, @Formula, @UseOutletClassBal, @BalanceMax
            END
     
      CLOSE sRecur1
      DEALLOCATE sRecur1
go

