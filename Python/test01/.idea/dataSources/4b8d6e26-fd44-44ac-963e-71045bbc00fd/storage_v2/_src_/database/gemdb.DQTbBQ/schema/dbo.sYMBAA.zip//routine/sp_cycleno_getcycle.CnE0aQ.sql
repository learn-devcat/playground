

CREATE PROCEDURE dbo.sp_CycleNo_GetCycle
@CoreID	int,
@Offset		int
AS
	DECLARE @CycleNo	int
	DECLARE @CycleDate	smalldatetime
	SELECT dbo.CurrentCycleNo(@CoreID) AS CycleNo

	DECLARE 	@cMsg  char(255)
	SET @cMsg = 'Retrieved current cycle number'
	EXEC dbo.sp_Logit 4 , @CoreID , 'SYSTEM' , @cMsg
go

