

CREATE FUNCTION dbo.GetNutrientID(@Description varchar(50))
RETURNS int
AS 
BEGIN
	DECLARE @Return	int

	SELECT @Return = NutrientID
	FROM	dbo.cfgNutrients
	WHERE 	[Description] = @Description

	RETURN @Return
END
go

