
CREATE PROCEDURE dbo.OverheadItemDelete
@LoginUserID		varchar(250),
@KeyID		varchar(50)

AS
	SET NOCOUNT ON

	DELETE dbo.cfgOverhead WHERE KeyID = @KeyID

	RETURN
go

