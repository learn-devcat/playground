


CREATE    PROCEDURE [dbo].[ASP_Session_ItemInsert]
@UserID			char(10),
@KeyName		varchar(100),
@Value			text,
@ASPsessionID	bigint

AS
	SET NOCOUNT ON
	
	Insert Into tblASPsession (KeyName, Value, ASPsessionID)
			    Values(@KeyName, @Value, @ASPsessionID)
go

