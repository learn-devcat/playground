CREATE PROCEDURE [dbo].[CCS_AllergiesUpdateFromModifiers_v4]
@MedicalRecordID	varchar(50),
@PatientVisitID		varchar(50),
@Modifiers			varchar(4000),
@Source				varchar(100),
@ConnectionName		varchar(50)=''

AS
	SET NOCOUNT ON

	IF (@Modifiers <> '')
		EXEC dbo.CCS_AllergiesUpdate_v4 @MedicalRecordID, @PatientVisitID, @Modifiers, @Source, @ConnectionName

	RETURN

go

