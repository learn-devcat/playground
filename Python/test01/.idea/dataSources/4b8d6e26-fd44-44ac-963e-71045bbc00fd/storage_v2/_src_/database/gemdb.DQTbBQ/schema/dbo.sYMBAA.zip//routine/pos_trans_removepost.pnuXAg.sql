

CREATE PROCEDURE dbo.pos_Trans_RemovePost
@User		char(10),
@DetailID	uniqueidentifier
AS
	EXEC dbo.sp_Trans_RemovePost 'support', @DetailID
go

