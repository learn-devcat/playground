


----------------------------------------------------------------------------------
--
--  RoomMapGetMaxValues                  09-Sep-03 w.j.scott
--
--  Return the max # of Rows and Cols so that the calling applicaiton can
--	anticipate the largets row and colum that will the RoomMapGet
--	proc will be returning and expeciting to be rendered.
--
--	NOTE:  This proc does NOT anticipate the number of records that will be returned,
--	       although, that would be easy enough to build in should that need occur.
--
-- Modified 			       10-Sep-03 j.b.dole
-- 
-- Added alias names(MaxRow,MaxCol) to identify columns when SP is ran
--            No columns names where returned before
--
-----------------------------------------------------------------------------------
CREATE PROCEDURE RoomMapGetMaxValues
@MapNumber int
AS

	set nocount on
	
	 select max(Row) As MaxRow,
	        max(Col) As MaxCol
	   from dbo.tblMapData M
	  where M.MapNumber = @MapNumber
go

