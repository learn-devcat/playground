

CREATE      PROCEDURE [dbo].[WorkorderDTL_GetEX]
@User   char(10),
@WOID INT,
@ID	int
AS
	SELECT      D.WorkOrderID,
		    D.WorkOrderDTLID,
		    D.WorkOrderDTLDefID,
		    D.AssigningEmployeeID,
		    D.AssignedEmployeeID,
		    D.AssignmentDate,
		    D.CompletingEmployeeID,
		    D.CompletionDate,
		    D.Completed,
		    D.Price,
		    D.Cost,
		    D.ActualHours,
		    D.ScheduledStartDate,
		    D.ActualStartDate,
		    D.Notes,
		    D.PriceChangeReason,
		    O.WorkorderNumber
	FROM        tblWorkOrderDTL D
			LEFT JOIN
	    	    tblWorkorderOHD O ON O.WorkorderID = D.WorkorderID
	WHERE       ID = @ID AND D.WorkorderID = @WOID
RETURN
go

