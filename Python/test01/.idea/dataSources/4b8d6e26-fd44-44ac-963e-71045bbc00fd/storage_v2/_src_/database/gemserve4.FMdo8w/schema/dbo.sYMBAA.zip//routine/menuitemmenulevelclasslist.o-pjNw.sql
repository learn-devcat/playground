

CREATE PROCEDURE dbo.MenuItemMenuLevelClassList
AS
	SET NOCOUNT ON

	SELECT	MenuLevelClassID,
		MLVL_CLASS_SEQ,
		OBJ_NUM,
		[NAME]
	FROM	dbo.tblMenuItemMenuLevelClass
	WHERE [NAME] IS NOT NULL

	RETURN
go

