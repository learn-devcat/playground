CREATE FUNCTION dbo.AccountOutletClassTTLIsActive ( @AccountNo varchar(19), @TransClassID int ) 
RETURNS bit AS 
BEGIN 
	DECLARE @cnt int,
			@rtn bit

	
	SELECT	@cnt = COUNT(*) 
	FROM	tblAccountTTL
	WHERE	AccountNo = @AccountNo
			AND 
			TransClassID = @TransClassID
	
	IF @cnt > 0
		SET @rtn = 1
	ELSE
		SET @rtn = 0

	RETURN @rtn
			
END
go

