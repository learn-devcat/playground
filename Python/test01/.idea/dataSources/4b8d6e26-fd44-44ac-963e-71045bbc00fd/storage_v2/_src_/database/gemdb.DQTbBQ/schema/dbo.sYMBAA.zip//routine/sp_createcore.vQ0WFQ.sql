

CREATE PROCEDURE dbo.sp_CreateCore
AS
	CREATE TABLE [dbo].[cfgCore] (
				[CoreID] [int] NOT NULL ,
				[Active] [bit] NOT NULL DEFAULT 0,
				[Description] [varchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL DEFAULT (''),
				[Category] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL DEFAULT (''),
				[SWKEY] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL DEFAULT (''),
				[SWPIN] [char] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL DEFAULT (''),
				[myIP] [char] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL DEFAULT (''),
				[ExceptionIP] [char] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL DEFAULT (''),
				[SysOptions] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL DEFAULT ('') 
			)
	ON [PRIMARY]
go

