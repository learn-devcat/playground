

CREATE procedure dbo.sp_StatsSpaceUsed
@objname nvarchar(776) = null,
@updateusage varchar(5) = true
as
DECLARE @id	int			
DECLARE @type	character(2)
DECLARE	@pages	int			
DECLARE @dbname sysname
DECLARE @dbsize dec(15,0)
DECLARE @logsize dec(15)
DECLARE @bytesperpage	dec(15,0)
DECLARE @pagesperMB		dec(15,0)
CREATE TABLE #spt_space
(
	rows		int null,
	reserved	dec(15) null,
	data		dec(15) null,
	indexp		dec(15) null,
	unused		dec(15) null
)
/*Create temp tables before any DML to ensure dynamic
**  We need to create a temp table to do the calculation.
**  reserved: sum(reserved) where indid in (0, 1, 255)
**  data: sum(dpages) where indid < 2 + sum(used) where indid = 255 (text)
**  indexp: sum(used) where indid in (0, 1, 255) - data
**  unused: sum(reserved) - sum(used) where indid in (0, 1, 255)
*/
/*
**  Check to see IF user wants usages updated.
*/
IF @updateusage is not null
	BEGIN
		SELECT @updateusage=lower(@updateusage)
		IF @updateusage not in ('true','false')
			BEGIN
				raiserror(15143,-1,-1,@updateusage)
				--RETURN(1)
			END
	END
/*
**  Check to see that the objname is local.
*/
IF @objname IS NOT NULL
BEGIN
	SELECT @dbname = parsename(@objname, 3)
	IF @dbname is not null AND @dbname <> db_name()
		BEGIN
			raiserror(15250,-1,-1)
			--RETURN (1)
		END
	IF @dbname is null
		SELECT @dbname = db_name()
	/*
	**  Try to find the object.
	*/
	SELECT @id = null
	SELECT @id = id, @type = xtype
		FROM sysobjects
			WHERE id = object_id(@objname)
	/*
	**  Does the object exist?
	*/
	IF @id is null
		BEGIN
			raiserror(15009,-1,-1,@objname,@dbname)
			--RETURN (1)
		END
	IF not exists (SELECT * FROM sysindexes
				WHERE @id = id AND indid < 2)
		IF      @type in ('P ','D ','R ','TR','C ','RF') --data stored in sysprocedures
				BEGIN
					raiserror(15234,-1,-1)
					--RETURN (1)
				END
		ELSE IF @type = 'V ' -- View => no physical data storage.
				BEGIN
					raiserror(15235,-1,-1)
					--RETURN (1)
				END
		ELSE IF @type in ('PK','UQ') -- no physical data storage. --?!?! too many similar messages
				BEGIN
					raiserror(15064,-1,-1)
					--RETURN (1)
				END
		ELSE IF @type = 'F ' -- FK => no physical data storage.
				BEGIN
					raiserror(15275,-1,-1)
					--RETURN (1)
				END
END
/*
**  UPDATE usages IF user specified to do so.
*/
IF @updateusage = 'true'
	BEGIN
		IF @objname is null
			dbcc updateusage(0) with no_infomsgs
		ELSE
			dbcc updateusage(0,@objname) with no_infomsgs
		print ' '
	END
SET NOCOUNT ON
/*
**  IF @id is null, then we want summary data.
*/
/*	Space used calculated in the following way
**	@dbsize = Pages used
**	@bytesperpage = d.low (WHERE d = master.dbo.spt_values) is
**	the # of bytes per page when d.type = 'E' AND
**	d.number = 1.
**	Size = @dbsize * d.low / (1048576 (OR 1 MB))
*/
IF @id is null
BEGIN
	SELECT @dbsize = sum(convert(dec(15),size))
		FROM dbo.sysfiles
		WHERE (status & 64 = 0)
	SELECT @logsize = sum(convert(dec(15),size))
		FROM dbo.sysfiles
		WHERE (status & 64 <> 0)
	SELECT @bytesperpage = low
		FROM master.dbo.spt_values
		WHERE number = 1
			AND type = 'E'
	SELECT @pagesperMB = 1048576 / @bytesperpage
	SELECT  database_name = db_name(),
		database_size =
			ltrim(str((@dbsize + @logsize) / @pagesperMB,15,2) + ' MB'),
		'unallocated space' =
			ltrim(str((@dbsize -
				(SELECT sum(convert(dec(15),reserved))
					FROM sysindexes
						WHERE indid in (0, 1, 255)
				)) / @pagesperMB,15,2)+ ' MB')
	print ' '
END
RETURN (0)
go

