

CREATE PROCEDURE dbo.ButtonScanInsert
@EmployeeID	varchar(20),
@ButtonID	varchar(50),
@ScanTime	datetime,
@BatchID	varchar(20) = 'system'
AS

	SET NOCOUNT ON

	INSERT INTO dbo.tblButtonScans (EmployeeID, ButtonID, BatchID, ScanTime)
		VALUES (@EmployeeID, @ButtonID, @BatchID, @ScanTime)

	RETURN
go

