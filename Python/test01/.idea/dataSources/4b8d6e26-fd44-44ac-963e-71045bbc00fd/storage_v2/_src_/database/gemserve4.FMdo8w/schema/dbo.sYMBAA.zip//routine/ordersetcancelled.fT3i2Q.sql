
CREATE PROCEDURE dbo.OrderSETCancelled
@LoginUserID	varchar(250),
@OrderID   int,
@Cancelled int = 1,
@LogDate   datetime = NULL,
@Msg	varchar(250) = NULL,
@ActionId	int=700
AS
	SET NOCOUNT ON 
	
	SET @Msg = COALESCE(@Msg,'Meal Order canceled - OrderID [' + CAST(@OrderID AS varchar(10)) + ']')
	SET @LogDate = COALESCE(@LogDate , getdate())
	
	-- Cancel the order
	UPDATE dbo.tblOrderOHD
	SET Cancelled = @Cancelled,
		CancelDate = @LogDate,
		LastUpdateBy = @LoginUserID
	WHERE OrderID = @OrderID
	
	-- Insert an order log entry for the order that is being canceled
    INSERT INTO dbo.tblOrderLOG (OrderID,  ActionID, LoginUserID)
        VALUES (@OrderID, @ActionId, @LoginUserID)

	-- Insert a log entry into the Patient Log for the order that is being canceled
	INSERT INTO dbo.tblPatientLog (EventClassID, LoginUserID, PatientID, PatientVisitID, RoomID, [Description], [Date])
		SELECT 7000, @LoginUserID, P.PatientID, P.PatientVisitID, P.RoomID, @Msg, @LogDate
		FROM    dbo.tblOrderOHD AS O (NOLOCK)
		JOIN dbo.tblPatientVisit AS P (NOLOCK) ON O.PatientVisitID = P.PatientVisitID
		WHERE O.OrderID = @OrderID
	
	RETURN
go

