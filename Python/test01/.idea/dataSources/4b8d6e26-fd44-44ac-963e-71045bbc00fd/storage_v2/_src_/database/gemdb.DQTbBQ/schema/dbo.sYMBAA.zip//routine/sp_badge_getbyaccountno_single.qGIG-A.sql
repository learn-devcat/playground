


CREATE  PROCEDURE dbo.sp_Badge_GetByAccountNo_Single
@User		char(10),
@LocationID	int,
@AccountNo	char(19)
AS
	DECLARE @BadgeNo varchar(19)
	
	SELECT		TOP 1 @BadgeNo = BadgeNo
	FROM		tblBadgesOHD
	WHERE		AccountNo= @AccountNo
			AND ISNULL(LocationID,0) = @LocationID
			AND Inactive = 0
			AND Lost = 0
			AND Stolen = 0
			AND ActiveDate < getdate()
			AND ExpireDate > getdate()
	ORDER BY 	PrimaryBadge 	Desc,
			ActiveDate	Desc
	SELECT ISNULL(@BadgeNo, '') as 'BadgeNo'
go

