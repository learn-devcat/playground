CREATE PROCEDURE [dbo].[KitchenTimeDelete]
	@LoginUserId		VARCHAR(150),
	@KitchenTimeId		INT
AS
	DECLARE @KitchenId	INT,
			@StartTime	CHAR(5),
			@EndTime	CHAR(5),
			@Msg		VARCHAR(200)
			
	SELECT @KitchenId = KitchenId,
			@StartTime = StartTime,
			@EndTime = EndTime
	FROM dbo.tblKitchenTimes
	WHERE KitchenTimeId = @KitchenTimeId			
			
	DELETE dbo.tblKitchenTimes 
	WHERE KitchenTimeId = @KitchenTimeId
	
	SET @Msg = 'Deleted kitchen time for KitchenId [' + CAST(@KitchenId AS VARCHAR(10)) + '] - StartTime [' + @StartTime + '], EndTime [' + @EndTime + ']'
	EXEC dbo.Logit 2, @Msg, @LoginUserID
	
	RETURN
go

