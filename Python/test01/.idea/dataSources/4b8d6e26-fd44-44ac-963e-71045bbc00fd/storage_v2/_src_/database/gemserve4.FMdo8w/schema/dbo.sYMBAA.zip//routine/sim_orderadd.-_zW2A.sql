CREATE PROCEDURE [dbo].[sim_OrderAdd]
    @CoreID int,
    @LoginUserID	varchar(250),
    @PatientVisitID varchar(50),
    @SubLevel int,
    @ChkEmpl int,
    @ChkName varchar(30),
    @WorkstationID int,
    @OutletNo int,
    @WaveID int,
    @WaveDate varchar(30),
    @MenuItems varchar(2000),
    @Nutrients	varchar(255),
    @StandingOrder bit,
	@OrderType	int=0,
	@OrderedFor varchar(16)='',
	@DietId		int=0

AS
	SET NOCOUNT ON
	
	DECLARE @OrderID int,	
		@ReturnCode int,
		@PatientID int,
		@CurrentDietId int,
		@EndTime char(5),
		@TempWaveDate varchar(30)

	SELECT @PatientID = PV.PatientID
	FROM	dbo.tblPatientVisit AS PV (NOLOCK) 
	WHERE	PV.PatientVisitID = @PatientVisitID

	SELECT @EndTime = EndTime
	FROM dbo.tblWave
	WHERE WaveID = @WaveID

	SET @TempWaveDate = dbo.dDatePlusNewTime(@WaveDate, @EndTime)

	IF (@OrderType = 1)
	BEGIN
		IF (@DietId <> dbo.GetActiveDiet(@PatientVisitId, @TempWaveDate))
			GOTO DietChanged
	END
	
	SET @orderID = 0

	BEGIN TRANSACTION

	EXEC @ReturnCode = dbo.OrderInsertNewEX @OrderID output, @PatientVisitID, @WaveID, @MenuItems, 1 , @WorkstationID , @OutletNo, @ChkEmpl ,@ChkName , @WaveDate , @SubLevel, @StandingOrder, '', 0, 0, 0, @OrderType, @OrderedFor, @DietId
	
	IF (@ReturnCode > 1 OR @ReturnCode < 0)
		GOTO AddFailed

	IF (@ReturnCode = 0) AND (@OrderType = 1)
	BEGIN
	 	EXEC @ReturnCode = dbo.PatientUpdateNutrientCountEX @PatientID, @OrderID

		IF (@ReturnCode <> 0)
			GOTO AddFailed
	END

	COMMIT TRANSACTION
	SELECT'Posted Order ID: ' + cast( @OrderID as varchar(10)) as ReturnMsg

	GOTO Finish

AddFailed:
	ROLLBACK TRANSACTION
		SELECT '/Unable to process order ' + CAST(@ReturnCode as varchar(10))

	GOTO Finish

DietChanged:
	SELECT '/Patient Diet has changed. Order not saved.'

Finish:
go

