

CREATE FUNCTION dbo.CheckUserLevel (@CoreID int, @UserID varchar(10), @Function int, @DesiredLevel int)
RETURNS bit
AS 
BEGIN 
DECLARE @SecurityLevel char(4)
DECLARE @Level 		int
	-- Check the Overhead file for an entry --
	SELECT 	@SecurityLevel = SecurityLevel 
	FROM 	cfgUsers 
	WHERE 	CoreID = @CoreID
		AND UserID = @UserID
	IF( @SecurityLevel is null )		-- User not found, can't allow it.
		RETURN 0
	IF( CAST( substring( @SecurityLevel , @Function , 1 ) as int ) >= @DesiredLevel )
		Return 1
	RETURN 0				-- Nope, not allowed.
END
go

