
CREATE PROCEDURE dbo.user_support AS DECLARE	@Company varchar(50), 
	@Address varchar(50), 
	@City varchar(50), 
	@State varchar(2), 
	@Zip varchar(10), 
	@Phone varchar(20),
	@Contact varchar(20), 
	@oKey varchar(50), 
	@sValue varchar(50), 
	@ReportDate datetime, 
	@AddressID int, 
	@Smsg0 varchar(255), 
	@Smsg1 varchar(255),
	@Smsg2 varchar(255), 
	@Smsg3 varchar(255),
	@Smsg4 varchar(255),
	@AccountNo char(19),
	@PreviousCharges money,
	@PreviousPayments money, 
	@Day30Date datetime, 
	@Day60Date datetime, 
	@Day90Date datetime, 
	@Day120Date datetime, 
	@DayCurrentDate datetime, 
	@Day30 money, @Day60 money, 
	@Day90 money, @Day120 money, 
	@DayCurrent money, 
	@CurrentCharges money,
	@CurrentPayments money, 
	@TotalPayments money, 
	@PreviousBalance money, 
	@CurrentCycle int,
	@xlatid varchar(10),
	@TempMonth int,
	@Addr1	varchar(40),
	@Addr2	varchar(40),
	@Addr3	varchar(40),
	@Addr4	varchar(40),
	@Addr5	varchar(40)

DECLARE CompanyTemp CURSOR FOR 
	SELECT oKey,sValue FROM cfgOverhead WHERE oKey='Company' OR oKey='Address' OR oKey='City' OR oKey='State' 
	OR oKey='Zip' OR oKey='Phone' OR oKey='Contact' 

OPEN CompanyTemp 
FETCH NEXT FROM CompanyTemp INTO @oKey,@sValue 

WHILE @@FETCH_STATUS = 0 
BEGIN 
	IF @oKey='Company' SET @Company=@sValue 
	IF @oKey='Address' SET @Address=@sValue 
	IF @oKey='City' SET @City=@sValue 
	IF @oKey='State' SET @State=@sValue 
	IF @oKey='Zip' SET @Zip=@sValue 
	IF @oKey='Phone' SET @Phone=@sValue 
	IF @oKey='Contact' SET @Contact=@sValue 

	FETCH NEXT FROM CompanyTemp INTO @oKey,@sValue 
END 
CLOSE CompanyTemp 
DEALLOCATE CompanyTemp 

DECLARE @Temp TABLE (Company varchar(100), CoAddress varchar(100), CoCity varchar(50), CoState varchar(20), CoZip varchar(20), 
			CoPhone varchar(20), Contact varchar(100), MasterAccountNo varchar(19), 
			FullName varchar(35), FirstName char(15), LastName char(20), AccountDesc char(30), AccountClassID int, Address1 varchar(40), 
			Address2 varchar(40), Address3 varchar(40), Address4 varchar(40), Address5 varchar(40), IsPayment int, TDescription varchar(24), 
			AccountNo varchar(19), TransDate datetime, TransID int, TransTotal money, RefNum	char(6), ChkNum char(6), OutletNo int, 
			OutletName varchar(24), Comment varchar(40), Msg0 varchar(255), Msg1 varchar(255), Msg2 varchar(255), Msg3 varchar(255), 
			Msg4 varchar(255), PreviousBalance money, Day120 money, Day90 money, Day60 money, Day30 money, DayCurrent money) 

SET @xlatid = 'STMT'
DECLARE @RB int 
SELECT 	@RB = Count(CycleNo)
FROM	tblCycleXlat
WHERE	xlatid = @xlatid

IF ( ISNULL(@RB,0) = 0 )
	SET @xlatid = 'MTH'

SET @ReportDate = '12/19/2005'

SELECT @CurrentCycle = dbo.GetCycleByXREF(0,@ReportDate,'STMT')
IF (@CurrentCycle = 0)
BEGIN
	SELECT @CurrentCycle = dbo.GetCycleByXREF(0,@ReportDate,'MTH')
	SET @xlatid = 'MTH'
END

SELECT @ReportDate = EndDate FROM tblCycleXlat WHERE CycleNo = @CurrentCycle AND xlatid = @xlatid
SELECT @Day30Date = BeginDate FROM tblCycleXlat WHERE CycleNo = @CurrentCycle AND xlatid = @xlatid
SELECT @Day60Date = BeginDate FROM tblCycleXlat WHERE CycleNo = @CurrentCycle - 1 AND xlatid = @xlatid
SELECT @Day90Date = BeginDate FROM tblCycleXlat WHERE CycleNo = @CurrentCycle - 2 AND xlatid = @xlatid
SELECT @Day120Date = BeginDate FROM tblCycleXlat WHERE CycleNo = @CurrentCycle - 3 AND xlatid = @xlatid

SELECT @AddressID = dbo.GetOverheadItem('StatementAddressID') 
IF ISNULL(@AddressID,0) = 0
	SELECT @AddressID = AddressID FROM tblAddressClass WHERE Description LIKE '%STA%'
IF ISNULL(@AddressID,0) = 0
	SELECT @AddressID = AddressID FROM tblAddressClass WHERE Description LIKE '%PRI%'
	
SELECT @Smsg0 = ISNULL(Message,'') FROM tblReportMessages 
WHERE MessageID = (SELECT sValue FROM cfgOverhead WHERE oKey = 'StmtMsg0' AND dType <> 0) 

SELECT @Smsg1 = ISNULL(Message,'') FROM tblReportMessages 
WHERE MessageID = (SELECT sValue FROM cfgOverhead WHERE oKey = 'StmtMsg1' AND dType <> 0) 

SELECT @Smsg2 = ISNULL(Message,'') FROM tblReportMessages 
WHERE MessageID = (SELECT sValue FROM cfgOverhead WHERE oKey = 'StmtMsg2' AND dType <> 0) 

SELECT @Smsg3 = ISNULL(Message,'') FROM tblReportMessages 
WHERE MessageID = (SELECT sValue FROM cfgOverhead WHERE oKey = 'StmtMsg3' AND dType <> 0)

SELECT @Smsg4 = ISNULL(Message,'') FROM tblReportMessages 
WHERE MessageID = (SELECT sValue FROM cfgOverhead WHERE oKey = 'StmtMsg4' AND dType <> 0) 

DECLARE Acc cursor FOR 
	SELECT AccountNo FROM tblAccountOHD LEFT JOIN tblAccountClass AS AC ON tblAccountOHD.AccountClassID = AC.AccountClassID  
	ORDER BY AccountNo OPEN Acc FETCH NEXT FROM Acc INTO @AccountNo WHILE @@FETCH_STATUS = 0 

BEGIN 
	SELECT @PreviousCharges = SUM(D.TransTotal) FROM tblDetail AS D INNER JOIN tblTransDef AS T 
	ON D.TransID = T.TransID WHERE D.AccountNo = @AccountNo AND T.Payment = 0 AND (D.TransDate < @Day30Date) 
	
	SELECT @PreviousPayments = SUM(D.TransTotal) FROM tblDetail AS D INNER JOIN tblTransDef AS T 
	ON D.TransID = T.TransID WHERE D.AccountNo = @AccountNo AND T.Payment = 1 AND (D.TransDate < @Day30Date) 
	
	SELECT @CurrentCharges = SUM(D.TransTotal) FROM tblDetail AS D INNER JOIN tblTransDef AS T ON D.TransID = T.TransID 
	WHERE D.AccountNo = @AccountNo AND T.Payment = 0 AND (D.TransDate >= @Day30Date AND D.TransDate < @ReportDate) 
	
	SELECT @CurrentPayments = SUM(D.TransTotal) FROM tblDetail AS D INNER JOIN tblTransDef AS T ON D.TransID = T.TransID 
	WHERE D.AccountNo = @AccountNo AND T.Payment = 1 AND (D.TransDate >= @Day30Date AND D.TransDate < @ReportDate) 
	
	SET @TotalPayments = ISNULL(@PreviousPayments,0) + ISNULL(@CurrentPayments,0) 
	
	SET @PreviousBalance = ISNULL(@PreviousCharges,0) - ISNULL(@PreviousPayments,0) 
	
	SELECT @Day120 = SUM(D.TransTotal) FROM tblDetail AS D INNER JOIN tblTransDef AS T ON D.TransID = T.TransID 
	WHERE D.AccountNo = @AccountNo AND T.Payment = 0 AND D.TransDate < @Day120Date 
	
	SELECT @Day90 = SUM(D.TransTotal) FROM tblDetail AS D INNER JOIN tblTransDef AS T ON D.TransID = T.TransID 
	WHERE D.AccountNo = @AccountNo AND T.Payment = 0 AND (D.TransDate < @Day90Date AND D.TransDate >= @Day120Date) 

	SELECT @Day60 = SUM(D.TransTotal) FROM tblDetail AS D INNER JOIN tblTransDef AS T ON D.TransID = T.TransID 
	WHERE D.AccountNo = @AccountNo AND T.Payment = 0 AND (D.TransDate < @Day60Date AND D.TransDate >= @Day90Date) 

	SELECT @Day30 = SUM(D.TransTotal) FROM tblDetail AS D INNER JOIN tblTransDef AS T ON D.TransID = T.TransID 
	WHERE D.AccountNo = @AccountNo AND T.Payment = 0 AND (D.TransDate < @Day30Date AND D.TransDate >= @Day60Date) 

	SELECT @DayCurrent = SUM(D.TransTotal) FROM tblDetail AS D INNER JOIN tblTransDef AS T ON D.TransID = T.TransID 
	WHERE D.AccountNo = @AccountNo AND T.Payment = 0 AND (D.TransDate < @ReportDate AND D.TransDate >= @Day30Date) 


	SET @Day120 = ISNULL(@Day120,0) - @TotalPayments 
	IF (@Day120 < 0) 
	BEGIN 
		SET @TotalPayments = ABS(@Day120) 
		SET @Day120 = 0 
	END 
	ELSE 
		SET @TotalPayments = 0 


	SET @Day90 = ISNULL(@Day90,0) - @TotalPayments 
	IF (@Day90 < 0) 
	BEGIN 
		SET @TotalPayments = ABS(@Day90) 
		SET @Day90 = 0 
	END 
	ELSE 
		SET @TotalPayments = 0 

	SET @Day60 = ISNULL(@Day60,0) - @TotalPayments 
	IF (@Day60 < 0) 
	BEGIN 
		SET @TotalPayments = ABS(@Day60) 
		SET @Day60 = 0 
	END 
	ELSE 
		SET @TotalPayments = 0 

	SET @Day30 = ISNULL(@Day30,0) - @TotalPayments 
	IF (@Day30 < 0) 
	BEGIN 
		SET @TotalPayments = ABS(@Day30) 
		SET @Day30 = 0 
	END 
	ELSE 
		SET @TotalPayments = 0 

	SET @DayCurrent = ISNULL(@DayCurrent,0) - @TotalPayments 
	
	-- SET Address to chosen address ID address
	-- Default to PRIMARY
	SET @Addr1 = ''
	SET @Addr2 = ''
	SET @Addr3 = ''
	SET @Addr4 = ''
	SET @Addr5 = ''	
	
	SELECT 	@Addr1 = Address1,
			@Addr2 = Address2,
			@Addr3 = Address3,
			@Addr4 = Address4,
			@Addr5 = Address5
	FROM 	tblaccountaddress
	WHERE 	AccountNo = @AccountNo
			AND AddressID = @AddressID 
	
	--IF 		RTRIM(ISNULL(@Addr1,'')) = '' AND RTRIM(ISNULL(@Addr2,'')) = '' AND RTRIM(ISNULL(@Addr3,'')) = '' AND RTRIM(ISNULL(@Addr4,'')) = '' AND RTRIM(ISNULL(@Addr5,'')) = '' 
	IF @@ROWCOUNT < 1
	BEGIN
			print 'using alternate address for account: ' + @AccountNo
			SELECT 	@Addr1 = Address1,
					@Addr2 = Address2,
					@Addr3 = Address3,
					@Addr4 = Address4,
					@Addr5 = Address5
			FROM 	tblAccountAddress
			WHERE 	AccountNo = @AccountNo
					AND AddressID = (SELECT AddressID FROM tblAddressClass WHERE Description LIKE '%PRIM%')	
	END

	INSERT INTO @Temp 
	SELECT 	@Company, @Address, @City, @State , @Zip , @Phone, @Contact, @AccountNo AS MasterAccountNo, 
		dbo.Description_FullNameWithMiddle(A.Description,RTRIM(A.FirstName),RTRIM(A.LastName), RTRIM(A.MiddleName),0), A.FirstName, A.LastName, A.Description AS AccountDesc, 
		A.AccountClassID, @Addr1, @Addr2, @Addr3, @Addr4, @Addr5, T.Payment, T.Description, D.AccountNo, 
		D.TransDate, D.TransID, D.TransTotal, D.RefNum, D.ChkNum, D.OutletNo, O.OutletName, ISNULL(D.Comment,'') AS Comment, @Smsg0 
		AS Msg1, @Smsg1 AS Msg2, @Smsg2 AS Msg3, @Smsg3 AS Msg4, @Smsg4 AS Msg5, @PreviousBalance AS PreviousBalance, @Day120 AS Day120, @Day90 
		AS Day90, @Day60 AS Day60, @Day30 AS Day30, @DayCurrent AS DayCurrent 
	FROM 	tblAccountOHD AS A 
		LEFT JOIN tblDetail AS D 
	ON 	A.AccountNo = D.AccountNo AND (D.TransDate >= @Day30Date AND D.TransDate < @ReportDate) 
		LEFT JOIN tblOutletOHD AS O 
	ON 	D.OutletNo = O.OutletNo 
		LEFT JOIN tblTransDef AS T 
	ON 	D.TransID = T.TransID 
		LEFT JOIN tblAccountClass AS AC 
	ON 	A.AccountClassID = AC.AccountClassID 
	WHERE 	A.AccountNo = @AccountNo 
			AND A.NoStatements = 0
	ORDER BY D.AccountNo, D.TransDate 

	FETCH NEXT FROM Acc INTO @AccountNo 
END 
CLOSE Acc 
DEALLOCATE Acc 

SELECT * FROM @Temp  ORDER BY dbo.lPad(RTRIM(MasterAccountNo),19,'0')
go

