CREATE PROCEDURE dbo.CCS_PatientDietTexture_v4
@PatientDietId AS int, 
@CurrentModifier AS varchar(100)
AS

    SET NOCOUNT ON

    DECLARE @KeyOut varchar(10)

    SELECT @KeyOut = KeyOut FROM dbo.tblXlat WHERE xlatId = 'Textures' AND KeyIn = @CurrentModifier;

    UPDATE dbo.tblPatientDiet SET MenuLevel = @KeyOut
    WHERE Id = @PatientDietId;

    RETURN
go

