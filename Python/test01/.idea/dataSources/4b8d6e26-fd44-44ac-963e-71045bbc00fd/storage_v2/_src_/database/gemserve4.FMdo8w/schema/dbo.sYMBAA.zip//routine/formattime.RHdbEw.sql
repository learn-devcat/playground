

CREATE FUNCTION dbo.FormatTime(@TimeString as char(5))
RETURNS varchar(8)
AS
BEGIN
	DECLARE @Return AS varchar(8),
		@Hours AS int,
		@AMPM AS char(3)

	SET @Hours = CAST(LEFT(@TimeString,2) AS int)


	IF (@Hours > 11)
		SET @AMPM = ' PM'
	ELSE
		SET @AMPM = ' AM'

	-- Handle the hours
	IF (@Hours > 12)
		SET @Return = CAST((@Hours - 12) AS varchar(2))
	ELSE
		SET @Return = CAST(@Hours AS varchar(2))

	-- Handle the minutes & AM/PM
	SET @Return = @Return + ':' + RIGHT(@TimeString,2) + @AMPM

	RETURN @Return
END
go

