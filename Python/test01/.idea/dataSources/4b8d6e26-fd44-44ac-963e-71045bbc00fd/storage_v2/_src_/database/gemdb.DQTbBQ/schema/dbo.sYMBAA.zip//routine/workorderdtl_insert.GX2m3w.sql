CREATE            PROCEDURE dbo.WorkorderDTL_Insert
@User                   char(10),
@WorkorderID            int, 
@WorkOrderDTLDefID      int = 0,           
@AssigningEmployeeID    int = 0,
@AssignedEmployeeID     int = 0,
@AssignmentDate         datetime = null,
@CompletingEmployeeID	int = 0,
@CompletionDate		datetime = null,
@Completed		bit = 0,
@ActualHours		money = 0,
@ActualStartDate	datetime = null,
@ScheduledStartDate     datetime = null,   
@Price                  money = 0.00,      
@Notes                  VarChar(500) = '',
@PriceChangeReason	varchar(250) = '',
@Cost                   money = 0.00      
AS 
SET NOCOUNT ON
DECLARE @WorkOrderDTLID  int,
	@Ident		 int,
	@ErrorNum	 int
    SET @AssignmentDate     = ISNULL( @AssignmentDate    , Getdate())
    SET @ScheduledStartDate = ISNULL( @ScheduledStartDate, Getdate())
    SET @CompletionDate = ISNULL( @CompletionDate, Getdate())
    SET @ActualStartDate = ISNULL( @ActualStartDate, Getdate())
    SET @WorkOrderDTLID = ISNULL((SELECT  TOP 1 WorkOrderDTLID
			          FROM    tblWorkOrderDTL
			          WHERE   WorkOrderID = @WorkorderID
			          order by WorkOrderDTLID desc),0)
    SET @WorkOrderDTLID = @WorkOrderDTLID + 1       -- The next one in line...
	INSERT INTO tblWorkorderDTL
                (WorkorderID,  WorkOrderDTLID,  WorkOrderDTLDefID, AssigningEmployeeID, AssignmentDate, AssignedEmployeeID, CompletingEmployeeID, CompletionDate, Completed, ActualHours, ActualStartDate, Price, Cost, ScheduledStartDate, Notes, PriceChangeReason )
    VALUES      (@WorkorderID, @WorkOrderDTLID, @WorkOrderDTLDefID,@AssigningEmployeeID,@AssignmentDate, @AssignedEmployeeID,@CompletingEmployeeID,@CompletionDate, @Completed,Round(@ActualHours,2), @ActualStartDate, @Price ,@Cost  ,@ScheduledStartDate , @Notes, @PriceChangeReason )
	
    IF @@Error <> 0 
      BEGIN
	SET @ErrorNum = @@Error
	SELECT @ErrorNum
        RETURN
      END
   SELECT @WorkOrderDTLID
    RETURN
go

