



----------------------------------------------------------------------------------
--
--  MapOHDGet                     09-Sep-03 w.j.scott
--
--  Returns one map record based on the matching ID.
--
--  NOTE:  If a map entry is flagged as inactive, it will not be included.
--         Since there can be only one ID per table, if one is inactive, then
--         it would be safe to assume it won't be included either, thus
--         resulting in an empty recordset.
--
--  TODO:  include the security class verification in this list so that we can
--         enforce the security of which users are allowed to see these maps.
--
-----------------------------------------------------------------------------------
CREATE PROCEDURE dbo.MapOHDGet
@MapID int

AS
	SET NOCOUNT ON

	SELECT 	*
	FROM	dbo.tblMapOHD
	WHERE	MapNumber = @MapID and
	        inactive = 0
	        
	RETURN
go

