

CREATE PROCEDURE dbo.MenuItemDelete
@LoginUserID		varchar(250),
@MenuItemID	int

AS
	SET NOCOUNT ON
	DECLARE @POSMenuEditing	varchar(10),
		@POSMenuItemID	int

	SET @POSMenuEditing = dbo.GetOverheadValue('POSMenuEditing')
	SELECT @POSMenuItemID = POSMenuItemID
	FROM 	dbo.tblMenuItemOHD
	WHERE	MenuItemID = @MenuItemID

	DELETE dbo.tblMenuItemOHD WHERE MenuItemID = @MenuItemID

	IF (@POSMenuEditing = '1')
		EXEC dbo.Micros_MenuItemDelete @LoginUserID, @POSMenuItemID

	RETURN
go

