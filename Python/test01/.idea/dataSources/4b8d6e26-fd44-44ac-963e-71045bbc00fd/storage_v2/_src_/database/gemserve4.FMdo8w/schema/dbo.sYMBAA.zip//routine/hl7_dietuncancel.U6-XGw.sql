CREATE PROCEDURE [dbo].[HL7_DietUncancel]
@PatientVisitID			varchar(50),
@TransactionIdentifier	varchar(50),
@Source					varchar(50)
AS

	DECLARE @Msg		varchar(500),
			@PatientID	int,
			@RoomID		int,
			@DietName	varchar(50),
			@Today		datetime

	SET @Today = getdate()

	SELECT @PatientID = PatientID,
			@RoomID = RoomID
	FROM	dbo.tblPatientVisit
	WHERE PatientVisitID = @PatientVisitID

	SELECT @DietName = [Description]
	FROM dbo.tblPatientDiet AS PD (NOLOCK)
		JOIN dbo.tblDietOHD AS D (NOLOCK) ON PD.DietID = D.DietID
	WHERE PD.TransactionIdentifier = @TransactionIdentifier

	UPDATE dbo.tblPatientDiet
	SET CancelDate = NULL
	WHERE PatientVisitID = @PatientVisitID
		AND TransactionIdentifier = @TransactionIdentifier

	UPDATE dbo.tblPatientNotes
	SET CancelDate = NULL,
		UpdateDate = @Today,
		UpdateID = @Source
	WHERE PatientVisitID = @PatientVisitID
		AND TransactionIdentifier = @TransactionIdentifier

	-- Add a patient log entry
	IF (@PatientID IS NOT NULL)
	BEGIN
		SET @Msg = 'Diet [' + COALESCE(@DietName,'N/A') + '] un-cancelled. Transaction identifier [' + @TransactionIdentifier + '].'
		EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, @PatientVisitID, @RoomID, @Msg
	END

	RETURN
go

