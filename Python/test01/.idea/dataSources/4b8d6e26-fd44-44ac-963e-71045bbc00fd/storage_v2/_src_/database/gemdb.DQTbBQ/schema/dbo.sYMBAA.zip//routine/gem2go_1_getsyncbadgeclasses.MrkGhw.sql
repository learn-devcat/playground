

CREATE PROCEDURE [dbo].[gem2go_1_GetSyncBadgeClasses]
    @CoreID int ,
    @User char(10)
AS
    SET NOCOUNT ON 

		Select BadgeClassId,
				[Description]
		From dbo.tblBadgeClass      
         
    return
go

