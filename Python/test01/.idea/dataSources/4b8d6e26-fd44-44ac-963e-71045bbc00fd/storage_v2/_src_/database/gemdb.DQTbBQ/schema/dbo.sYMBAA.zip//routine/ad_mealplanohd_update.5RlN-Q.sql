

CREATE PROCEDURE dbo.ad_MealPlanOHD_Update
@MealPlanID		int,
@Name			varchar(32),
@Status		int,
@SubType		int,
@Freq			char(3),
@InitialNumPeriods	smallint,
@FirstDayOfWeek	smallint,
@ReloadQty		int,
@ReloadBalance	money
AS
	UPDATE	tblPlanOHD
	SET		Name = @Name,
			Status = @Status,
			SubType = @SubType,	
			Freq = @Freq,
			InitialNumPeriods = @InitialNumPeriods,
			FirstDayOfWeek = @FirstDayOfWeek,
			ReloadQty = @ReloadQty,
			ReloadBalance = @ReloadBalance
	WHERE	MealPlanID = @MealPlanID
go

