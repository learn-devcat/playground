

CREATE FUNCTION dbo.IncludeInPatientNotes(@Lookup varchar(100))
RETURNS varchar(100)
AS
BEGIN
	DECLARE @Return varchar(100)

	SELECT @Return = KeyOut FROM dbo.tblXlat WHERE KeyIn = @Lookup AND xlatid = 'Patient_Notes'

	RETURN ISNULL(@Return, 'NO')
END
go

