

CREATE PROCEDURE dbo.DietMealPeriodNutrientAddForImport
@LoginUserID		varchar(250),
@DietID		varchar(50),
@NutrientName	varchar(50),
@MealPeriodName	varchar(50),
@Qty		decimal(10,3)
AS
	SET NOCOUNT ON

	DECLARE @NutrientID int,
		@MealPeriodID int

	SELECT 	@NutrientID = NutrientID
	FROM	dbo.cfgNutrients
	WHERE	[Description] = @NutrientName

	SELECT 	@MealPeriodID = MealPeriodID
	FROM	dbo.tblMealPeriods
	WHERE	[Description] = @MealPeriodName

	IF ((@NutrientID IS NOT NULL) AND (@MealPeriodID IS NOT NULL))
	BEGIN
		INSERT INTO dbo.tblDietMealPeriodNutrients (DietID, NutrientID, MealPeriodID, Qty)
			VALUES (@DietID, @NutrientID, @MealPeriodID, @Qty)
	END
	RETURN
go

