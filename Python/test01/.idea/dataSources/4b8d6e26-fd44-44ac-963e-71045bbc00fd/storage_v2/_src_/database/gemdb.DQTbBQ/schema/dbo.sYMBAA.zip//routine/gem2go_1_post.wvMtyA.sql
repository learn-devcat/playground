

CREATE PROCEDURE [dbo].[gem2go_1_Post]
    @CoreID int ,
    @User char(10) ,
    @AccountNo char(19) ,
    @BadgeNo char(19) ,
    @OutletNo int ,
    @TransID int ,
    @CheckNum char(6)  = '' ,
    @RefNum char(6)    = '',
    @ServeEmpl int     = 0 ,
    @TransDate datetime= 0,
    @Sales1 money      = 0,
    @Tax1 money        = 0 ,
    @Dsc money         = 0 ,
    @Svc money         = 0 ,
    @TransTotal money  = 0,
    @Comment varchar(40) = '',
    @BatchDetailID varchar(100) = ''

AS
    SET NOCOUNT ON 

    DECLARE @Today datetime,
            @FirstName varchar(30),
            @Lastname varchar(50),
            @Description varchar(50),
            @Balance money,
            @ReturnName varchar(200),
            @SP_Return int,
            @PostReturn int,
            @TransIDName varchar(25) ,
            @TransClassID int,
            @AccountClassID int,
            @BadgeClassID  int,
            @Bump200  int,							-- badges and accounts can bump the transid.
            @BumpByValue int,
            @TransDateBegin datetime ,
            @TransDateEnd datetime ,
            @DupeTrans varchar(19) ,
            @Msg varchar(200),
            @CycleNo int,
            @Category char(10) ,
            @PaymentNo int ,
            @PostEmpl int ,
            @Covers smallint ,
            @RevCntr int ,
            @Sales2 money ,
            @Sales3 money,
            @Sales4 money,
            @Sales5 money,
            @Sales6 money,
            @Sales7 money,
            @Sales8 money,
            @Sales9 money,
            @Sales10 money,
            @Sales11 money,
            @Sales12 money,
            @Sales13 money,
            @Sales14 money,
            @Sales15 money,
            @Sales16 money,
            @Tax2 money,
            @Tax3 money,
            @Tax4 money,
            @SvcA money,
            @Correction bit,
            @Auditable bit,
            @PostDate datetime ,
            @MealPlanID int ,
            @LocationID int ,
            @DBLocationID int,				-- Returned from the database.
            @Lost int,
            @Stolen int,
            @Flagged int,
            @Inactive int,
            @ActiveDate datetime,
            @ExpireDate datetime,
            @ReturnCode int,
            @GEMpayVersion as varchar(100),
            @ReturnMsg as varchar(500),
			@TransTotalForAuth money = @TransTotal,
			@IsPaymentTrans bit = 0

    SET @CycleNo    = -1
    SET @Category   = 'WEB' 
    SET @PaymentNo  = @TransID
    SET @PostEmpl   = @ServeEmpl
    SET @Covers     = 1
    SET @RevCntr    = @OutletNo
    SET @Sales2     = 0 
    SET @Sales3     = 0 
    SET @Sales4     = 0 
    SET @Sales5     = 0 
    SET @Sales6     = 0 
    SET @Sales7     = 0 
    SET @Sales8     = 0 
    SET @Sales9     = 0 
    SET @Sales10    = 0 
    SET @Sales11    = 0 
    SET @Sales12    = 0 
    SET @Sales13    = 0 
    SET @Sales14    = 0 
    SET @Sales15    = 0 
    SET @Sales16    = 0 
    SET @Tax2       = 0 
    SET @Tax3       = 0 
    SET @Tax4       = 0 
    SET @SvcA       = 0 
    SET @Correction = 0
    SET @Auditable  = 0 
    SET @PostDate   = '' 
    SET @MealPlanID = 0 
    SET @LocationID = -1

    --EXEC dbo.sp_Logit 1, @CoreID, @User, @MealPlanID, 950

    SET @TransDateBegin = CAST(dbo.DateOnly(@TransDate) + ' 0:0' AS datetime)          -- Extract the date part from the transaction date coming in ...
    SET @TransDateEnd   = CAST(dbo.DateOnly(@TransDate) + ' 23:59:59.950' AS datetime)
    SET @Today          = GETDATE()						-- Define here cauz can't use it in an EXEC call ...
    SET @ReturnCode     = 0
    
    --------------------------------------------------------------------
    --	Verify the transaction data before we try to post anything.
    ---------------------------------------------------------------------        
    
    select @GEMpayVersion = sValue           -- we have to handle pre version 3 systems differently.
    from cfgOverhead
    where oKey = 'Version'

    if( @GEMpayVersion < '2.00' )
      begin
         select '/Not compatible with this version of GEMpay: [' + @GEMpayVersion + ']'
         return
      end
     
    SELECT  @OutletNo = OutletNo
    FROM    tblOutletOHD
    WHERE   OutletNo = @OutletNo
    
    if( @@ROWCOUNT = 0 )
      BEGIN
        SELECT '/Not a Valid Outlet: ' + cast( @OutletNo as varchar(10)) as ReturnMsg
        RETURN
      END
    
    IF( ISNULL(@BadgeNo,'') = '' )				--  Need one of these dudes to continue ...
      BEGIN
        SELECT '/Badge Number Was Passed In Blank - A Badge # is Required'   as ReturnMsg
        RETURN
      END	

    IF( left( @BadgeNo,1) = '~' )								-- Since we did this for other swipe readers, let's do it here too... jic
        SET @BadgeNo = right( @BadgeNo , len( @BadgeNo  ) - 1 )

    select @Lost           = Lost,						-- Check all the Badge level parameters.
           @Stolen         = Stolen,
           @Flagged        = Flagged,
           @Inactive       = Inactive,
           @ActiveDate     = ActiveDate,
           @ExpireDate     = ExpireDate,
           @DBLocationID   = LocationID,
           @BumpByValue    = BC.BumpByValue,
           @BadgeClassID   = B.BadgeClassID
    from   tblBadgesOHD B
    left join tblBadgeClass BC on B.BadgeClassID = BC.BadgeClassID
    where  B.BadgeNo       = @BadgeNo
       and B.AccountNo     = @AccountNO

    if( @@ROWCOUNT = 0 )
      begin
        SELECT '/Badge Not On File' as ReturnMsg
        RETURN
      end
      
    if( @LocationID < 0 )							-- if we defaulted this, let's get it from the badge table.
        SET @LocationID = @DBLocationID

    if( @Lost != 0 )            -- TODO: Retrieve these messages from a message response table to allow the end-user to customze these.
      begin
        SELECT '/Message 1 :: Transaction Not Allowed (Status L)' as ReturnMsg
        RETURN
      end

    if( @Stolen != 0 )
      begin
        SELECT '/Message 2 :: Transaction Not Allowed (Status S)' as ReturnMsg
        RETURN
      end

    if( @Flagged != 0 )
      begin
        SELECT '/Message 3 :: Transaction Not Allowed (Status F)' as ReturnMsg
        RETURN
      end

    if( @Inactive != 0 )
      begin
        SELECT '/Badge Is Inactive' as ReturnMsg
        RETURN
      end

    if( @ActiveDate > @Today )
      begin
        SELECT '/Badge Is Not Active Yet' as ReturnMsg
        RETURN
      end

    if( @ExpireDate < @Today )
      begin
        SELECT '/Badge Has Expired' as ReturnMsg
        RETURN
      end
    
    --------------------------------------------------[ Now check the Account Information
    
    select @Inactive       = Inactive,
           @ActiveDate     = ActiveDate,
           @ExpireDate     = ExpireDate,
           @AccountClassID = AC.AccountClassID,
           @Bump200        = Bump200
    from   tblAccountOHD A
    left join tblAccountClass AC on AC.AccountClassID = A.AccountClassID
    where  A.AccountNo = @AccountNO

    if( @Inactive != 0 )
      begin
        SELECT '/Account Is Inactive' as ReturnMsg
        RETURN
      end

    if( @ActiveDate > @Today )
      begin
        SELECT '/Account Is Not Active Yet' as ReturnMsg
        RETURN
      end

    if( @ExpireDate < @Today )
      begin
        SELECT '/Account Has Expired' as ReturnMsg
        RETURN
      end

    --------------------------------------------------------[ Now check the other zillion things ...

    ------------------------------------------------------------------------
    -- test the TransID down here cuz we may have bumped it up above...
    ------------------------------------------------------------------------

    set @TransID = @TransID + @BumpByValue          -- this is set at the badge class level

    if( @Bump200 != 0 )                             -- this is set at the Account level 
        set @TransID = @TransID + 200

    SELECT  @TransIDName  = description,           -- we need the TransID Name when we return from here... (so we do't look it up again)
            @TransClassID = TransClassID,
			@IsPaymentTrans = Payment
    FROM    tblTransDef
    WHERE   TransID       = @TransID

    IF ( @@ROWCOUNT = 0 ) 
        BEGIN
            if( @Bump200 + @BumpByValue > 0 )
               SELECT '/Trans ID Has Not Been Defined (Was Bumped):' + cast( @TransID as varchar(10)) as ReturnMsg
            else
               SELECT '/Trans ID Has Not Been Defined: ' + cast( @TransID as varchar(10)) as ReturnMsg
            RETURN
        END

    if( dbo.IsAllowed(@OutletNo, @AccountClassID , @TransClassID ) = 0 )
      begin
        SELECT '/Not Allowed At This Location' as ReturnMsg
        RETURN
      end

	  
	  If (@IsPaymentTrans = 1)
	  BEGIN
		SET @TransTotalForAuth = @TransTotal * -1
	  END


    EXEC @SP_Return = dbo.sp_PreChargeAuthorization @AccountNo, @BadgeNo, @TransTotalForAuth, @TransID, @OutletNo

    IF (@SP_Return = 0)        -- Ok, we're good so far... Let's party! 0 means we passed all the credit limit checks...
    BEGIN

        SELECT TOP 1
                @DupeTrans     = AccountNo                          -- Let's make sure that this transaction doesn't already exist
        FROM    tblDetail                                       --   Sure hope the index is up to date!!
        WHERE   AccountNo      = @AccountNo
                AND BadgeNo    = @BadgeNo
                AND TransDate BETWEEN @TransDateBegin
                                AND   @TransDateEnd
                AND ChkNum     = @CheckNum
                AND TransTotal = @TransTotal
                AND OutletNo   = @OutletNO
                AND TransID    = @TransID
                AND PaymentNo  = @PaymentNo

        IF ( @@ROWCOUNT = 0 )          -- Only a non-dup trans will actually post -- everything else will just ACT like it posted, but really it posted before...
          BEGIN			

            IF( @GEMpayVersion < '3.00' )
            BEGIN
                  EXEC @PostReturn = sp_Trans_Post  @CoreID,   @User,      
                                                    @AccountNo,@BadgeNo,   @TransDate, @OutletNo,  @RefNum,
                                                    @CheckNum, @TransTotal,@Sales1,    @Comment,
                                                    @CycleNo,  @TransID,   @Category,  @PaymentNo,
                                                    @ServeEmpl,@PostEmpl,  @Covers,    @RevCntr,   
                                                    @Sales2,   @Sales3,    @Sales4,    @Sales5,    @Sales6,    
                                                    @Sales7,   @Sales8,    @Sales9,    @Sales10,   @Sales11,   
                                                    @Sales12,  @Sales13,   @Sales14,   @Sales15,   @Sales16,   
                                                    @Tax1,     @Tax2,      @Tax3,      @Tax4,      
                                                    @Dsc,      @Svc,       @SvcA,
                                                    @Correction,@Auditable,
                                                    @PostDate,  @MealPlanID         -- no location for pre-version 3.00 gempay systems.
            END
            ELSE
            BEGIN
                  EXEC @PostReturn = sp_Trans_Post  @CoreID,   @User,      
                                                    @AccountNo,@BadgeNo,   @TransDate, @OutletNo,  @RefNum,
                                                    @CheckNum, @TransTotal,@Sales1,    @Comment,
                                                    @CycleNo,  @TransID,   @Category,  @PaymentNo,
                                                    @ServeEmpl,@PostEmpl,  @Covers,    @RevCntr,   
                                                    @Sales2,   @Sales3,    @Sales4,    @Sales5,    @Sales6,    
                                                    @Sales7,   @Sales8,    @Sales9,    @Sales10,   @Sales11,   
                                                    @Sales12,  @Sales13,   @Sales14,   @Sales15,   @Sales16,   
                                                    @Tax1,     @Tax2,      @Tax3,      @Tax4,      
                                                    @Dsc,      @Svc,       @SvcA,
                                                    @Correction,@Auditable,
                                                    @PostDate,  @MealPlanID,
                                                    @LocationID

            END

		--Flag the order as a GEM2go order
		UPDATE dbo.tblDetail
		SET	G2GOrder = 1	
		WHERE   AccountNo = @AccountNo
			AND BadgeNo = @BadgeNo
			AND TransDate BETWEEN @TransDateBegin
							AND     @TransDateEnd
			AND ChkNum = @CheckNum
			AND TransTotal = @TransTotal
			AND OutletNo = @OutletNO
			AND TransID = @TransID
			AND PaymentNo = @PaymentNo
        END 
        ELSE 
        BEGIN
            SET @msg = 'Duplicate GEM2go Posting: Acct: '
                + RTRIM(@AccountNo) + ' Badge: ' + RTRIM(@BadgeNo)
                + ' Chk #' + @CheckNum + ' Total:'
                + CAST(@TransTotal AS varchar(12))
            EXEC dbo.sp_Logit 1, @CoreID, @User, @msg
            set @PostReturn = 0
        END							

    END

    IF ( @SP_Return <> 2627 AND @SP_Return <> 0 )        -- This is returned from the credit limits above...
      begin
        SELECT  '/SQL Error Code: ' + CAST(@SP_Return AS varchar(25))	as ReturnMsg
        RETURN
      end

    IF (@PostReturn = 0)            -- it posted; so only then let's look up this other stuff as only then will it be needed!!!
      begin

        -- Let's see if this is a Transaction from tblBatch that we are processing
        --   We know it is by examining the BatchDetailID field -- if null, not something we need to remove from batch.
        -- it's easy to do, just set the posted flag for this detail id; 

        if( len( isnull( @BatchDetailID , '' )) > 0 )
          begin
             update tblBatch
                set Posted = 'P'
              where DetailID = @BatchDetailID
          end

        SELECT  @FirstName   = A.FirstName,
                @LastName    = A.LastName,
                @Description = A.Description,
                @Balance     = CASE TC.DeclBalMode
                                  WHEN 0 THEN TT.Balance 
                                  ELSE -TT.Balance
                               END
        FROM	   tblAccountOHD AS A
        LEFT JOIN tblAccountTTL AS TT ON A.AccountNo = TT.AccountNo
        LEFT JOIN tblTransDef   AS T  ON TT.TransClassID = T.TransClassID
        LEFT JOIN tblTransClass AS TC ON T.TransClassID = TC.TransClassID
        WHERE A.AccountNo   = @AccountNo
              AND T.TransID = @TransID
                
        IF (@FirstName <> '' OR @LastName <> '')
            SET @ReturnName = RTRIM(@LastName) + ', ' + RTRIM(@FirstName)
        ELSE
            SET @ReturnName = @Description
                
      end
      
      
    SELECT CASE @SP_Return
            WHEN '0'  THEN
                CASE @PostReturn
                    WHEN 0 THEN '@' + @ReturnName + Char(28) + 'Balance: ' + CAST(@Balance AS varchar(16)) + Char(28) + @ReturnName + char(13)+char(10) + 'Transaction: APPROVED ' + char(13)+char(10) +   'New Current Balance: ' + CAST(@Balance AS varchar(16)) + char(13) + char(10)  + '----------------------------------------' + char(13) + char(10) + '            ' + CAST(  GETDATE() as varchar(30)) + char(13) + char(10)
                    ELSE '/Error Code: ' + CAST( @PostReturn as varchar(10))
                END
            WHEN '1' THEN '/Over Account Limit'
            WHEN '2' THEN '/Over Daily Limit'
            WHEN '3' THEN '/Badge Not On File'
            WHEN '4' THEN '/Badge Not Valid'
            WHEN '5' THEN '/Over Daily Qty'
            WHEN '6' THEN '/Over Badge Trans Limit'
            WHEN '7' THEN '/Over Account Trans Limit'
            WHEN '8' THEN '/Inactive Account'
            WHEN '9' THEN '/Over Badge Limit'
            WHEN '10' THEN '/Not Authorized Here'
            WHEN '11' THEN '/Outlet Not Defined'
            ELSE           '/Undefined Error #:' +  CAST( @SP_Return as varchar(10))
        END AS ReturnMsg

    RETURN

go

