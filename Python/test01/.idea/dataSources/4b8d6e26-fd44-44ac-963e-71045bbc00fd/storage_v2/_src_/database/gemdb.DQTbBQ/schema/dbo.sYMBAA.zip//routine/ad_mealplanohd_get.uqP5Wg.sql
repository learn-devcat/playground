

CREATE PROCEDURE dbo.ad_MealPlanOHD_Get
@MealPlanID	int
AS
	SELECT	MealPlanID,
			Name,
			Status,
			SubType,
			Freq,
			InitialNumPeriods,
			FirstDayOfWeek,	
			ReloadQty,
			ReloadBalance
	FROM 		tblPlanOHD 
	WHERE 	MealPlanID=@MealPlanID
go

