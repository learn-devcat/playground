
CREATE PROCEDURE [dbo].[MenuListForRole]
@Roles		varchar(1000)

AS
	SET NOCOUNT ON

	DECLARE @MenuPointSize	varchar(10)

	IF EXISTS (SELECT 1 FROM dbo.cfgOverhead WHERE KeyID = 'ImagesDirectory')
		UPDATE dbo.cfgWebMenus SET IsDisabled = 0 WHERE Description = 'Manage Private Images'
	ELSE
		UPDATE dbo.cfgWebMenus SET IsDisabled = 1 WHERE Description = 'Manage Private Images'


        DECLARE @Menus TABLE (
                        MenuID int,
                        ParentID int,
                        [Description] varchar(50),
                        MenuAction varchar(1000),
                        MenuImage varchar(100),
                        MenuHoverImage varchar(100),
                        [Sequence] int,
                        IsSeparator bit,
                        IsDisabled bit,
                        IsChecked bit,
                        MenuGroup int,
                        MenuPointSize int)
                              
	SELECT @MenuPointSize = dbo.GetOverheadValue('MenuPointSize')
	IF (@MenuPointSize = '')
		SET @MenuPointSize = '10'

        INSERT INTO @Menus
	SELECT DISTINCT	M.MenuID,
		M.ParentID,
		ISNULL(M.Description,'') AS Description,
		ISNULL(M.MenuAction,'') AS MenuAction,
		ISNULL(M.MenuImage,'') AS MenuImage,
		ISNULL(M.MenuHoverImage,'') AS MenuHoverImage,
		M.Sequence,
		ISNULL(M.IsSeparator,0) AS IsSeparator,
		ISNULL(M.IsDisabled,0) AS IsDisabled,
		ISNULL(M.IsChecked,0) AS IsChecked,
		M.MenuGroup,
		CAST(@MenuPointSize as int)
	FROM	dbo.tblSecurityRoleActions AS R (NOLOCK) 
                JOIN dbo.tblSecurityActions AS A (NOLOCK) ON R.ActionID = A.ActionID
		JOIN dbo.cfgWebMenus AS M (NOLOCK) ON A.ActionID = M.ActionID			
	WHERE	R.RoleID IN (SELECT RoleID FROM GEM.dbo.GetUserRolesFromString(@Roles))

        SELECT * FROM @Menus
        ORDER BY [Sequence], ParentID
        
	RETURN
go

