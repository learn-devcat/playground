CREATE FUNCTION dbo.GetActiveDietNotesByID
(@PatientDietID int)

RETURNS varchar(500)

AS
	BEGIN
		DECLARE @Return	varchar(500)

		SELECT @Return = Notes
		FROM dbo.tblPatientDiet
		WHERE [ID] = @PatientDietID

		RETURN ISNULL( @Return, '' )
	END
go

