

CREATE PROCEDURE dbo.sp_Connection_Insert
@ConnectionID int, 
@InterfaceID 	int, 
@sDesc 	varchar(32)
AS
	INSERT INTO	cfgConnection (ConnectionID,InterfaceID,Active,Description)
	VALUES	(@ConnectionID,@InterfaceID,'1',@sDesc)
go

