CREATE PROCEDURE [dbo].[sim_Lookup]
@CoreID	smallint = 1,
@User		char(10),
@Lookup	varchar(30)
 AS
	set nocount on			-- Required so we can pass back a string.
declare @LastName varchar(16),
	@FirstName varchar(16),
	@message varchar(8000),
	@BadgeNo varchar(19),
	@count int
    
set @Lookup =upper( RIGHT(@Lookup, LEN(@Lookup) -1)) + '%' --removed the 1st character '?'

	SELECT 	@count = count(*)
	FROM 		tblBadgesOHD
	WHERE 	Lastname like @Lookup and
			inactive = 0 and
			expiredate >= getdate() and
			activeDate <= getdate() and 
			Lastname <> '' and
			Firstname <> '' and
            LocationID = 0

	if @count = 0 		-- Not found.
	begin
		select '/Name Not Found' as ReturnMsg
		return 
	end
	if @count > 100
	begin
		set @count = 100
	end

	set @message =  'success' + char(28) + cast(@count as varchar(10))

	DECLARE Name_Cursor CURSOR FOR 
	SELECT 	top 100 rtrim(Lastname), rtrim(Firstname) ,  BadgeNo
	FROM 		tblBadgesOHD
	WHERE 	Lastname like @Lookup and
			inactive = 0 and
			expiredate >= getdate() and
			activeDate <= getdate()and 
			Lastname <> '' and
			Firstname <> '' and 
			LocationID = 0
	ORDER BY 	Lastname, Firstname

	OPEN Name_Cursor
	FETCH NEXT FROM name_cursor
		INTO @LastName, @FirstName, @BadgeNo
	WHILE @@FETCH_STATUS = 0
	BEGIN
		set @message = @message  + char(28) + rtrim(@lastname) + ',' +  rtrim(@firstname) + ',' + rtrim(@badgeno)
		FETCH NEXT FROM Name_Cursor	-- Get next row if one exists.
		INTO @LastName, @FirstName, @BadgeNo
	END
	CLOSE Name_Cursor
	DEALLOCATE Name_Cursor

	select @message as ReturnMsg
go

