CREATE PROCEDURE dbo.ad_BadgeClass_Get
@User			char(10),
@BadgeClassID	int
AS 
	SELECT	BadgeClassID,
			Description,
			DailyLimit,
			DailyQtyLimit,
			Limit,
			ExpireDays,
			Status,
			BumpByValue,
			EnableWeb
	FROM	tblBadgeClass
	WHERE	BadgeClassID = @BadgeClassID
go

