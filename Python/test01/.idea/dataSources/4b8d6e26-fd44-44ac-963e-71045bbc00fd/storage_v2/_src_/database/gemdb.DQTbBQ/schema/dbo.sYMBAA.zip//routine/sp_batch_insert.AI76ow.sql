CREATE PROCEDURE [dbo].[sp_Batch_Insert]
@CoreID	int,
@User		char(10),
@BatchID	char(10),
@AccountNo	char(19),
@BadgeNo	char(19),
@TransDate	datetime,
@OutletNo	int,
@RefNum		char(6),
@CheckNum	char(6),
@TransTotal	money,
@Sales1		money,
@Comment	varchar(40),
@CycleNo	int=0,
@TransID	int,
@MealPlanID	int=0,
@Category 	char(10)=' ',
@PaymentNo	int=0,
@ServeEmpl	int=0,
@PostEmpl	int=0,
@Covers		smallint=0,
@RevCntr	int=0,
@Sales2		money=0,
@Sales3		money=0,
@Sales4		money=0,
@Sales5		money=0,
@Sales6		money=0,
@Sales7		money=0,
@Sales8		money=0,
@Sales9		money=0,
@Sales10	money=0,
@Sales11	money=0,
@Sales12	money=0,
@Sales13	money=0,
@Sales14	money=0,
@Sales15	money=0,
@Sales16	money=0,
@Tax1		money=0,
@Tax2		money=0,
@Tax3		money=0,
@Tax4		money=0,
@Dsc		money=0,
@Svc		money=0,
@ExcepMsg	varchar(255) = ''
		
AS
	DECLARE	@Error	int
	
	IF (@CycleNo < 1)
		SELECT	@CycleNo = X.CycleNo
		FROM	dbo.tblAccountOHD AS A
				INNER JOIN dbo.tblAccountClass AS AC ON A.AccountClassID = AC.AccountClassID
				INNER JOIN dbo.tblCycleXlat AS X ON	AC.CycleXRefID = X.xlatid
		WHERE	getdate() BETWEEN X.BeginDate AND X.EndDate
				AND A.AccountNo = @AccountNo
	INSERT INTO		dbo.tblBatch (CoreID,AccountNo,BadgeNo,TransDate,OutletNo,RefNum,
					ChkNum,TransTotal,Sales1,Comment,CycleNo,TransID,
					Category,PaymentNo,ServeEmpl,PostEmpl,Covers,RevCntr,
					Sales2,Sales3,Sales4,Sales5,Sales6,Sales7,Sales8,
					Sales9,Sales10,Sales11,Sales12,Sales13,Sales14,Sales15,
					Sales16,Tax1,Tax2,Tax3,Tax4,Dsc,Svc,BatchID, MealPlanID,ExceptionMessage)
	VALUES			(@CoreID,@AccountNo,@BadgeNo,@TransDate,@OutletNo,@RefNum,
					@CheckNum,@TransTotal,@Sales1,@Comment,@CycleNo,@TransID,
					@Category,@PaymentNo,@ServeEmpl,@PostEmpl,@Covers,@RevCntr,
					@Sales2,@Sales3,@Sales4,@Sales5,@Sales6,@Sales7,@Sales8,
					@Sales9,@Sales10,@Sales11,@Sales12,@Sales13,@Sales14,@Sales15,
					@Sales16,@Tax1,@Tax2,@Tax3,@Tax4,@Dsc,@Svc,@BatchID,@MealPlanID,@ExcepMsg)
	SET @ERROR = @@Error
	IF (@Error <> 0)
	BEGIN
		
		DECLARE 	@cMsg varchar(255)
		SET @cMsg = 'ERR Inserting Batch item ::: Error code=' + CAST(@Error AS varchar(10)) + ' ::: AccountNo=' + @AccountNo + 
			',BadgeNo=' + @BadgeNo + ',TransID=' + @TransID + 
			',OutletNo=' + @OutletNo + ',ChkNum=' + @CheckNum + ',TransTotal=' + CAST(@TransTotal AS varchar(10)) + 
			',TransDate=' + CAST(@TransDate AS varchar(20))
		EXEC dbo.sp_Logit 0 , @CoreID , @User , @cMsg
	END
go

