CREATE PROCEDURE dbo.MealPeriodListForMap
AS
	SET NOCOUNT ON

	DECLARE @ValidDays int,
		@WaveDays varchar(5),
		@TotalDays int,
		@Today datetime,
		@Current int

	DECLARE @Temp TABLE (MealPeriodID int,
			Description varchar(50),
			ShortName varchar(16),
			Active bit,
			IsCurrentMealPeriod bit,
			TotalDays int,
			EndTime varchar(5))


	SET @Today = getdate()
	SELECT @WaveDays = dbo.GetOverheadValue('Wavedays')
	SELECT @ValidDays = IsNumeric(@WaveDays)

	If @ValidDays = 1
		SET @TotalDays = CAST(@WaveDays as int) + 1
	ELSE
		SET @TotalDays = 1

	INSERT INTO @Temp
	SELECT M.MealPeriodID,
		M.[Description],
		ISNULL(M.ShortName, M.[Description]) AS ShortName,
		0 AS Active,
		0,
		@TotalDays AS TotalDays,
		dbo.MealPeriodEndTime(@Today, M.MealPeriodID) AS EndTime
	FROM	dbo.tblMealPeriods AS M (NOLOCK)
	WHERE	M.MealPeriodID IN (SELECT DISTINCT MealPeriodID FROM dbo.tblWave WHERE ShowOnMap <> 0)
	ORDER BY EndTime,MealPeriodID

	SELECT @Current = dbo.GetMealPeriod(getdate())

	UPDATE @Temp SET IsCurrentMealPeriod = 1
	WHERE MealPeriodID = @Current
		AND Description <> 'Anytime'

	SELECT * FROM @Temp
	ORDER BY EndTime, MealPeriodID

 	RETURN
go

