

CREATE FUNCTION dbo.AccountClassLU (@TempClass varchar(32))
RETURNS int
AS 
BEGIN 
	DECLARE @TempID int
	-- Looks up the Account Class using the Xref field.
	-- IF no match is found, RETURN the same value that was passed in
	SELECT @TempID = AccountClassID FROM tblAccountClass WHERE Xref=@TempClass
	SET @TempID = ISNULL(@TempID, @TempClass)
	RETURN @TempID
END
go

