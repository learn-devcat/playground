CREATE PROCEDURE [dbo].[CCS_DietOverridesDelete_v4]
@PatientDietID		varchar(50), 
@Source		varchar(100)
AS
	SET NOCOUNT ON

	DECLARE @ActiveDate	datetime,
		@DietID		int,
		@PatientVisitID	varchar(50),
		@Msg		varchar(500)

	SELECT 	@PatientVisitID = PatientVisitID,
		@DietID = DietID,
		@ActiveDate = ActiveDate,
		@Source = Source
	FROM	dbo.tblPatientDiet
	WHERE [ID] = @PatientDietID

	IF (@PatientVisitID IS NULL)
	BEGIN
		SET @Msg = ''
		GOTO Finished
	END

	-- Delete all daily nutrient overrides
	DELETE dbo.tblPatientDailyNutrientOverride 
	FROM dbo.tblPatientDailyNutrientOverride
	WHERE PatientDietID = @PatientDietID

	-- Delete all meal period nutrient overrides
	DELETE dbo.tblPatientMealPeriodNutrientOverride 
	FROM dbo.tblPatientMealPeriodNutrientOverride
	WHERE PatientDietID = @PatientDietID

        SET @Msg = 'Daily and meal period nutrient overrides deleted for Patient Visit ID: [' + @PatientVisitID + '] due to a diet update.'

Finished:

	EXEC dbo.Logit 1, @Msg, 'system'

	RETURN


go

