CREATE PROCEDURE [dbo].[sp_Task_AddForUser]
	@User char(10),
	@TaskId int
AS

	DECLARE @UserRole	int,
			@Msg		varchar(50),
			@MinPrivilegeClass	 int
	
	-- get the user's max role id
	SELECT @UserRole = MAX(PrivilegeClassId)
	FROM dbo.tblPrivilegeClassMembers
	WHERE UserID = @User;

	-- add the task for the user
	IF NOT EXISTS (SELECT 1 FROM dbo.Tasks WHERE TaskId = @TaskID AND EntryID = @User)
		INSERT INTO dbo.Tasks (TaskId, EntryId, EntryDate)
		SELECT	TaskId, @User, GETDATE()
		FROM	dbo.TaskOHD
		WHERE	TaskId = @TaskId
			AND	@UserRole >= MinPrivilegeClass
go

