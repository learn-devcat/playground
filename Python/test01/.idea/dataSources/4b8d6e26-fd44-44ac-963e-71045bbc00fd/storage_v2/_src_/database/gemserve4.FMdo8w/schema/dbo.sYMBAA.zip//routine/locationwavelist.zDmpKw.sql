

CREATE PROCEDURE dbo.LocationWaveList
@WaveID	int
AS
	SET NOCOUNT ON 

	SELECT	@WaveID AS WaveID,
		L.LocationClassID,
		L.[Description] AS Location,
		COALESCE(X.Active, 0) AS Active
	FROM	dbo.tblLocationClass AS L (NOLOCK)
		LEFT JOIN (SELECT W.WaveID, LW.LocationClassID, LW.Active
				FROM dbo.tblWave AS W (NOLOCK)
				JOIN dbo.tblLocationWave AS LW (NOLOCK) ON LW.WaveID = W.WaveID
				WHERE W.WaveID = @WaveID) AS X ON L.LocationClassID = X.LocationClassID
	WHERE 	L.Active = 1
		
	RETURN
go

