


CREATE PROCEDURE [dbo].[ad_Location_Get]
    @User char(10),
    @LocationID int
AS 
    SELECT  LocationID,
            Description,
            DefaultChargeOutlet,
            DefaultPaymentOutlet,
            DefaultWorkOrderOutlet,
			TimeZone,
			UserCode1,
			UserCode2,
			UserCode3,
			UserCode4,
			UserCode5
    FROM    cfgLocations
    WHERE   LocationID = @LocationID
go

