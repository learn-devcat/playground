
CREATE FUNCTION dbo.dDatePlusNewTime (@WholeDate as smalldatetime, @NewTime as varchar(12))
RETURNS datetime
AS 
BEGIN 
	RETURN
	CAST(DATEPART(year,@WholeDate) AS varchar(4)) + '/' +
	CAST(DATEPART(month,@WholeDate) AS varchar(2)) + '/' + CAST(DATEPART(day,@WholeDate) AS varchar(2)) + ' ' +
	@NewTime
	 
END
go

