

CREATE PROCEDURE dbo.sp_Interface_GetData
@CoreID int
AS
	SELECT	InterfaceID, CoreID, Active, RTRIM(Category) AS Category, 
			RTRIM(Description) AS Description, 
			RTRIM(Contact) AS Contact, 
			RTRIM(MyIP) AS MyIP, 
			RTRIM(ExceptionIP) AS ExceptionIP,
			RTRIM(GatewayIP) AS GatewayIP, 
			RTRIM(PrinterIP) AS PrinterIP,
			RTRIM(SysOptions) AS SysOptions
	FROM		cfgInterface
	WHERE	CoreID = @CoreID
go

