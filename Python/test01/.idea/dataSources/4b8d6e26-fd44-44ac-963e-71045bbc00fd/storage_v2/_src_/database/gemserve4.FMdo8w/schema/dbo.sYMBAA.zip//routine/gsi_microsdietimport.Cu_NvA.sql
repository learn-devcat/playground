
CREATE PROCEDURE [dbo].[GSI_MicrosDietImport]
@UserID		char(10),
@ObjectNumber	int,
@Description	varchar(16)
AS
	SET NOCOUNT ON

	DECLARE @SQL nvarchar(4000)
	
	SET @SQL = 'IF EXISTS(SELECT obj_num FROM Micros..micros.mi_def WHERE obj_num = @ObjectNumber)
		UPDATE Micros..micros.mi_def
		SET name_1 = @Description1
		WHERE obj_num = @ObjectNumber1
	ELSE
		INSERT INTO Micros..micros.mi_def (obj_num,name_1,maj_grp_seq,fam_grp_seq,mi_grp_seq,mi_slu_seq,mi_type_seq,mlvl_class_seq,prn_def_class_seq)
			VALUES(@ObjectNumber1, @Description1,3,2,1,68,1,1,12)'
			
	EXEC sp_executesql @SQL, N'@ObjectNumber1 int, @Description1 varchar(16)', @ObjectNumber, @Description			

	RETURN
go

