
CREATE FUNCTION dbo.PatientNumberGet(@String varchar(500),@Index int)
RETURNS varchar(50)
BEGIN
	DECLARE @Return		varchar(50),
		@Separator	varchar(10),
		@Start		int,
		@End		int,
		@Count		int

	SELECT @Separator = dbo.GetOverheadValue('ORMSeparator')
	IF (@Separator = '')
		SET @Separator = '|'

	SET @Count = 1
	SET @Start = 1

	WHILE (1=1)
	BEGIN
		SET @End = CHARINDEX(@Separator, @String, @Start)

		IF (@End = 0)
		BEGIN
			SET @Return = SUBSTRING(@String, @Start, LEN(@String) - @Start + 1)
			BREAK
		END

		IF (@Count = @Index)
		BEGIN
			SET @Return = SUBSTRING(@String, @Start, @End-@Start)
			BREAK
		END
		
		SET @Count = @Count + 1
		SET @Start = @End + 1

		-- At end of string and Index is larger than the number of elements in the string
		-- In this case, return null
		IF (LEN(@String) <= @End)
			BREAK
	END

	RETURN @Return
END
go

