CREATE FUNCTION [dbo].[GetMenuItemsFromNotes](@OrderID int)
RETURNS @XLATPOSMenuItems TABLE (POSMenuItemID varchar(50))
AS
BEGIN
/* How should I handle Patient Merges? */

	DECLARE @Notes varchar(max),
			@PatientVisitID varchar(50),
			@PatientID	int,
			@OrderDate	datetime,
			@WaveID	int

	-- Set the variables from only the patient orders
	SELECT	@PatientID = PatientID,
			@PatientVisitID = PatientVisitID,
			@OrderDate = OrderDate,
			@WaveID = WaveID
	FROM	dbo.tblOrderOHD
	WHERE	OrderID = @OrderID
		AND	OrderType = 1

	--  This is not a patient order so exit
	IF (@@ROWCOUNT = 0)
		RETURN

	-- Check if any NoteMenuItem xlat entries exist
	IF EXISTS (SELECT 1 FROM dbo.tblXLAT WHERE XlatID = 'NotePOSMenuItem')
	BEGIN
		
		-- Get all of the patient notes into a single string
		SELECT @Notes = Notes
		FROM dbo.tblPatientOHD
		WHERE PatientID = @PatientID

		-- Append the Active Diet Notes
		SET @Notes = RTRIM(@Notes) + dbo.GetActiveDietNotesEX(@PatientVisitID,@OrderDate,@WaveID)

		--See if patient has any notes
		IF (LEN(@Notes) > 0) 
			INSERT INTO @XLATPOSMenuItems
			SELECT KeyOut
			FROM dbo.tblXLAT
			WHERE xlatID = 'NotePOSMenuItem'
				AND CHARINDEX(KeyIn, @Notes) > 0 
			ORDER BY RIGHT('0000' + [Description],4)

	END

	RETURN
END
go

