CREATE PROCEDURE dbo.sp_GiftCard_Update
@User			char(10),
@AccountNo 		char(19),
@Title			char(10),
@FirstName		char(15),
@LastName		char(20),
@Phone 			char(15),
@ActiveDate		datetime,
@ExpireDate		datetime,
@MiddleName		char(15)=''
AS
	UPDATE	tblAccountOHD
	SET		Title = @Title,
			FirstName = @FirstName,
			MiddleName = @MiddleName,
			LastName = @LastName,
			Phone = @Phone,
			ActiveDate = @ActiveDate,
			ExpireDate = @ExpireDate,
			LastUpdateDate = GETDATE()
	WHERE	AccountNo = @AccountNo
	
	DECLARE	@cMsg  char(255),
			@CoreID	int
	SET @CoreID = dbo.GetCoreIDFromUser(@User)
	SET @cMsg = 'Updated GiftCard No <' + RTRIM(@AccountNo) + '>'
	EXEC dbo.sp_Logit 2 , @CoreID , @User , @cMsg
go

