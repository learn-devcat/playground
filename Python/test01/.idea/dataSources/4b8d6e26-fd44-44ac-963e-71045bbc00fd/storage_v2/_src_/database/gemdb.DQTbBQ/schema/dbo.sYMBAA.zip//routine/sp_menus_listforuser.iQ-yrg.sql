



CREATE   PROCEDURE [dbo].[sp_Menus_ListForUser]
@UserID	char(10)
AS
	SELECT 		DISTINCT M.MenuID, M.Description, M.SubMenuID, M.URL, M.ActionID, M.ImageURL
	FROM		tblPrivilegeClassMembers AS P
			JOIN tblPrivilegeLinks AS PL ON P.PrivilegeClassID = PL.PrivilegeClassID
			JOIN tblPrivilegeActions AS A ON PL.ActionID = A.ActionID
			JOIN cfgMenus AS M ON PL.ActionID = M.ActionID			
	WHERE		P.UserID = @UserID
	ORDER BY	MenuID, SubMenuID
go

