
CREATE PROCEDURE [dbo].[GSI_MicrosPOSDietImport]
AS

	DECLARE @SQL nvarchar(4000)
	
	SET @SQL = 'DECLARE @DietID int,
		@POSDescription varchar(16),
		@MajorGroupSeq int, 
		@FamilyGroupSeq int,
		@MIGroupSeq int, 
		@MITypeSeq int, 
		@MLvlClassSeq int, 
		@PrnDefClassSeq int,
		@Temp varchar(10)

	SET @MajorGroupSeq = null
	SET @FamilyGroupSeq = null
	SET @MIGroupSeq = null

	SELECT @Temp = dbo.GetOverheadValue(''DietMenuItemType'')
	IF (@Temp = '') 
		SELECT @MITypeSeq = MIN(mi_type_seq) FROM Micros..micros.mi_type_class_def
	ELSE
		SET @MiTypeSeq = CAST(@Temp AS int)

	SELECT @Temp = dbo.GetOverheadValue(''DietMenuLevel'')
	IF (@Temp = '') 
		SELECT @MLvlClassSeq = MIN(mlvl_class_seq) FROM Micros..micros.mlvl_class_def
	ELSE
		SET @MLvlClassSeq = CAST(@Temp AS int)

	SELECT @Temp = dbo.GetOverheadValue(''DietPrinterClass'')
	IF (@Temp = '') 
		SELECT @PrnDefClassSeq = MIN(prn_def_class_seq) FROM Micros..micros.prn_class_def
	ELSE
		SET @PrnDefClassSeq = CAST(@Temp AS int)

	DECLARE MyDiets CURSOR FOR
		SELECT DISTINCT DietID, POSDescription
		FROM dbo.tblDietOHD
		WHERE DietID >= 0

	OPEN MyDiets

	FETCH NEXT FROM MyDiets INTO @DietID, @POSDescription

	WHILE (@@FETCH_STATUS=0)
	BEGIN
		SET @DietID = @DietID + 9000000
		EXEC dbo.GSI_MicrosMenuItemUpdate @DietID, @POSDescription, 
			@MajorGroupSeq, @FamilyGroupSeq, @MIGroupSeq, 
			@MITypeSeq, @MLvlClassSeq, @PrnDefClassSeq, '', 0, 0

		FETCH NEXT FROM MyDiets INTO @DietID, @POSDescription
	END

	CLOSE MyDiets
	DEALLOCATE MyDiets'
	
	EXEC sp_executesql @SQL

	RETURN
go

