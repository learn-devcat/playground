CREATE PROCEDURE [dbo].[sp_Badge_GetTransIDDescription]
@User		char(10),
@TransID	int
AS
	DECLARE @ReturnValue varchar(50)
	
	SELECT	@ReturnValue = CAST(@TransID AS varchar(10)) + ' - ' + [Description]
	FROM		tblTransDef
	WHERE	TransID = @TransID
	
	IF (@@ROWCOUNT = 0)
		SET @ReturnValue = CAST(@TransID AS varchar(10)) + ' - Transaction Definition Not Found'
	
	SELECT @ReturnValue
go

