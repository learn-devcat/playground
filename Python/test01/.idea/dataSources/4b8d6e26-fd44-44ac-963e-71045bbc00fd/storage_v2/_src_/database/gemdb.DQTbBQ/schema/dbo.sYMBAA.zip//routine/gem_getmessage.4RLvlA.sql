CREATE   PROCEDURE [dbo].[gem_GetMessage]
@MessageID      varchar(50),
@Language       int         = 0,
@PageID         varchar(50) = ''
AS
	DECLARE @message as varchar(255)

    ----------------------------------------------------------------------------------
    --
    -- TODO:  Alter Table Structure for tblMessages
    --
    --              ID - VarChar(50)
    --          PageID - VarChar(50)
    --          
    --          This is required to accept the new page id formats.
    --
    ------------------------------------------------------------------------------------
	
	SET NOCOUNT ON
	
	SELECT TOP 1 @message = Message 
	FROM   tblMessages 
	WHERE  ID = @MessageID 
	       AND (( Language=0 ) or ( Language=@Language )) 
		   AND PageID = @PageID
	ORDER BY Language DESC

		
	IF( @@Error <> 0 )
	    SELECT '[' + @MessageID  + ':' + @PageID + ']' + CAST( @@Error as Varchar(20)) as Message
	ELSE
	    SELECT @message as Message
	
	RETURN
go

