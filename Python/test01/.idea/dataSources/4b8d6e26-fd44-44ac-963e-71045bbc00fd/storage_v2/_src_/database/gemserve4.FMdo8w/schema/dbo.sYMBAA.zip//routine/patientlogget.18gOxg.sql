

/*
    Get the listing of the patient log information ...
    
    @Style = 0  By Patient
             1  By Room
             2  Event ID

*/
CREATE PROCEDURE PatientLogGET
(
	@SearchID int,
	@Style    int = 0
)
AS
	
    IF(@Style = 0)
        BEGIN
            SELECT     E.[Description] AS EventDescription, P.EventClassID, P.[Date], P.LoginUserID, P.[Description]
            FROM       dbo.tblPatientLog AS P (NOLOCK)
            LEFT JOIN  dbo.cfgEventClass AS E (NOLOCK) ON E.ID = P.EventClassID
            WHERE      P.PatientID = @SearchID
            ORDER BY   P.[Date] DESC
        END
     ELSE IF(@Style = 1)
        BEGIN 
            SELECT     E.[Description] AS EventDescription, P.EventClassID, P.[Date], P.LoginUserID, P.[Description]
            FROM       dbo.tblPatientLog AS P (NOLOCK)
            LEFT JOIN  dbo.cfgEventClass AS E (NOLOCK) ON E.ID = P.EventClassID
            WHERE      P.RoomID = @SearchID
            ORDER BY   P.[Date] DESC
         END
     ELSE
         BEGIN
            SELECT     E.[Description] AS EventDescription, P.EventClassID, P.[Date], P.LoginUserID, P.[Description]
            FROM       dbo.tblPatientLog AS P (NOLOCK)
            LEFT JOIN  dbo.cfgEventClass AS E (NOLOCK) ON E.ID = P.EventClassID
            WHERE      P.EventClassID = @SearchID
            ORDER BY   P.[Date] DESC
         END
          
	RETURN
go

