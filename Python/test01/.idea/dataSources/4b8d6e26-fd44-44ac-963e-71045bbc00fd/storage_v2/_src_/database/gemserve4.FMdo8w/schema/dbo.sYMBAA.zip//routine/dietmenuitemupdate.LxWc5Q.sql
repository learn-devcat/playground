CREATE PROCEDURE [dbo].[DietMenuItemUpdate]
@LoginUserID		varchar(250),
@DietMenuItemID		int,
@DietID				int,
@POSMenuItemID		int

AS
	IF (@DietMenuItemID < 1)
	BEGIN
		INSERT INTO dbo.tblDietMenuItems (DietID, POSMenuItemID)
			VALUES (@DietID, @POSMenuItemID)

		SET @DietMenuItemID = SCOPE_IDENTITY()
	END
	ELSE
		UPDATE dbo.tblDietMenuItems
		SET DietID = @DietID,
			POSMenuItemID = @POSMenuItemID
		WHERE DietMenuItemID = @DietMenuItemID


	SELECT @DietMenuItemID AS DietMenuItemID
go

