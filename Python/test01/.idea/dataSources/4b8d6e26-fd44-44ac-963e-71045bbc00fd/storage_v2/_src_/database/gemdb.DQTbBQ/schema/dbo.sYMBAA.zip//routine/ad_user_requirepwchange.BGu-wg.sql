


CREATE  PROCEDURE dbo.ad_User_RequirePWChange
@UserID	varchar(16)
AS
	DECLARE	@LastPWChange		datetime,
		@ChangePWInterval	varchar(10),
		@PWNeverExpires		bit
	
	-- Make sure we did not get a blank UserID
	IF (@UserID = '')
	BEGIN
		RAISERROR ('Invalid UserID.', 16, 1)
		--ROLLBACK TRANSACTION    <---- No declared transaction to rollback. RBEV 12-12-05
	END
	-- Find out the last time the user changed their password
	SELECT  @LastPWChange = LastPWChange,
		@PWNeverExpires = PWNeverExpires		
	FROM	cfgUsers
	WHERE 	UserID = @UserID	
	IF (@PWNeverExpires = 1)
		GOTO ChangeNotRequired
	-- Get the ChangePWInterval FROM the Overhead table
	-- IF it is not found, the policy is not in effect, so exit
	SELECT @ChangePWInterval = dbo.GetOverheadItem('ChangePWInterval')
	IF (@ChangePWInterval = '')
		GOTO ChangeNotRequired
	IF (DATEADD(d, CAST(@ChangePWInterval AS int), @LastPWChange) <= getdate())
	BEGIN
		SELECT '1' AS Required
		RETURN
	END
	ChangeNotRequired:
		SELECT '0' AS Required
		RETURN
go

