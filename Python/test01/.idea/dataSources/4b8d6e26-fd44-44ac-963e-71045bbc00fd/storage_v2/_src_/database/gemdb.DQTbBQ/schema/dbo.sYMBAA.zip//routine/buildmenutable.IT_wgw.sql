CREATE PROCEDURE [dbo].[BuildMenuTable]
					@ParentID int, 
					@UserID as varchar(20)
AS
BEGIN
	SET NOCOUNT ON
	
	DECLARE @MenuID int,
			@NestLvl int

	/*
		Author: Richard Beverly
		Date: 10-13-2008
		Description: This proc assembles UI menu items the user has permissions to see AND
						puts them in the proper order for rendering to the web page. This proc
						recursively calls itself to ensure child menu items are inserted directly 
						after their parents.
	*/
	-- IF nocount is off, COM will not process the @@NESTLEVEL AND the proc will fail

	INSERT	#MenuBuildup
	SELECT	MenuID,
			SubMenuID,
			Description,
			ShortDescription,
			Synopsis,
			URL,
			ActionID,
			@@NESTLEVEL,
			ImageURL
	FROM	dbo.cfgMenus
	WHERE	MenuID = @ParentID AND dbo.isPermitted( @UserID , ActionID ) > 0

	SET @MenuID = (SELECT MIN(MenuID) FROM dbo.cfgMenus WHERE SubMenuID = @ParentID AND dbo.isPermitted( @UserID , ActionID ) > 0)

	WHILE @MenuID IS NOT NULL
	BEGIN
		EXEC dbo.BuildMenuTable @MenuID, @UserID
		SET @MenuID = (SELECT MIN(MenuID) FROM dbo.cfgMenus WHERE SubMenuID = @ParentID AND MenuID > @MenuID  AND dbo.isPermitted( @UserID , ActionID ) > 0)
	END

END
go

