CREATE PROCEDURE [dbo].[CCS_PatientSwap_v4]
@PatientVisitID	varchar(50),
@RoomNumber		varchar(50),
@Bed			varchar(50),
@PatientClass		varchar(50),
@Location			varchar(50),
@PatientVisitID2	varchar(50),
@RoomNumber2		varchar(50),
@Bed2			varchar(50),
@PatientClass2		varchar(50),
@Location2		varchar(50),
@Source			varchar(50)
AS

	-- Execute transfers.
	-- All logging takes place in the Transfer procedure, logged to ADT-A17.
	EXEC dbo.CCS_PatientTransfer_v4 @PatientVisitID, @RoomNumber, @Source, @Bed, @PatientClass, @Location
	EXEC dbo.CCS_PatientTransfer_v4 @PatientVisitID2, @RoomNumber2, @Source, @Bed2, @PatientClass2, @Location2

	RETURN


go

