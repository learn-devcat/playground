CREATE PROCEDURE [dbo].[OrderTypesList]
AS
	SELECT OrderTypeId,
			Description,
			[Value]
	FROM dbo.tblOrderTypes
	WHERE Active = 1
	
	RETURN 0
go

