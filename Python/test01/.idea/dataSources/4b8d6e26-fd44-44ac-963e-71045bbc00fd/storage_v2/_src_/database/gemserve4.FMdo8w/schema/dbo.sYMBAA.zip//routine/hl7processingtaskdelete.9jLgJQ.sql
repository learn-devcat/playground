CREATE PROCEDURE dbo.HL7ProcessingTaskDelete
@CommandID	int

AS
	SET NOCOUNT ON

	UPDATE dbo.tblHL7Processing
	SET Active = 0
	WHERE CommandID = @CommandID

	RETURN
go

