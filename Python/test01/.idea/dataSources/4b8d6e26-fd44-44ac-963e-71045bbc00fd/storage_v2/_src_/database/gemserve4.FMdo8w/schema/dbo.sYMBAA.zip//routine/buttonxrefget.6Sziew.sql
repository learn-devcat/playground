

CREATE PROCEDURE dbo.ButtonXrefGet
@ID	int
AS

	SET NOCOUNT ON

	SELECT 	[ID],
		ButtonID,
		RoomNumber,
		Bed,
		ActionID
	FROM 	dbo.tblButtonXref
	WHERE	[ID] = @ID

	RETURN
go

