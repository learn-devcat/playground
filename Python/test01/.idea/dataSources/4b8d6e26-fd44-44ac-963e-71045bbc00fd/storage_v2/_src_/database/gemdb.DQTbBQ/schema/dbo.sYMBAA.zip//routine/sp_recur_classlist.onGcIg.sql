


CREATE  PROCEDURE dbo.sp_Recur_ClassList
AS 
	SELECT	Description, ClassID, NextDate, Active
	FROM		tblRecurChgClass
	WHERE	Active <> 0
go

