


CREATE FUNCTION dbo.FirstOfMonth (@WholeDate smalldatetime)
RETURNS smalldatetime
AS 
BEGIN 
	RETURN
	
	CAST(DATEPART(year,@WholeDate) AS varchar(4)) + '/' +
	CAST(DATEPART(month,@WholeDate) AS varchar(2)) + '/01' 
	 
END
go

