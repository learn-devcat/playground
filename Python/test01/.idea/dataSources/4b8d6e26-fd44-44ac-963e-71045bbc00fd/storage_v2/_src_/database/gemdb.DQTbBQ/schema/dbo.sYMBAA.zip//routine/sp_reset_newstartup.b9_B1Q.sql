
CREATE PROCEDURE [dbo].[sp_Reset_NewStartup]
	@User char(10) = 'SYSTEM'
AS
  IF( dbo.GetOverheadItem( 'STARTUP' ) <> 'YES' )
    BEGIN
      EXEC dbo.sp_logit 0 , 0 , 'SYSTEM' , 'sp_Reset_NewStartup Failed. No Startup Key'
      RETURN
    END
  /*
	Changes made 4-17-2008 by RBeverly:
		* Added a @User parameter so the log will report the logged in user 
			(this assumes a management page will exist to run the reset)
		* Added reset for all AccountOutletClassTTLs
		* Added auto reset of the "STARTUP" overhead item that allows this procedure to run. It is reset to "NO"
  */
    
    
 /*
 Ensure we have the database backed up first ...
 */
DECLARE @ReturnCode int
EXEC @ReturnCode=sp_helpdevice 'MyGEMdb'
IF (@ReturnCode<>0)
 EXEC sp_addumpdevice 'disk', 'MyGEMdb',  'C:\GEM\database\GEMdbBAK.dat'
 BACKUP DATABASE GEMdb TO MyGEMdb WITH description = 'BACKUP Before RESET'
  /*
 First, clear out the Cycle Related tables -- these are tables that have one record for each cycle number AND account.
 */ 
 -- Account Related
 UPDATE tblAccountTTL
 SET Balance = 0,
 DailyBalance = 0,
 Qty = 0,
 DailyQty = 0,
 LastPayDate = '01/01/1980',
 LastChgDate = '01/01/1980'

 UPDATE tblAccountOutletClassTTL
 SET Balance = 0,
 DailyBalance = 0,
 Qty = 0,
 DailyQty = 0,
 LastPayDate = '01/01/1980',
 LastChgDate = '01/01/1980'

 Truncate Table tblAccountTransTTL
 Truncate Table tblTrackingTTL
 -- Overhead Related
 Truncate Table tblOutletTTL
 Truncate Table tblCycleLog
 Truncate Table tblLog
 --Transaction Related
 Truncate Table tblTransDefTTL
 Truncate Table tblDetail
 Truncate Table tblBatch 
 Truncate Table dbo.tblBadgeTTL 
  
 -- Now clear the balances in non-cycle related tables.
UPDATE tblBadgesOhd
SET		LastPayDate = '01/01/1980',
             LastChgDate = '01/01/1980',
             DailyBalance = 0,
             DailyQty = 0
UPDATE	cfgCore
SET		CycleNo = -1
EXEC dbo.sp_CycleNo_Increment 1  -- So we have a starting record in the tblCycleLog
EXEC dbo.sp_CycleNo_Increment 1  -- So we have a starting record in the tblCycleLog

-- reset the startup option to prevent accidental reset of system
EXEC dbo.sp_Overhead_UpdateKey 'system', 'STARTUP', 'NO'

	DECLARE 	@cMsg char(255),
				@CoreID	int
		IF( @@Error = 0 )
 			SET @cMsg = 'ALL balances, transactions, logs AND batches have been reset or deleted'
 		ELSE
 			SET @cMsg = 'sp_Reset_NewStartup FAILED'
	EXEC dbo.sp_Logit 0 , 0 , @User , @cMsg
go

