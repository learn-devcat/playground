CREATE FUNCTION [dbo].[GetOrderDetail]
(@OrderID INT, @OrderType INT, @IncludeStatusItems bit)
RETURNS VARCHAR (4000)
AS
BEGIN
	DECLARE	@Return		varchar(4000),
		@POSMenuItemID	varchar(50),
		@ItemType	int,
		@ExcludeDietOnReceipt varchar(10);
		
	DECLARE @OrderItems TABLE (ItemType int, POSMenuItemID varchar(50), IsDiet bit);

	SET @Return = '';
	SELECT @ExcludeDietOnReceipt = dbo.GetOverheadValue('ExcludeDietOnReceipt');

	-- *********************************
	-- Temp table to improve performance
	-- *********************************
	INSERT INTO @OrderItems (ItemType, POSMenuItemID, IsDiet)
	SELECT ItemType, POSMenuItemID, IsDiet
	FROM dbo.tblOrderItems
	WHERE OrderId = @OrderId
	ORDER BY OrderItemID;
	-- *********************************
	-- End Temp table
	-- *********************************

	-- *********************************
	-- Get the Diet Menu Item if it exists
	-- *********************************
	-- Check for the Overhead flag 'ExcludeDietOnReceipt'. If it exists with a value of '1', then do not print the Diet Menu Item
	-- Added as an update for Orange Regional and marked for release in GEMserve 4.60 - 3/19/14 - rab
	IF (@ExcludeDietOnReceipt <> '1')
	BEGIN
		SELECT @POSMenuItemID = POSMenuItemID, @ItemType = ItemType
		FROM @OrderItems
		WHERE IsDiet = 1;

		IF (@POSMenuItemID IS NOT NULL)
			SELECT @Return = CAST(@ItemType AS varchar(10)) + ',' + @POSMenuItemID + ',';
	END
	-- *********************************
	-- End Diet Menu Item
	-- *********************************



	-- *********************************
	-- Get the Diet Menu Item if it exists
	-- *********************************
	SELECT @POSMenuItemID = POSMenuItemID, @ItemType = ItemType
	FROM @OrderItems
	WHERE IsDiet = 1;

	IF (@POSMenuItemID IS NOT NULL AND @ExcludeDietOnReceipt <> '1')
		SELECT @Return = CAST(@ItemType AS varchar(10)) + ',' + @POSMenuItemID + ',';
	-- *********************************
	-- End Diet Menu Item
	-- *********************************

	-- ****************************************************************************************
	-- Get additional menu items for the Patient Status table, Diet, and Location if any exists
	-- ****************************************************************************************
	IF (@IncludeStatusItems = 1)
		SELECT @Return = @Return + '259,' + POSMenuItemID + ','
		FROM dbo.GetMenuItemsFromStatus(@OrderID);
	-- *************************
	-- End additional menu items
	-- *************************

	-- *********************************
	-- Get all other menu items
	-- *********************************
	SELECT @Return = @Return + CAST(ItemType as varchar(10)) + ',' + POSMenuItemID + ','
	FROM @OrderItems
	WHERE COALESCE(IsDiet, 0) = 0
	-- *********************************
	-- Get all other menu items
	-- *********************************

	IF (LEN(@Return) > 0)
		SET @Return = LEFT(@Return, LEN(@Return) - 1)

	RETURN @Return
END
go

