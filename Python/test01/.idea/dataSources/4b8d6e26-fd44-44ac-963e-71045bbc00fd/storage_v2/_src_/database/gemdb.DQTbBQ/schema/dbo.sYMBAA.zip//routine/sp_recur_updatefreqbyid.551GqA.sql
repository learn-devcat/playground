CREATE     PROCEDURE [dbo].[sp_Recur_UpdateFreqByID]
@User		char(10),
@ClassID	int

AS   
   	DECLARE	@TempFreq		char(1),
   		@TempValue		int,
		@Active			bit,
		@NextDate		datetime,
		@Frequency		char(16),		
		@TempDate		datetime,
		@DateOffset		int	

		SELECT 	@NextDate = NextDate, @Frequency = Frequency, @DateOffset = DateOffset
		FROM	dbo.tblRecurChgClass
		WHERE	ClassID = @ClassID;
		
		--Get the frequency VALUES FROM the current record
		SET @TempFreq = SUBSTRING(@Frequency, 1, 1)
		IF @TempFreq <> 'C' -----------------------------------------------------------ADDED RB
			SET @TempValue = CAST(SUBSTRING(@Frequency, 2, 2) AS int)
		
		--UPDATE the frequency based on the current frequency VALUES
		IF @TempFreq = 'D'
			UPDATE	dbo.tblRecurChgClass
			SET	NextDate = DATEADD(d, @TempValue, @NextDate)
			WHERE ClassID = @ClassID
		ELSE
		BEGIN
			IF @TempFreq = 'W'
				UPDATE	dbo.tblRecurChgClass
				SET		NextDate = DATEADD(wk, @TempValue, @NextDate)
				WHERE ClassID = @ClassID	
			ELSE
			BEGIN
				IF @TempFreq = 'M'
					UPDATE	dbo.tblRecurChgClass
					SET		NextDate = DATEADD(m, @TempValue, @NextDate)
					WHERE ClassID = @ClassID
				ELSE
				BEGIN
					IF @TempFreq = 'E'
					BEGIN
	
						--Increment the @NextDate by the number of months in the @TempValue variable
						SET @NextDate = DATEADD(m,@TempValue,@NextDate)
						--Check the day to make sure it is the last day in the month.
						--This is necessary because adding a month to a date of 28, 29 or 30 may not move
						--us to the last day of the next month (i.e., 31)
						WHILE (MONTH(@NextDate) = MONTH(DATEADD(d,1,@NextDate)))
						BEGIN
							SET @NextDate = DATEADD(d,1,@NextDate)
						END
							
						--UPDATE the table
						UPDATE	dbo.tblRecurChgClass
						SET		NextDate = @NextDate
						WHERE ClassID = @ClassID
					END
					ELSE
					BEGIN
						IF @TempFreq = 'A'
							UPDATE	dbo.tblRecurChgClass
							SET		NextDate = DATEADD(yy, @TempValue, @NextDate)
							WHERE ClassID = @ClassID
						ELSE
						BEGIN
							IF @TempFreq = 'C' ------------------------------------- ADDED RB
							UPDATE	dbo.tblRecurChgClass
							SET	NextDate = dbo.GetNextRecurDateByXref(getdate(), @Frequency, @DateOffset)
							WHERE ClassID = @ClassID
								
								IF @TempFreq = 'B'
								BEGIN
									--IF the day is less than 14, then add 15 days AND UPDATE
									IF (DAY(@NextDate) < 14)
										UPDATE	dbo.tblRecurChgClass
										SET	NextDate = DATEADD(d, 15, @NextDate)
										WHERE ClassID = @ClassID
		
									ELSE
									BEGIN
										--Since the day is more than 13, roll it to the TempValue date
										--Increment by one month
										SET @NextDate = DATEADD(m, 1, @NextDate)
										--SET the day of the month to 1st
										SET @NextDate = CAST(MONTH(@NextDate) AS varchar(2)) + 
											'/' + CAST(@TempValue AS varchar(2)) + 
											'/' + CAST(YEAR(@NextDate) AS varchar(4))											
										
										--UPDATE the table
										UPDATE	dbo.tblRecurChgClass
										SET	NextDate = @NextDate
										WHERE ClassID = @ClassID
									END
								END
						END
					END
				END
			END
		END
go

