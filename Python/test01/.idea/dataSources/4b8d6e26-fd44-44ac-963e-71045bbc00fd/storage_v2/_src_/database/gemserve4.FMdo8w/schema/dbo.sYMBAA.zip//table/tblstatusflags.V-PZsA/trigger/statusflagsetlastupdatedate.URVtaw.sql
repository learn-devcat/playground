CREATE TRIGGER [dbo].[StatusFlagSetLastUpdateDate] ON [dbo].[tblStatusFlags] FOR INSERT, UPDATE    
AS
      UPDATE    dbo.tblStatusFlags
       SET              LastUpdateDate = getdate()
       FROM         Inserted AS I JOIN
                              dbo.tblStatusFlags AS S ON I.StatusFlagID = S.StatusFlagID
go

