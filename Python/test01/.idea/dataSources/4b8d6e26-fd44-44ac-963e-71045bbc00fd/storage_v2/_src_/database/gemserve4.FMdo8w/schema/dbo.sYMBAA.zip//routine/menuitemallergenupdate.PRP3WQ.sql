


CREATE PROCEDURE dbo.MenuItemAllergenUpdate
@LoginUserID		varchar(250),
@MenuItemID		int,
@AllergenID		int

AS
	SET NOCOUNT ON

	IF NOT EXISTS (SELECT AllergenID FROM dbo.tblMenuItemAllergens WHERE MenuItemID = @MenuItemID AND AllergenID = @AllergenID)
		INSERT INTO dbo.tblMenuItemAllergens(MenuItemID, AllergenID)
			VALUES(@MenuItemID, @AllergenID)

	RETURN
go

