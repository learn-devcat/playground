

----------------------------------------------------------------------------------
--
--  DateString( datetime )                  15-Aug-03 w.j.scott
--
--  Return the date portion of the date/time field as a string, fixed at
--  10 characters with the format YYYYMMDD.  
--
--  e.g.,   2003-09-01
--           
--
-----------------------------------------------------------------------------------
CREATE FUNCTION dbo.DateString (@WholeDate as datetime)
RETURNS char(10)
AS 
BEGIN 
	RETURN 	Cast(DatePart(year,@WholeDate) AS varchar(4)) + 
	        '-' +
	        right( '0' + Cast(DatePart(month,@WholeDate) AS varchar(2)),2) + 
	        '-' + 
	        right( '0' + Cast(DatePart(day,@WholeDate) AS varchar(2)) , 2 )
	 
END
go

