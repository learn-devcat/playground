
CREATE PROCEDURE dbo.VM_Inq
@CoreID int,
@UserID char(10),
@BadgeNo char(19),
@Channel int,
@TransID int,
@RevenueCenter int
AS
DECLARE @loglevel int
DECLARE @Today datetime,
	@AccountNo	char(19),
	@MealLimit	money,
	@MealCountAll	int,
	@MealCount	int,
	@MealPlanID	int
	SET @loglevel = 1	
	SET @Today = getdate()
	SELECT TOP 1 @AccountNo = AccountNo
	FROM	tblBadgesOHD
	WHERE	BadgeNo = @BadgeNo
			AND Inactive = 0
			AND Lost = 0
			AND Stolen = 0
			AND dbo.dDateOnly(ActiveDate) <= dbo.dDateOnly(@Today)
			AND dbo.dDateOnly(ExpireDate) >= dbo.dDateOnly(@Today)
	DECLARE	@DailyQty		int,
		@AccountDailyBalance	money,
		@DailyLimit		money,
		@AcctBalance		money,
		@Limit			money,
		@DailyQtyLimit		int,
		@BadgeDailyBalance	money,
		@BadgeDailyLimit	money,
		@BadgeDailyQty		int,
		@BadgeDailyQtyLimit	int,
		@BadgeBalance		money,
		@BadgeLimit		money,
		@TransLimit		money,
		@AvailableBalance	money,
		@MPBalance		money,
		@GlobalTransOverride money
		
	-- get the Balance AND qty VALUES
	SELECT  @DailyQty = t.DailyQty,
		@AccountDailyBalance = dbo.IsDailyMoney( t.DailyBalance ,t.LastChgDate , @Today),
 		@DailyLimit = dbo.fnMin( t.DailyLimit, c.DailyLimit ),
 		@AcctBalance = t.Balance,
 		@Limit = dbo.fnMin( t.Limit , c.Limit ),
		@DailyQtyLimit = dbo.fnMin( t.DailyQtylimit,  c.DailyQtyLimit ),
		@badgeDailyBalance = dbo.IsDailyMoney( b.DailyBalance ,b.LastChgDate , @Today),
 		@badgeDailyLimit = dbo.fnMin( bc.DailyLimit ,  b.DailyLimit ),
		@badgeDailyQty = dbo.IsDailyMoney( b.DailyQty ,b.LastChgDate , @Today),
		@badgeDailyQtyLimit = dbo.fnMin( bc.DailyQtyLimit  , b.DailyQtylimit),
		@BadgeBalance = ISNULL(bt.Total,0),
		@badgeLimit = b.limit,
		@TransLimit = b.TransLimit
	FROM 	tblAccountOHD a
		LEFT outer  JOIN tblAccountTTL t on  t.AccountNo = a.AccountNo
		RIGHT JOIN tblAccountClass c on c.AccountClassID = a.AccountClassID 
		RIGHT JOIN tblBadgesOHD b on b.AccountNo = @AccountNo AND b.BadgeNo = @BadgeNo
		RIGHT JOIN tblBadgeClass bc on bc.BadgeClassID =  b.BadgeClassID 
		RIGHT JOIN tblTransClass AS tc on tc.TransClassID = t.TransClassID
		RIGHT JOIN tblOutletOHD AS o on o.OutletNo = @RevenueCenter
 		LEFT JOIN tblBadgeTTL bt on a.AccountNo = bt.AccountNo AND bt.BadgeNo = @BadgeNo AND
 			dbo.GetCycleByXRef(0,bt.date,'bc' + cASt(b.BadgeClassID AS varchar(10))) = dbo.GetCycleByXRef(0,@Today,'bc' + cASt(b.BadgeClassID AS varchar(10)))
		LEFT JOIN tblTransDef AS td on t.TransClassID = td.TransClassID AND td.TransID = @TransID 
	WHERE 	a.AccountNo = @AccountNo AND
		dbo.dDateOnly(a.ExpireDate) >= dbo.dDateOnly(@Today) AND 
		dbo.dDateOnly(a.ActiveDate) <= dbo.dDateOnly(@Today) AND 
		dbo.dDateOnly(b.ExpireDate) >= dbo.dDateOnly(@Today) AND 
		dbo.dDateOnly(b.ActiveDate) <= dbo.dDateOnly(@Today) AND 
		dbo.dDateOnly(t.ExpireDate) >= dbo.dDateOnly(@Today)  AND
		tc.DisablePOSPosting = 0  AND
		dbo.IsAllowed(O.OutletNo,-1,tc.TransClassID) <> 0
		--tc.Subtype & o.Subtype <> 0
	ORDER BY a.AccountNo,t.TransClassID

	IF EXISTS (SELECT 1 FROM dbo.tblAccountOHD WHERE AccountNo = @AccountNo AND TransOverride = 1)
		SELECT @GlobalTransOverride = TransOverrideAmt
		FROM dbo.tblAccountOHD WHERE AccountNo = @AccountNo AND TransOverride = 1

	-- Update all Limits to the Global Override Amt. if it is set
	IF (@GlobalTransOverride IS NOT NULL)
	BEGIN
		SET @TransLimit = @GlobalTransOverride
		SET @Limit = @GlobalTransOverride
		SET @BadgeLimit = @GlobalTransOverride
		SET @DailyLimit = @GlobalTransOverride
		SET @BadgeDailyLimit = @GlobalTransOverride
	END

	-- get the Limit with the lowest value
	SELECT @MPBalance = dbo.VM_ValidateMealPlan(@AccountNo,@TransID,@RevenueCenter, getdate(), 0)
	SELECT @MealPlanID = ISNULL(dbo.VM_ValidateMealPlan(@AccountNo,@TransID,@RevenueCenter, getdate(), 1), 0)
	SELECT @AvailableBalance = dbo.fnMin(dbo.fnMin(dbo.fnMin(dbo.fnMin( @TransLimit, (@Limit - @AcctBalance)), (@badgeLimit - @BadgeBalance)), (@DailyLimit - @AccountDailyBalance)), (@badgeDailyLimit - @badgeDailyBalance))
	IF (NOT (@MPBalance IS NULL))
		SELECT @AvailableBalance = dbo.fnMin(@AvailableBalance, @MPBalance)
	
	-- check the QTY limits. IF we are >= the QTY Limit for any item, THEN SET the @AvailableBalance to 0
	IF (@BadgeDailyQty >= @BadgeDailyQtyLimit) OR (@DailyQty >= @DailyQtyLimit) 
		SET @AvailableBalance = 0
	IF (@AvailableBalance >= 999999)	-- In case we have all params SET to unlimited
		SET @AvailableBalance = 0
	SELECT RTRIM(@Channel) + char(28) + 
		CAST(CAST(ISNULL(@AvailableBalance * 100,0) AS int) as varchar(12)) + char(28) +
		CAST(ISNULL(@MealPlanID,0) as varchar(20))
	
	DECLARE @cmsg  char(255)
	
	SET @cMsg = ''
	IF( @@ROWCOUNT = 0 ) 
		BEGIN
			SET @cmsg = 'VM_INQ account/badge # ' + RTRIM(ISNULL(@AccountNo,'')) + '/' + RTRIM(ISNULL(@BadgeNo,'')) + ' <no match>'
			SET @loglevel = @loglevel - 1		-- drop logging level to catch failure.
		END
	ELSE
		SET @cmsg = 'VM_INQ account/badge # ' + RTRIM(ISNULL(@AccountNo,'')) + '/' + RTRIM(ISNULL(@BadgeNo,''))
	EXEC sp_logit @loglevel , @coreid , 'system' , @cmsg
go

