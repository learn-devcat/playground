

CREATE FUNCTION dbo.GetPeriodName (@TransDate datetime, @TransID int) 
RETURNS varchar(32)
AS 
BEGIN 
	DECLARE	@TempMP	varchar(10),
		@Return	varchar(32)
	
	SELECT 	@TempMP = oKey
	FROM	cfgOverhead
	WHERE	sValue = CAST(@TransID AS varchar(5))
			AND LEFT(oKey,2) = 'MP'
	
	IF (@TempMP IS NOT NULL)
	BEGIN
		SET @TempMP = RIGHT(@TempMP,LEN(@TempMP) - 2)
	
		SELECT 	@Return = Description 
		FROM	tblPlanDtl
		WHERE 	MealPlanID = CAST(@TempMP as int)
			AND BegTime <= dbo.TimeOnly(@TransDate)
			AND EndTime >= dbo.TimeOnly(@TransDate)
	END
	ELSE
		SELECT @Return = 'Not Found'
	
	RETURN @Return
END
go

