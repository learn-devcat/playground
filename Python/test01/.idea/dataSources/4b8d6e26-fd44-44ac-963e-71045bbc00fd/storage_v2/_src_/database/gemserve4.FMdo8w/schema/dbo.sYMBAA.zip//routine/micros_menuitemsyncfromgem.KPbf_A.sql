CREATE PROCEDURE [dbo].[Micros_MenuItemSyncFromGEM]
AS
	DECLARE	@POSMenuItemID		int,
		@Description		varchar(50),
		@MajorGroupSequence	int,
		@FamilyGroupSequence	int,
		@MenuItemGroupSequence	int,
		@MenuItemTypeSequence	int,
		@MenuLevelClassSequence	int,
		@PrinterDefClassSequence int,
		@CrossReference1	varchar(50),
		@Cost			money,
		@Price			money,
		@POSMenuItemSEQ		int,
		@MenuItemID		int
	
	DECLARE menuItems CURSOR FOR
		SELECT 	MenuItemID,
			POSLegend,
			MajorGroupSequence,
			FamilyGroupSequence,
			MenuItemGroupSequence,
			MenuItemTypeSequence,
			MenuLevelClassSequence,
			PrinterDefClassSequence,
			CrossReference1,
			Cost,
			Price
		FROM	dbo.tblMenuItemOHD
	
	OPEN menuItems
	
	FETCH NEXT FROM menuItems INTO @MenuItemID, @Description, @MajorGroupSequence, @FamilyGroupSequence,
			@MenuItemGroupSequence, @MenuItemTypeSequence, @MenuLevelClassSequence,
			@PrinterDefClassSequence, @CrossReference1, @Cost, @Price
	
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @POSMenuItemID = -1

		EXEC @POSMenuItemSEQ = dbo.Micros_MenuItemUpdate @POSMenuItemID OUTPUT, @Description, @MajorGroupSequence, @FamilyGroupSequence,
			@MenuItemGroupSequence, @MenuItemTypeSequence, @MenuLevelClassSequence,
			@PrinterDefClassSequence, @CrossReference1, @Cost, @Price

		UPDATE dbo.tblMenuItemOHD SET POSMenuItemSEQ = @POSMenuItemSEQ,
			POSMenuItemID = @POSMenuItemID
		WHERE	MenuItemID = @MenuItemID
	
		FETCH NEXT FROM menuItems INTO @MenuItemID, @Description, @MajorGroupSequence, @FamilyGroupSequence,
			@MenuItemGroupSequence, @MenuItemTypeSequence, @MenuLevelClassSequence,
			@PrinterDefClassSequence, @CrossReference1, @Cost, @Price
	END
	
	CLOSE menuItems
	DEALLOCATE menuItems

	RETURN
go

