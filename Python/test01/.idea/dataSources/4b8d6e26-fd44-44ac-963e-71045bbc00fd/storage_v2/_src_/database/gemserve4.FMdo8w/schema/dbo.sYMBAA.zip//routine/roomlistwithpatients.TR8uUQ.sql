



CREATE PROCEDURE dbo.RoomListWithPatients
@LocationClassID	int

AS
	SET NOCOUNT ON

	SELECT 	L.LocationClassID, 
		L.Description,
		R.RoomNumber, 
		P.PatientID,
		ISNULL(RTRIM(P.MedicalRecordID),'N/A') AS MedicalRecordID,
		P.LastName,
		P.FirstName,
		CASE 
			WHEN P.LastName IS NULL THEN 'N/A'
			WHEN P.FirstName IS NULL THEN 'N/A'
			ELSE RTRIM(P.LastName) + ', ' + RTRIM(P.FirstName)
		END AS PatientName,
		CASE
			WHEN P.PatientID IS NULL THEN 0
			ELSE 1
		END AS EnableDischarge,
		PV.PatientVisitID
	FROM	dbo.tblLocationClass AS L (NOLOCK)
		JOIN dbo.tblRoomOHD AS R (NOLOCK) ON R.LocationClassID = L.LocationClassID
		LEFT JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON R.RoomID = PV.RoomID AND PV.DischargeDate IS NULL
		LEFT JOIN dbo.tblPatientOHD AS P (NOLOCK) ON PV.PatientID = P.PatientID
	WHERE	L.LocationClassID = @LocationClassID AND PV.DischargeDate IS NULL
	ORDER BY RoomNumber

	RETURN
go

