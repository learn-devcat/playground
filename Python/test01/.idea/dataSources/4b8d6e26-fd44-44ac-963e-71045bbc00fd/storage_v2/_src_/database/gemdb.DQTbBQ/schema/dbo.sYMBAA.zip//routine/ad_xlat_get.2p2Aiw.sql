



CREATE  PROCEDURE dbo.ad_Xlat_Get
AS 
	SELECT	XlatID,
		InChar,
		OutChar
	FROM	dbo.tblXLAT
	ORDER BY XlatID
go

