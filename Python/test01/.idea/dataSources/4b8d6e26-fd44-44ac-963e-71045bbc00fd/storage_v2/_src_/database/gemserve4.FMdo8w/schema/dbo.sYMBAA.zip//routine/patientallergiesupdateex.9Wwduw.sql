CREATE PROCEDURE [dbo].[PatientAllergiesUpdateEX]
@LoginUserID			varchar(200),
@MedicalRecordID	varchar(50),
@Allergies		varchar(6000)

AS
	DECLARE	@Allergen	varchar(150),
		@AllergenID	int,
		@Notes		varchar(4000),
		@PatientID	int,
		@ORMSeparator varchar(10),
		@Msg		varchar(200)

	DECLARE @Process TABLE (AllergenID int)
		
	SELECT @ORMSeparator = COALESCE(dbo.GetOverheadValueNULL('ORMSeparator'),'|')

	SELECT @PatientID = PatientID 
	FROM	dbo.tblPatientOHD
	WHERE	MedicalRecordID = @MedicalRecordID

	SET @Allergies = REPLACE(@Allergies,'"','')

   	-- Update allergy information
    	WHILE (LEN(@Allergies)>0)
    	BEGIN
		-- Find a separator in the text string
		IF (CHARINDEX(@ORMSeparator,@Allergies) > 0)
			SET @Allergen = LEFT(@Allergies, CHARINDEX(@ORMSeparator, @Allergies) - 1)
		ELSE
			SET @Allergen = @Allergies

		IF ((@Allergen IS NOT NULL) AND (@Allergen <> ''))
		BEGIN
			-- Put all Allergens that need to be set by this item into a temporary table
			DELETE @Process

			INSERT INTO @Process 
			SELECT CAST(KeyOut AS int)
			FROM dbo.tblXlat
			WHERE KeyIn = @Allergen
				AND xlatID = 'ModifierAllergenID'
			
			INSERT INTO @Process
			SELECT AllergenID
			FROM dbo.cfgAllergens
			WHERE [Description] = @Allergen
				AND AllergenID NOT IN (SELECT AllergenID FROM @Process)

			-- Null AllergenID
			IF NOT EXISTS (SELECT 1 FROM @Process)
			BEGIN
				-- Write the text to the Patient Notes.
				SELECT @Notes = Notes
				FROM	dbo.tblPatientOHD
				WHERE 	PatientID  = @PatientID

				IF (@Notes IS NULL)
					SET @Notes = ''

				IF (CHARINDEX(@Allergen, @Notes) = 0)
				BEGIN
					IF (@Notes = '')
						SET @Notes = @Allergen
					ELSE
						SET @Notes = @Notes + @ORMSeparator + @Allergen

					UPDATE dbo.tblPatientOHD
					SET Notes = @Notes
					WHERE PatientID = @PatientID
				END
			END
			ELSE
			BEGIN
				SELECT TOP 1 @AllergenID = AllergenID
				FROM @Process

				WHILE (1=1)
				BEGIN
					IF (@AllergenID IS NULL)
						BREAK

					IF NOT EXISTS (SELECT AllergenID FROM dbo.tblPatientAllergens (NOLOCK)
					WHERE PatientID = @PatientID
					AND AllergenID = @AllergenID)
					BEGIN
						INSERT INTO dbo.tblPatientAllergens(PatientID, AllergenID)
							VALUES (@PatientID, @AllergenID)

						SELECT @Msg = 'Allergen added: ' + UPPER([Description])
							FROM cfgAllergens WHERE AllergenID = @AllergenID
	
						EXEC dbo.PatientLOGAdd 1000, @LoginUserID, @PatientID, '', NULL, @Msg
					END

					DELETE @Process
					WHERE AllergenID = @AllergenID

					SET @AllergenID = NULL
					SELECT TOP 1 @AllergenID = AllergenID
					FROM @Process
				END
			END

			-- Remove the allergen description
			IF (CHARINDEX(@ORMSeparator,@Allergies) > 0)
				SET @Allergies = RIGHT(@Allergies, LEN(@Allergies) - CHARINDEX(@ORMSeparator, @Allergies))
			ELSE
				SET @Allergies = ''
		END
		ELSE
			SET @Allergies = ''

    	END

	RETURN
go

