CREATE FUNCTION [dbo].[StringCenter]
    (
    @String varchar(255),
    @width int = 32
    )
RETURNS varchar(255) 
AS
begin
declare @Return as varchar(255),
        @i as int,
        @sl as int

    set @sl = len( @String )

    if( @sl  > 253 )      -- nothing to do if the string is this long ...
        return @String

    set @i = (@Width - @sl) /2

    RETURN substring( space(@i) + @String , 1 , @Width )
end
go

