

CREATE PROCEDURE dbo.PatientAllergensGet
@PatientID int
AS

	SELECT 	P.FullName,
		A.Description,
		CASE WHEN PA.AllergenID IS NULL THEN 0
			ELSE 1
		END AS Valid
	FROM	dbo.cfgAllergens AS A (NOLOCK)
		LEFT JOIN dbo.tblPatientAllergens AS PA (NOLOCK) ON A.AllergenID = PA.AllergenID
			AND PA.PatientID = @PatientID
		LEFT JOIN dbo.tblPatientOHD AS P (NOLOCK) ON P.PatientID = @PatientID

	RETURN
go

