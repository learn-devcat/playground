

CREATE PROCEDURE [dbo].[CCS_PatientCancelTransfer_v4]
@PatientVisitID varchar(50),
@Source         varchar(50),
@ConnectionName varchar(50)=''
AS
	SET NOCOUNT ON
	DECLARE @PatientID	int,
		@Msg varchar(200),
		@RoomID int

	IF EXISTS(SELECT 1 FROM dbo.tblPatientVisit (NOLOCK) WHERE PatientVisitID = @PatientVisitID)
	BEGIN
		SELECT @PatientID = PatientID,
			@RoomID = RoomID
		FROM dbo.tblPatientVisit
		WHERE PatientVisitID = @PatientVisitID

		UPDATE dbo.tblPatientVisit
		SET RoomID = PreviousRoomID,
			Bed = PreviousBed
		WHERE PatientVisitID = @PatientVisitID

		SET @Msg = 'Transfer canceled for PatientVisitID: ' + @PatientVisitID

		EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, @PatientVisitID, @RoomID, 'Updated patient location.'
	END
	ELSE
	        SET @Msg = 'Unable to process Cancel Transfer for PatientVisitID: ' + @PatientVisitID + '. Patient does not exist.'
	

	SET @ConnectionName = 'Idt' + @ConnectionName
	EXEC dbo.WorkstationUpdateByID @ConnectionName

	EXEC dbo.Logit 1, @Msg, 'system'

	RETURN


go

