

CREATE PROCEDURE dbo.ad_AccountCategory_Get  
@User			char(10),
@Category		char(10)
AS 
	SELECT	Category,
			Description
	FROM	tblAccountCategory
	WHERE	Category = @Category
go

