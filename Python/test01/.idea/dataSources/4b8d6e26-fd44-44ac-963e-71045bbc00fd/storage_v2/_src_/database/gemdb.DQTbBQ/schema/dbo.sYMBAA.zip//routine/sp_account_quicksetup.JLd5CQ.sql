CREATE PROCEDURE [dbo].[sp_Account_QuickSetUp]
    @User			char(10),
    @AccountNo		char(19),
    @AccountClassID int,
    @AccountTTL		int,
	@BadgeNo		char(19),
	@BadgeClassID	int,
	@LocationID		int,
	@FirstName		char(15) = '',
	@MiddleName		char(15) = '',
	@LastName		char(20) = ''
AS 
    DECLARE @ReturnCode int,
        @ActiveDate datetime,
        @ExpireDate datetime,
        @TransDate datetime,
        @OutletClassID int,
        @BadgeLimit varchar(50),
        @AcctLimit varchar(50),
		@PrimaryBadge bit

	--If the Badge Number is blank, set it to the Account Number
	IF (COALESCE(@BadgeNo, '') = '')
		SET @BadgeNo = @AccountNo

	--If the BadgeClassID is not valid that use the quick badge class from the overhead table
	IF NOT EXISTS (SELECT 1 FROM dbo.tblBadgeClass WHERE BadgeClassID = @BadgeClassID)
	BEGIN
	    SET @BadgeClassID = dbo.GetOverheadItem('QBadgeClass')
		
		--Check to see if the overhead badge class is valid, if not, return the first badge class id in badge class table
	    IF NOT EXISTS (SELECT 1 FROM tblBadgeClass WHERE BadgeClassID = @BadgeClassID ) 
        SELECT TOP 1 @BadgeClassID = BadgeClassID
        FROM    dbo.tblBadgeClass
        ORDER BY BadgeClassID
	END

	--If the Location does not exist, the get the top location for the user
	IF NOT EXISTS (SELECT 1 FROM dbo.cfgLocations WHERE LocationID = @LocationID)
	    SELECT TOP 1 @LocationID = LocationID
		FROM    dbo.cfgUserLocations
		WHERE   UserID = @User
		ORDER BY LocationID

	--Get the default outlet class
	SELECT TOP 1 @OutletClassID = OutletClassID
	FROM	dbo.tblOutletClass
	ORDER BY OutletClassID

    SET @BadgeLimit = dbo.GetOverheadItem('QBadgeLimit')
    SET @AcctLimit = dbo.GetOverheadItem('QAcctLimit')
	SET @PrimaryBadge = 1

	--stop sp messages FROM being returned
    SET NOCOUNT ON
	
    BEGIN TRANSACTION
	
	--Insert AND Update a new account
    EXEC @ReturnCode = dbo.sp_Account_Insert @User, @AccountNo, @AccountClassID
    IF ( @ReturnCode <> 0 ) 
        GOTO AddFailed
		
		--Insert AND Update a new badge
    EXEC @ReturnCode = dbo.sp_Badge_QuickInsert @User, @BadgeNo, @AccountNo, @BadgeClassID, @LocationID, @PrimaryBadge
    IF ( @ReturnCode <> 0 ) 
        GOTO AddFailed

		--Insert account TTL     
    EXEC @ReturnCode = dbo.sp_AccountTTL_Insert @User, @AccountNo, @AccountTTL
    IF ( @ReturnCode <> 0 ) 
        GOTO AddFailed

		--Insert ALL Outlet Class TTLs     
    EXEC dbo.sp_Account_InsertNewOutletClassTTLs @User, @AccountNo


		/*UPDATE the Account limit*/
    IF ( @AcctLimit <> '' ) 
        UPDATE  tblAccountTTL
        SET     Limit = CAST(@AcctLimit AS money)
        WHERE   AccountNo = @AccountNo

		/*UPDATE the badge limit*/
    IF ( @BadgeLimit <> '' ) 
        UPDATE  tblBadgesOHD
        SET     Limit = CASE WHEN @BadgeLimit = '' THEN 999999
                             ELSE CAST(@BadgeLimit AS money)
                        END,
				FirstName = @FirstName,
				MiddleName = @MiddleName,
				LastName = @LastName
        WHERE   AccountNo = @AccountNo
                AND BadgeNo = @BadgeNo
				  
    UPDATE  dbo.tblAccountOHD
    SET     FirstName = @FirstName,
			MiddleName = @MiddleName,
			LastName = @LastName,
			LocationID = @LocationID,
			LastUpdateDate = GETDATE()
    WHERE   AccountNo = @AccountNo
			
	--Add succeeded, so commit AND RETURN
    COMMIT TRANSACTION
    RETURN
	
    AddFailed:
		
		--Add failed, so RETURN failure message		
    ROLLBACK TRANSACTION
    RETURN 1
go

