

CREATE FUNCTION dbo.DateFromFilter(@CurrentDate datetime, @DateChangeValue int, @TimeChangeValue varchar(8))
RETURNS datetime
AS
BEGIN
 	DECLARE	@ReturnValue	datetime,
 			@WhatWeek		varchar(2)
 			
 	IF (@DateChangeValue > 0)
 		BEGIN
 			IF (@DateChangeValue = 1) 
 				BEGIN
 					-- Beginning of the week
 					SET @WhatWeek = DATEPART(week,@CurrentDate) 
 					
 					SET @ReturnValue = @CurrentDate
 					
 					WHILE DATEPART(week,@ReturnValue) = @WhatWeek
 					BEGIN
						SET @ReturnValue = @ReturnValue - 1 					
 					END
 					
					SET @ReturnValue = @ReturnValue + 1
					SET @ReturnValue = dbo.dDateOnly(@ReturnValue)
				END
	 		ELSE
	 			BEGIN
	 	 			-- Beginning of the month
	 	 			SET @ReturnValue = CAST(DATEPART(month,@CurrentDate) AS varchar(2)) + '/1/' + CAST(DATEPART(year,@CurrentDate) AS char(4))
	 	 			SET @ReturnValue = dbo.dDateOnly(@ReturnValue)
	 	 		END
		END
 ELSE
 	SET @ReturnValue = @CurrentDate + @DateChangeValue
	 	
	-- SET the time portion of the RETURN value
	-- ELSE IF the @TimeChangeValue = '', then leave the time alone	 
	IF (@TimeChangeValue <> '')
		SET @ReturnValue = dbo.dDateOnly(@ReturnValue) + ' ' + @TimeChangeValue
	 
	RETURN @ReturnValue
END
go

