


CREATE PROCEDURE dbo.DailyProcessing

AS
	
	EXEC dbo.AutoDischarge

	EXEC dbo.PurgeData

	EXEC dbo.Logit 0, 'DailyProcessing complete.','system'
go

