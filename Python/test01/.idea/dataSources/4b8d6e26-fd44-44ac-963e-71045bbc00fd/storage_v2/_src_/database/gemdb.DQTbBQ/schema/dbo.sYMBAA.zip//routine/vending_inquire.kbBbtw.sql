CREATE PROCEDURE [dbo].[Vending_Inquire]
@CoreID as int,
@UserID as char(10),
@BadgeNo AS char(19),
@MachineTAG AS varchar(50)
/*
== 	retrieve an account record with the Associated other fields FROM the supporting tables.  the limit, DailyLimit, DailyQty fileds
==	are resolved to the proper limits for this transaction
==
*/
AS

DECLARE @loglevel int

DECLARE @Today datetime,
    @AccountNo	char(19),
    @BadgeClassID int,
    @AccountClassID int,
    @MealLimit	money,
    @MealCountAll	int,
    @MealCount	int,
    @MealPlanID	int,
    @DailyQty		int,
        @AccountDailyBalance	money,
        @DailyLimit		money,
        @AcctBalance		money,
        @Limit			money,
        @DailyQtyLimit		int,
        @BadgeDailyBalance	money,
        @BadgeDailyLimit	money,
        @BadgeDailyQty		int,
        @BadgeDailyQtyLimit	int,
        @BadgeBalance		money,
        @BadgeLimit		money,
        @TransLimit		money,
        @AvailableBalance	money,
        @MPBalance		money,
        @OutletNO	int,
        @TransID	int,
        @LocationID int,
        @BadgeCycleNow varchar(10),
        @VendValue Money,
        @DateOnlyToday varchar(20),
		@GlobalTransOverride money
        
    SET NOCOUNT ON

    SET @loglevel = 1		-- default to read/access level	
    SET @Today = getdate()
    set @DateOnlyToday = dbo.dDateOnly(@Today)

	IF EXISTS (SELECT 1 FROM dbo.tblAccountOHD WHERE AccountNo = @AccountNo AND TransOverride = 1)
		SELECT @GlobalTransOverride = TransOverrideAmt
		FROM dbo.tblAccountOHD WHERE AccountNo = @AccountNo AND TransOverride = 1

    SELECT  TOP 1  @AccountNo = AccountNo,
                @BadgeClassID = BadgeClassID 
    FROM	tblBadgesOHD
    WHERE	BadgeNo = @BadgeNo
            AND Inactive = 0
            AND Lost = 0
            AND Stolen = 0
            AND dbo.dDateOnly(ActiveDate) <= @DateOnlyToday
            AND dbo.dDateOnly(ExpireDate) >= @DateOnlyToday

    -- Not on file
    if( @@ROWCOUNT = 0 )
      begin
        select 0.01 as ReturnValue
        return
      end



    select @AccountClassID = AccountClassID
    from   tblAccountOHD
    where  AccountNo = @AccountNo AND
            dbo.dDateOnly( ExpireDate) >= @DateOnlyToday AND 
            dbo.dDateOnly( ActiveDate) <= @DateOnlyToday 
          
    -- This should never happen -- if we have a badge record, we should have an account record...
    if( @@ROWCOUNT = 0 )
      begin
        select 0.02 as ReturnValue
        return
      end


    Select @OutletNo = OutletNo,
            @TransID = TransID,
            @LocationID = LocationID,
            @VendValue = MaxItemPrice
    from	 tblVendingDTL
    where	MachineTAG = @MachineTAG 
            and Isnull( AccountClassID , @AccountClassID ) =  @AccountClassID
            and Isnull( BadgeClassID , @BadgeClassID ) = @BadgeClassID

    if( @@rowcount = 0 )                        -- 13-Jun-13 WJS if the machine tag is was undefined, would return max value.
      begin                                     -- oops ....
        select 0.04 as ReturnValue
        return
      end

    -- Not defined in the Vending detail configuration; outta here...
    if( @OutletNo = 0 ) or (@TransID = 0 )
      begin
            select 0.00 as ReturnValue
            return
      end
        
    SET @BadgeCycleNow = dbo.GetCycleByXRef(0,@Today,'bc' + cASt(@BadgeClassID AS varchar(10)))

    Select @BadgeBalance = bt.Total
    from tblBadgeTTL bt
    where  bt.AccountNo = @AccountNO AND bt.BadgeNo = @BadgeNo 
          AND dbo.GetCycleByXRef(0,bt.date,'bc' + cASt(@BadgeClassID AS varchar(10))) = @BadgeCycleNow

    -- get the Balance AND qty values
    SELECT  @DailyQty = t.DailyQty,
        @AccountDailyBalance = dbo.IsDailyMoney( t.DailyBalance ,t.LastChgDate , @Today),
        @DailyLimit = dbo.fnMin( t.DailyLimit, c.DailyLimit ),
        @AcctBalance = t.Balance,
        @Limit = dbo.fnMin( t.Limit , c.Limit ),
        @DailyQtyLimit = dbo.fnMin( t.DailyQtylimit,  c.DailyQtyLimit ),
        @badgeDailyBalance = dbo.IsDailyMoney( b.DailyBalance ,b.LastChgDate , @Today),
        @badgeDailyQty = dbo.IsDailyMoney( b.DailyQty ,b.LastChgDate , @Today),
        @badgeDailyLimit = dbo.fnMin( bc.DailyLimit ,  b.DailyLimit ),
        @badgeDailyQtyLimit = dbo.fnMin( bc.DailyQtyLimit  , b.DailyQtylimit),
        --@BadgeBalance = isnull(bt.Total,0),
        @badgeLimit = b.limit,
        @TransLimit = b.TransLimit
    FROM 	 tblAccountOHD  a 
        LEFT outer  JOIN tblAccountTTL t on  t.AccountNo = a.AccountNo
        RIGHT JOIN tblAccountClass c on c.AccountClassID = a.AccountClassID 
        RIGHT JOIN tblBadgesOHD b on b.AccountNo = @AccountNo AND b.BadgeNo = @BadgeNo
        RIGHT JOIN tblBadgeClass bc on bc.BadgeClassID =  b.BadgeClassID 
        RIGHT JOIN tblTransClass AS tc on tc.TransClassID = t.TransClassID
        -- LEFT JOIN tblBadgeTTL bt on a.AccountNo = bt.AccountNo AND bt.BadgeNo = @BadgeNo AND dbo.GetCycleByXRef(0,bt.date,'bc' + cASt(b.BadgeClassID AS varchar(10))) = @BadgeCycleNow
        LEFT JOIN tblTransDef AS td on t.TransClassID = td.TransClassID AND td.TransID = @TransID 
    WHERE 	a.AccountNo = @AccountNo AND 
        dbo.dDateOnly(t.ExpireDate) >= @DateOnlyToday		
        AND tc.DisablePOSPosting = 0  
        AND dbo.IsAllowed( @OutletNo,-1,tc.TransClassID) <> 0
        
    --ORDER BY a.AccountNo,t.TransClassID

	-- Update all Limits to the Global Override Amt. if it is set
	IF (@GlobalTransOverride IS NOT NULL)
	BEGIN
		SET @TransLimit = @GlobalTransOverride
		SET @Limit = @GlobalTransOverride
		SET @BadgeLimit = @GlobalTransOverride
		SET @DailyLimit = @GlobalTransOverride
		SET @BadgeDailyLimit = @GlobalTransOverride
	END
    
    -- get the Limit with the lowest value
--	SELECT @MPBalance = dbo.VM_ValidateMealPlan(@AccountNo,@TransID,@OutletNO, getdate(), 0)
    SELECT @MealPlanID = ISNULL(dbo.VM_ValidateMealPlan(@AccountNo,@TransID,@OutletNO, getdate(), 1), 0)
    SELECT @AvailableBalance = dbo.fnMin(dbo.fnMin(dbo.fnMin(dbo.fnMin( @TransLimit, (@Limit - @AcctBalance)), (@badgeLimit - @BadgeBalance)), (@DailyLimit - @AccountDailyBalance)), (@badgeDailyLimit - @badgeDailyBalance))
    
    IF (NOT (@MPBalance IS NULL))
        SELECT @AvailableBalance = dbo.fnMin(@AvailableBalance, @MPBalance)
    
    -- check the QTY limits. If we are >= the QTY Limit for any item, THEN SET the @AvailableBalance to 0
    IF (@BadgeDailyQty >= @BadgeDailyQtyLimit) OR (@DailyQty >= @DailyQtyLimit) 
        SET @AvailableBalance = 0

    IF (@AvailableBalance >= 999999)	-- In case we have all params set to unlimited
        SET @AvailableBalance = 0

--	IF (@AvailableBalance < 0)
--		SET @AvailableBalance = 0

    SELECT cast( dbo.fnMin( ISNULL(@AvailableBalance,0) , @VendValue) as varchar(12)) as ReturnValue

    --[ update log ]---------------------------------------
    DECLARE @cmsg  char(255)
    
    set @cMsg = ''
    IF( @@ROWCOUNT = 0 ) 
        BEGIN
            SET @cmsg = 'Vending_Inquire account/badge # ' + rtrim(ISNULL(@AccountNo,'')) + '/' + rtrim(ISNULL(@BadgeNo,'')) + ' <no match>'
            SET @loglevel = @loglevel - 1		-- drop logging level to catch failure.
        END
    ELSE
        SET @cmsg = 'Vending_Inquire account/badge # ' + rtrim(ISNULL(@AccountNo,'')) + '/' + rtrim(ISNULL(@BadgeNo,''))
    EXEC sp_logit @loglevel , @coreid , 'system' , @cmsg
    -------------------------------------------------------[ update log END ]------
go

