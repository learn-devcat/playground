CREATE PROCEDURE [dbo].[sp_Trans_PostAccountOutletClassTTL]
@AccountNo	char(19),
@Qty		int,
@TransClassID	int,
@TransTotal	money,
@OutletNo	int,
@IsPayment	bit,
@Correction	bit=0,
@ResetTtlQty bit = 0,
@PostDate datetime = null
AS
DECLARE	@DailyQty			int,
		@DailyBalance		money,
		@LastPayDate		datetime,
		@LastChgDate		datetime,
		@CurrentError		int,
		@OutletClassID		int,
		@DoResetQty		bit

	--Resolve OutletClass
	SELECT	@OutletClassID = OutletClassID
	FROM	tblOutletOHD
	WHERE	OutletNo = @OutletNo

	--Add any OutletClass TTLs that don't exist for this account
	EXEC dbo.sp_Account_InsertNewOutletClassTTLs 'system', @AccountNo


	-- get qtys AND bals
	SELECT 	@DailyQty			= DailyQty,
			@DailyBalance		= DailyBalance,
			@LastPayDate		= LastPayDate,
			@LastChgDate		= LastChgDate 
	FROM	tblAccountOutletClassTTL
	WHERE	AccountNo = @AccountNo   
			AND OutletClassID = @OutletClassID
			AND TransClassID = @TransClassID

	-- Check anything FROM the above SELECT ... IF absent then quit returning an error number
	IF @DailyQty IS NULL		-- AccountOutletClassTTL record does not exist ... This should NOT occur.
	BEGIN
		SET @CurrentError = 1001
		GOTO END_PROCEDURE
	END 	
	
	IF (@Correction = 1)
	BEGIN
		SET @TransTotal=-@TransTotal
		SET @Qty=-@Qty

		IF (@IsPayment=1)
		BEGIN
			SET @TransTotal=-@TransTotal			-- Reverse for a payment	
					
			-- SET @LastChgDate = getdate()		-- Don't touch dates on a correction.
			UPDATE 	tblAccountOutletClassTTL 
			SET 	Qty = Qty + @Qty,
					Balance	= Balance + @TransTotal
			WHERE 	AccountNo=@AccountNo 
					AND OutletClassID = @OutletClassID
					AND TransClassID = @TransClassID

			SET @CurrentError=@@ERROR
			IF (@CurrentError<>0)  GOTO END_PROCEDURE
		END			
		ELSE
			IF dbo.DateOnly(@LastChgDate) <> dbo.DateOnly(getdate())		-- IF not today, don't touch daily ttls.
				UPDATE 	tblAccountOutletClassTTL 
				SET 	Qty  = Qty + @Qty,
						Balance	= Balance + @TransTotal
				WHERE 	AccountNo=@AccountNo 
						AND OutletClassID = @OutletClassID
						AND TransClassID = @TransClassID
			ELSE
				UPDATE 	tblAccountOutletClassTTL 
				SET 	Qty = Qty + @Qty,
						DailyQty = DailyQty + @Qty,
						DailyBalance = DailyBalance + @TransTotal,
						Balance	= Balance + @TransTotal
				WHERE 	AccountNo=@AccountNo 
						AND OutletClassID = @OutletClassID
						AND TransClassID = @TransClassID
	END				
	ELSE 
	BEGIN
		IF @IsPayment=1					-- Payments do NOT affect DAILY buckets.
		BEGIN
			SET @LastPayDate=getdate()			
			SET @TransTotal=-@TransTotal			-- Reverse total for a payment transaction.
		END
		ELSE
		BEGIN
			IF dbo.DateOnly(@LastChgDate) <> dbo.DateOnly(getdate())
			BEGIN
				SET @LastChgDate=getdate()
				SET @DailyQty        = 0			-- IF this transaction is NOT today, then reset the daily's.
				SET @DailyBalance = 0.00
			END
		END
		
		
		--DECLARE @loc varchar(1000)                

	   SET @DoResetQty = @ResetTtlQty
	   --SET @loc = '1: ' + CAST(@ResetTtlQty AS varchar(6))
	   
	   -- IF reset qty is SET, let's rule out conditions WHERE it shouldn't reset like:
	   -- * PostDate is older than 20 seconds old - this means it has likely been through before (probably a rollback), don't reset in this case
	   -- * neagative val (depending on ispayment) means this is an adjustment... don't reset
	   -- * this is a correction... don't reset
	   IF (@DoResetQty = 1)
	   BEGIN
		   IF (@TransTotal > 0 AND @IsPayment = 1)
		   BEGIN
			SET @DoResetQty = 0 
	   		--SET @loc = @loc + '| 2: ' + CAST(@TransTotal AS varchar(25)) + ' isPmt: ' + CAST(@IsPayment AS varchar(6))
		   END
				
		   IF (@TransTotal < 0 AND @IsPayment = 0)
		   BEGIN
			SET @DoResetQty = 0 
	   		--SET @loc = @loc + '| 3: ' + CAST(@TransTotal AS varchar(25)) + ' isPmt: ' + CAST(@IsPayment AS varchar(6))
		   END
				
		   IF(DATEDIFF(s,@PostDate, GETDATE()) > 20)
		   BEGIN
			SET @DoResetQty = 0 
	   		--SET @loc = @loc + '| 4: ' + CAST(@PostDate AS varchar(25))
		   END														   	
	   END
   
                
	--EXEC dbo.sp_Logit 1 , 99 , 'rb' , @loc   		
				
		UPDATE 	tblAccountOutletClassTTL 
		SET     Qty = CASE WHEN @DoResetQty > 0 THEN 0 ELSE  Qty + @Qty END,
                DailyQty = CASE WHEN @DoResetQty > 0 THEN 0 ELSE  @DailyQty + @Qty END,
				DailyBalance = @DailyBalance + @TransTotal,
				Balance	= Balance + @TransTotal,
				LastPayDate = @LastPayDate,
				LastChgDate = @LastChgDate
		WHERE 	AccountNo=@AccountNo 
				AND OutletClassID = @OutletClassID
				AND TransClassID = @TransClassID
			
		SET @CurrentError=@@ERROR
		IF (@CurrentError<>0)  GOTO END_PROCEDURE
	END
	RETURN
END_PROCEDURE:
	
	RETURN @CurrentError
go

