CREATE   PROCEDURE [dbo].[sp_Batch_Post]
@User		char(10),
@BatchID	char(10),
@EndDate	datetime
AS
SET CURSOR_CLOSE_ON_COMMIT OFF
DECLARE	@Posted	char(1),
		@Duplicate	char(1),
		@Unresolved	char(1),
		@Exception	char(1),
		@InProcess	char(1),
		@BatchPostRetentionDays int,
		@GEM2goRetentionDays	int
	SET	@Posted = 'P'
	SET	@Duplicate = 'D'
	SET	@Unresolved = 'U'
	SET	@Exception = 'E'
	SET @InProcess = 'I'
	SET @BatchPostRetentionDays = COALESCE(dbo.GetOverheadItem('BatchPostRetentionDays'),0)
	SET @GEM2goRetentionDays = COALESCE(dbo.GetOverheadItem('GEM2goRetentionDays'),0)
--local variables
DECLARE	@Status	char(1),
		@ReturnCode	int,
		@FetchStatus	int,
		@BatchDetailID	uniqueidentifier,
		@CoreID	integer,
		@AccountNo	char(19),
		@BadgeNo	char(19),
		@TransDate	datetime,
		@OutletNo	int,
		@RefNum	char(6),
		@ChkNum	char(6),
		@TransTotal	money,
		@Sales1	money,
		@Comment	varchar(40),
		@CycleNo	int,
		@TransID	int,
		@Category 	char(10),
		@PaymentNo	int,
		@ServeEmpl	int,
		@PostEmpl	int,
		@Covers	smallint,
		@RevCntr	int,
		@Sales2	money,
		@Sales3	money,
		@Sales4	money,
		@Sales5	money,
		@Sales6	money,
		@Sales7	money,
		@Sales8	money,
		@Sales9	money,
		@Sales10	money,
		@Sales11	money,
		@Sales12	money,
		@Sales13	money,
		@Sales14	money,
		@Sales15	money,
		@Sales16	money,
		@Tax1		money,
		@Tax2		money,
		@Tax3		money,
		@Tax4		money,
		@Dsc		money,
		@Svc		money,
		@SvcA		money,
		@Auditable	bit,
		@PostDate	datetime,
		@LocationID	int,
		@ExceptionMsg varchar(50),
		@TransClassID int
SET NOCOUNT ON
	
	--delete all previously posted items prior to the BatchPostRetentioDays in overhead table 
	DELETE	tblBatch
	WHERE	Posted = @Posted
		AND ((BatchID <> 'GEM2GO'
				AND dbo.dDateOnly(LastUpdateDate) < (dbo.dDateOnly(GETDATE())-@BatchPostRetentionDays))
			OR	(BatchID = 'GEM2GO'
				AND dbo.dDateOnly(LastUpdateDate) < (dbo.dDateOnly(GETDATE())-@GEM2goRetentionDays)))
	
	--remove status code for all Non-post batch transactions
	UPDATE	tblBatch
	SET		Posted='',
			LastUpdateDate = GETDATE()
	WHERE	Posted IN (@Duplicate, @Unresolved, @Exception)
	
	
	SET @SvcA=0
	DECLARE TempBatch CURSOR FOR SELECT
				DetailID,
				CoreID,
				AccountNo,
				BadgeNo,
				TransDate,
				CycleNo,
				Category,
				OutletNo,
				TransID,
				RefNum,
				ChkNum,
				PaymentNo,
				ServeEmpl,
				PostEmpl,
				Covers,
				RevCntr,
				TransTotal,
				Sales1,
				Sales2,
				Sales3,
				Sales4,
				Sales5,
				Sales6,
				Sales7,
				Sales8,
				Sales9,
				Sales10,
				Sales11,
				Sales12,
				Sales13,
				Sales14,
				Sales15,
				Sales16,
				tax1,
				tax2,
				tax3,
				tax4,
				dsc,
				svc,
				Comment,
				Auditable,
				ISNULL(PostDate,getdate()) as PostDate,
				LocationID
				FROM	tblBatch 
				WHERE	BatchID=@BatchID 
					AND dbo.dDateOnly(TransDate) <= dbo.dDateOnly(@EndDate)
					AND Posted NOT IN (@Posted,@InProcess)
				ORDER BY TransDate,DetailID
	
	--open the cursor
	OPEN TempBatch
	FETCH NEXT FROM TempBatch INTO 
				@BatchDetailID,
				@CoreID,
				@AccountNo,
				@BadgeNo,
				@TransDate,
				@CycleNo,
				@Category,
				@OutletNo,
				@TransID,
				@RefNum,
				@ChkNum,
				@PaymentNo,
				@ServeEmpl,
				@PostEmpl,
				@Covers,
				@RevCntr,
				@TransTotal,
				@Sales1,
				@Sales2,
				@Sales3,
				@Sales4,
				@Sales5,
				@Sales6,
				@Sales7,
				@Sales8,
				@Sales9,
				@Sales10,
				@Sales11,
				@Sales12,
				@Sales13,
				@Sales14,
				@Sales15,
				@Sales16,
				@tax1,
				@tax2,
				@tax3,
				@tax4,
				@dsc,
				@svc,
				@Comment,
				@Auditable,
				@PostDate,
				@LocationID
	SET @FetchStatus=@@Fetch_Status
	WHILE @FETCHSTATUS = 0
 	BEGIN
 		

		SET @ExceptionMsg = ''			-- we need to ensure EVERY transaction starts with a clean "Exception Message" since only errors will populate this 

 		--resolve transclassid from transid for checking if account has ttl
 		--since this is coming from batch, there is the posibility the transid may not exist
		SELECT @TransClassID = ISNULL(TransClassID,0)
		FROM dbo.tblTransDef
		WHERE TransID = @TransID
 		
 		--check unresolvable conditions, do NOT try to run transpost IF unresolvable
 		--cast all vars as varchar, so as to not add useless whitespace in msg
 		IF(NOT EXISTS (SELECT AccountNo FROM dbo.tblAccountOHD WHERE AccountNo = @AccountNo))
 			BEGIN
 				SET @ExceptionMsg = 'Account [' + CAST(@AccountNo AS varchar(19))  + '] does not exist'
 				SET @ReturnCode = 547
 			END		
 		ELSE IF (NOT EXISTS (SELECT * FROM dbo.tblBadgesOHD WHERE AccountNo = @AccountNo AND BadgeNo = @BadgeNo))
 			BEGIN
 				SET @ExceptionMsg = 'Badge [' + CAST(@BadgeNo AS varchar(19))+ '] does not exist for account [' + CAST(@AccountNo AS varchar(19)) + ']'
 				SET @ReturnCode = 547
 			END	
 		ELSE IF (NOT EXISTS (SELECT * FROM dbo.tblOutletOHD WHERE OutletNo = @OutletNo))
 			BEGIN
 				SET @ExceptionMsg = 'Outlet [' + CAST(@OutletNo AS varchar(10)) + '] does not exist'
 				SET @ReturnCode = 547
 			END	
 		ELSE IF (NOT EXISTS (SELECT * FROM dbo.tblTransDef WHERE TransID = @TransID))
 			BEGIN
 				SET @ExceptionMsg = 'Trans Def [' + CAST(@TransID AS varchar(10)) + '] does not exist'
 				SET @ReturnCode = 547
 			END	
 		ELSE IF (NOT EXISTS (SELECT * FROM dbo.tblAccountTTL WHERE TransClassID = @TransClassID AND AccountNo = @AccountNo))
 			BEGIN
 				SET @ExceptionMsg = 'Account [' + CAST(@AccountNo AS varchar(19)) + '] does not have TTL [' + CAST(@TransClassID AS varchar(10)) + ']'
 				SET @ReturnCode = 547
 			END	 			
 		ELSE
			BEGIN
 				--post the valid transaction
 				SET @Status = @Posted
 				EXEC @ReturnCode = dbo.sp_Trans_Post @CoreID,@User,@AccountNo,@BadgeNo,@TransDate,@OutletNo,@RefNum,@ChkNum,
 								@TransTotal,@Sales1,@Comment,@CycleNo,@TransID,@Category,@PaymentNo,@ServeEmpl,
 								@PostEmpl,@Covers,@RevCntr,@Sales2,@Sales3,@Sales4,@Sales5,@Sales6,@Sales7,
 								@Sales8,@Sales9,@Sales10,@Sales11,@Sales12,@Sales13,@Sales14,@Sales15,@Sales16,
 								@Tax1,@Tax2,@Tax3,@Tax4,@Dsc,@Svc,@SvcA,0, @Auditable,@PostDate, 0, @LocationID, 1		
			END

		IF (@ReturnCode <> 0)
		  BEGIN
			IF @ReturnCode = 547
			  BEGIN
				SET @Status = @Unresolved
		  	  END
			ELSE
			  BEGIN
				IF @ReturnCode = 2627
				  BEGIN
					SET @Status = @Duplicate
				  	SET @ExceptionMsg = 'Duplicate Transaction'
				  END
			  ELSE
				BEGIN
					SET @Status = @Exception
				END				
			  END
			
			-- 6-Oct-10 rbb
			-- if we have no message from above, let's get it from the log table (meaning it came from transpost)
			--  14-Dec-10 wjs
			-- We are here BECAUSE we had a !0 return code AND we apparently do NOT have an Exception Message, (not desirable) so let's TRY to recover it from the log.
			--   If we can't get one from the log, well oh well -- we'll just have to show 'Unknown Error'...
			IF(@ExceptionMsg = '')
			  BEGIN
				SELECT TOP 1 @ExceptionMsg = [Description] + ' (' + + CAST(@ReturnCode AS varchar(20)) + ')'
				FROM dbo.tblLog
				WHERE LogDate > GETDATE() - .00002 AND LEFT(Description, 4) = 'ERR:'
				ORDER BY LogDate DESC
		      END

			SET @ExceptionMsg =  ISNULL( @ExceptionMsg , 'Unknown error #' ) + ' (' + + CAST(@ReturnCode AS varchar(20)) + ')'	-- aparently we didn't get anything from the log -- oh well, this is the best we can do...

		END
		
		-- every record gets updated; some with "P"osted, some with various errors since this runs for EVERY transaction we are trying to post.
		UPDATE	tblBatch
		SET		Posted=@Status,
				ExceptionMessage = @ExceptionMsg,
				LastUpdateDate = GETDATE()
		WHERE	CURRENT OF TempBatch


	FETCH NEXT FROM TempBatch INTO 
				@BatchDetailID,
				@CoreID,
				@AccountNo,
				@BadgeNo,
				@TransDate,
				@CycleNo,
				@Category,
				@OutletNo,
				@TransID,
				@RefNum,
				@ChkNum,
				@PaymentNo,
				@ServeEmpl,
				@PostEmpl,
				@Covers,
				@RevCntr,
				@TransTotal,
				@Sales1,
				@Sales2,
				@Sales3,
				@Sales4,
				@Sales5,
				@Sales6,
				@Sales7,
				@Sales8,
				@Sales9,
				@Sales10,
				@Sales11,
				@Sales12,
				@Sales13,
				@Sales14,
				@Sales15,
				@Sales16,
				@tax1,
				@tax2,
				@tax3,
				@tax4,
				@dsc,
				@svc,
				@Comment,
				@Auditable,
				@PostDate,
				@LocationID
		SET @FetchStatus=@@Fetch_Status
	END
	
	CLOSE TempBatch
	DEALLOCATE TempBatch
	
	DECLARE 	@cMsg  	char(255)
	
	SET @cMsg = 'sp_Post_Batch - Batch ID: ' + @User + ' - ' + @BatchID
	EXEC dbo.sp_Logit 2 , 1 , @User , @cMsg
go

