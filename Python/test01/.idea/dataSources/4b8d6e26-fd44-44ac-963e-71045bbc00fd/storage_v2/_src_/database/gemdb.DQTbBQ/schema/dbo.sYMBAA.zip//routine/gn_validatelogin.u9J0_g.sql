

CREATE PROCEDURE dbo.gn_ValidateLogin
@UserID	varchar(50),
@Remove	int = 0
AS
	SELECT	FullName
	FROM		GEMNet..tblAccountLogin
	WHERE	UserName = @UserID
	IF ( @Remove = 1 )
		DELETE	GEMNet..tblAccountLogin
		WHERE	UserName = @UserID
go

