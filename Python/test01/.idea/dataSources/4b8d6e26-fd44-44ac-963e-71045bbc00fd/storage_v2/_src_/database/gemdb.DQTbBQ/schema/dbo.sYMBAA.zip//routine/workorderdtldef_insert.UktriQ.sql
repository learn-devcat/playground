
CREATE       PROCEDURE dbo.WorkorderDTLDef_Insert
@User			        char(10),
@LocationID	            int,
@WorkOrderDTLClassID    int,
@EmployeeClassID        int,
@ShortDescription       varchar(50),
@Description            varchar(250),
@SkillLevel             int,
@Price                  money, 
@Cost                   money, 
@EstimatedHours         money,
@LeadTime               money,
@TransID                int,
@LaborCenterID		int	
AS
	INSERT INTO	tblWorkorderDTLDef
		        (LocationID, WorkOrderDTLClassID, EmployeeClassID, ShortDescription, Description, SkillLevel, Price, Cost, EstimatedHours, LeadTime, TransID, LaborCenterID )
	Values      (@LocationID, @WorkOrderDTLClassID, @EmployeeClassID, @ShortDescription, @Description, @SkillLevel, @Price, @Cost, Round(@EstimatedHours,2), Round(@LeadTime,2), @TransID, @LaborCenterID )
    IF @@Error <> 0 
      BEGIN
        RETURN
      END
   RETURN
go

