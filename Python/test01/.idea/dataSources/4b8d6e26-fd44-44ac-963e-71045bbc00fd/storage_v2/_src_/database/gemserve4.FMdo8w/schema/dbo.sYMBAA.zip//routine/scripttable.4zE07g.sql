CREATE PROCEDURE [dbo].[ScriptTable](
@TableName varchar(128),
@WhereClause varchar(400) = Null,
@OrderByClause varchar(400) = Null
)
AS
SET NOCOUNT ON
DECLARE @sql varchar(Max)
DECLARE @sqlColumns varchar(Max)
DECLARE @SqlColumnValues varchar(Max)
DECLARE @HasIdentity bit

--Determine Columns
SELECT @sqlColumns = Coalesce(@SqlColumns + ',','') + '['+Column_Name+']' from Information_Schema.Columns where Table_name = @TableName AND Data_Type<>'Timestamp' 

--Determine Values (representation/casting)
SELECT 
@SqlColumnValues = Coalesce(@SqlColumnValues + '+ '','' + ','') +
CASE
WHEN Data_Type in ('varchar','nvarchar', 'char', 'nchar', 'datetime' ) THEN 'ISNULL(QuoteName([' + Column_Name + '], ''''''''), ''NULL'')'
ELSE 'ISNULL(Cast([' + Column_Name + '] as varchar(MAX)), ''NULL'')'
END
FROM
Information_Schema.Columns where Table_name = @TableName AND Data_Type<>'Timestamp' 


--Build SQL String
SELECT @sql = 'Select ''Insert Into [' + @TableName + '] (' + @SqlColumns + ') Values ('' + ' + @SqlColumnValues +' + '')'' FROM [' + @TableName +']'+ IsNull(' WHERE ' + @WhereClause, '')+ IsNull(' ORDER BY ' + @OrderByClause, '')

-- Determine if Identity field exists
SELECT @HasIdentity=MAX(COLUMNPROPERTY(OBJECT_ID(@TableName),Column_Name,'IsIdentity')) from Information_Schema.Columns where Table_name = @TableName AND Data_Type<>'Timestamp' 


--Output
PRINT 'SET NOCOUNT ON'
IF @HasIdentity=1 PRINT 'SET IDENTITY_INSERT '+@TableName+' ON'
PRINT 'PRINT '' ADDING Data to '+@TableName+' '' '
exec(@sql)
IF @HasIdentity=1 PRINT 'SET IDENTITY_INSERT '+@TableName+' OFF'
go

