CREATE FUNCTION [dbo].[GetRoomNumberByDateTime](@PatientID int, @DateTimeToCheck datetime, @CurrentDate datetime)
RETURNS varchar(20)

AS
	BEGIN
		DECLARE @Return AS varchar(20),
				@AppendBed as varchar(10)

		SELECT @AppendBed = COALESCE(dbo.GetOverheadValueNull('AppendBed'),'')
		
		-- Get only one record... the latest
		SELECT 	TOP 1 @Return = CASE
				WHEN @AppendBed = '' THEN R.RoomNumber + '-' + COALESCE(PV.Bed,'')
				ELSE R.RoomNumber 
			END
		FROM	dbo.tblPatientVisit AS PV (NOLOCK)
			JOIN dbo.tblRoomOHD AS R (NOLOCK) ON PV.RoomID = R.RoomID
		WHERE	PV.RoomID IS NOT NULL
			AND @DateTimeToCheck BETWEEN EntryDate AND ISNULL(DischargeDate, @CurrentDate)
			AND PatientID = @PatientID
		ORDER BY ISNULL(DischargeDate, @CurrentDate) DESC

		RETURN @Return
	END
go

