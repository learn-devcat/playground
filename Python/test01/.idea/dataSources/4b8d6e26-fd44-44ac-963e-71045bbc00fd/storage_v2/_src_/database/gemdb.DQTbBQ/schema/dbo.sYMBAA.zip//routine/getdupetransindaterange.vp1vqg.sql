CREATE FUNCTION [dbo].[GetDupeTransInDateRange](
		@User		char(10),
		@BeginDate	datetime,
		@EndDate	datetime,
		@UseTempTable	bit)
RETURNS	@MyTable	TABLE
	(DetailID	uniqueidentifier,
	 AccountNo	varchar(19),
	 BadgeNo	varchar(19),
	 TransDate	datetime,
	 PostDate	datetime,
	 OutletNo	int,
	 TransID	int,
	 RefNum		varchar(6),
	 ChkNum		varchar(6),
	 TransTotal	money)
AS
BEGIN	
	IF @UseTempTable = 0
	BEGIN
	
		INSERT INTO @MyTable
		
		SELECT 	DetailID,
			AccountNo, 
			BadgeNo, 
			TransDate, 
			PostDate, 
			OutletNo, 
			TransID, 
			Refnum, 
			Chknum, 
			TransTotal
		FROM 	tblDetail
		WHERE 	TransDate BETWEEN @BeginDate AND @EndDate AND
			dbo.DateOnly(TransDate)+ 
			AccountNo + 
			BadgeNo + 
			Chknum+ 
			--Refnum + 
			CAST(OutletNo as char(8))+
			CAST(TransID as char(8))+
			cast(TransTotal as varchar(50)) 
		IN 
		(SELECT dbo.DateOnly(TransDate)+ 
				AccountNo + 
				BadgeNo + 
				Chknum+ 
				--Refnum + 
				CAST(OutletNo as char(8))+
				CAST(TransID as char(8))+
				cast(TransTotal as varchar(50)) 
		 FROM 	tblDetail
		 WHERE  TransDate BETWEEN @BeginDate AND @EndDate   
		 GROUP BY 	dbo.DateOnly(TransDate)+ 
					AccountNo + 
					BadgeNo + 
					Chknum+ 
					--Refnum + 
					CAST(OutletNo as char(8))+
					CAST(TransID as char(8))+
					cast(TransTotal as varchar(50))
		 Having  count(*) > 1
		)
	 	ORDER BY AccountNo, BadgeNo, dbo.DateOnly(TransDate),TransTotal
	END
	ELSE
	BEGIN
		INSERT INTO @MyTable
		
		SELECT 	DetailID,
			AccountNo, 
			BadgeNo, 
			TransDate, 
			PostDate, 
			OutletNo, 
			TransID, 
			Refnum, 
			Chknum, 
			TransTotal
		FROM 	dbo.temptableDupes
		WHERE 	TransDate BETWEEN @BeginDate AND @EndDate AND
			dbo.DateOnly(TransDate)+ 
			AccountNo + 
			BadgeNo + 
			Chknum+ 
			--Refnum + 
			CAST(OutletNo as char(8))+
			CAST(TransID as char(8))+
			cast(TransTotal as varchar(50)) 
		IN 
		(SELECT dbo.DateOnly(TransDate)+ 
				AccountNo + 
				BadgeNo + 
				Chknum+ 
				--Refnum + 
				CAST(OutletNo as char(8))+
				CAST(TransID as char(8))+
				cast(TransTotal as varchar(50)) 
		 FROM 	dbo.temptableDupes
		 WHERE  TransDate BETWEEN @BeginDate AND @EndDate
		 GROUP BY 	dbo.DateOnly(TransDate)+ 
					AccountNo + 
					BadgeNo + 
					Chknum+ 
					--Refnum + 
					CAST(OutletNo as char(8))+
					CAST(TransID as char(8))+
					cast(TransTotal as varchar(50))
		 Having  count(*) > 1
		)
	 	ORDER BY AccountNo, BadgeNo, dbo.DateOnly(TransDate),TransTotal
	END

	RETURN
END
go

