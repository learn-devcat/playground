CREATE PROCEDURE [dbo].[MapCreateNewFromLocation]
@LocationClassID	int,
@MapDescription		varchar(50)='',
@DeleteExisting		bit=0
AS

	DECLARE	@MapNumber	int,
		@Company	varchar(50),
		@MapTitle	varchar(50),
		@MapSubTitle	varchar(50),
		@MenuAction	varchar(100),
		@ParentID	int

		IF EXISTS (SELECT 1 FROM dbo.tblLocationClass WHERE LocationClassID = @LocationClassID AND COALESCE(ExcludeFromDashboard,0) = 1)
			RETURN
		
		IF NOT EXISTS (SELECT MapNumber FROM dbo.tblMapOHD WHERE [Description] = 'Main')
			INSERT INTO [dbo].[tblMapOHD] ([MapNumber],[Title],[SubTitle],[Description],[Notes],[Inactive],[Status],[SubType],[SecurityMask],[DefaultGBS],[Row],[Col],[GridCol],[GridRow],[CssSrc],[href],[TitleStyle],[SubTitleStyle])
			VALUES(101,'','Main','Main',NULL,0,0,-1,-1,8,100,100,100,150,'headerStyles.css','header.html','border:0;border-style:solid;border-color:red;z-index:5;Width:32;Position:Absolute;Top:150;Left:116','border:0;border-style:solid;border-color:red;z-index:5;Width:32;Position:Absolute;Top:150;Left:116')

		IF(@MapDescription = '')
			SELECT @MapDescription = [Description]
			FROM dbo.tblLocationClass
			WHERE @LocationClassID = LocationClassID
		
		-- If no rooms exist for this location class, then there is nothing to do, so exit
		IF NOT EXISTS (SELECT TOP 1 LocationClassID FROM dbo.tblRoomOHD WHERE LocationClassID = @LocationClassID)
			RETURN

		IF (@DeleteExisting = 1)
		BEGIN
			SELECT @MapNumber = MapNumber
			FROM dbo.tblMapOHD
			WHERE [Description] = @MapDescription
			
			DELETE dbo.tblMapData
			WHERE Label = @MapDescription

			DELETE dbo.tblMapData
			WHERE MapNumber = @MapNumber

			DELETE dbo.tblMapOHD 
			WHERE MapNumber = @MapNumber

			DELETE dbo.cfgWebMenus 
			WHERE [Description] = @MapDescription
		END
	
		SELECT @Company = dbo.GetOverheadValue('Company')	
	
		SELECT @MapNumber = MAX(MapNumber) + 1
		FROM dbo.tblMapOHD

		IF (@MapNumber IS NULL)
			SET @MapNumber = 1
	
		SET @MapTitle = '<h2>' + @Company + '</h2>'
		SET @MapSubTitle = '<h3>' + @MapDescription + '</h3>'
		
		-- Insert a row into the MapOHD table for the new item we are adding
		IF NOT EXISTS (SELECT 1 FROM dbo.tblMapOHD WHERE [Description] = @MapDescription)
			EXEC dbo.MapOHDInsert @MapNumber, @MapDescription, @MapTitle, @MapSubTitle, 'headerStyles.css', 'header.html' 
		ELSE
			SELECT @MapNumber = MapNumber FROM dbo.tblMapOHD WHERE [Description] = @MapDescription
	
		-- Get the parent ID for the Order Status top-level menu
		SELECT @ParentID = MenuID FROM dbo.cfgWebMenus
		WHERE [Description] = 'Order Status'	
	
		SET @MenuAction = '../Orders/OrderStatus.aspx?MapID=' + CAST(@MapNumber AS varchar(50))
	
		-- Add a menu item for this location
		IF NOT EXISTS (SELECT 1 FROM dbo.cfgWebMenus WHERE [Description] = @MapDescription)
			EXEC dbo.MenuUpdate 'system', 0, @ParentID, @MapDescription, @MenuAction, '', ''
	
		-- Add a map item for each room
		INSERT INTO dbo.tblMapData (MapItemType, MAPNumber, Label, Row, Col, Width, Height, Orientation, Prefix, Layer, ImgSrc, HRef, Inactive)
			SELECT 101, @MapNumber, RoomNumber, 0, 0, 4, 4, 1, 'S',1, '', '', 0
			FROM dbo.tblRoomOHD
			WHERE LocationClassID = @LocationClassID
				AND RoomNumber NOT IN (SELECT Label FROM dbo.tblMapData WHERE MapNumber = @MapNumber)
	
		-- Add a map item to the Main map page for the new location map
		SET @ParentID = null
		SELECT @ParentID = MapNumber FROM dbo.tblMapOHD
		WHERE [Description] = 'Main'	
	
		IF NOT (@MapNumber IS NULL)
		BEGIN
			IF NOT EXISTS (SELECT 1 FROM dbo.tblMapData WHERE Label = @MapDescription AND MapItemType = 110)
			BEGIN
				INSERT INTO dbo.tblMapData (MapItemType, MAPNumber, Label, Row, Col, Width, Height, Orientation, Prefix, Layer, ImgSrc, HRef, Inactive)
					VALUES(110, @ParentID, @MapDescription, 0, 0, 0, 0, 1, 'S', 1, CAST(@MapNumber as varchar(10)) + ',2','OrderStatus.aspx?MapID=' + CAST(@MapNumber as varchar(10)), 0)
			END
		END
go

