
/*
Retrieves the first meal period id
*/

CREATE FUNCTION dbo.GetFirstMealPeriodID(@Today datetime)
RETURNS int
AS

BEGIN
	DECLARE @Return int

        DECLARE @MealPeriods TABLE (MealPeriodID int, BeginTime varchar(5))

        INSERT INTO @MealPeriods
        SELECT MealPeriodID, dbo.MealPeriodStartTime(@Today,MealPeriodID)
        FROM   dbo.tblMealPeriods

        SELECT TOP 1 @Return = MealPeriodID
        FROM   @MealPeriods
        ORDER BY BeginTime

        RETURN ISNULL(@Return,-1)
END
go

