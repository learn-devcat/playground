CREATE PROCEDURE [dbo].[LocationUpdate]
@LoginUserID		varchar(250),
@LocationClassID	int,
@Description		varchar(50),
@DeliveryPriority	int = 0,
@Active				bit = 1,
@KitchenId			int = NULL,
@ExcludeFromDashboard	bit = 0
AS

	SET NOCOUNT ON

	IF (@LocationClassID > 0)
	BEGIN
		UPDATE dbo.tblLocationClass 
		SET [Description] = @Description,
			Active = @Active,
			DeliveryPriority = @DeliveryPriority,
			KitchenId = COALESCE(@KitchenId, KitchenId),
			ExcludeFromDashboard = COALESCE(@ExcludeFromDashboard, ExcludeFromDashboard)
		WHERE LocationClassID = @LocationClassID

		-- Remove all dashboard items for this Location, since it is set to ExcludeFromDashboard. This action will also delete the tblMapData items	
		IF (COALESCE(@ExcludeFromDashboard, 0) = 1)
		BEGIN
			DECLARE @MapNumber int

			SELECT @MapNumber = MapNumber
			FROM dbo.tblMapOHD
			WHERE [Description] = @Description

			DELETE dbo.tblMapData
			WHERE MapNumber = @MapNumber

			DELETE dbo.tblMapData 
			WHERE Label = @Description

			DELETE dbo.tblMapOHD 
			WHERE MapNumber = @MapNumber

			DELETE dbo.cfgWebMenus 
			WHERE [Description] = @Description
		END
		ELSE
			EXEC dbo.MapCreateNewFromLocation @LocationClassID, '', 1
	END
	ELSE
	BEGIN
		INSERT INTO dbo.tblLocationClass ([Description], DeliveryPriority, Active, KitchenId, ExcludeFromDashboard)
			VALUES (@Description, @DeliveryPriority, @Active, @KitchenId, @ExcludeFromDashboard)

		SET @LocationClassID = SCOPE_IDENTITY()
	END	

	SELECT @LocationClassID AS LocationClassID

	RETURN
go

