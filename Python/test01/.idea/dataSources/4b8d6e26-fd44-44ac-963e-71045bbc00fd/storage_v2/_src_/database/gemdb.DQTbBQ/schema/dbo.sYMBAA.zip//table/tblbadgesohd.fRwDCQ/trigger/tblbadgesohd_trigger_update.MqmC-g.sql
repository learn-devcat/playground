CREATE TRIGGER [dbo].[tblBadgesOHD_Trigger_Update]
	   ON  [dbo].[tblBadgesOHD]
	   AFTER UPDATE
	AS 
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		DECLARE @CurDateTime as DateTime;
		set @CurDateTime = dbo.GetDateLocalTime();

		-- Insert statements for trigger here
		IF NOT UPDATE(LastUpdateDate)
		BEGIN 
			Update t
			Set t.LastUpdateDate = @CurDateTime
			FROM dbo.tblBadgesOHD as t
			INNER JOIN 
			(SELECT * from INSERTED
			EXCEPT
			SELECT * from DELETED)
			as a
			ON t.BadgeNo = a.BadgeNo AND t.AccountNo = a.AccountNo
			;
		END
	END
go

