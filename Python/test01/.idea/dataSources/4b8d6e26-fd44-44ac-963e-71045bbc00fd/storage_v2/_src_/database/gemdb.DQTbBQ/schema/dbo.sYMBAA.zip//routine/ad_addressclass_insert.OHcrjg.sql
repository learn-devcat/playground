

CREATE PROCEDURE dbo.ad_AddressClass_Insert
@User		char(10),
@AddressID	int,
@Description	char(10)
AS
	INSERT INTO	tblAddressClass
			(AddressID, Description)
	VALUES	(@AddressID, @Description)
go

