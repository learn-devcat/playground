

CREATE FUNCTION dbo.MealCountForDiet(@BeginDate as datetime, @EndDate as datetime, @DietID as int)
RETURNS int
BEGIN
	DECLARE @Return int

	SELECT @Return = COUNT([Date])
	FROM dbo.tblOrderLOG 
	WHERE [Date] BETWEEN @BeginDate AND @EndDate
		AND COALESCE(DietID, -1) = @DietID
		AND dbo.GetActionID('RECEIVED') = ActionID

	SELECT @Return = @Return + COUNT([Date])
	FROM dbo.tblArchive_OrderLOG 
	WHERE [Date] BETWEEN @BeginDate AND @EndDate
		AND COALESCE(DietID, -1) = @DietID
		AND dbo.GetActionID('RECEIVED') = ActionID

	RETURN COALESCE(@Return, 0)
END
go

