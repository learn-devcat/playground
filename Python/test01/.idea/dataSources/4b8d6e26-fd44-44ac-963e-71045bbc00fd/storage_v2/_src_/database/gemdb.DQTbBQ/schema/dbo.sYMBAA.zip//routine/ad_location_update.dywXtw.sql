


CREATE PROCEDURE dbo.ad_Location_Update
@User		char(10),
@LocationID	int,
@Description	varchar(50)
AS 
	UPDATE cfgLocations
	SET Description = @Description
	WHERE LocationID = @LocationID
go

