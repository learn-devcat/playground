
CREATE PROCEDURE dbo.MenuList

AS
	SET NOCOUNT ON

        DECLARE @MenuPointSize	varchar(10)

	SELECT @MenuPointSize = dbo.GetOverheadValue('MenuPointSize')
	IF (@MenuPointSize = '')
		SET @MenuPointSize = '10'

	SELECT 	MenuID,
		ISNULL(ParentID,'') AS ParentID,
		ISNULL([Description],'') AS Description,
		ISNULL(MenuAction,'') AS MenuAction,
		ISNULL(MenuImage,'') AS MenuImage,
		ISNULL(MenuHoverImage,'') AS MenuHoverImage,
		[Sequence],
		ISNULL(IsSeparator,0) AS IsSeparator,
		ISNULL(IsDisabled,0) AS IsDisabled,
		ISNULL(IsChecked,0) AS IsChecked,
		MenuGroup,
		ActionID,
                CAST(@MenuPointSize as int) AS MenuPointSize
	FROM	cfgWebMenus
	ORDER BY ParentID, [Sequence]
go

