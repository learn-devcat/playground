







CREATE       PROCEDURE dbo.EmployeeClass_Get
@User			char(10),
@EmployeeClassID	int
AS
	SELECT		EmployeeClassID,
			EmployeeClassName,
			Description,
			LogonHours,
			CanCreateWorkOrder,
			CanDeleteWorkorder,
			CanCloseWorkOrder,
			CanPrintWorkOrder,
			CanAddWorkOrderDTL,
			CanCompleteWorkOrderDTL,
			CanDeleteWorkOrderDTL,
			ViewAllWorkorders,
			ViewWorkordersInClass,
			AdjustWorkorderCharge,
			ConfigString
	FROM		tblEmployeeClass
	WHERE		EmployeeClassID = @EmployeeClassID
go

