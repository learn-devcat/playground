
CREATE procedure dbo.ol_GetScheduleItem
@CoreID smallint,
@user char(10),
@ScheduleID smallint 
AS 
DECLARE @LogLevel int
DECLARE @Date datetime
	SET @LogLevel = 3		-- Default to Read/Access Level	
	SET @Date = getdate()
	
	SELECT 	s.ScheduleID, s.Description, s.Category, s.Status, s.DailyPassLimit,
		dbo.zSelect( d.PassLimit, s.PassLimit) as PassLimit , d.Equivalency, d.Status as PeriodStatus, d.Period
		
	
	FROM 	tblTransScheduleOHD s
		right outer JOIN tblTransScheduleDtl d on s.ScheduleID = d.ScheduleID AND 
						    dbo.TimeOnly(d.BeginTime) <= dbo.timeonly(@Date) AND
						    dbo.TimeOnly(d.EndTime)  >= dbo.timeonly(@Date)
	WHERE 	s.ScheduleID = @ScheduleID
	
	DECLARE @cMsg char(255)
	
	SET @cMsg = 'ol_GetScheduleItem Accessed'
	EXEC dbo.sp_Logit @LogLevel , @CoreID , @User , @cMsg, 925
go

