CREATE PROCEDURE dbo.PatientDietNotesGet
@PatientVisitID		varchar(50)

AS

	SET NOCOUNT ON

	DECLARE @Notes	varchar(2000),
			@Today	datetime

	SET @Today = getdate()

	SELECT @Notes = dbo.GetActiveDietNotesEX (@PatientVisitID, @Today, 0)

	SELECT @Notes AS DietNotes

	RETURN
go

