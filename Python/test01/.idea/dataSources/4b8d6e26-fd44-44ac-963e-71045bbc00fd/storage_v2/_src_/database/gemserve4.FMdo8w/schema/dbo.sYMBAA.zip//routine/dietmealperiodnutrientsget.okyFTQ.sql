

CREATE PROCEDURE dbo.DietMealPeriodNutrientsGet
@DietID	int

AS
	SET NOCOUNT ON

	DECLARE	@NutrientID	int,
		@Qty		int

	--IF NOT EXISTS (SELECT DietID FROM dbo.tblDietOHD (NOLOCK) WHERE DietID = @DietID)
	--BEGIN
	--	RAISERROR ('Diet does not exist',16,1)
	--	RETURN
	--END
		
	SELECT N.NutrientID, N.[Description],
		M.MealPeriodID, M.[Description] AS MealPeriodName,
		CASE WHEN MN.Qty IS NULL THEN N.DefaultQty
			ELSE MN.Qty
		END AS Qty,
		CASE WHEN MN.Qty IS NULL THEN 1
			ELSE 0
		END AS IsDefault
	FROM dbo.cfgNutrients AS N (NOLOCK)
		LEFT JOIN dbo.tblMealPeriods AS M (NOLOCK) ON 1=1
		LEFT JOIN dbo.tblDietMealPeriodNutrients AS MN (NOLOCK) ON M.MealPeriodID = MN.MealPeriodID
			AND N.NutrientID = MN.NutrientID 
			AND MN.DietID = @DietID
	ORDER BY dbo.MealPeriodEndTime(getdate(),M.MealPeriodID)

	RETURN
go

