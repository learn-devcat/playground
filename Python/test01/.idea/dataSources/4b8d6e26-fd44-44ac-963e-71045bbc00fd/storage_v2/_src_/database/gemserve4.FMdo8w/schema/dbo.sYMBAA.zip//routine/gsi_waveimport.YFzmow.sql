
CREATE PROCEDURE [dbo].[GSI_WaveImport]
@LoginUserID			varchar(250),
@WaveID			int,
@MealPeriodName		varchar(50),
@BeginTime		varchar(5),
@EndTime		varchar(5),
@Description		varchar(25),
@MaxOrder		int = 99,
@WarningMinutes		int = 30,
@CriticalMinutes	int = 45

AS
	DECLARE @MealPeriodID	int

	SELECT 	@MealPeriodID = MealPeriodID
	FROM	dbo.tblMealPeriods
	WHERE	[Description] = @MealPeriodName

	INSERT INTO dbo.tblWave (WaveID, MealPeriodID, BeginTime, EndTime, SubType, Description, MaxOrder, WarningMinutes, CriticalMinutes)
		VALUES (@WaveID, @MealPeriodID, @BeginTime, @EndTime, -1, @Description, @MaxOrder, @WarningMinutes, @CriticalMinutes)
go

