


CREATE PROCEDURE dbo.gem_Trans_PostBadgeTTL
@User		char(10),
@AccountNo	char(19),
@BadgeNo	char(19),
@TransDate	datetime,
@TransTotal	money,
@Qty		int,
@IsPayment	bit,
@Correction	bit
AS
	DECLARE	@BadgeClassID	int,
			@XlatID	varchar(10)
	IF ( @IsPayment = 1 )
		SET @TransTotal = -@TransTotal
	IF (@Correction=1)
	BEGIN
		SET @TransTotal=-@TransTotal
		SET @Qty=-@Qty
	END
	-- Badge class
	SELECT 	@BadgeClassID = BadgeClassID
	FROM	dbo.tblBadgesOHD
	WHERE	AccountNo = @AccountNo
		AND BadgeNo = @BadgeNo
	-- Check for a Badge Class
	IF NOT EXISTS (SELECT TOP 1 * FROM tblCycleXlat WHERE xlatid = 'BC' + CAST(@BadgeClassID AS varchar(10))) 
	BEGIN
		SET @XlatID = 'BC'		
	END
	ELSE
	BEGIN
		SET @XlatID = 'BC' + CAST(@BadgeClassID AS varchar(10))
	END
	-- Edit the BadgeTTL
	UPDATE	dbo.tblBadgeTTL
	SET 		Total = Total + @TransTotal,
			Qty = Qty + @Qty
	WHERE 	dbo.GetCycleByXREF(0,[Date],@XlatID)  = dbo.GetCycleByXREF(0,@TransDate,@XlatID)
		AND BadgeNo = @BadgeNo
		AND AccountNo = @AccountNo
	IF ( @@ROWCOUNT = 0 )
		INSERT INTO tblBadgeTTL (AccountNo, BadgeNo, [Date], Qty, Total)
			VALUES (@AccountNo, @BadgeNo, @TransDate, @Qty, @TransTotal)
go

