CREATE       PROCEDURE dbo.WorkorderClass_Insert
@User               		char(10),
@WorkorderClassID   		int,
@Description        		Varchar(50),
@PostChargeWhenComplete		bit,
@PostChargeAsCompleted		bit,
@PostChargeWhenWOClosed		bit,
@PostAltCharge			bit,
@CloseWorkOrderWhenComplete	bit,
@RequiresInspection		bit,
@PostItemChargesWhenWOClosed	bit
AS 
	INSERT INTO tblWorkorderClass 
	            (WorkorderClassID, Description, PostChargeWhenComplete, PostChargeAsCompleted, 
		     PostChargeWhenWOClosed, PostAltCharge, CloseWorkOrderWhenComplete, 
		     RequiresInspection, PostItemChargesWhenWOClosed)
         VALUES (@WorkorderClassID, @Description, @PostChargeWhenComplete, @PostChargeAsCompleted, 
		 @PostChargeWhenWOClosed, @PostAltCharge, @CloseWorkOrderWhenComplete, 
		 @RequiresInspection, @PostItemChargesWhenWOClosed)
SELECT @@Error
go

