
CREATE PROCEDURE [dbo].[GSI_DietModifierMealPeriodNutrientImport]
@LoginUserID		varchar(250),
@DietModifierCode	varchar(100),
@NutrientName	varchar(50),
@MealPeriodName	varchar(50),
@Qty		decimal(10,3)
AS
	SET NOCOUNT ON

	DECLARE @NutrientID int,
		@MealPeriodID int,
		@KeyIn varchar(100),
		@Return	int
		
	SET @Return = -1

	SELECT 	@NutrientID = NutrientID
	FROM	dbo.cfgNutrients
	WHERE	[Description] = @NutrientName
	
	--Return -1 if nutrient doesn't exist
	IF (@@RowCount = 0)
	BEGIN
		SET @Return = -1
		GOTO Finished
	END

	SELECT 	@MealPeriodID = MealPeriodID
	FROM	dbo.tblMealPeriods
	WHERE	[Description] = @MealPeriodName

	--Return -2 if meal period doesn't exist
	IF (@@RowCount = 0)
	BEGIN
		SET @Return = -2
		GOTO Finished
	END
	
	SET @KeyIn = @DietModifierCode + '_' + CAST(@MealPeriodID AS varchar(10))

	IF NOT EXISTS (SELECT 1 FROM dbo.tblXLAT WHERE xlatID = 'NutrientByMealPeriod' AND KeyIn = @KeyIn AND KeyOut = @NutrientID)
	BEGIN
		INSERT INTO dbo.tblXLAT (xlatID, KeyIn, KeyOut, Description)
			VALUES ('NutrientByMealPeriod', @KeyIn, @NutrientID, @Qty)

		SELECT @Return = SCOPE_IDENTITY()
	END
	ELSE
	BEGIN
		-- Return -3 if XLAT entry already exists
		SET @Return = -3
	END

Finished:
	--Return -1 if nutrient does exist, -2 if meal period doesn't exist, -3 Xlat entry already exists, otherwise return id
	SELECT @RETURN As ErrorMessage
	RETURN
go

