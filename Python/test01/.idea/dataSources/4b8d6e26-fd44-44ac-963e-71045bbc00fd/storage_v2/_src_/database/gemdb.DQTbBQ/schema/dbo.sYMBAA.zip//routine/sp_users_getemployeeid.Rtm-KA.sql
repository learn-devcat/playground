



CREATE   PROCEDURE dbo.sp_Users_GetEmployeeID
@UserID	varchar(10)
AS
DECLARE @EmpID	int
	SELECT	@EmpID = E.EmployeeID
	FROM	cfgUsers U
			JOIN
		tblEmployeeOHD E on U.EmployeeNumber = E.EmployeeNumber
	WHERE 	U.UserID = @UserID
	SELECT ISNULL(@EmpID,-1)
go

