

CREATE PROCEDURE dbo.gn_UserInfo
@UserID	varchar(50),
@Remove	int = 0
AS
	SELECT	CoreID,
			DefaultOutlet,
			UserName
	FROM		GEMNet..tblAccountLogin
	WHERE	UserName = @UserID
	IF ( @Remove = 1 )
		DELETE	GEMNet..tblAccountLogin
		WHERE	UserName = @UserID
go

