CREATE   PROCEDURE dbo.EmployeeOHD_List
@User			char(10),
@WorkorderClassID	int = 0
AS
	IF @WorkorderClassID = 0 
		BEGIN
	    /*
		    Procedure: EmployeeOHD_List
		       Author: Richard Beverly
			     Date: 05-May-05
		    Revisions: Added filtering by workorderClassID 7-6-2005
	    */
			SELECT		EmployeeID,
					EmployeeClassID,
					RTRIM(FirstName) + ' ' + RTRIM(LastName) as FullName,
					FirstName,
					LastName,
					SkillLevel,
					LocationID
			FROM		tblEmployeeOHD	
			ORDER BY	LastName, FirstName
		END
	ELSE
		BEGIN
			SELECT		EmployeeID,
					EmployeeClassID,
					RTRIM(FirstName) + ' ' + RTRIM(LastName) as FullName,
					FirstName,
					LastName,
					SkillLevel,
					LocationID
			FROM		tblEmployeeOHD	
			WHERE		WorkorderClassID = @WorkorderClassID	
			ORDER BY	LastName, FirstName
		END
go

