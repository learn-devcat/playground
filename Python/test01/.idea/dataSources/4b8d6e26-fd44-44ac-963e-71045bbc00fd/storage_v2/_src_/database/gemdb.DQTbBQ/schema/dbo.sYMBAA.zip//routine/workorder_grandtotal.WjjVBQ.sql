CREATE      PROCEDURE dbo.Workorder_GrandTotal
@User   	char(10),
@WorkorderID	int
AS
DECLARE @Total	money
    SELECT  ISNULL(SUM(Price),0)
    FROM    tblWorkOrderDTL
    WHERE   WorkorderID = @WorkorderID
    RETURN
go

