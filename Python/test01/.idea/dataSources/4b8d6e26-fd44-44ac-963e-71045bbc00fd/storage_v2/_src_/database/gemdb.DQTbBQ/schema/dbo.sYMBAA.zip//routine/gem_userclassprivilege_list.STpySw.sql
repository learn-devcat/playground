

CREATE PROCEDURE dbo.gem_UserClassPrivilege_List
@User		char(10),
@WhatClasses	varchar(500)
AS
SET NOCOUNT ON
DECLARE @P Table (PrivilegeClassID	int,
		PDescription		varchar(50),
		Allowed			int,
		ActionID		int,
		ClassSeek		varchar(25),
		Application		int)
DECLARE @PClassID	int,
	@PDescription	varchar(50)
WHILE @WhatClasses <> ''
BEGIN
	IF ( CHARINDEX(',', @WhatClasses) <> 0 )
	BEGIN
		SET @PClassID = LEFT(@WhatClasses, CHARINDEX(',', @WhatClasses) - 1)
		SET @WhatClasses = RIGHT(@WhatClasses, LEN(@WhatClasses) - CHARINDEX(',', @WhatClasses))
		INSERT INTO @P (PrivilegeClassID) VALUES (@PClassID)
	END
	ELSE
	BEGIN
		INSERT INTO @P (PrivilegeClassID) VALUES (@WhatClasses)
		SET @WhatClasses = ''
	END
END
DECLARE Temp cursor FOR
	SELECT PrivilegeClassID, Description FROM tblPrivilegeClass
	WHERE PrivilegeClassID IN (SELECT PrivilegeClassID FROM @P)
OPEN Temp 
FETCH NEXT FROM Temp INTO @PClassID, @PDescription
WHILE (@@FETCH_STATUS = 0)
BEGIN
	INSERT INTO @P (PrivilegeClassID, PDescription, ActionID, ClassSeek)
		SELECT @PClassID, @PDescription, ActionID, CAST(@PClassID as varchar(10)) + CAST(ActionID AS varchar(15))
		FROM tblPrivilegeActions
	UPDATE @P SET ALLOWED = CASE 
			WHEN P.ActionID IS NULL THEN 0
			ELSE 1
		END,
		Application = P.Application
	FROM	@P AS A
		JOIN tblPrivilegeLinks AS P ON A.PrivilegeClassID = P.PrivilegeClassID AND A.ActionID = P.ActionID
--	WHERE ActionID IN (SELECT ActionID FROM tblPrivilegeLinks WHERE PrivilegeClassID = @PClassID)
	WHERE	A.PrivilegeClassID = @PClassID
	
	FETCH NEXT FROM Temp INTO @PClassID, @PDescription
END
CLOSE Temp
DEALLOCATE Temp
SELECT PrivilegeClassID, PDescription, ActionID, ISNULL(Allowed,0) AS Allowed, ClassSeek, ISNULL(Application,0) AS Application FROM @P 
	WHERE NOT (ClassSeek IS NULL) ORDER BY ActionID, PrivilegeClassID
go

