

CREATE PROCEDURE dbo.DietPOSList

AS
	SET NOCOUNT ON

	DECLARE @Diets TABLE (DietID int, [Description] varchar(50))

	INSERT INTO @Diets (DietID)
	SELECT DISTINCT POSDietID
	FROM    dbo.tblDietOHD (NOLOCK)
	WHERE	NPO = 0

	UPDATE @Diets
	SET [Description] = D.[Description]
	FROM @Diets AS T
		JOIN dbo.tblDietOHD AS D (NOLOCK) ON T.DietID = D.POSDietID
	WHERE D.NPO = 0

	SELECT	DietID,
            	[Description],
            	'' AS AltDescription,
            	DietID AS POSDietID,
            	'' AS POSDescription,
            	'' AS Notes,
		1 AS Active,
		0 AS NPO 	
	FROM @Diets
	ORDER BY [Description]

	RETURN
go

