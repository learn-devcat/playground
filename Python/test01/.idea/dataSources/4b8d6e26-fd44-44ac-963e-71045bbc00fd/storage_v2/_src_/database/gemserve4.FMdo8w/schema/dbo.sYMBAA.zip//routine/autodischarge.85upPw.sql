CREATE PROCEDURE dbo.AutoDischarge

AS
	SET NOCOUNT ON

	DECLARE @PatientVisitID varchar(50),
		@RoomID	int,
	      	@Msg varchar(100),
		@Today	datetime,
		@AutoDischargeRoomOverride int

	SET @Today = getdate()

	-- If @AutoDischargeRoomOverride = 1, then only auto discharge patients with a room id that is null
	SELECT @AutoDischargeRoomOverride = COALESCE(dbo.GetOverheadValueNull('AutoDischargeRoomOverride'),0)
	
	DECLARE Patients cursor FOR
	SELECT P.PatientVisitID, P.RoomID
	FROM dbo.tblPatientVisit AS P (NOLOCK)
		JOIN dbo.tblPatientClass AS PC (NOLOCK) ON P.PatientClassID = PC.PatientClassID
		JOIN dbo.tblPatientOHD AS PT (NOLOCK) ON P.PatientID = PT.PatientID
	WHERE PC.AutoDischargeInterval > 0
		AND DATEADD(hh,(PC.AutoDischargeInterval * 24),P.EntryDate) < getdate()
		AND P.DischargeDate IS NULL
		
	OPEN Patients

	FETCH NEXT FROM Patients INTO @PatientVisitID, @RoomID

	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @Msg = 'AutoDischarge run for PatientVisitID: ' + @PatientVisitID
		EXEC dbo.Logit 0,@Msg,'system'

		IF (@AutoDischargeRoomOverride = 1)
		BEGIN	
			IF (@RoomID IS NULL)
				EXEC dbo.PatientDischarge 'AutoDischarge', @PatientVisitID, @Today
		END
		ELSE
			EXEC dbo.PatientDischarge 'AutoDischarge', @PatientVisitID, @Today

		FETCH NEXT FROM Patients INTO @PatientVisitID, @RoomID
	END

	CLOSE Patients
	DEALLOCATE Patients
go

