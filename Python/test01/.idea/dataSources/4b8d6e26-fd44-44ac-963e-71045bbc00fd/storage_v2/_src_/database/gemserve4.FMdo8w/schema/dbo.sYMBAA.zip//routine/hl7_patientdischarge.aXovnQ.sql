

CREATE PROCEDURE dbo.HL7_PatientDischarge
@MedicalRecordID	varchar(30),
@PatientVisitID     varchar(50),
@DischargeDate  	varchar(20),
@Source             varchar(50)

AS
    BEGIN TRANSACTION
        DECLARE @Msg                varchar(250),
                @MyDate     datetime,
		@PatientID	int,
		@RoomID	int

        IF ( @DischargeDate = '0' OR @DischargeDate = '' )
            SET @MyDate = getdate()
        ELSE
            SET @MyDate = dbo.HL7ConvertDateTime(@DischargeDate, getdate())            
        
        -- If this patient does not exist in our system, then log an error
        IF NOT EXISTS (SELECT PatientVisitID FROM dbo.tblPatientVisit WHERE PatientVisitID = @PatientVisitID) 
        BEGIN
            SET @Msg = 'Unable to process discharge for PatientVisitID' + @PatientVisitID + '. PatientVisitID does not exist.'
            GOTO TransError
        END
    
        -- Cancel all orders linked to this patient visit that are in the future
	    UPDATE  dbo.tblOrderOHD
	        SET Cancelled = 1
	    WHERE   PatientVisitID = @PatientVisitID
	        AND OrderDate > getdate()
	        
	    -- Archive Patient
        UPDATE dbo.tblPatientVisit
        SET DischargeDate = @MyDate,
            ArchiveDate = @MyDate
        WHERE PatientVisitID = @PatientVisitID
        
	    SET @Msg = 'Discharge processed for PatientVisitID:' + @PatientVisitID
	    EXEC dbo.Logit 1, @Msg, 'system'

	SELECT @PatientID = PatientID,
		@RoomID = RoomID
	FROM dbo.tblPatientVisit
	WHERE PatientVisitID = @PatientVisitID

	-- Delete all diet overrides for this patient
	DELETE dbo.tblPatientDailyNutrientOverride
	WHERE PatientID = @PatientID
	AND PatientID NOT IN (SELECT PatientID FROM dbo.tblPatientVisit WHERE PatientID = @PatientID AND DischargeDate IS NULL)

	DELETE dbo.tblPatientMealPeriodNutrientOverride
	WHERE PatientID = @PatientID
	AND PatientID NOT IN (SELECT PatientID FROM dbo.tblPatientVisit WHERE PatientID = @PatientID AND DischargeDate IS NULL)

	-- End Delete

	SET @Msg = 'Discharged patient'

	EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, @PatientVisitID, @RoomID, @Msg
	    
	    EXEC dbo.ProcessLogInsert @Source
    COMMIT TRANSACTION	    
    RETURN
    
TransError:
	ROLLBACK TRANSACTION

	IF ( @Msg IS NULL )    
        SET @Msg = 'Unable to process Discharge for PatientVisitID:' + @PatientVisitID
        
    EXEC dbo.Logit 1, @Msg, 'system'
go

