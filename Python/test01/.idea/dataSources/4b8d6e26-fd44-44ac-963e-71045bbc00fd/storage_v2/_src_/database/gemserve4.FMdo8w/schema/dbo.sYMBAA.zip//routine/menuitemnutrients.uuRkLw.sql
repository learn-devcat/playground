

CREATE FUNCTION dbo.MenuItemNutrients(@Mi int, @MIQty int, @MIStatus smallint,@FieldSeparator char(1))
RETURNS varchar(255)
BEGIN
	DECLARE @Return		varchar(255),
		    @Qty 		decimal(10,3),
		    @MenuitemID	int

	SET @Return = ''

	IF (@MIQty < -1)
		SET @MIQty = 0

	
	DECLARE Nutrients cursor FOR
		SELECT M.Qty
		FROM  cfgNutrients AS N (NOLOCK)
		LEFT JOIN tblMenuItemNutrients AS M (NOLOCK) ON N.NutrientID = M.NutrientID AND M.MenuItemID = @MI
		ORDER BY N.NutrientID

	OPEN Nutrients

	FETCH NEXT FROM Nutrients INTO @Qty

	WHILE @@FETCH_STATUS = 0
	BEGIN						
		SET @Return = @Return + @FieldSeparator + CAST(ISNULL(CAST((@Qty*@MIQty*@MIStatus*1000) as int),0) as varchar(12))
		
		FETCH NEXT FROM Nutrients INTO @Qty
	END

	CLOSE Nutrients
	DEALLOCATE Nutrients

	IF (LEN(@Return) > 0)
	BEGIN
		SET @Return = RIGHT(@Return,LEN(@Return)-1)
	END
	ELSE
		SET @Return = ''


	RETURN @Return	
END
go

