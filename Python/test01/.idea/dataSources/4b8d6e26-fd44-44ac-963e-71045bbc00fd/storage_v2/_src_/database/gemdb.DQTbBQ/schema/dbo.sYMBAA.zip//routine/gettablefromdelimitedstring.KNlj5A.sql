
	CREATE FUNCTION dbo.GetTableFromDelimitedString (@String varchar(2000), @Delimiter char(1))
	RETURNS @tblStringFields TABLE (Field varchar(500) NULL, RowNumber int NULL) 
	AS
	BEGIN
		/*
			This function returns a table with a row for each field found in a delimited string
			The table also has a "Row Number" column that could be used in a processing loop
		*/

		DECLARE @pos int
		DECLARE @field varchar(500)
		DECLARE @RowNum int

		SET @RowNum = 1
	
		-- Add delimiter to END IF it's not there so the final item will be found
		IF RIGHT(RTRIM(@string),1) <> @Delimiter AND @String <> ''
		 SET @string = @string  + @Delimiter

		SET @pos =  CHARINDEX(@Delimiter , @string)
		WHILE @pos <> 0 
		BEGIN
			SET @field = LEFT(@string, @pos - 1)

			-- add found field to table
			INSERT @tblStringFields VALUES(CAST(@field AS varchar(500)), @RowNum)

			SET @string = SUBSTRING(@String, @pos + 1, LEN(@String))
			SET @pos =  CHARINDEX(@Delimiter , @string)
			SET @RowNum = @RowNum + 1
		END
	
		RETURN
	END

  go

