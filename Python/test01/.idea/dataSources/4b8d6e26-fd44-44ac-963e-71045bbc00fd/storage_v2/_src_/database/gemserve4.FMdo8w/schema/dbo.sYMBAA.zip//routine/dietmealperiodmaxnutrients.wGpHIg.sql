
CREATE FUNCTION [dbo].[DietMealPeriodMaxNutrients](@PatientDietID int, @MealPeriodID int, @FieldSeparator char(1))
RETURNS varchar(255)
BEGIN
	DECLARE 	@Return 	varchar(255),
			@DietWaveID	int,
			@NutrientID	int,
			@DefaultQty	decimal(10,3),
			@Qty 		decimal(10,3),
			@DietID		int

	SET @Return = ''
	SELECT @DietID = DietID
	FROM dbo.tblPatientDiet
	WHERE [ID] = @PatientDietID

	SET @Return = ''

	IF (@DietID IS NULL)
		RETURN @Return

	DECLARE Nutrients cursor FOR
		SELECT  NutrientID, DefaultQty
		FROM 	cfgNutrients (NOLOCK)
		ORDER BY NutrientID

	OPEN Nutrients
	FETCH NEXT FROM Nutrients INTO @NutrientID, @DefaultQty

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @Qty = null

		-- Get the patient nutrient meal period override if it exists
		SELECT @Qty = Qty FROM tblPatientMealPeriodNutrientOverride
		WHERE PatientDietID = @PatientDietID 
			AND NutrientID = @NutrientID
			AND MealPeriodID = @MealPeriodID

		-- If no patrient nutrient meal period override, get the diet wave value if it exists
		-- If more than one override exists for this meal period, then the maximum override value is retrieved
		IF (@Qty IS NULL)
			SELECT @Qty = DM.Qty
			FROM dbo.tblDietOHD AS DO (NOLOCK) 
				JOIN dbo.tblDietMealPeriodNutrients AS DM (NOLOCK) ON DM.DietID = DO.DietID
			WHERE DO.DietID = @DietID 
				AND DM.MealPeriodID = @MealPeriodID
				AND DM.NutrientID = @NutrientID

		SET @Return = @Return +@FieldSeparator + CAST(ISNULL(CAST(@Qty * 1000 AS int), @DefaultQty * 1000) as varchar(10))
		
		FETCH NEXT FROM Nutrients INTO @NutrientID, @DefaultQty
	END

	CLOSE Nutrients
	DEALLOCATE Nutrients

	IF (LEN(@Return) > 0)
		SET @Return = RIGHT(@Return,LEN(@Return)-1)

	RETURN @Return	
END
go

