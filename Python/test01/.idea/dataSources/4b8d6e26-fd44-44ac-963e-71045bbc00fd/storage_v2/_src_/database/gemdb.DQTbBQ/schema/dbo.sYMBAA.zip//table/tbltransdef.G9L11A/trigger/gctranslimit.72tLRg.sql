

CREATE TRIGGER GCTransLimit ON dbo.tblTransDef 
FOR INSERT
AS
	DECLARE	@TransID 	int
	SELECT @TransID = TransID
	FROM	inserted
	IF (@TransID >2999 AND @TransID < 4000)
	BEGIN
		UPDATE 	tblTransDef
		SET		TransLimit = .01
		WHERE	TransID = @TransID
	END
go

