CREATE FUNCTION [dbo].[PatientNutrientCountByMPId]
(@PatientID INT, @BeginDate DATETIME, @EndDate DATETIME, @NutrientId INT, @MealPeriodId INT)
RETURNS DECIMAL(5,2)
AS
BEGIN
	DECLARE @Return AS decimal(5,2);

	SELECT @Return = SUM(MN.Qty * (OI.Consumption / CAST(100 as decimal(5,2))))
	FROM dbo.tblOrderItems AS OI (NOLOCK) 
	JOIN dbo.tblOrderOHD AS O (NOLOCK) ON OI.OrderID = O.OrderID 
		AND O.PatientID = @PatientID	
		AND O.OrderType = 1
		AND dbo.dDateOnly(O.OrderDate) BETWEEN @BeginDate AND @EndDate
		AND COALESCE(O.Cancelled,0) = 0
	JOIN dbo.tblWave AS W (NOLOCK) ON O.WaveId = W.WaveId
		AND W.MealPeriodId = @MealPeriodId
	JOIN dbo.tblMenuItemOHD AS M (NOLOCK) ON OI.POSMenuItemID = M.POSMenuItemID
	JOIN dbo.tblMenuItemNutrients AS MN (NOLOCK) ON MN.MenuItemID = M.MenuItemID AND MN.NutrientID = @NutrientId;

	RETURN COALESCE(@Return, 0)

END
go

