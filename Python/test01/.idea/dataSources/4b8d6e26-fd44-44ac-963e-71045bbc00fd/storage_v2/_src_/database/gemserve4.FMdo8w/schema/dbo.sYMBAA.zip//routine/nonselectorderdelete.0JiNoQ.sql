CREATE PROCEDURE [dbo].[NonSelectOrderDelete]
@LoginUserID		varchar(250),
@NonSelectOrderID	int

AS

	SET NOCOUNT ON

	DELETE dbo.tblNonSelectOHD
	WHERE NonSelectOrderID = @NonSelectOrderID

	RETURN
go

