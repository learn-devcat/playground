CREATE FUNCTION dbo.PatientMealPeriodNutrientCountEX(@PatientID int, @Today datetime, @MealPeriodID int, @FieldSeparator char(1))
RETURNS varchar(255)
BEGIN
	DECLARE @Return 	varchar(255),
		@NutrientID	int,
		@Qty		decimal(10,3)

	SET @Return = ''
	SET @Today = dbo.dDateOnly(@Today)

	DECLARE @Orders TABLE (OrderID int)

	INSERT INTO @Orders
	SELECT  OrderID 
	FROM dbo.tblMealPeriods AS MP (NOLOCK)
	JOIN dbo.tblWave AS W (NOLOCK) ON W.MealPeriodID = MP.MealPeriodID
		AND MP.MealPeriodID = @MealPeriodID
	JOIN dbo.tblOrderOHD AS O ON O.WaveID = W.WaveID
	WHERE dbo.dDateOnly(O.OrderDate) = @Today
					AND O.PatientID = @PatientID
					AND COALESCE(O.Cancelled,0) = 0
					AND OrderType = 1

	-- Cursor to retrieve all nutrients and dailymax for the diet
	DECLARE Nutrients cursor FOR
		SELECT N.NutrientID, SUM(MN.Qty * (I.Consumption / CAST(100 as decimal(5,2)))) AS Qty
		FROM dbo.cfgNutrients AS N (NOLOCK)
			LEFT JOIN (@Orders AS O
				JOIN dbo.tblOrderItems AS I (NOLOCK) ON O.OrderID = I.OrderID AND I.IsDiet = 0
				JOIN dbo.tblMenuItemOHD AS M (NOLOCK) ON I.POSMenuItemID = M.POSMenuItemID
				JOIN dbo.tblMenuItemNutrients AS MN (NOLOCK) ON M.MenuItemID = MN.MenuItemID)
				ON MN.NutrientID = N.NutrientID
		GROUP BY N.NutrientID
		ORDER BY N.NutrientID


	OPEN Nutrients
	FETCH NEXT FROM Nutrients INTO @NutrientID, @Qty

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @Return = @Return +@FieldSeparator + CAST(ISNULL(CAST(@Qty * 1000 AS int), 0) AS varchar(10))
		
		FETCH NEXT FROM Nutrients INTO @NutrientID, @Qty
	END

	CLOSE Nutrients
	DEALLOCATE Nutrients

	IF (LEN(@Return) > 0)
		SET @Return = RIGHT(@Return,LEN(@Return)-1)

	RETURN @Return	
END
go

