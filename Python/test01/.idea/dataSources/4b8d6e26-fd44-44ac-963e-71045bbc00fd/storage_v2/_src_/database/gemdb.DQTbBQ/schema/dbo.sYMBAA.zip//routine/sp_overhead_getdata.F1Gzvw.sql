

CREATE PROCEDURE dbo.sp_Overhead_GetData
AS
	SELECT	oKey, sValue, dType
	FROM		cfgOverhead
	ORDER BY	Sequence
go

