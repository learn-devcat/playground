CREATE PROCEDURE [dbo].[Micros_MenuItemDelete]
@UserID		varchar(250),
@ObjectNumber	int
AS
	SET NOCOUNT ON
	
	DECLARE @Msg varchar(200)

	DELETE	MicrosMenuItems
	WHERE	obj_num = @ObjectNumber

	SET @Msg = 'Deleted Micros menu item - object number[' + CAST(@ObjectNumber AS varchar(10)) + ']'
	EXEC dbo.Logit 9000,@Msg,@UserID
	
	RETURN
go

