

CREATE PROCEDURE dbo.LocationDelete
@LoginUserID		varchar(250),
@LocationClassID	int
AS

	SET NOCOUNT ON
	
	DELETE dbo.tblLocationClass 
	WHERE LocationClassID = @LocationClassID

	RETURN
go

