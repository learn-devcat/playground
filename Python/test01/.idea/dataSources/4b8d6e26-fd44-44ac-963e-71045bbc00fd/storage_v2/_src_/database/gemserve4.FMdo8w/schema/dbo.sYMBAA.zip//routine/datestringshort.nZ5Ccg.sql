CREATE FUNCTION dbo.DateStringShort (@WholeDate as datetime)
RETURNS char(6)
AS 
BEGIN 
	RETURN 	RIGHT('0' + CAST(DATEPART(MONTH,@WholeDate) AS varchar(2)),2) +
		RIGHT('0' + CAST(DATEPART(DAY,@WholeDate) AS varchar(2)),2) + 
		RIGHT(CAST(DATEPART(YEAR,@WholeDate) AS varchar(4)),2)	 
END
go

