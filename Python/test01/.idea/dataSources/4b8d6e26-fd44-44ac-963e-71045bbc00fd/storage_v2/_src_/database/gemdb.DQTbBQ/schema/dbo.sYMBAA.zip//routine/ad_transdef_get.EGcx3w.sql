

CREATE PROCEDURE dbo.ad_TransDef_Get
@User		char(10),
@TransID	int
AS 
	SELECT	TD.TransID, 
			TD.TransClassID, 
			TD.SubType, 	
			TD.SourceXfer, 
			TD.Description, 
			TD.glAccount, 
			RTRIM(TD.Category) AS Category, 
			TD.Status, 
			TD.Payment, 
			TD.EnforceSchedule, 
			TD.Preset, 
			TD.TransLimit, 
			TD.SlotNo,
			TD.IsMealPlan,
			TD.AllSame,
			TD.item1, 
			TD.item2, 
			TD.item3, 
			TD.item4, 
			TD.item5, 
			TD.item6, 
			TD.item7, 
			TD.item8, 
			TD.item9, 
			TD.item10,
			TD.item11, 
			TD.item12, 
			TD.item13, 
			TD.item14, 
			TD.item15, 
			TD.item16, 
			TD.item17, 
			TD.item18, 
			TD.item19,
			TD.item20, 
			TD.item21, 
			TD.item22, 
			TD.item23,
			TC.DeclBalMode,
			TD.ResetTtlQty
	FROM		tblTransDef AS TD
			INNER JOIN
			tblTransClass AS TC 
	ON		TD.TransClassID = TC.TransClassID
	WHERE	TD.TransID = @TransID
go

