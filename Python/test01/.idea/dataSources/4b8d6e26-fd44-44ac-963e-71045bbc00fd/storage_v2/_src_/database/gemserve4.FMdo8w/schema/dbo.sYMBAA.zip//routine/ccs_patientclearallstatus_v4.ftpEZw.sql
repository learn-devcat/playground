




CREATE PROCEDURE [dbo].[CCS_PatientClearAllStatus_v4]
@PatientVisitID varchar(50),
@Source         varchar(50)

AS
    DECLARE @PatientID	int,
	@Msg        varchar(250),
	@RoomID	    int

    -- If this patient does not exist in our system, then log an error
    IF NOT EXISTS (SELECT 1 FROM dbo.tblPatientVisit WHERE PatientVisitID = @PatientVisitID) 
    BEGIN
        SET @Msg = 'Unable to clear all status flags for PatientVisitID' + @PatientVisitID + '. PatientVisitID does not exist.'
        GOTO TransError
    END

    -- Get PatientID 
    SELECT @PatientID = PatientID,
       @RoomID = RoomID
    FROM dbo.tblPatientVisit
    WHERE PatientVisitID = @PatientVisitID
    
    -- Clear the Optional Status Flags
    UPDATE dbo.tblPatientOHD
    SET OptionalStatus1 = 0,
	OptionalStatus2 = 0,
	OptionalStatus3 = 0,
	OptionalStatus4 = 0
    WHERE PatientID = @PatientID

    -- Log that the Optional Status Flags have been cleared
	IF (@Source LIKE '%ADT-A03%')
		SET @Msg = 'Patient status flags reset on discharge'
	ELSE
		SET @Msg = 'Patient status flags reset'
		
    EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, @PatientVisitID, @RoomID, @Msg

    RETURN
    
TransError:

    IF ( @Msg IS NULL )    
       	SET @Msg = 'Unable to clear all status flags for PatientVisitID:' + @PatientVisitID
        
    EXEC dbo.Logit 1, @Msg, 'system'


go

