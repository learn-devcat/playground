
CREATE PROCEDURE dbo.DBGetStats
@DBName varchar(1024)
AS
        SET NOCOUNT ON

        DECLARE @Cmd nvarchar(1024),
                @LogSpaceAllocated real,
                @LogSpaceUsed real
        
        -- Temp table to hold the DB stats
        CREATE TABLE #Temp (
                        FileID int,
                        FileGroup int,
                        TotalExtents int,
                        UsedExtents int,
                        Name varchar(1024),
                        FileName varchar(1024)
                        )

        -- Temp table to hold the Log stats
        CREATE TABLE #LogInfo (
                        DBName varchar(32),
                        LogSize real,
                        LogSpaceUsed real,
                        Status int
                        )

        
        -- Get the DB stats
        SET @Cmd = 'DBCC SHOWFILESTATS'
        INSERT INTO #Temp EXECUTE(@Cmd)
        
        -- Get the Log stats        
        SET @Cmd = 'DBCC SQLPERF (logspace)'
        INSERT INTO #LogInfo EXECUTE(@Cmd)
        SELECT @LogSpaceAllocated = LogSize, @LogSpaceUsed = (LogSize*LogSpaceUsed)/100.0 FROM #LogInfo WHERE DBName = @DBName
        
        -- Return the retrieved information
        SELECT @DBName AS DatabaseName,CAST(CAST((TotalExtents * 64) AS decimal(8,2))/1024 as decimal(8,2)) AS SpaceAllocated, 
                CAST(CAST((UsedExtents * 64) AS decimal(8,2))/1024 as decimal(8,2)) AS SpaceUsed, 
                CAST(CAST((TotalExtents * 64) AS decimal(8,2))/1024 as decimal(8,2)) - CAST(CAST((UsedExtents * 64) AS decimal(8,2))/1024 as decimal(8,2)) AS SpaceRemaining,
                CAST((CAST(CAST((UsedExtents * 64) AS decimal(8,2))/1024 as decimal(8,2)) / CAST(CAST((TotalExtents * 64) AS decimal(8,2))/1024 as decimal(8,2))) * 100 AS int) AS PercentDataUsed,
                CAST(@LogSpaceAllocated AS decimal(8,2)) AS LogSpaceAllocated, 
                CAST(@LogSpaceUsed AS decimal(8,2)) AS LogSpaceUsed,
                CAST(@LogSpaceAllocated AS decimal(8,2)) - CAST(@LogSpaceUsed AS decimal(8,2)) AS LogSpaceRemaining,
                CAST((CAST(@LogSpaceUsed AS decimal(8,2)) / CAST(@LogSpaceAllocated AS decimal(8,2))) * 100 AS int) AS PercentLogUsed
        FROM #Temp
        
        DROP TABLE #LogInfo
        DROP TABLE #Temp
        
        RETURN
go

