


CREATE PROCEDURE dbo.gem_ArchiveTransactions
@User		char(10),
@CutoffDate	datetime,
@TransClassID	int,
@AccountClassID	int = 0,
@CoreID		int = 1
AS
	DECLARE @FileName as varchar(200),      -- NOTE: The archiving process is inclusive of the CutoffDate, regardless of the time.
		@Temp 	as char(1),
		@TempCharges	as money,
		@TempPmts	as money,
		@ChargeTransID	int,
		@PmtTransID	int,
		@TempSQL	nvarchar(4000),
		@CurError	int,
		@Msg		varchar(255),
		@ArchiveWindow	int,
		@Return	varchar(255)
	IF NOT EXISTS(SELECT [name] FROM GEMArchive.dbo.sysobjects WHERE [name]='tblDetail')
	BEGIN
		CREATE TABLE [GEMArchive].[dbo].[tblDetail] (
			[DetailID]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
			[CoreID] [int] NOT NULL ,
			[AccountNo] [char] (19) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
			[BadgeNo] [char] (19) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
			[TransDate] [datetime] NOT NULL ,
			[PostDate] [datetime] NOT NULL ,
			[CycleNo] [int] NOT NULL ,
			[Category] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
			[OutletNo] [int] NOT NULL ,
			[TransID] [int] NOT NULL ,
			[RefNum] [char] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
			[ChkNum] [char] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
			[PaymentNo] [int] NOT NULL ,
			[ServeEmpl] [int] NOT NULL ,
			[PostEmpl] [int] NOT NULL ,
			[Covers] [smallint] NOT NULL ,
			[RevCntr] [int] NOT NULL ,
			[TransTotal] [money] NOT NULL ,
			[Sales1] [money] NOT NULL ,
			[Sales2] [money] NOT NULL ,
			[Sales3] [money] NOT NULL ,
			[Sales4] [money] NOT NULL ,
			[Sales5] [money] NOT NULL ,
			[Sales6] [money] NOT NULL ,
			[Sales7] [money] NOT NULL ,
			[Sales8] [money] NOT NULL ,
			[Sales9] [money] NOT NULL ,
			[Sales10] [money] NOT NULL ,
			[Sales11] [money] NOT NULL ,
			[Sales12] [money] NOT NULL ,
			[Sales13] [money] NOT NULL ,
			[Sales14] [money] NOT NULL ,
			[Sales15] [money] NOT NULL ,
			[Sales16] [money] NOT NULL ,
			[tax1] [money] NOT NULL ,
			[tax2] [money] NOT NULL ,
			[tax3] [money] NULL ,
			[tax4] [money] NOT NULL ,
			[dsc] [money] NOT NULL ,
			[svc] [money] NOT NULL ,
			[Memo] [image] NULL ,
			[Comment] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
			[flag] [bit] NOT NULL ,
			[Auditable] [bit] NOT NULL ,
			[AuditDate] [datetime] NULL ,
			[AuditUser] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
			[MealPlanID] [int] NULL ,
			[ConnectionID] [int] NULL ,
			[LocationID] [int] NULL)
	END
	-- Get the buffer for archiving transactions.
	-- The butter is the number of days FROM the current date that cannot be archived
	SELECT @ArchiveWindow = CAST(sValue AS int) FROM cfgOverhead WHERE oKey = 'ArchiveWindow'
	SET @ArchiveWindow = ISNULL(@ArchiveWindow,400)
	-- IF the cutoff date is too close to today, raise an error AND exit
	IF ( (getdate() - @CutoffDate) < @ArchiveWindow )
	BEGIN
		SET @Return = CAST(dbo.dDateOnly(getdate() - @ArchiveWindow) AS varchar(30))
		SET @Return = LEFT(@Return,LEN(@Return) - 8)
		SET @Return =  'Cutoff Date is too close to current date. The latest Cutoff Date allowed is ' + @Return
		RAISERROR (@Return,18,1)
		RETURN -1
	END
	
	-- Table that holds the temporary balances of the items we are moving
	IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE NAME LIKE '#TempBalances%')
		DROP TABLE #TempBalances
	CREATE TABLE #TempBalances 
			(
			AccountNo	char(19),
			TransBalance	money
			)
	SET @ChargeTransID = 80000 + @TransClassID
	SET @PmtTransID = 90000 + @TransClassID
	-- Make sure the charge AND payment TransID's exist
	IF NOT EXISTS (SELECT * FROM tblTransDef WHERE TransID = @ChargeTransID)	--charge
		EXEC dbo.ad_TransDef_Insert 'support',@ChargeTransID,@TransClassID,-1,0,'Bal. Fwd. Charges','','BALFWD',0,0,0,0,999999
	IF NOT EXISTS (SELECT * FROM tblTransDef WHERE TransID = @PmtTransID)	--pmt
		EXEC dbo.ad_TransDef_Insert 'support',@PmtTransID,@TransClassID,-1,0,'Bal. Fwd. Pmts','','BALFWD',0,1,0,0,999999
	IF ( @AccountClassID > 0 )
	BEGIN
		-- SELECT by AccountClassID
		BEGIN TRANSACTION
		-- Insert the balance of the items that we are going to archive
		-- into the temporary table
		INSERT INTO #TempBalances
			SELECT X.AccountNo, ISNULL(X.Charges, 0) -  ISNULL(Y.Payments, 0) AS Total
			FROM
			(SELECT D.AccountNo, SUM(D.TransTotal) AS Charges
			FROM	tblDetail AS D
				JOIN tblTransDef AS T ON D.TransID = T.TransID
				JOIN tblAccountOHD AS A ON D.AccountNo = A.AccountNo
			WHERE	dbo.dDateOnly(TransDate) <= dbo.dDateOnly(@CutOffDate)
				AND T.TransClassID = @TransClassID
				AND A.AccountClassID = @AccountClassID
				AND T.Payment = 0
			GROUP BY D.AccountNo) AS X
			LEFT JOIN
			(SELECT D.AccountNo, SUM(D.TransTotal) AS Payments
			FROM	tblDetail AS D
				JOIN tblTransDef AS T ON D.TransID = T.TransID
				JOIN tblAccountOHD AS A ON D.AccountNo = A.AccountNo
			WHERE	dbo.dDateOnly(TransDate) <= dbo.dDateOnly(@CutOffDate)
				AND T.TransClassID = @TransClassID
				AND A.AccountClassID = @AccountClassID
				AND T.Payment = 1
			GROUP BY D.AccountNo) AS Y ON X.AccountNo = Y.AccountNo
		-- Make a second call to get accounts that have no charges currently being archived
		-- but that have current payments being archived. This is required since the JOIN above
		-- will not have a LEFT side value IF there are no current charges being archived, thus missing
		-- payments that require archiving
		INSERT INTO #TempBalances
			SELECT Y.AccountNo, ISNULL(X.Charges, 0) -  ISNULL(Y.Payments, 0) AS Total
			FROM
			(SELECT D.AccountNo, SUM(D.TransTotal) AS Payments
			FROM	tblDetail AS D
				JOIN tblTransDef AS T ON D.TransID = T.TransID
				JOIN tblAccountOHD AS A ON D.AccountNo = A.AccountNo
			WHERE	dbo.dDateOnly(TransDate) <= dbo.dDateOnly(@CutOffDate)
				AND T.TransClassID = @TransClassID
				AND A.AccountClassID = @AccountClassID
				AND T.Payment = 1
			GROUP BY D.AccountNo) AS Y
			LEFT JOIN
			(SELECT D.AccountNo, SUM(D.TransTotal) AS Charges
			FROM	tblDetail AS D
				JOIN tblTransDef AS T ON D.TransID = T.TransID
				JOIN tblAccountOHD AS A ON D.AccountNo = A.AccountNo
			WHERE	dbo.dDateOnly(TransDate) <= dbo.dDateOnly(@CutOffDate)
				AND T.TransClassID = @TransClassID
				AND A.AccountClassID = @AccountClassID
				AND T.Payment = 0
			GROUP BY D.AccountNo) AS X  ON X.AccountNo = Y.AccountNo
			WHERE Y.AccountNo NOT IN (SELECT AccountNo FROM #TempBalances)
		SET @CurError = @@ERROR
		IF ( @CurError <> 0 )
		BEGIN
			SET @Msg = ''
			GOTO ArchiveError
		END
		-- Insert the transactions we are archiving into the Archive database
		-- Make sure we do not move any previous archive summary lines 
		-- (i.e., TransID <> @ChargeTransID AND T.TransID <> @PmtTransID),
		-- since the detail lines for this summary item already exist in the archive DB.
		INSERT INTO GEMArchive.dbo.tblDetail
			SELECT D.DetailID, D.CoreID, D.AccountNo, D.BadgeNo, D.TransDate, D.PostDate, D.CycleNo, D.Category, D.OutletNo, D.TransID,
				D.RefNum, D.ChkNum, D.PaymentNo, D.ServeEmpl, D.PostEmpl, D.Covers, D.RevCntr, D.TransTotal, D.Sales1, D.Sales2,
				D.Sales3, D.Sales4, D.Sales5, D.Sales6, D.Sales7, D.Sales8, D.Sales9, D.Sales10, D.Sales11, D.Sales12, D.Sales13, D.Sales14,
				D.Sales15, D.Sales16, D.tax1, D.tax2, D.tax3, D.tax4, D.dsc, D.svc, D.Memo, D.Comment, D.flag, D.Auditable, D.AuditDate, 
				D.AuditUser, D.MealPlanID, D.ConnectionID, D.LocationID
			FROM	tblDetail AS D
				JOIN tblTransDef AS T ON D.TransID = T.TransID
				JOIN tblAccountOHD AS A ON D.AccountNo = A.AccountNo
			WHERE	dbo.dDateOnly(TransDate) <= dbo.dDateOnly(@CutOffDate)
				AND T.TransClassID = @TransClassID
				AND A.AccountClassID = @AccountClassID
				AND T.TransID <> @ChargeTransID
				AND T.TransID <> @PmtTransID
		SET @CurError = @@ERROR
		IF ( @CurError <> 0 )
			GOTO ArchiveError
		-- DELETE transactions that were just moved to the archive DB
		DELETE 	tblDetail 
			FROM	tblDetail AS D
				JOIN tblTransDef AS T ON D.TransID = T.TransID
				JOIN tblAccountOHD AS A ON D.AccountNo = A.AccountNo
			WHERE	dbo.dDateOnly(TransDate) <= dbo.dDateOnly(@CutOffDate)
				AND T.TransClassID = @TransClassID
				AND A.AccountClassID = @AccountClassID
		SET @CurError = @@ERROR
		IF ( @CurError <> 0 )
			GOTO ArchiveError
		-- Insert a single line into the tblDetail table for the transactions just moved.
		-- The single line total is retrieved FROM the temporary table
		INSERT INTO tblDetail (CoreID,AccountNo,BadgeNo,TransDate,PostDate,CycleNo,OutletNo,TransID,RefNum,ChkNum,
					PaymentNo,ServeEmpl,PostEmpl,Covers,RevCntr,TransTotal,Sales1,MealPlanID,ConnectionID,LocationID)
			SELECT 1,AccountNo,'',@CutOffDate,getdate(),0,1,
				CASE WHEN TransBalance > 0 THEN @ChargeTransID
					ELSE @PmtTransID
				END,
				'AUTO','BALFWD', 0,0,0,0,0,ABS(TransBalance),ABS(TransBalance),0,0,0
			FROM #TempBalances
		SET @CurError = @@ERROR
		IF ( @CurError <> 0 )
			GOTO ArchiveError
		COMMIT TRANSACTION
	END
 	ELSE
 	BEGIN
 		-- SELECT all
		BEGIN TRANSACTION
		-- Insert the balance of the items that we are going to archive
		-- into the temporary table
		INSERT INTO #TempBalances
			SELECT X.AccountNo, ISNULL(X.Charges, 0) -  ISNULL(Y.Payments, 0) AS Total
			FROM
			(SELECT D.AccountNo, SUM(D.TransTotal) AS Charges
			FROM	tblDetail AS D
				JOIN tblTransDef AS T ON D.TransID = T.TransID
				JOIN tblAccountOHD AS A ON D.AccountNo = A.AccountNo
			WHERE	dbo.dDateOnly(TransDate) <= dbo.dDateOnly(@CutOffDate)
				AND T.TransClassID = @TransClassID
				AND T.Payment = 0
			GROUP BY D.AccountNo) AS X
			LEFT JOIN
			(SELECT D.AccountNo, SUM(D.TransTotal) AS Payments
			FROM	tblDetail AS D
				JOIN tblTransDef AS T ON D.TransID = T.TransID
				JOIN tblAccountOHD AS A ON D.AccountNo = A.AccountNo
			WHERE	dbo.dDateOnly(TransDate) <= dbo.dDateOnly(@CutOffDate)
				AND T.TransClassID = @TransClassID
				AND T.Payment = 1
			GROUP BY D.AccountNo) AS Y ON X.AccountNo = Y.AccountNo
		SET @CurError = @@ERROR
		IF ( @CurError <> 0 )
			GOTO ArchiveError
		-- Make a second call to get accounts that have no charges currently being archived
		-- but that have current payments being archived. This is required since the JOIN above
		-- will not have a LEFT side value IF there are no current charges being archived, thus missing
		-- payments that require archiving
		INSERT INTO #TempBalances
			SELECT Y.AccountNo, ISNULL(X.Charges, 0) -  ISNULL(Y.Payments, 0) AS Total
			FROM
			(SELECT D.AccountNo, SUM(D.TransTotal) AS Payments
			FROM	tblDetail AS D
				JOIN tblTransDef AS T ON D.TransID = T.TransID
				JOIN tblAccountOHD AS A ON D.AccountNo = A.AccountNo
			WHERE	dbo.dDateOnly(TransDate) <= dbo.dDateOnly(@CutOffDate)
				AND T.TransClassID = @TransClassID
				AND T.Payment = 1
			GROUP BY D.AccountNo) AS Y
			LEFT JOIN
			(SELECT D.AccountNo, SUM(D.TransTotal) AS Charges
			FROM	tblDetail AS D
				JOIN tblTransDef AS T ON D.TransID = T.TransID
				JOIN tblAccountOHD AS A ON D.AccountNo = A.AccountNo
			WHERE	dbo.dDateOnly(TransDate) <= dbo.dDateOnly(@CutOffDate)
				AND T.TransClassID = @TransClassID
				AND T.Payment = 0
			GROUP BY D.AccountNo) AS X  ON X.AccountNo = Y.AccountNo
			WHERE Y.AccountNo NOT IN (SELECT AccountNo FROM #TempBalances)
		-- Insert the transactions we are archiving into the Archive database
		-- Make sure we do not move any previous archive summary lines 
		-- (i.e., TransID <> @ChargeTransID AND T.TransID <> @PmtTransID),
		-- since the detail lines for this summary item already exist in the archive DB.
		INSERT INTO GEMArchive.dbo.tblDetail
			SELECT D.DetailID, D.CoreID, D.AccountNo, D.BadgeNo, D.TransDate, D.PostDate, D.CycleNo, D.Category, D.OutletNo, D.TransID,
				D.RefNum, D.ChkNum, D.PaymentNo, D.ServeEmpl, D.PostEmpl, D.Covers, D.RevCntr, D.TransTotal, D.Sales1, D.Sales2,
				D.Sales3, D.Sales4, D.Sales5, D.Sales6, D.Sales7, D.Sales8, D.Sales9, D.Sales10, D.Sales11, D.Sales12, D.Sales13, D.Sales14,
				D.Sales15, D.Sales16, D.tax1, D.tax2, D.tax3, D.tax4, D.dsc, D.svc, D.Memo, D.Comment, D.flag, D.Auditable, D.AuditDate, 
				D.AuditUser, D.MealPlanID, D.ConnectionID, D.LocationID
			FROM	tblDetail AS D
				JOIN tblTransDef AS T ON D.TransID = T.TransID
				JOIN tblAccountOHD AS A ON D.AccountNo = A.AccountNo
			WHERE	dbo.dDateOnly(TransDate) <= dbo.dDateOnly(@CutOffDate)
				AND T.TransClassID = @TransClassID
				AND T.TransID <> @ChargeTransID
				AND T.TransID <> @PmtTransID
		SET @CurError = @@ERROR
		IF ( @CurError <> 0 )
			GOTO ArchiveError
		-- DELETE transactions that were just moved to the archive DB
		DELETE 	tblDetail 
			FROM	tblDetail AS D
				JOIN tblTransDef AS T ON D.TransID = T.TransID
				JOIN tblAccountOHD AS A ON D.AccountNo = A.AccountNo
			WHERE	dbo.dDateOnly(TransDate) <= dbo.dDateOnly(@CutOffDate)
				AND T.TransClassID = @TransClassID
		SET @CurError = @@ERROR
		IF ( @CurError <> 0 )
			GOTO ArchiveError
		-- Insert a single line into the tblDetail table for the transactions just moved.
		-- The single line total is retrieved FROM the temporary table
		INSERT INTO tblDetail (CoreID,AccountNo,BadgeNo,TransDate,PostDate,CycleNo,OutletNo,TransID,RefNum,ChkNum,
					PaymentNo,ServeEmpl,PostEmpl,Covers,RevCntr,TransTotal,Sales1,MealPlanID,ConnectionID,LocationID)
			SELECT @CoreID,AccountNo,'',@CutOffDate,getdate(),0,1,
				CASE WHEN TransBalance > 0 THEN @ChargeTransID
					ELSE @PmtTransID
				END,
				'AUTO','BALFWD', 0,0,0,0,0,ABS(TransBalance),ABS(TransBalance),0,0,0
			FROM #TempBalances
		SET @CurError = @@ERROR
		IF ( @CurError <> 0 )
			GOTO ArchiveError
		COMMIT TRANSACTION
 	END
	DROP TABLE #TempBalances
	RETURN
ArchiveError:
	ROLLBACK TRANSACTION
	SELECT @Msg = description
	FROM master..sysmessages
	WHERE error = @CurError
		AND msglangid = 1033
	EXEC dbo.sp_Logit 1 , @CoreID , @User , @Msg, 1000
	RETURN @CurError
go

