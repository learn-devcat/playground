
CREATE PROCEDURE dbo.OrderSETPrepared
@LoginUserID	varchar(250),
@OrderID   	int,
@PreparedDate	datetime = NULL
AS
	SET NOCOUNT ON 

	DECLARE @ActionID	int
	
	UPDATE dbo.tblOrderOHD
	SET Prepared = 1
	WHERE OrderID = @OrderID
	    
	IF (@@ERROR = 0)
	BEGIN
		SELECT  @ActionID = ActionID
		FROM    dbo.tblActions
		WHERE   ActionKey = 'PREPARE'

		IF (@PreparedDate IS NULL)
			SET @PreparedDate = getdate()

		EXEC dbo.UpdateOrderLOG @LoginUserID, @OrderID, @ActionID, NULL, NULL, @PreparedDate
		EXEC dbo.UpdatePatientOrderStatus @OrderID, @ActionID
	END	    

	RETURN
go

