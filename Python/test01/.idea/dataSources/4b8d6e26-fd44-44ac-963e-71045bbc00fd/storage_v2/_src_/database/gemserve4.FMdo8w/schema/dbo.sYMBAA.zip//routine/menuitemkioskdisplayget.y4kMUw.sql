

CREATE PROCEDURE dbo.MenuItemKioskDisplayGet
@MenuItemKioskID	int
AS
	SET NOCOUNT ON

	DECLARE	@MenuItemKioskClassID	int

	SELECT	@MenuItemKioskClassID = MenuItemKioskClassID
	FROM	dbo.tblMenuItemKiosk
	WHERE	MenuItemKioskID = @MenuItemKioskID

	SELECT	MenuItemKioskClassID,
		BackColor,
		ForeColor,
		FontName,
		FontSize
	FROM	dbo.tblMenuItemKioskClass
	WHERE	MenuItemKioskClassID = @MenuItemKioskClassID

	RETURN
go

