CREATE FUNCTION [dbo].[GetMealPeriodNameByID](@MealPeriodID int)
RETURNS varchar(50)
BEGIN
	DECLARE @Return	varchar(10)

	SELECT @Return = Description
	FROM dbo.tblMealPeriods
	WHERE MealPeriodID = @MealPeriodID

	RETURN ISNULL(@Return, 'N/A')
END
go

