
CREATE PROCEDURE dbo.MenuItemNutrientAddForImport
@LoginUserID		varchar(250),
@MenuItemID		int,
@NutrientName		varchar(50),
@Qty			decimal(10,3)

AS
	SET NOCOUNT ON
	DECLARE @NutrientID	int

	SELECT @NutrientID = NutrientID
	FROM	dbo.cfgNutrients
	WHERE	[Description] = @NutrientName

	INSERT INTO dbo.tblMenuItemNutrients(MenuItemID, NutrientID, Qty)
		VALUES(@MenuItemID, @NutrientID, @Qty)

	RETURN
go

