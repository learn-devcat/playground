


CREATE PROCEDURE [dbo].[MenuDelete]
@LoginUserID		varchar(250),
@MenuID		int
AS
	SET NOCOUNT ON

	DELETE dbo.cfgWebMenus WHERE MenuID = @MenuID
go

