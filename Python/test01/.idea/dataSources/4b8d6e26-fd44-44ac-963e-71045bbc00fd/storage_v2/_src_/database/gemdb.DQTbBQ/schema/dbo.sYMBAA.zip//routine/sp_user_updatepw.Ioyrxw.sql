



CREATE   PROCEDURE [dbo].[sp_User_UpdatePW]
@UserID		varchar(16),
@OldPW		varchar(100),
@NewPW		varchar(100)
AS
	DECLARE @Cmsg  char(255),
		@CoreID	int
	SET @CoreID = dbo.GetCoreIDFromUser(@UserID)
	IF NOT EXISTS (SELECT PW FROM cfgUsers WHERE UserID = @UserID AND PW = @OldPW)
	BEGIN
		SELECT '1' AS Valid
		
		SET @Cmsg = 'UpdatePW failed - UsedID: ' + @UserID 	
		EXEC dbo.sp_Logit 0, @CoreID, @UserID, @Cmsg, 102
	
		RETURN
	END
	
	-- Check for password change
	IF (@OldPW = @NewPW)
	BEGIN
		SELECT '2' AS Valid
		RETURN
	END
	UPDATE cfgUsers
	SET PW = @NewPW,
		LastPWChange = getdate()			
	WHERE UserID = @UserID AND PW = @OldPW
	SET @Cmsg = 'Password changed for user <' + @UserID + '>'
	EXEC dbo.sp_Logit 0, @CoreID, @UserID, @Cmsg, 102
	SELECT '0' AS Valid
go

