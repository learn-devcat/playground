



CREATE PROCEDURE dbo.PatientDelete
@LoginUserID		varchar(250),
@PatientID	int

AS
	SET NOCOUNT ON
	
	DELETE	dbo.tblPatientOHD
	WHERE	PatientID = @PatientID

	RETURN
go

