

CREATE PROCEDURE dbo.sp_Outlet_List
@OutletClassID		int = 0
AS
	IF (@OutletClassID > 0) 
		SELECT	OutletNo,
				OutletName
		FROM		tblOutletOHD
		WHERE	OutletClassID = @OutletClassID
		ORDER BY	OutletNo
	ELSE
		SELECT	OutletNo,
				OutletName
		FROM		tblOutletOHD
		ORDER BY	OutletNo
go

