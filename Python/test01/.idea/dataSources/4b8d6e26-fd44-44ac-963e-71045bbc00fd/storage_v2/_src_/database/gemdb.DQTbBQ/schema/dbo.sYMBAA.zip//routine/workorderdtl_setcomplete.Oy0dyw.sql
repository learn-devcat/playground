
CREATE   PROCEDURE dbo.WorkorderDTL_SetComplete
@User                   char(10),
@WorkorderID            int, 
@WorkOrderDTLID         int,
@EmployeeID             int,
@CDate                  varchar(20)
AS
DECLARE @rtn	varchar(100)
SET NOCOUNT ON
DECLARE @PostChargeAsCompleted      bit,
        @PostChargeWhenComplete     bit,
        @CloseWorkOrderWhenComplete bit,
        @NumberOpenDetail           int,
        @CompletionDate             datetime
    -- Now, IF we get a date FROM the caller, use it -- ELSE, use now.         
    SET @CompletionDate = ISNULL( @CDate , getdate())
    -- SET the entry as completed only IF not already done.
    UPDATE	tblWorkorderDTL
       SET  Completed            = 1,
            CompletionDate       = @CompletionDate,
            CompletingEmployeeID = @EmployeeID           
	WHERE	WorkOrderID    = @WorkOrderID AND
	        WorkOrderDTLID = @WorkOrderDTLID AND
	        Completed      = 0
    IF @@ERROR <> 0               -- IF we have an error updating this record, bark.
        BEGIN
            -- TODO: Log the error AND exit
            RETURN
        END
   -- IF @@ROWCOUNT = 0 
   ---   BEGIN
	-- commented this out because @@rowcount wasn't correctly reporting 1 row was affected --RB
        -- TODO: Didn't UPDATE -- either not found, or was already complete.  So, log it.
   --     RETURN
   --   END
    -- Read the options of what we need to do as we "complete" these records. These options
    -- live in the WorkOrder CLASS table, so need to JOIN through the OHD.
    SELECT @PostChargeAsCompleted       = C.PostChargeAsCompleted,
           @PostChargeWhenComplete      = C.PostChargeWhenComplete,
           @CloseWorkOrderWhenComplete  = C.CloseWorkOrderWhenComplete
    FROM   tblWorkOrderDTL DTL
    LEFT JOIN tblWorkOrderOHD O on DTL.WorkOrderID = O.WorkOrderID
    LEFT JOIN tblWorkOrderClass C on O.WorkOrderClassID = C.WorkOrderClassID
    -- IF we are posting with every detail line item, then go post it ...
    IF @PostChargeAsCompleted <> 0 
      BEGIN
        EXEC WorkOrderDTL_PostCharge @User , @WorkOrderID, @WorkOrderDTLID, @EmployeeID, @CompletionDate
      END
    -- Now, check to see IF we are the last item in the list.  IF so,
    -- we need to post the transaction for the Work Order.
    -- NOTE: both detail AND work order level charges can be posted-- 
    --       this would allow for the creation of a "balanced" account
    --       IF the details post one item AND the completed record posts
    --       the credit.
    SELECT @NumberOpenDetail = count(Completed) 
    FROM   tblWorkOrderDTL
    WHERE  Completed   = 0 AND
           WorkOrderID = @WorkOrderID 
    /*
        IF NumberOpenDetail = 0, this would indicate that was the last detail entry since
        IF there were no detail, we really shouldn't be in this routine ...
        There may be one or more detail entries attached to this Work Order, we dont' really
        care, as long as there are now none open...
    */
    IF( @NumberOpenDetail = 0 )         
      BEGIN 
        UPDATE  tblWorkOrderOHD
        SET     Completed            = 1,
                CompletionDate       = @CompletionDate,
                CompletingEmployeeID = @EmployeeID
        WHERE   WorkOrderID = @WorkOrderID
        IF @CloseWorkOrderWhenComplete <> 0 
          BEGIN
            EXEC dbo.WorkorderOHD_Close @User , @WorkOrderID , @EmployeeID , @CompletionDate
          END                    
        IF( @PostChargeWhenComplete <> 0 )
          BEGIN
            EXEC WorkOrderOHD_PostCharge @User , @WorkOrderID, @EmployeeID, @CompletionDate
          END
      END
   RETURN
go

