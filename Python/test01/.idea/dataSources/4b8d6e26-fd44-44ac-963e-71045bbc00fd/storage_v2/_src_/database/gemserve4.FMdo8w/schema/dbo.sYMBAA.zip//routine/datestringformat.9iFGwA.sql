CREATE FUNCTION dbo.DateStringFormat(@WholeDate varchar(50), @Format int, @Today datetime)
RETURNS varchar(30)
AS
BEGIN
	DECLARE @Date as datetime,
		@Return varchar(30)

	IF (@Format < 0)
		SET @Format = COALESCE(dbo.GetOverheadValueNull('DefaultDateFormat'),110)
	

	IF (ISDATE(@WholeDate) = 1)
		SET @Date = CAST(@WholeDate AS datetime)
	ELSE
		SET @Date = dbo.HL7ConvertDate(@WholeDate, @Today)	
	
	
	IF (ISDATE(@Date) = 1)
		SET @Return = CONVERT(VARCHAR(10), @Date, @Format)
	

	RETURN @Return
END
go

