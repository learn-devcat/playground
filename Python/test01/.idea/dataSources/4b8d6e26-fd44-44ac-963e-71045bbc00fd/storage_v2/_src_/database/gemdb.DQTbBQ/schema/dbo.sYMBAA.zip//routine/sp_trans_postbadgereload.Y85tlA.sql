CREATE PROCEDURE [dbo].[sp_Trans_PostBadgeReload]
@CoreID				int,
@User				char(10),
@AccountNo			char(19),
@BadgeNo			char(19),
@TransDate			datetime,
@OutletNo			int,
@RefNum				char(6),
@CheckNum			char(6),
@TransClassID		int,
@TransTotal			money
	
AS

DECLARE
	@ReturnCode			int,
	@BatchID	char(10),
	@ReloadActive		int,
	@ReloadTransID		int,
	@ReloadThreshold	money,
	@ReloadAmount		money,
	@Balance			money,
	@DeclBalMode		bit
	
	SET @ReturnCode = 0
	SET @BatchID = 'GEM2GO'
	
	-- Get the Reload information from the badges table where ReloadActive from tblBadgesOHD is enabled
	SELECT	@ReloadActive=B.ReloadActive,
			@ReloadTransID = B.ReloadTransID,
			@ReloadThreshold = B.ReloadThreshold,
			@ReloadAmount = B.ReloadAmount,
			@DeclBalMode = COALESCE(TC.DeclBalMode,0)
	FROM	dbo.tblBadgesOHD AS B
	LEFT JOIN	dbo.tblTransDef AS TD ON B.ReloadTransID = TD.TransID
	LEFT JOIN	dbo.tblTransClass AS TC ON TD.TransClassID = TC.TransClassID
	WHERE	B.AccountNo = @AccountNo  
		AND		B.BadgeNo = @BadgeNo
		AND		B.ReloadActive <> 0
		AND		TD.TransClassID = @TransClassID
		
	-- If reload account exists and active, then determine if the badge needs to be reloaded	
	IF (@@ROWCOUNT > 0)
	BEGIN
		-- If any results are returned, then the reload threshold has been reached
		SELECT	1
		FROM	dbo.tblAccountTTL
		WHERE	(AccountNo = @AccountNo
			AND TransClassID = @TransClassID)
			AND (((@DeclBalMode = 0) AND (Balance > @ReloadThreshold))
				OR ((@DeclBalMode <> 0) AND (-Balance < @ReloadThreshold)))			
			
		--Reload threshold exceeded so make sure reload transaction doesn't already exist before posting to the tblBatchOHD table
		IF (@@ROWCOUNT > 0) AND NOT EXISTS (SELECT 1 FROM dbo.tblBatch WHERE Posted IN ('I','') AND AccountNo = @AccountNo AND BadgeNo = @BadgeNo AND TransID = @ReloadTransID AND TransTotal = @ReloadAmount)		
			EXEC @ReturnCode = dbo.sp_Batch_Insert @CoreID,@User,@BatchID,@AccountNo,@BadgeNo,@TransDate,@OutletNo,@RefNum,@CheckNum,@ReloadAmount,@ReloadAmount,'',0,@ReloadTransID						
	END		
			
	RETURN @ReturnCode
go

