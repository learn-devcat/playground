


CREATE PROCEDURE dbo.pos_Badge_Insert
@User			char(10),
@AccountNo		char(19),
@BadgeNo		char(19),
@ActiveDate		datetime,
@ExpireDate		datetime,
@ExpireOldBadges	int = 1
AS
	DECLARE	@cMsg  char(255),
		@CoreID	int
	SET @CoreID = dbo.GetCoreIDFromUser(@User)
	IF ( @ExpireOldBadges = 1 )
		-- Turn off all existing badges for this account
		UPDATE 	tblBadgesOHD
		SET 		Inactive = 1,
				ExpireDate = getdate() - 1
		WHERE 	AccountNo = @AccountNo
	-- Turn off all existing instances of this badge no
	UPDATE	tblBadgesOHD
	SET		Inactive = 1,
			ExpireDate = getdate() - 1
	WHERE	BadgeNo = @BadgeNo
	-- Attempt to UPDATE the new badge number.
	-- This step is required in case the badge already
	-- exists for this account
	UPDATE	tblBadgesOHD
	SET	ActiveDate = @ActiveDate,
		ExpireDate = @ExpireDate,
		Inactive = 0,
		ModifiedBy = @User
	WHERE	BadgeNo = @BadgeNo
		AND AccountNo = @AccountNo
	-- IF the UPDATE did not affect any rows, then the badge did not exist
	-- In this case, we need to add a new badge to the account.
	IF (@@ROWCOUNT = 0)
	BEGIN
		INSERT INTO	tblBadgesOHD (BadgeNo,AccountNo, ActiveDate, ExpireDate, ModifiedBy)
			VALUES	(@BadgeNo,@AccountNo, @ActiveDate, @ExpireDate, @User)
		--[ UPDATE Log ]---------------------------------------
		SET @cMsg = 'Badge No [' + RTRIM(@BadgeNo) + '] for Account No [' + RTRIM(@AccountNo) + '] inserted by user ' + @User
		EXEC dbo.sp_Logit 1 , @CoreID , @User , @cMsg, 300
		-------------------------------------------------------[ UPDATE Log END ]------
	END
	ELSE
	BEGIN
		--[ UPDATE Log ]---------------------------------------
		SET @cMsg = 'Badge No [' + RTRIM(@BadgeNo) + '] for Account No [' + RTRIM(@AccountNo) + '] updated by user ' + @User
		EXEC dbo.sp_Logit 1 , @CoreID , @User , @cMsg, 300
		-------------------------------------------------------[ UPDATE Log END ]------
	END
go

