CREATE PROCEDURE dbo.sp_Kiosk_UpdatePIN
@User		char(10),
@AccountNo	char(19),
@PIN		char(10),
@NewPIN		char(10)
AS 
	UPDATE	tblAccountOHD
	SET		PIN = @NewPIN,
			LastUpdateDate = GETDATE()
	WHERE	AccountNo = @AccountNo AND
			PIN = @PIN
go

