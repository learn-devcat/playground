

CREATE PROCEDURE [dbo].[sp_Recur_AccountList_EX]
@User		char(10),
@AccountNo	char(19)
AS 
	DECLARE	@CoreID				int,
			@AccountClassID		int 
			
	--Get the CoreID for the specified user
	SET @CoreID	= dbo.GetCoreIDFromUser(@User)
	
	--Get the account class for the specified account
	SELECT 	@AccountClassID = AccountClassID 
	FROM	tblAccountOHD
	WHERE	AccountNo = @AccountNo
	
	--Get the recurring charges that apply to this account and the account class for the account
	SELECT	R.RecurID,
			R.ClassID,
			R.Description, 
			C.NextDate, 
			R.Amount,
			R.[Percent],
			R.Minimum,
			R.Balance,
			R.PastDue,
			R.TrackIDNum,
			R.TrackSlotNum,
			CASE(R.AcctClassID)
				WHEN 0 THEN 0
				ELSE 1
				END AS ClassItem,
			R.TransID,
			T.Preset,
			R.UseOutletClassBal,
			R.Formula,
			R.Active,
			R.BalanceMax
	FROM	tblRecurChgClass AS C INNER JOIN
			tblRecurChg AS R
	ON		C.ClassID = R.ClassID LEFT JOIN
			tblTransDef AS T
	ON		R.TransID = T.TransID
	WHERE	(R.AcctClassID = @AccountClassID OR
			R.AccountNo = @AccountNo)
	ORDER BY R.AcctClassID, C.NextDate, R.ClassID
go

