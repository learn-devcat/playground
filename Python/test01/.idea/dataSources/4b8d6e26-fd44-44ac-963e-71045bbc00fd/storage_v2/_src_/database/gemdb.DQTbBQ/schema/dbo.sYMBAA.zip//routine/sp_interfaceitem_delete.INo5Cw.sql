

CREATE PROCEDURE dbo.sp_InterfaceItem_Delete
@InterfaceID int
AS
	DELETE	cfgInterface
	WHERE	InterfaceID = @InterfaceID
go

