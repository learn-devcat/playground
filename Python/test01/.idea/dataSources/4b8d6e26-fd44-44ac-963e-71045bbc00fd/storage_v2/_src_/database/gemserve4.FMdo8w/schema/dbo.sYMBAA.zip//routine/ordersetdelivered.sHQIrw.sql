
CREATE PROCEDURE dbo.OrderSETDelivered
    @OrderID   int,
    @Delivered int = 1,
    @DeliveredBy varchar(30)='System',
    @LogDate   datetime = NULL
AS
	SET NOCOUNT ON 
	DECLARE @PatientID	int,
		@PatientVisitID varchar(50),
		@OrderDate datetime,
		@DietID int,
		@RoomID int,
		@Msg varchar(200),
		@CheckNo varchar(20),
		@LoginUserID varchar(200),
		@UserID int
		
	IF (ISDATE(@LogDate) = 0)
		SET @LogDate = getdate()				
				
	SELECT 	@PatientID = PatientID,
		@PatientVisitID = PatientVisitID,
		@OrderDate = OrderDate,
		@CheckNo = CheckNo
	FROM dbo.tblOrderOHD
	WHERE OrderID = @OrderID

	SELECT @DietID = dbo.GetActiveDiet(@PatientVisitID, @OrderDate)

	SELECT @RoomID = RoomID 
	FROM dbo.tblPatientVisit
	WHERE PatientVisitID = @PatientVisitID

	SELECT @UserID = UserID,
	@LoginUserID = LoginUserID
	FROM dbo.tblEmployees
	WHERE BadgeNo = @DeliveredBy

	IF (@UserID IS NULL)
		SELECT 	@UserID = UserID,
				@LoginUserID = LoginUserID
		FROM dbo.tblEmployees
		WHERE LoginUserID = @DeliveredBy

	SET @Msg = 'Order delivered for CheckNo. ['	+ @CheckNo + '] at [' + CAST(@LogDate AS varchar(30)) + ']'
    EXEC dbo.PatientLOGAdd 1000, @LoginUserID, @PatientID, @PatientVisitID, @RoomID, @Msg, @LogDate
	
	SELECT  @Delivered = ActionID
	FROM    dbo.tblActions
	WHERE   ActionKey = 'DELIVERED'

 	UPDATE 	dbo.tblOrderOHD
    SET 	Delivered = @Delivered,
			DeliveryEmployee = @UserID
	WHERE 	OrderID   = @OrderID
	    
	EXEC dbo.UpdateOrderLOG @LoginUserID , @OrderID , @Delivered , null, null, @LogDate
	EXEC dbo.UpdatePatientOrderStatus @OrderID, @Delivered

	RETURN
go

