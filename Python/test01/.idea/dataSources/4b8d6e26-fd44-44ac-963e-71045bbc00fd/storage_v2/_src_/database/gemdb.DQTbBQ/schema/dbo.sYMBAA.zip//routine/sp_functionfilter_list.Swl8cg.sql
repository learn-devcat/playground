

CREATE PROCEDURE dbo.sp_FunctionFilter_List
AS 
	SELECT	FilterID,
			FilterString
	FROM	cfgFilterStrings
	ORDER BY FilterID
go

