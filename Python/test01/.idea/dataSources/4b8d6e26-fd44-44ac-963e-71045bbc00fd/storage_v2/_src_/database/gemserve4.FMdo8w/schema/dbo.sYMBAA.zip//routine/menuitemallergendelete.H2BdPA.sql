
CREATE PROCEDURE dbo.MenuItemAllergenDelete
@LoginUserID		varchar(250),
@MenuItemAllergenID	int,
@MenuItemID		int=0,
@AllergenID		int=0


AS
	SET NOCOUNT ON
	
	IF(@MenuItemAllergenID > 0)
		DELETE dbo.tblMenuItemAllergens WHERE MenuItemAllergenID = @MenuItemAllergenID
	ELSE
	BEGIN
		IF(@MenuItemID > 0)
		BEGIN
			DELETE dbo.tblMenuItemAllergens WHERE MenuItemID = @MenuItemID
		END
		ELSE
		BEGIN
			DELETE dbo.tblMenuItemAllergens WHERE AllergenID = @AllergenID
		END
	END

	RETURN
go

