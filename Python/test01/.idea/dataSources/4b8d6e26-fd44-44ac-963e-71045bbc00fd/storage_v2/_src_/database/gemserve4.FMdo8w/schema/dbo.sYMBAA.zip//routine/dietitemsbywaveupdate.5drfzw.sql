

CREATE PROCEDURE dbo.DietItemsByWaveUpdate
@LoginUserID		varchar(250),
@DietID		int,
@WaveID		int,
@DietItemID	decimal(10,4),
@Qty		int

AS
	IF (@Qty = 9999)
		RETURN

	IF NOT EXISTS (SELECT DietWaveID FROM dbo.tblDietWave WHERE DietID = @DietID AND WaveID = @WaveID)
	BEGIN
		INSERT INTO dbo.tblDietWave (DietID, WaveID, Active)
			VALUES (@DietID, @WaveID, 1)

	END

	DELETE dbo.tblDietDtl WHERE DietWaveID IN (SELECT DietWaveID FROM dbo.tblDietWave WHERE DietID = @DietID AND WaveID = @WaveID) AND NutrientID = @DietItemID

	INSERT INTO dbo.tblDietDtl (DietWaveID, NutrientID, Qty)
		SELECT	DietWaveID, @DietItemID, @Qty
		FROM	dbo.tblDietWave (NOLOCK)
		WHERE	DietID = @DietID
			AND WaveID = @WaveID
go

