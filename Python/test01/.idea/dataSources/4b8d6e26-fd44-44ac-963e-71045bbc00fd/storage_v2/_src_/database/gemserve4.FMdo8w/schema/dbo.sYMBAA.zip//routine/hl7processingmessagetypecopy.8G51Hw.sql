CREATE PROCEDURE dbo.HL7ProcessingMessageTypeCopy
@MessageType	varchar(32),
@NewMessageType	varchar(32)
AS
	SET NOCOUNT ON

	INSERT INTO dbo.tblHL7Processing (MessageType, [Name], [Description], ControlType, CommandType, Command, ReturnColumn, [Sequence], Active)
		SELECT @NewMessageType, [Name], [Description], ControlType, CommandType, Command, ReturnColumn, [Sequence], Active
		FROM dbo.tblHL7Processing
		WHERE MessageType = @MessageType

	RETURN
go

