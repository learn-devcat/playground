

CREATE FUNCTION dbo.GetMealPeriodNameForOrder(@OrderID int)
RETURNS varchar(50)
BEGIN
	DECLARE @Return	varchar(50)

	SELECT @Return = M.[Description]
	FROM	dbo.tblOrderOHD AS O
		JOIN dbo.tblWave AS W ON O.WaveID = W.WaveID
		JOIN dbo.tblMealPeriods AS M ON M.MealPeriodID = W.MealPeriodID
	WHERE 	O.OrderID = @OrderID

	RETURN ISNULL(@Return, 'None')
END
go

