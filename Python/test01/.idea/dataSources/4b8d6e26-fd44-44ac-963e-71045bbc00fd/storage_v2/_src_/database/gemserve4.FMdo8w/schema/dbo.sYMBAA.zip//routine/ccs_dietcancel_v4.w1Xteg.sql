
CREATE PROCEDURE [dbo].[CCS_DietCancel_v4]
@PatientVisitID			varchar(50),
@TransactionIdentifier	varchar(50),
@Source					varchar(50),
@CancelDate		datetime=null
AS

	DECLARE @Msg		varchar(500),
			@PatientID	int,
			@RoomID		int,
			@OldDietID	int,
			@DietID		int,
			@DietName	varchar(50),
			@Today		datetime,
			@PatientDietID int,
			@CancelMealOnDietCancel int,
			@ProcessType varchar(10)

	SET @ProcessType = 'ORM-O01'

	-- Get overhead key to determine if cancelled diets should also cancel future orders
	SELECT @CancelMealOnDietCancel = COALESCE(dbo.GetOverheadValueNull('CancelMealOnDietCancel'),1)
	IF (@CancelMealOnDietCancel = 1)
	BEGIN
		-- Set the cancel date of the diet
		IF (@CancelDate IS NULL)
			SET @Today = getdate()
		ELSE
			SET @Today = @CancelDate

		-- Get the PatientID
		SELECT @PatientID = PatientID,
				@DietID = DietID,
				@RoomID = RoomID
		FROM	dbo.tblPatientVisit
		WHERE PatientVisitID = @PatientVisitID
		
		-- If this patient does not exist in our system, then log an error
		IF (@PatientID IS NULL)
		BEGIN
		    SET @Msg = 'Unable to cancel Diet Order for Patient Visit ID: [' + @PatientVisitID + '].' + '. Patient Visit ID not found.'
		    GOTO TransError
		END 
	 
		-- Get the name of the diet
		SELECT @DietName = D.[Description], @PatientDietID = PD.[ID]
		FROM dbo.tblPatientDiet AS PD (NOLOCK)
			JOIN dbo.tblDietOHD AS D (NOLOCK) ON PD.DietID = D.DietID
		WHERE PD.TransactionIdentifier = @TransactionIdentifier
			AND PD.PatientVisitID = @PatientVisitID

		-- If diet does not exist in our system, the log an error
		IF (@PatientDietID IS NULL)
		BEGIN
			Set @Msg = 'Unable to cancel Diet Order for Patient Visit ID: [' + @PatientVisitID + '].' + '. PatientDietID not found.'
			GOTO TransError
		END
			
		-- Set the cancel flag for the Patient Diet
		UPDATE dbo.tblPatientDiet
		SET CancelDate = @Today,
			UpdateDate = getdate(),
			UpdateID = @Source
		WHERE PatientVisitID = @PatientVisitID
			AND TransactionIdentifier = @TransactionIdentifier

		-- Get the dietid  for the current active diet after the current diet has been canceled.
		SELECT @OldDietID = dbo.GetActiveDiet(@PatientVisitID,getdate())
		
		-- Cancel the future orders if both the previous diet and the diet being canceled are not the same.
		-- Or if there is no active diet
		IF (@DietID <> @OldDietID) OR (dbo.GetActivePatientDietID(@PatientVisitID, getdate()) = -1)	
		BEGIN
			-- Cancel all patient orders for this patient visit that are in the future. Do not cancel guest/parent/stork orders linked to PatientVisit
			-- Insert a log entry into the Order Log for all orders that we are cancelling
			INSERT INTO dbo.tblOrderLOG (OrderID, ActionID, LoginUserID)
				SELECT 	OrderID, 700, @ProcessType
				FROM	dbo.tblOrderOHD AS O (NOLOCK)
					JOIN dbo.tblPatientVisit AS P (NOLOCK) ON (O.PatientVisitID = P.PatientVisitID OR O.PatientVisitID = P.MergedTo)
				WHERE O.OrderDate >= @Today  
				    	AND ISNULL(O.Cancelled,0) <> 1
					AND COALESCE(O.Received,0) <> 1
					AND O.OrderType = 1
				    	AND O.PatientVisitID = @PatientVisitID
				    	
			-- Deletes all nutrient counts for orders that are being canceled.
			DELETE dbo.tblPatientNutrientCount 
			WHERE OrderID IN (SELECT OrderID FROM dbo.tblOrderOHD AS O (NOLOCK)
				JOIN dbo.tblPatientVisit AS P (NOLOCK) ON (O.PatientVisitID = P.PatientVisitID OR O.PatientVisitID = P.MergedTo)
		       	WHERE O.OrderDate >= @Today 
		                	AND ISNULL(O.Cancelled,0) <> 1
					AND COALESCE(O.Received,0) <> 1
			    	AND O.PatientVisitID = @PatientVisitID)

			-- Insert a log entry into the Patient Log for all orders that we are cancelling
			SET @Msg = ' Order cancelled due to Diet Cancellation. Order ID: '
			INSERT INTO dbo.tblPatientLog (EventClassID, LoginUserID, PatientID, PatientVisitID, RoomID, [Description], [Date])
			SELECT 7000, @Source, P.PatientID, P.PatientVisitID, P.RoomID, M.[Description] + @Msg + CAST(O.OrderID AS varchar(30)), getdate()
			FROM dbo.tblOrderOHD AS O (NOLOCK)
			        JOIN dbo.tblPatientVisit AS P (NOLOCK) ON O.PatientVisitID = P.PatientVisitID
					JOIN dbo.tblWave AS W (NOLOCK) ON O.WaveID = W.WaveID
					JOIN dbo.tblMealPeriods AS M (NOLOCK) ON W.MealPeriodID = M.MealPeriodID
			WHERE O.OrderDate >= @Today 
			AND ISNULL(O.Cancelled,0) <> 1
			AND COALESCE(O.Received,0) <> 1
			AND O.OrderType = 1
			AND O.PatientVisitID = @PatientVisitID				
						
			-- Set the cancelled flag to 1 for any orders in future waves			
			UPDATE dbo.tblOrderOHD
			SET Cancelled = 1,
					CancelDate = @Today,
					LastUpdateBy = @Source
			WHERE	PatientVisitID = @PatientVisitID
					AND ISNULL(Cancelled,0) <> 1
					AND COALESCE(Sent,0) <> 1
					AND OrderDate >= @Today
					AND OrderType = 1

			-- Set the cancelled flag to 1 for notes for this TransactionID
			UPDATE dbo.tblPatientNotes
			SET Cancelled = 1,
				CancelDate = @Today,
				UpdateDate = getdate(),
				UpdateID = @Source
			WHERE PatientVisitID = @PatientVisitID
				AND TransactionIdentifier = @TransactionIdentifier

			-- Check and see if the Optional Patient Status flags need to be updated based on the now active DietID
			IF EXISTS (SELECT KeyIn FROM dbo.tblXLAT WHERE xlatID = 'OptionalStatus' AND KeyIn = CAST(@OldDietID AS varchar(10)))
			BEGIN
				EXEC dbo.CCS_PatientStatusUpdate_v4 @PatientID, @PatientDietID, @OldDietID, @Source
			END	

		END
			-- Add a patient log entry about the Diet being cancelled
			IF (@PatientID IS NOT NULL)
			BEGIN
				SET @Msg = 'Diet [' + COALESCE(@DietName,'N/A') + '] cancelled - effective at [' + CAST(@Today AS varchar(30)) + ']. Transaction identifier [' + @TransactionIdentifier + '].'
				EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, @PatientVisitID, @RoomID, @Msg
			END
		
	END
		RETURN
	
TransError:

	IF (@Msg IS NULL)    
			SET @Msg = 'Unable to cancel Diet Order for Patient Visit ID: [' + @PatientVisitID + '].'
       
    EXEC dbo.Logit 1, @Msg, 'system'

	RETURN

go

