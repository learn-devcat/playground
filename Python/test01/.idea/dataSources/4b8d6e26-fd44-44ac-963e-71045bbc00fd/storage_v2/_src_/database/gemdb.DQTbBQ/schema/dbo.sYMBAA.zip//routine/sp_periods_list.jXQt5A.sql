

CREATE PROCEDURE dbo.sp_Periods_List
@User		char(10)
AS 
	SELECT 	Period,
			Description
	FROM	tblPeriods
go

