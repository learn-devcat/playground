

CREATE PROCEDURE [dbo].[ad_Location_Delete]
@User		char(10),
@LocationID	int
AS 
	DELETE	cfgLocations
	WHERE	LocationID = @LocationID
	
	EXEC dbo.gem_UserDeleteLocation 'support', @LocationID
go

