
CREATE PROCEDURE dbo.RotateLog
@LogFile        varchar(200)
AS
        DECLARE @GEMDirectory varchar(300),
        	@CMD varchar(1000),
        	@FilePart varchar(100),
                @LogFileOnly varchar(100),
                @Start int

        -- Create date/time string to help up create the saved file name        
        SET @FilePart = dbo.DateString(getdate()) + '-' + REPLACE(dbo.TimeString(getdate()),':','-') + '-' + RIGHT('0' + DATENAME(ss,getdate()),2)
        
        -- Get the GEM installation directory
        EXEC master.sys.xp_regread 'HKEY_LOCAL_MACHINE', 
        			'SOFTWARE\Common CENTS Solutions\GEMpay\Settings',
        			'Install Directory',
        			@GEMDirectory OUTPUT

        -- Strip out the name of the file we are rotating
        SET @Start = 1
        SET @LogFileOnly = @LogFile

        WHILE (1=1)
        BEGIN
                -- Remove path information
                SET @Start = CHARINDEX('\',@LogFileOnly)
                IF (@Start > 0)
                        SET @LogFileOnly = RIGHT(@LogFileOnly,LEN(@LogFileOnly) - @Start)
                ELSE                                
                BEGIN
                        -- Remove extension. Assumes there is only a single . in the string
                        IF(CHARINDEX('.',@LogFileOnly) > 0)
                                SET @LogFileOnly = LEFT(@LogFileOnly,CHARINDEX('.',@LogFileOnly) - 1)

                        BREAK
                END
        END

        -- Create the command to execute
        SET @CMD = @GEMDirectory + '\Scripts\RotateLog.bat ' + @LogFile + ' ' + @GEMDirectory + '\Log\ ' + @LogFileOnly + @FilePart + '.sav ' + 
                @GEMDirectory + '\Log\RotateLog.log'

        -- Rotate the file
        EXEC master.sys.xp_cmdshell @CMD

        RETURN
go

