

CREATE PROCEDURE dbo.TouchscreenButtonsList
@CategoryID	int
AS
	DECLARE	@Count	int,
			@Category	varchar(50)
	DECLARE	@Buttons TABLE (ButtonNo	int,
				Item		varchar(50))

	SELECT @Category = M.[Description]
	        FROM	dbo.tblMenuItemCategory AS M
	                JOIN dbo.tblMenuItem_Touchscreen AS T ON T.MenuCategoryID = M.MenuItemCategoryID 
	WHERE MenuItemCategoryID = @CategoryID

	SET @Count = 1

	WHILE (@Count < 49)
	BEGIN
		INSERT INTO @Buttons(ButtonNo)
			VALUES (@Count)

		SET @Count = @Count + 1
	END

	UPDATE @Buttons
	SET Item = M.[Description]
	FROM @Buttons AS B
		JOIN dbo.tblMenuItem_Touchscreen AS T (NOLOCK) ON B.ButtonNo = dbo.GetTSLocation(T.RowStart, T.ColStart)
		JOIN dbo.tblMenuItemOHD AS M (NOLOCK) ON T.MenuItemID = M.MenuItemID
	WHERE T.MenuCategoryID = @CategoryID
	
	SELECT @Category AS Category,ButtonNo, COALESCE(Item,'[Available]') AS Item, getdate() AS ReportRun
	FROM @Buttons
	ORDER BY ButtonNo

	RETURN
go

