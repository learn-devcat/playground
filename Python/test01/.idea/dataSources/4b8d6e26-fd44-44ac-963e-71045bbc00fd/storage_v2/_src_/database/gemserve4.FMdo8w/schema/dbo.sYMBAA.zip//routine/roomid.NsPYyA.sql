

CREATE FUNCTION [dbo].[RoomID]
	(
        @RoomNumber varchar(50),
		@Bed	varchar(10)
	)
RETURNS int

AS
    BEGIN
        DECLARE @RoomID int,
				@Separator	varchar(10)

	IF EXISTS (SELECT 1 FROM dbo.cfgOverhead WHERE KeyID = 'AppendBed')
	BEGIN
		SELECT @Separator = dbo.GetOverheadValueNull('AppendBed')
	
		SET @RoomNumber = CASE WHEN @Bed = '' THEN @RoomNumber
				ELSE @RoomNumber + COALESCE(@Separator,'') + 
					COALESCE(@Bed,'') END
		
		--GOTO Finish
	END

	IF EXISTS (SELECT KeyOut FROM dbo.tblXlat WHERE KeyIn = @RoomNumber AND xlatID = 'Room')
		SELECT @RoomNumber = KeyOut
		FROM dbo.tblXlat 
		WHERE KeyIn = @RoomNumber 
			AND xlatID = 'Room'

	IF EXISTS (SELECT KeyOut FROM dbo.tblXlat WHERE KeyIn = @RoomNumber + @Bed AND xlatID = 'Room')
	BEGIN
		SET @RoomNumber = @RoomNumber + @Bed
		
		SELECT @RoomNumber = KeyOut
		FROM dbo.tblXlat 
		WHERE KeyIn = @RoomNumber
			AND xlatID = 'Room'
	END

Finish:
        SELECT @RoomID = RoomID FROM dbo.tblRoomOHD (NOLOCK)
	    WHERE RoomNumber = @RoomNumber	


	RETURN @RoomID
    END
go

