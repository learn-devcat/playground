
CREATE PROCEDURE [dbo].[ScheduledReportGetPending]

AS
	SET NOCOUNT ON

	DECLARE @ReportWindow varchar(10),
		@ScheduledReportID int,
		@Today		datetime
		
	-- Set the date
	SET @Today = getdate()

	-- Get the report windows
	SELECT @ReportWindow = dbo.GetOverheadValue('ReportWindow')
	IF (@ReportWindow = '')
		SET @ReportWindow = '15'

	-- Update any reports that were missed for printing
	DECLARE Reports cursor FOR
		SELECT ScheduledReportID FROM dbo.tblScheduledReports
			WHERE NextDate <= DATEADD(m,CAST(@ReportWindow AS int),@Today)

	OPEN Reports
	FETCH NEXT FROM Reports INTO @ScheduledReportID

	WHILE (@@FETCH_STATUS=0)
	BEGIN
		EXEC dbo.ScheduledReportsIncrement @ScheduledReportID

		FETCH NEXT FROM Reports INTO @ScheduledReportID
	END	

	CLOSE Reports
	DEALLOCATE Reports

	-- Get reports to run
	SELECT ScheduledReportID,
		DefName,
		ReportTitle,
		ReportFile,
		ReportSQL,
		DefXML,
		PrinterName,
		NextDate,
		Frequency
	FROM dbo.tblScheduledReports
	WHERE NextDate <= getdate()
	ORDER BY PrinterName

	RETURN
go

