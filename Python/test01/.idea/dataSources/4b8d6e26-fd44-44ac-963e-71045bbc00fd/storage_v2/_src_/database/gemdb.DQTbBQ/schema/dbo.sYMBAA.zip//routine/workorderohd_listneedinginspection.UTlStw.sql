
CREATE   PROCEDURE dbo.WorkorderOHD_ListNeedingInspection
@User			char(10),
@LocationID     int
AS
	
	SELECT  WorkOrderID,
	        WorkOrderNumber,
	        LocationID,
	        WorkorderClassID,
	        ShortDescription, 
	        PO,
	        Description,
	        OpenDate,
	        OpeningEmployeeID,
	        ClosingDate,
	        ClosingEmployeeID,
	        Closed,
	        CompletionDate,
	        CompletingEmployeeID,
	        Completed,
	        Inspected,
	        InspectingEmployeeID,
	        EstimatedHours,
	        ActualHours,
	        AccountNo,
	        TransID,
	        Notes,
	        TotalCharge
    FROM    tblWorkOrderOHD
    WHERE   LocationID IN (SELECT LocationID FROM cfgUserLocations WHERE UserID = @User) AND  -- Our locations or 0 = all.
            Completed = 1 AND       -- IS Complete.
            Inspected = 0 AND       -- Not inspected
            Closed    = 0           -- AND NOT closed.
    RETURN
go

