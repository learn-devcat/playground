CREATE PROCEDURE [dbo].[tt5_Post4] 
@CoreID		INT,
@User		CHAR(10),
@BadgeNo	CHAR(19),
@Outlet		INT,
@TransID	INT,
@TerminalID	INT,
@ChkNum		CHAR(10),
@CashierID	INT,
@Subtotal	MONEY,
@Tax		MONEY,
@Dsc		MONEY,
@Svc		MONEY,
@Total		MONEY

AS
   /* This tt5_Post4 proc is based off of the tt5_Post2 proc
    03-Oct-13 jlb
		Included the lost or stolen filter in the initial check.
		Added a badge limit check.  If the transaction is over the badge limit it will return a
		"Over Badge Limit" error.
    27-Sep-13 jlb
		The TT5 is not sending the correct check number over so we are having to increment the check number by 1
   
    24-Aug-11 wjs
        Updated the receipt portions to center the output -- this makes the receipt move visually apealing.

    08-Oct-04 wjs 
        I changed the way the final results verified for correctness.  Previously, if we didn't explictily 
        capture an error, it would fall through as "success".   Now, I capture a 0 as success and if another
        code isn't present, we capture it as a "undefined error".
   
    2-14-2006 RBB
        Added code to use the "IsAllowed()" function instead of "Anding" the subtypes. The "IsAllowed()" function 
        now checks both methodologies for determining if an account can charge at a particular location	
   */


	DECLARE @Today 		DATETIME,
		@ChargeWindow 	DATETIME,			-- The amount of time we'll consider for a duplicate charge
		@ReturnCode  	INT,
		@AccountNo   	CHAR(19),
        @SP_Return		INT,
        @PostReturn		INT,
        @FirstName		CHAR(15),
        @LastName		CHAR(20),
        @Description	CHAR(32),
        @ReturnName		VARCHAR(24),
        @Balance		MONEY,
        @TransClassID	INT,
        @OutletSubtype 	INT,
        @TransDescription VARCHAR(35),
        @isDuplicate 	INT,
		@BadgeLimit		MONEY,
		@BadgeTotal		MONEY,
		@BadgeClassID 	INT

    SET NOCOUNT ON

	-- Removes badge swipe character if it exists in @BadgeNo
	SET @BadgeNo = dbo.RemoveBadgeSwipePrefix(@BadgeNo);

	-- Check to see if we have a badge number
    IF	(ISNULL(@BadgeNo,'') = '')
	BEGIN
		--Return a Badge Required error message
        SELECT '/Badge # Required'  + CHAR(28) + 'Press CLEAR To Continue' AS ReturnMsg
        RETURN
    END

    IF (LEFT(@BadgeNo,1) = '~' )			-- The TT5 may need some configuration.
        SET @BadgeNo = RIGHT(@BadgeNo , LEN(@BadgeNo) - 1)

    SET @Today = GETDATE()					-- Define here cauz can't use it in an EXEC call ...
    SET @ChargeWindow = GETDATE() - .05			-- How far back will we consider a duplicate charge.  (.05 is roughly an hour)
    SET @ReturnCode = 0
    
    SELECT 	TOP 1 @AccountNo = B.AccountNo,
			@BadgeLimit = B.Limit,
			@BadgeClassID = B.BadgeClassID
    FROM	dbo.tblBadgesOHD AS B
		LEFT JOIN	dbo.tblAccountOHD A ON A.AccountNo = B.AccountNo
		LEFT JOIN	dbo.tblAccountClass AC ON A.AccountClassID = AC.AccountClassID
    WHERE	B.BadgeNo = @BadgeNo
		AND B.Inactive = 0
		AND B.Lost = 0			--03-Oct-13 jlb  added the lost and stolen check
		AND B.Stolen = 0
		AND B.ActiveDate <= @Today
		AND B.ExpireDate >= @Today
		AND dbo.IsAllowed(@Outlet, A.AccountClassID, -1) <> 0
	ORDER BY	primaryBadge
	
    SET @AccountNo = ISNULL(@AccountNo,'')		-- wjs 05-Sep-12  previously we blanked the account No, but this is the same thing and fixes the next part where we will NEED the account NO to valid.

	IF(@@RowCount = 0)
	BEGIN
		SELECT '/Not Valid Here' + CHAR(28) + '/Error Code' + CHAR(28) + ' ' AS ReturnMsg
		RETURN
	END  
	
	-- jlb 03-Oct-13 Added a badge limit check to see if the transaction is over the badge limit.
	-- Get the badge total for the account and badge for the badge cycle.
	SELECT	@BadgeTotal=Total
	FROM 	dbo.tblBadgeTTL 
	WHERE	AccountNo = @AccountNo 
		AND BadgeNo = @BadgeNo 
		AND dbo.GetCycleByXREF(0,Date,'BC' + CAST(@BadgeClassID AS VARCHAR(10))) = dbo.GetCycleByXREF(0,@Today,'BC' + CAST(@BadgeClassID AS VARCHAR(10)))
			
	-- Check to see if the transaction is over the badge limit.
	IF (COALESCE(@BadgeTotal,0) + @Total >  @BadgeLimit)
	BEGIN
		SELECT '/Over Badge Limit' + CHAR(28) + '/Error Code' + CHAR(28) + ' ' AS ReturnMsg
	    RETURN
	END
	
	BEGIN TRY -- jlb 27-Sep-13  The TT5 is not sending the correct check number over so we are having to increment the check number by 1
		SET @ChkNum = @ChkNum + 1  
	END TRY
	BEGIN CATCH
	END CATCH			

	-- Let's check for dup.  If we get a hit, we're dup.
	SELECT  @Description = AccountNo
	FROM	dbo.tblDetail
	WHERE   AccountNo  = @AccountNo
		AND BadgeNo    = @Badgeno
		AND OutletNo   = @Outlet
		AND TransID    = @TransID
		AND TransTotal = @Total
		AND ChkNum     = @ChkNum
		AND TransDate between @ChargeWindow AND @Today
    
    IF( @@ROWCOUNT = 0 )
       SET @isDuplicate = 0
    ELSE
	BEGIN
		SET @isDuplicate = 1
		SET @SP_Return = 0
		SET @PostReturn = 0
	END
		
	IF( @isDuplicate = 0 )	
		EXEC @SP_Return = dbo.sp_PreChargeAuthorization @AccountNo, @BadgeNo, @Total, @TransID, @Outlet
 
    IF (@SP_Return = 0)
    BEGIN
		
		IF( @isDuplicate = 0 )					-- not a dup -- good, so let's post
			EXEC @PostReturn = dbo.sp_Trans_Post  @CoreID, @User,  @AccountNo, @BadgeNo , @Today , @Outlet , 'TT5', @ChkNum, @Total , @Total, @Outlet, -1 , @TransID		
		
        IF (@PostReturn = 0)
        BEGIN
            SELECT	@FirstName = A.FirstName,
                    @LastName = A.LastName,
                    @Description = A.Description,
                    @TransDescription = T.Description,
                    @Balance = CASE TC.DeclBalMode
                                    WHEN 0 THEN TT.Balance 
                                    ELSE -TT.Balance
                                END
            FROM	tblAccountOHD AS A
            LEFT JOIN tblAccountTTL AS TT ON	A.AccountNo = TT.AccountNo
            LEFT JOIN tblTransDef AS T ON	TT.TransClassID = T.TransClassID
            LEFT JOIN tblTransClass AS TC ON	T.TransClassID = TC.TransClassID
            WHERE	A.AccountNo = @AccountNo
                AND T.TransID = @TransID
                
            IF (@FirstName <> '' OR @LastName <> '')
                SET @ReturnName = RTRIM(@LastName) + ', ' + RTRIM(@FirstName)
            ELSE
                SET @ReturnName = @Description
                
        END
        
    END
       
    SELECT 	CASE @SP_Return
				WHEN '0'  THEN
					CASE @PostReturn
						WHEN 0 THEN '@' + @ReturnName + CHAR(28) + 'Balance: ' + CAST(@Balance AS VARCHAR(8)) + CHAR(28) + dbo.StringCenter( @ReturnName , 40) + 
							CHAR(13)+CHAR(10) + dbo.StringCenter('Transaction: APPROVED ' , 40) + CHAR(13)+CHAR(10) + dbo.StringCenter( @TransDescription , 40 ) + 
							CHAR(10) + CHAR(13) +  dbo.StringCenter( 'New Current Balance: ' + CAST(@Balance AS VARCHAR(10)) , 40 ) + CHAR(13) + 
							CHAR(10)  + '----------------------------------------' + CHAR(13) + CHAR(10) + '            ' + CAST(  getdate() as VARCHAR(30)) + CHAR(13) + CHAR(10)
						ELSE '/Invalid Location' + CHAR(28) + '/Error Code: ' + CAST(@PostReturn AS VARCHAR(10)) + CHAR(28) + ' '
					END
				WHEN '1' THEN '/Over Account Limit' + CHAR(28) + '/Error Code' + CHAR(28) + ' '
				WHEN '2' THEN '/Over Daily Limit' + CHAR(28) + '/Error Code' + CHAR(28) + ' '
				WHEN '3' THEN '/Badge Not On File' + CHAR(28) + '/Error Code' + CHAR(28) + ' '
				WHEN '4' THEN '/Badge Not Valid' + CHAR(28) + '/Error Code' + CHAR(28) + ' '
				WHEN '5' THEN '/Over Daily Qty' + CHAR(28) + '/Error Code' + CHAR(28) + ' '
				WHEN '6' THEN '/Over Badge Trans Limit' + CHAR(28) + '/Error Code' + CHAR(28) + ' '
				WHEN '7' THEN '/Over Account Trans Limit' + CHAR(28) + '/Error Code' + CHAR(28) + ' '
				WHEN '8' THEN '/Inactive Account' + CHAR(28) + '/Error Code' + CHAR(28) + ' '
				WHEN '9' THEN '/Over Badge Limit' + CHAR(28) + '/Error Code' + CHAR(28) + ' '
				WHEN '10' THEN '/Not Authorized Here' + CHAR(28) + '/Error Code' + CHAR(28) + ' '
				WHEN '11' THEN '/Outlet Not Defined' + CHAR(28) + '/Error Code' + CHAR(28) + ' '
				ELSE 
					'/Undefined Error #:' +  cast( @SP_Return AS VARCHAR(10)) + CHAR(28) + '/Error Code' + CHAR(28) + ' '      
				   
			END AS ReturnMsg
go

