



CREATE PROCEDURE [dbo].[CCS_PatientTransfer_v4]
@PatientVisitID varchar(50),
@RoomNumber     varchar(50),
@Source         varchar(50),
@Bed		varchar(20)='',
@PatientClass	varchar(32)='',
@Location		varchar(50)='',
@ConnectionName varchar(50)=''
AS
    DECLARE @PatientID	int,
	    @Msg        varchar(250),
            @RoomID     int,
            @PatientClassID	int,
	    @CurrentRoomID int,
	    @CurrentBed varchar(10),
            @SaveWhenOverwritten bit,
		@ResetRoom	varchar(10)

	IF (@RoomNumber = '')
		SET @RoomNumber = @Location
	ELSE
	BEGIN
	 	IF EXISTS (SELECT 1 FROM dbo.tblXlat WHERE xlatId = 'ExcludeLocation' AND KeyIn = @Location)
		BEGIN
			SET @Msg = 'Update record ignored for excluded location [' + @Location + ']. PatientVisitId [' + @PatientVisitID + ']'
		  	GOTO Finished
		END
	END

	SELECT @ResetRoom = COALESCE(dbo.GetOverheadValueNULL('ResetRoomOnBlank'),'0')
            
	-- Make sure roomnumber is valid
	SELECT @RoomID = dbo.RoomID(@RoomNumber, @Bed)  

	SELECT  @PatientID = PatientID,
	    @CurrentRoomID = RoomID,
	    @CurrentBed = Bed
	FROM    dbo.tblPatientVisit
	WHERE   PatientVisitID = @PatientVisitID

	SELECT @PatientClassID = dbo.PatientClassLookup(@PatientClass)

	-- Make sure patient is valid
	IF NOT EXISTS (SELECT 1 FROM dbo.tblPatientVisit (NOLOCK) WHERE PatientVisitID = @PatientVisitID AND DischargeDate IS NULL)
	BEGIN
		SET @Msg = 'Unable to process Transfer for PatientVisitID' + @PatientVisitID + '. PatientVisitID:' + @PatientVisitID + ' does not exist.'
		GOTO Finished
	END

	-- Execute the transfer by updating the roomnumber and bed
	UPDATE dbo.tblPatientVisit
	SET     RoomID = CASE WHEN @ResetRoom = '1' THEN @RoomID
				ELSE COALESCE(@RoomID, @CurrentRoomID) END,
	        Bed = @Bed,
	        PatientClassID = @PatientClassID
	WHERE   PatientVisitID = @PatientVisitID

	IF (@RoomID IS NULL AND @ResetRoom = '1')
	        -- Set the cancelled flag to 1 for any orders in future waves
	        UPDATE  dbo.tblOrderOHD
	        SET Cancelled = 1,
	            CancelDate = getdate()
	        FROM    dbo.tblOrderOHD AS O (NOLOCK)
	                JOIN tblPatientVisit AS P (NOLOCK) ON (O.PatientVisitID = P.PatientVisitID OR O.PatientVisitID = P.MergedTo)
	        WHERE O.OrderDate > getdate()
	                AND ISNULL(O.Cancelled,0) <> 1
		  AND O.PatientVisitID = @PatientVisitID

	IF NOT (@CurrentRoomID IS NULL)
	    UPDATE dbo.tblPatientVisit
		SET PreviousRoomID = @CurrentRoomID,
			LastUpdateBy = @Source,
			PreviousBed = @CurrentBed
		WHERE PatientVisitID = @PatientVisitID

	SET @Msg = 'Transferred patient to RoomNumber:' + @RoomNumber

	EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, @PatientVisitID, @RoomID, @Msg
	EXEC dbo.ProcessLogInsert @Source

	SET @Msg = NULL

Finished:

	IF NOT (@Msg IS NULL)    
	    EXEC dbo.Logit 1, @Msg, 'system'

	SET @ConnectionName = 'Idt' + @ConnectionName
	EXEC dbo.WorkstationUpdateByID @ConnectionName

	RETURN


go

