
CREATE   PROCEDURE dbo.LaborCenter_List
@User      	char(10),
@LocationID	int
AS 
	SELECT	LaborCenterID,
		Description,
		DeptAccountNo
	FROM	tblLaborCenter
	WHERE	LocationID IN (SELECT LocationID FROM cfgUserLocations WHERE UserID = @User)
	Order By Description
go

