
CREATE PROCEDURE dbo.MenuItemGet
@MenuItemID	     int,
@SearchString        varchar(200) = ''

AS
        SET NOCOUNT ON

	IF (@SearchString <> '')
	BEGIN
		DECLARE @SQL	nvarchar(4000),
			@Rows	int,
			@MergedTo varchar(32)

		CREATE TABLE #MyMenuItem
			(
			MenuItemID 	int,
			[Description]	varchar(50),
			POSDescription	varchar(50)
			)

		SET @SQL = 'INSERT INTO #MyMenuItem SELECT MenuItemID, [Description], POSLegend ' + 
				'FROM dbo.tblMenuItemOHD ' + @SearchString +
                                ' ORDER BY [Description]'

		EXEC sys.sp_executesql @SQL

		SELECT MenuItemID,
                        [Description]
                FROM #MyMenuItem
                ORDER BY [Description]

		DROP TABLE #MyMenuItem

		RETURN
	END

	SELECT 	MenuItemID,
		[Description],
		ISNULL(Cost,0) AS Cost,
		ISNULL(Price, 0) AS Price,
		POSMenuItemID,
		POSMenuItemSEQ,
		POSLegend, 
		MajorGroupSequence, 
		FamilyGroupSequence, 
		MenuItemGroupSequence,
		MenuItemTypeSequence, 
		MenuLevelClassSequence, 
		PrinterDefClassSequence,
		CrossReference1, 
		CrossReference2
	FROM	dbo.tblMenuItemOHD (NOLOCK)
	WHERE	MenuItemID = @MenuItemID

	RETURN
go

