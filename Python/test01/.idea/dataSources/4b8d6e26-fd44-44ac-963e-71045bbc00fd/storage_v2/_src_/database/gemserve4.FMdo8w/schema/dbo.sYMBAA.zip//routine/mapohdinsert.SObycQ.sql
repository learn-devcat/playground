

CREATE PROCEDURE dbo.MapOHDInsert
@MapNumber	int,
@Description	varchar(50),
@Title		varchar(50)='',
@SubTitle	varchar(50)='',
@CssSrc	varchar(128)='',
@href		varchar(255)='',
@Inactive	bit=0,
@Status		int=0,
@SubType	int=-1,
@Notes	text='',
@SecurityMask	int=-1,
@DefaultGBS	int=8,
@Row		int=0,
@Col		int=0,
@GridCol	int=50,
@GridRow	int=50,
@TitleStyle	varchar(255)='border:0;border-style:solid;border-color:red;z-index:5;Width:32;Position:Absolute;Top:150;Left:116',
@SubTitleStyle	varchar(255)='border:0;border-style:solid;border-color:red;z-index:5;Width:32;Position:Absolute;Top:150;Left:116'

AS
	INSERT INTO dbo.tblMapOHD (MapNumber, Title, SubTitle, Description, Notes, Inactive, Status, SubType, SecurityMask, DefaultGBS, Row, Col, 
				GridCol, GridRow, CssSrc, href, TitleStyle, SubTitleStyle)
		VALUES (@MapNumber, @Title, @SubTitle, @Description, @Notes, @Inactive, @Status, @SubType, @SecurityMask, @DefaultGBS, @Row, @Col,
				@GridCol, @GridRow, @CssSrc, @href, @TitleStyle, @SubTitleStyle)
go

