
----------------------------------------------------------------------------------
--
--  TimeString( datetime )                  15-Aug-03 w.j.scott
--
--  Return the time portion of the date/time field as a string, fixed at
--  5 characters with the center character being the ':'.  
--
--  e.g.,   01:01, 09:09, 10:01, 23:59
--           
--
-----------------------------------------------------------------------------------
CREATE FUNCTION dbo.TimeString (@WholeDate as datetime )
RETURNS char(5)
AS 
BEGIN 
	
    return  right( '0' + CAST(DATEPART(hh,@WholeDate) AS varchar(2)),2) + 
	        ':' + 
	        right( '0' + CAST(DATEPART(mi,@WholeDate) AS varchar(2)) ,2 )
	 
END
go

