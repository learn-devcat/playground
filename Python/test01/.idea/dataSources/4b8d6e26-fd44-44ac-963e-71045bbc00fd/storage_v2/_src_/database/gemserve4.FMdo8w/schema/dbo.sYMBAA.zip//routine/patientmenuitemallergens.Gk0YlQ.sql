

CREATE FUNCTION dbo.PatientMenuItemAllergens(@MI int, @PatientID int,@FieldSeparator char(1))
RETURNS varchar(255)
BEGIN
	DECLARE @POSMI int,
	                  @Return varchar(255),
		    @Allergen varchar(50)
    
	SET @Return = ''

	DECLARE Allergens cursor FOR
		SELECT cfgA.Description
		FROM tblPatientAllergens AS P (NOLOCK)
			JOIN tblMenuItemAllergens AS A ON P.AllergenID = A.AllergenID
			JOIN tblMenuItemOHD AS MI ON A.MenuItemID = MI.MenuItemID
			JOIN cfgAllergens as cfgA ON P.AllergenID = cfgA.AllergenID
		WHERE A.MenuItemID = @MI AND P.PatientID = @PatientID

	OPEN Allergens

	FETCH NEXT FROM Allergens INTO @Allergen

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @Return = @Return + @FieldSeparator + @Allergen
		
		FETCH NEXT FROM Allergens INTO @Allergen
	END

	CLOSE Allergens
	DEALLOCATE Allergens

	IF (LEN(@Return) > 0)
	BEGIN
		SET @Return = RIGHT(@Return,LEN(@Return)-1)
	END
	ELSE
		SET @Return = ''

	RETURN @Return	
END
go

