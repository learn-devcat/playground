
CREATE PROCEDURE [dbo].[GSI_MealPeriodImport]
@LoginUserID		varchar(250),
@MealPeriodID	int,
@Description	varchar(50),
@ShortName	varchar(10)=null

AS
	SET NOCOUNT ON

	IF (@MealPeriodID > 0)
		UPDATE dbo.tblMealPeriods
		SET [Description] = @Description,
			ShortName = COALESCE(@ShortName, M.ShortName)
		FROM	dbo.tblMealPeriods AS M
		WHERE M.MealPeriodID = @MealPeriodID
	ELSE
	BEGIN
		IF ((@ShortName IS NULL) OR (@ShortName = ''))
		BEGIN
			IF (LEN(@Description) < 10)
				SET @ShortName = @Description
			ELSE		
				SET @ShortName = LEFT(@Description, 10)
		END
			
		INSERT INTO dbo.tblMealPeriods ([Description], ShortName)
			VALUES (@Description, @ShortName)

	END
	RETURN
go

