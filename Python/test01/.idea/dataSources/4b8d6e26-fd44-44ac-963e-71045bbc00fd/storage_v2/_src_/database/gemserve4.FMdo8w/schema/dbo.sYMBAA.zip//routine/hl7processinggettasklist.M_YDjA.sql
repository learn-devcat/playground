CREATE PROCEDURE dbo.HL7ProcessingGetTaskList
@MessageType	varchar(32)
AS
	SET NOCOUNT ON

	SELECT CommandID,
		MessageType,
		[Name],
		[Description],
		ControlType,
		CommandType,
		Command,
		ReturnColumn,
		[Sequence],
		Active
	FROM dbo.tblHL7Processing
	WHERE MessageType = @MessageType
		AND Active = 1
	ORDER BY [Sequence]

	RETURN
go

