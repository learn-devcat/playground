
----------------------------------------------------------------------------------
--
--  OrderWaveDelete                  15-Aug-03 w.j.scott
--
--  Remove an entire WAVE from the database.  The detail entries, if any, are
--  also removed.
--
--
-----------------------------------------------------------------------------------
CREATE PROCEDURE dbo.OrderWaveDelete
@WaveID as int,
@Date as datetime
AS
	
	DELETE dbo.tblOrderOHD
	WHERE  WaveID = @WaveID 
	        AND dbo.dDateonly( OrderDate ) = dbo.dDateOnly( @Date )
		
	RETURN
go

