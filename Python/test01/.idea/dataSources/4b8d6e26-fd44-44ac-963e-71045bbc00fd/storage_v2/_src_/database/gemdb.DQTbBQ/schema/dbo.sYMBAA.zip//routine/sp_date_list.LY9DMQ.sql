


CREATE PROCEDURE dbo.sp_Date_List
@User			char(10),
@AccountNo		char(19),
@BadgeNo		char(19)=''
AS
	IF (@BadgeNo = '')
		SELECT	D.AccountNo,
				D.BadgeNo,
				RTRIM(B.FirstName) + ' ' + RTRIM(B.LastName) AS BName,
				dbo.Description_FullNameWithMiddle(RTRIM(A.[Description]), RTRIM(A.FirstName), RTRIM(A.LastName), RTRIM(A.MiddleName),0) AS AName,
				D.DateID,
				D.[Date],
				DC.Description
		FROM		tblDateOHD AS D INNER JOIN
				tblDateClass AS DC 
		ON		D.DateID = DC.DateID LEFT JOIN
				tblBadgesOHD AS B
		ON		B.AccountNo = D.AccountNo
				AND B.BadgeNo = D.BadgeNo
				LEFT JOIN tblAccountOHD AS A ON D.AccountNo = A.AccountNo
		WHERE	D.AccountNo = @AccountNo
		ORDER BY	Month(D.[Date]),Day(D.[Date])
	ELSE
		SELECT	D.AccountNo,
				D.BadgeNo,
				RTRIM(B.FirstName) + ' ' + RTRIM(B.LastName) AS BName,
				dbo.Description_FullNameWithMiddle(RTRIM(A.[Description]), RTRIM(A.FirstName), RTRIM(A.LastName), RTRIM(A.MiddleName),0) AS AName,
				D.DateID,
				D.[Date],
				DC.Description
		FROM		tblDateOHD AS D INNER JOIN
				tblDateClass AS DC 
		ON		D.DateID = DC.DateID LEFT JOIN
				tblBadgesOHD AS B
		ON		B.AccountNo = D.AccountNo
				AND B.BadgeNo = D.BadgeNo
				LEFT JOIN tblAccountOHD AS A ON D.AccountNo = A.AccountNo
		WHERE	D.AccountNo = @AccountNo AND
				(D.BadgeNo = @BadgeNo)
		ORDER BY	Month(D.[Date]),Day(D.[Date])
		
	DECLARE 	@cMsg  char(255),
			@CoreID	int
	SET @CoreID = dbo.GetCoreIDFromUser(@User)
	SET @cMsg = 'Listed all dates for  AccountNo <' + RTRIM(@AccountNo) + '>'
	EXEC sp_Logit 5 , @CoreID , @User , @cMsg
go

