CREATE PROCEDURE dbo.ad_BadgeClass_Insert
@User			char(10),
@BadgeClassID	int,
@Description	varchar(24),
@DailyLimit		money,
@DailyQtyLimit	int,
@Limit			money,
@ExpireDays		int,
@Status			int,
@BumpByValue	int,
@EnableWeb		int
AS 
	INSERT INTO	tblBadgeClass (BadgeClassID,Description,DailyLimit,DailyQtyLimit,Limit,ExpireDays,Status,BumpByValue,EnableWeb)
				VALUES(@BadgeClassID,@Description,@DailyLimit,@DailyQtyLimit,@Limit,@ExpireDays,@Status,@BumpByValue,@EnableWeb)
go

