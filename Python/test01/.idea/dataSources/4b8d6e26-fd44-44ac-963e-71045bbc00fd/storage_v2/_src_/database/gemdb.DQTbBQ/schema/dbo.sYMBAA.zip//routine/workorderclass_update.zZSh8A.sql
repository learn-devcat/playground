CREATE      PROCEDURE dbo.WorkorderClass_Update
@User               		char(10),
@WorkorderClassID   		int,
@Description        		varchar(50),
@PostChargeWhenComplete		bit,
@PostChargeAsCompleted		bit,
@PostChargeWhenWOClosed		bit,
@PostAltCharge			bit,
@CloseWorkOrderWhenComplete	bit,
@RequiresInspection		bit,
@PostItemChargesWhenWOClosed	bit
AS
	UPDATE	tblWorkorderClass
	SET	Description = @Description,
		PostChargeWhenComplete	= @PostChargeWhenComplete,
		PostChargeAsCompleted = @PostChargeAsCompleted,
		PostChargeWhenWOClosed	= @PostChargeWhenWOClosed,
		PostAltCharge	= @PostAltCharge,
		CloseWorkOrderWhenComplete = @CloseWorkOrderWhenComplete,
		RequiresInspection = @RequiresInspection,
		PostItemChargesWhenWOClosed = @PostItemChargesWhenWOClosed
	WHERE	WorkorderClassID = @WorkorderClassID
go

