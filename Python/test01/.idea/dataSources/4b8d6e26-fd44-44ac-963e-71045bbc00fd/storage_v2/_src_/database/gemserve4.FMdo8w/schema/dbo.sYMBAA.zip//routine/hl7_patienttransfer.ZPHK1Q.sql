CREATE PROCEDURE [dbo].[HL7_PatientTransfer]
@MedicalRecordID    varchar(30),
@PatientVisitID     varchar(50),
@RoomNumber         varchar(50),
@Source             varchar(50),
@Bed		        varchar(20)='',
@PatientClass	    varchar(32)=''
AS
    DECLARE @Msg        varchar(250),
            @RoomID     int,
            @PatientID  int,
            @PatientClassID	int,
	    @CurrentRoomID int,
	    @CurrentBed varchar(10),
            @SaveWhenOverwritten bit
            
    -- Make sure roomnumber is valid
    SELECT @RoomID = dbo.RoomID(@RoomNumber, @Bed)  
    SELECT @PatientID = PatientID
    FROM dbo.tblPatientVisit
    WHERE PatientVisitID = @PatientVisitID          

    SELECT  @CurrentRoomID = RoomID,
	    @CurrentBed = Bed
    FROM    dbo.tblPatientVisit
    WHERE   PatientVisitID = @PatientVisitID
    IF ( @RoomID IS NULL )
    BEGIN
	    SET @Msg = 'Unable to transfer room. RoomNumber:' + @RoomNumber + ' not found.'
	    GOTO TransError
    END

	SELECT @PatientClassID = dbo.PatientClassLookup(@PatientClass)

	-- Make sure patient is valid
	IF NOT EXISTS (SELECT PatientVisitID FROM dbo.tblPatientVisit (NOLOCK) WHERE PatientVisitID = @PatientVisitID AND DischargeDate IS NULL)
	BEGIN
		SET @Msg = 'Unable to process Transfer for PatientVisitID' + @PatientVisitID + '. PatientVisitID:' + @PatientVisitID + ' does not exist.'
		GOTO TransError
	END

    IF ( @Msg IS NULL )
        SET @Msg = 'Transferred patient to RoomNumber:' + @RoomNumber

    -- Execute the transfer by updating the roomnumber
    UPDATE dbo.tblPatientVisit
    SET     RoomID = @RoomID,
	        Bed = @Bed,
	        PatientClassID = @PatientClassID
    WHERE   PatientVisitID = @PatientVisitID

    IF NOT (@CurrentRoomID IS NULL)
    	UPDATE dbo.tblPatientVisit
	SET LastUpdateBy = @Source,
		PreviousRoomID = @CurrentRoomID,
		PreviousBed = @CurrentBed
	WHERE PatientVisitID = @PatientVisitID

    EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, @PatientVisitID, @RoomID, @Msg
    EXEC dbo.ProcessLogInsert @Source

    RETURN 
    
TransError:

	IF ( @Msg IS NULL )    
        SET @Msg = 'Unable to process transfer for PatientVisitID:' + @PatientVisitID
        
    EXEC dbo.Logit 1, @Msg, 'system'
go

