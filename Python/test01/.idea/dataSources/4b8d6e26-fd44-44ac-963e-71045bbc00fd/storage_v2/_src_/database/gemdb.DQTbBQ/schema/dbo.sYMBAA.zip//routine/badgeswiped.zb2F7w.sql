CREATE FUNCTION [dbo].[BadgeSwiped] (@BadgeNo char(19))  
	RETURNS bit
	AS
	BEGIN 
		DECLARE @Return bit, 
				@BadgeSwipePrefix varchar(10)

		SET @Return = 0

		SET @BadgeSwipePrefix = dbo.GetOverheadItem('BadgeSwipePrefix')

		IF (@BadgeSwipePrefix <> '')
		BEGIN
			IF (LEFT(@BadgeNo, 1) = @BadgeSwipePrefix)
				SET @Return = 1
		END
	
		RETURN @Return
	END
go

