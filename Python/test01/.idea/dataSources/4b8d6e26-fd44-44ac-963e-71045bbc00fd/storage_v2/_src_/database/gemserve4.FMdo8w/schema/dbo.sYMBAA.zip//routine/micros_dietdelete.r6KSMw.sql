CREATE PROCEDURE [dbo].[Micros_DietDelete]
@UserID		varchar(250),
@ObjectNumber int=0

AS
	SET NOCOUNT ON
	
	DECLARE @Msg varchar(200)
	
	IF (@ObjectNumber = 0)
	BEGIN
		SET @Msg = 'Invalid POS Object Number [' + CAST(@ObjectNumber AS varchar(50)) + ']. Diet not deleted!'
		GOTO Finished	
	END
	
	DELETE	MicrosMenuItems
	WHERE	obj_num = @ObjectNumber

	SET @Msg = 'Successfully deleted MICROS diet for POS Object Number[' + CAST(@ObjectNumber AS varchar(50)) + '].'

Finished:
	EXEC dbo.Logit 9000,@Msg,@UserID
	
	RETURN
go

