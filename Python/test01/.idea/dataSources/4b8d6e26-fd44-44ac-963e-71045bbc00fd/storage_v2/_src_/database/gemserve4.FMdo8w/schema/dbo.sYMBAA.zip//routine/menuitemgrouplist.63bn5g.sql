

CREATE PROCEDURE dbo.MenuItemGroupList
AS
	SET NOCOUNT ON
	
	SELECT MenuItemGroupID,
			MI_GRP_SEQ,
		OBJ_NUM,
		[NAME]
	FROM	dbo.tblMenuItemGroup
	WHERE 	[NAME] IS NOT NULL

	RETURN
go

