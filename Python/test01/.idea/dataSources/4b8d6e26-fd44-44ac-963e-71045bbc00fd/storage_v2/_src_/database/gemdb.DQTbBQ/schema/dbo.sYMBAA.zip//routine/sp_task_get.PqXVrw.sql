CREATE PROCEDURE [dbo].[sp_Task_Get]
	@User char(10),
	@TaskId int
AS

	DECLARE @UserRole int
	
	-- get the user's max role id
	SELECT @UserRole = MAX(PrivilegeClassId)
	FROM dbo.tblPrivilegeClassMembers
	WHERE UserID = @User;

	SELECT	O.TaskId,
			O.TaskName,
			M.Message AS [TaskNameMsg],
			O.MessageId,
			M2.Message,
			O.CategoryId,
			M3.Message AS [CategoryIdMsg],
			O.TaskType,
			O.Detail,
			O.Sequence,
			O.EntryId,
			O.EntryDate,
			O.MinPrivilegeClass
	FROM dbo.TaskOHD AS O
	LEFT JOIN dbo.tblMessages AS M
		ON M.ID = O.TaskName AND M.PageID = 'Tasks'
	LEFT JOIN dbo.tblMessages AS M2
		ON M2.ID = O.MessageId AND M.PageID = 'Tasks'
	LEFT JOIN dbo.tblMessages AS M3
		ON M3.ID = O.CategoryId AND M.PageID = 'Tasks'
	WHERE O.TaskId = @TaskId
		AND @UserRole >= O.MinPrivilegeClass;
go

