CREATE  PROCEDURE [dbo].[sim_IdleEvent]
    @CoreID as int,
    @LoginUserID		varchar(250),
    @WorkstationID		varchar(10)
AS
    SET NOCOUNT ON
    
    DECLARE @Temp				varchar(50),
        @SentOrderBuffer		int,
        @OrderID 				int,
        @RoomNumber 			varchar(20),
        @PatientName 			varchar(50),
        @PatientDietNotes		varchar(500),
        @PatientOHDNotes		varchar(500),
        @PatientNotes 			varchar(MAX),
		@PatientNotesLength		int,
        @PatientAllergens		varchar(500),
        @PatientLocation 		varchar(50),
        @PatientWaveDescription varchar(50),
        @SubLevel 				int,
        @DietName 				varchar(50),
        @OrderWorkstationID		int,
        @Detail 				varchar(2000),
        @PatientNameFlag 		int,
        @PatientNotesFlag 		int,
        @PatientLocationFlag	int,
        @PatientWaveDescriptionFlag int,
        @OrderDate 				datetime,
        @Retries				int,
        @NonSelectOrder 		bit,
        @StandingOrder			bit,
        @DietMenuLevel			int,
        @AppendBed				varchar(10),
        @OrderType				int,
        @OrderedFor				varchar(50),
        @LocationClassID		int,
        @MicrosOrderType		int,
        @Now					datetime,
        @LocationId				int,
        @KitchenId				int,
        @OfflineRuleId			int,
        @AlternateKitchenId		int,
        @Msg					varchar(200),
        @ORMSeparator			varchar(10),
        @DietId					int,
        @CurrentDietId			int,
        @OnHoldGuestOrdering	bit,
        @PatientDietId			int,
		@WorkstationIDName		varchar(13)

	SET @PatientNotesLength = 240
        
    SELECT @OnHoldGuestOrdering = COALESCE(dbo.GetOverheadValueNull('OnHoldGuestOrdering'),1)
    SELECT @ORMSeparator = COALESCE(dbo.GetOverheadValueNull('ORMSeparator'),'|')	
    SELECT @AppendBed = COALESCE(dbo.GetOverheadValueNull('AppendBed'),NULL)
        
    IF NOT EXISTS(SELECT WorkstationID FROM dbo.tblWorkstationsAllowed WHERE WorkstationID = @WorkstationID)
    BEGIN
        SELECT 'DONE' as rMsg
                RETURN
        END

    SET @Now = getdate()
    SET @WorkstationIDName = 'wrk' + @WorkstationID
    
    SET @Temp = dbo.GetOverheadValue('SendOrderRetries')
    IF ( @Temp = '' )
        SET @Retries = 2
    ELSE
        SET @Retries = CAST(@Temp as int)

    SET @Temp = dbo.GetOverheadValue('SentOrderBuffer')
    IF ( @Temp = '' )
        SET @SentOrderBuffer = 120
    ELSE
        SET @SentOrderBuffer = CAST(@Temp as int)

    SET @PatientNameFlag = dbo.GetOverheadValue('PatientNameOnOrder')
    SET @PatientNotesFlag = dbo.GetOverheadValue('PatientNotesOnOrder')
    SET @PatientLocationFlag = dbo.GetOverheadValue('PatientLocationOnOrder')
    SET @PatientWaveDescriptionFlag = dbo.GetOverheadValue('PatientWaveDescriptionOnOrder')

GetOrder:
    -- Get Order ID
    SELECT TOP 1 @OrderID = O.OrderID
    FROM dbo.tblOrderOHD AS O (NOLOCK)
    LEFT JOIN dbo.tblPatientOHD AS P (NOLOCK) ON O.PatientID = P.PatientID
    LEFT JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON O.PatientVisitID = PV.PatientVisitID 
    AND PV.MergedTo IS NULL
    AND PV.DischargeDate IS NULL
    LEFT JOIN dbo.tblRoomOHD AS R (NOLOCK) ON PV.RoomID = R.RoomID
    LEFT JOIN dbo.tblLocationClass AS C (NOLOCK) ON R.LocationClassID = C.LocationClassID
    LEFT JOIN dbo.tblDietOHD AS DIET (NOLOCK) ON PV.DietID = DIET.DietID
    LEFT JOIN dbo.tblWave AS W (NOLOCK) ON O.WaveID = W.WaveID
    LEFT JOIN dbo.tblNonSelectOHD AS SO (NOLOCK) ON PV.DietID = SO.DietID AND
        W.MealPeriodID = SO.MealPeriodID AND
        SO.DayOfWeek = DATEPART(dw,@Now)
    WHERE dbo.dDateOnly(O.OrderDate) = dbo.dDateOnly(@Now) 
        AND dbo.TimeString(O.OrderDate) <= dbo.TimeString(@Now)
        AND (O.Sent = 0 OR (O.Sent = 1 AND O.Received = 0 AND O.Retries < @Retries AND DATEDIFF(s, O.SentDate, @Now) > @SentOrderBuffer))
        AND ISNULL(O.Cancelled,0) = 0 
        AND DATEDIFF( s , O.Postdate , @Now) > 30
        AND ((COALESCE(P.OnHold, 0) <> 1) OR (O.OrderType <> 1 AND @OnHoldGuestOrdering = 1))		
        AND R.RoomNumber IS NOT NULL
    ORDER BY O.Sent DESC,  COALESCE(Rush,0) DESC, O.OrderDate, C.DeliveryPriority, RIGHT('000000000' + R.RoomNumber,10)

    IF (@@ROWCOUNT = 1)
    BEGIN
        -- Make sure the patient is still on the diet that they were on when the order was taken. If not, cancel the order and start over
        SELECT @CurrentDietId = dbo.GetActiveDiet(PatientVisitID, @Now),
               @PatientDietId = dbo.GetPatientDietID(PatientVisitID, @Now, dbo.TimeString(@Now)),
                @DietId = DietId,
                @OrderType = OrderType
        FROM dbo.tblOrderOHD
        WHERE OrderID = @OrderID

        IF (@OrderType = 1)
        BEGIN
            IF (@CurrentDietId <> @DietId)
            BEGIN
                UPDATE dbo.tblOrderOHD
                    SET Cancelled = 1,
                    CancelDate = @Now
                WHERE OrderID = @OrderID

                GOTO GetOrder
            END
        END

        -- Update the sentdate and the retry counter
        UPDATE dbo.tblOrderOHD
        SET Retries = Retries + 1
        WHERE OrderID = @OrderID

        SELECT TOP 1 @RoomNumber = 'RM ' + R.RoomNumber + CASE WHEN @AppendBed IS NULL THEN '-' + COALESCE(PV.Bed,'')
            ELSE '' END,
            @LocationClassID = R.LocationClassID,
            @PatientAllergens = dbo.PatientAllergens(O.PatientID),
            @PatientName = CASE
                        WHEN @PatientNameFlag = 1 THEN P.LastName + ',' + P.Firstname
                        ELSE ''
                    END ,
            @SubLevel = O.SubLevel,
            @DietName =  DIET.Description, 
            @OrderWorkstationID = O.WorkstationID,
            @Detail = CASE 
                    WHEN O.NonSelectOrder = 1 THEN dbo.GetNonSelectOrderDetail(SO.NonSelectOrderID)
                    ELSE dbo.GetOrderDetail(O.OrderID, @OrderType, 1)
                END,
            @OrderDate = O.OrderDate,
            @NonSelectOrder = O.NonSelectOrder,
            @StandingOrder = O.StandingOrder,
            @DietMenuLevel = COALESCE(PD.MenuLevel, DIET.MenuLevel, 1),				-- changed this to default to 1, since the SIM requires a value greater than 0 - 13-May-14 - rbishop
            @PatientDietNotes = CASE
                        WHEN (@PatientNotesFlag & 1) > 0 THEN ISNULL(dbo.GetActiveDietNotesEX(O.PatientVisitID,O.OrderDate,O.WaveID),'') 
                        ELSE ''
                    END ,
            @PatientOHDNotes = CASE
                        WHEN (@PatientNotesFlag & 2) > 0 THEN CAST(ISNULL(P.Notes,'') AS varchar(500))
                        ELSE ''
                    END,
            @PatientLocation = CASE WHEN @OrderType <> 1 THEN O.OrderedFor
					ELSE
						CASE WHEN @PatientLocationFlag = 1 THEN ISNULL(C.Description,'')
							WHEN @PatientLocationFlag = 2 THEN dbo.DateStringMMDDYYYY(ISNULL(P.BirthDate,''))
							WHEN @PatientLocationFlag = 3 THEN CAST(PV.PatientVisitID AS varchar(20))
							ELSE ''
						END
                    END,
            @PatientWaveDescription = CASE
                        WHEN @PatientWaveDescriptionFlag = 1 THEN ISNULL(W.Description,'')
                        ELSE ''
                    END,
            @OrderType = O.OrderType,
            @OrderedFor = O.OrderedFor
        FROM dbo.tblOrderOHD AS O (NOLOCK)
        LEFT JOIN dbo.tblPatientOHD AS P (NOLOCK) ON O.PatientID = P.PatientID
        LEFT JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON O.PatientVisitID = PV.PatientVisitID 
            AND PV.MergedTo IS NULL
            AND PV.DischargeDate IS NULL
        LEFT JOIN dbo.tblRoomOHD AS R (NOLOCK) ON PV.RoomID = R.RoomID
        LEFT JOIN dbo.tblLocationClass AS C (NOLOCK) ON R.LocationClassID = C.LocationClassID
        LEFT JOIN dbo.tblDietOHD AS DIET (NOLOCK) ON PV.DietID = DIET.DietID
        LEFT JOIN dbo.tblWave AS W (NOLOCK) ON O.WaveID = W.WaveID
        LEFT JOIN dbo.tblNonSelectOHD AS SO (NOLOCK) ON PV.DietID = SO.DietID AND
            W.MealPeriodID = SO.MealPeriodID AND
            SO.DayOfWeek = DATEPART(dw,@Now)
        LEFT JOIN dbo.tblPatientDiet AS PD ON PD.Id = @PatientDietId
        WHERE O.OrderID = @OrderID
            AND R.RoomNumber IS NOT NULL
        ORDER BY O.Sent DESC,  COALESCE(Rush,0) DESC, O.OrderDate, C.DeliveryPriority, RIGHT('000000000' + R.RoomNumber,10)
    END
    ELSE
    BEGIN
        EXEC dbo.WorkstationUpdateByID @WorkstationIDName

        SELECT 'DONE' as rMsg
        RETURN
    END

	-- Get the visit notes
    SET @PatientNotes = @PatientDietNotes

	-- Add the patient notes to the notes if set in the cfgOverhead table
    IF ((@PatientNotesFlag & 2) > 0)
		SET @PatientNotes = @PatientNotes + ' ' + @PatientOHDNotes

	-- Add the allergen notes to the notes if set in the cfgOverhead table
    IF ((@PatientNotesFlag & 4) > 0)
        SET @PatientNotes = @PatientNotes + ' Allergies: ' + @PatientAllergens

	-- Return only the allowed length of notes on the MICROS
	SET @PatientNotes = LEFT(@PatientNotes, @PatientNotesLength)
    
    -- Resolve the Kitchen
    SELECT @MicrosOrderType = O.[Value],
            @KitchenId = K.KitchenId
    FROM dbo.tblOrderTypes AS O (NOLOCK)
    JOIN dbo.tblKitchens AS K (NOLOCK) ON O.OrderTypeId = K.OrderTypeId
    JOIN dbo.tblLocationClass AS L (NOLOCK) ON L.KitchenId = K.KitchenId
    WHERE L.LocationClassID = @LocationClassID
        AND dbo.ValidateCS(K.KitchenId,K.Description,K.LicenseKey) = K.CSValue
        AND dbo.KitchenOpen(K.KitchenId, @Now) = 1
        AND K.Active = 1
        AND O.Active = 1

    IF (@MicrosOrderType IS NULL)
    BEGIN
        -- Resolved Kitchen is not valid, so process according to the rules
        SELECT @KitchenId = K.KitchenId,
                @OfflineRuleId = K.OfflineRuleId,
                @AlternateKitchenId = K.AlternateKitchenId
        FROM dbo.tblKitchens AS K (NOLOCK)
        JOIN dbo.tblLocationClass AS L (NOLOCK) ON L.KitchenId = K.KitchenId
        WHERE L.LocationClassID = @LocationClassID

        IF (@OfflineRuleId = 1)
        BEGIN
            -- Send to alternate kitchen
            SELECT @MicrosOrderType = O.[Value],
                @KitchenId = K.KitchenId
            FROM dbo.tblOrderTypes AS O (NOLOCK)
            JOIN dbo.tblKitchens AS K (NOLOCK) ON O.OrderTypeId = K.OrderTypeId
            WHERE K.KitchenId = @AlternateKitchenId
                AND dbo.ValidateCS(K.KitchenId,K.Description,K.LicenseKey) = K.CSValue
                AND dbo.KitchenOpen(K.KitchenId, @Now) = 1
                AND K.Active = 1
                AND O.Active = 1		

            IF NOT (@MicrosOrderType IS NULL)
                GOTO ProcessOrder
            ELSE	-- Set the order to Canceled
            BEGIN
                SET @Msg = 'Meal Order canceled -- Kitchen rule applied. Order ID [' + CAST(@OrderId AS varchar(10)) + ']'
                EXEC dbo.OrderSETCancelled @LoginUserID, @OrderID, 1, @Now, @Msg, 800
            END
        END
        ELSE
        BEGIN
            IF (@OfflineRuleId = 2)		-- Cancel the order
            BEGIN
                SET @Msg = 'Meal Order canceled -- Kitchen rule applied. Order ID [' + CAST(@OrderId AS varchar(10)) + ']'
                EXEC dbo.OrderSETCancelled @LoginUserID, @OrderID, 1, @Now, @Msg, 800
            END
            ELSE
            BEGIN
                -- TODO: Delay this meal until the next time the default kitchen is open
                -- Write a function to accomplish this -- have it return a time, which we will write to the tblOrderOHD table as OrderDate
                DECLARE @NewTime AS datetime
                SELECT @NewTime = dbo.GetNextKitchenOpenTime(@KitchenId, @Now)	

                IF NOT (@NewTime IS NULL)
                    UPDATE dbo.tblOrderOHD 
                    SET OrderDate = @NewTime
                    WHERE OrderId = @OrderId	
                ELSE
                BEGIN
                    SET @Msg = 'Meal Order canceled -- Kitchen rule applied. Order ID [' + CAST(@OrderId AS varchar(10)) + ']' 
                    EXEC dbo.OrderSETCancelled @LoginUserID, @OrderID, 1, @Now, @Msg, 800
                    
                END
                
                -- Make a recursive call to get the next order to process, since this one is being canceled or delayed
                EXEC dbo.sim_IdleEvent @CoreID, @LoginUserID, @WorkstationID
                GOTO Finish
            END
        END
    END
    ELSE
    BEGIN	    
ProcessOrder:
        -- stuff in the item that sets the Micros order type, which directs the order to the correct kitchen devices
        SET @Detail = @Detail + ',1,' + CAST(@MicrosOrderType AS varchar(10))
        
        IF (@OrderType <> 1)
        BEGIN
            SET @DietName = 'REGULAR'
            SET @PatientNotes = ''
            
            --IF (@PatientLocationFlag = 2) -- No longer needed 08-April-15 - rbishop
            --    SET @PatientLocation = ''
        END

        SET @PatientNotes = REPLACE(@PatientNotes, '^', @ORMSeparator)
        
        -- send the order to the Micros server
        SELECT 'ORDER' +char(28) + CAST(@OrderID as varchar(10)) + '^' + @RoomNumber + '^' + @PatientName + '^' + 
            CAST( @SubLevel as varchar(5)) + '^' +
            @DietName + '^' + dbo.DateString(@OrderDate) + ' ' + dbo.TimeString(@OrderDate) + '^' + @Detail + '^' +
            CAST(@DietMenuLevel as varchar(2)) + '^' + CAST(@OrderType as varchar(10)) + '^' + @OrderedFor + 
            '^' + @PatientNotes + '^' + @PatientLocation + '^' + @PatientWaveDescription  AS rsMsg

        -- Update the sentdate and the retry counter
        UPDATE dbo.tblOrderOHD
        SET SentDate = @Now
        WHERE OrderID = @OrderID

        EXEC OrderSetSENT @OrderID, 1, @KitchenId
    END

Finish:	
    EXEC dbo.WorkstationUpdateByID @WorkstationIDName
go

