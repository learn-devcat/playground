

CREATE PROCEDURE dbo.TaxMasterGet
@LocationID 	int
AS

	SET NOCOUNT ON

	SELECT	TaxMasterID,
		LocationID,
		TaxLevel,
		TaxRate
	FROM	dbo.tblTaxMaster
	WHERE	LocationID = @LocationID
	ORDER BY TaxLevel

	RETURN
go

