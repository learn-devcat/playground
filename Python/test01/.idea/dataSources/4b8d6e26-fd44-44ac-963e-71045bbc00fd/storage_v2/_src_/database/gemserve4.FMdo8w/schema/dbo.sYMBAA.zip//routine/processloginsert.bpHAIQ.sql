


CREATE PROCEDURE dbo.ProcessLogInsert
@Source     varchar(50)

AS
    DECLARE @ProcessTypeID  int
	
	UPDATE  dbo.tblProcessLog
	SET     ProcessCount = ProcessCount + 1,
	        LastProcessTime = getdate()
	FROM    dbo.tblProcessLog AS P (NOLOCK)
	        JOIN dbo.cfgProcessTypes AS T (NOLOCK) ON P.ProcessTypeID = T.ProcessTypeID
	WHERE   T.Source = @Source
	        AND dbo.dDateOnly(P.LastProcessTime) = dbo.dDateOnly(getdate())
	
	IF ( @@ROWCOUNT = 0 )
	BEGIN
	    SELECT  @ProcessTypeID = ProcessTypeID
	    FROM    dbo.cfgProcessTypes (NOLOCK)
	    WHERE   Source = @Source
	
	    INSERT INTO dbo.tblProcessLog (ProcessTypeID, ProcessCount, LastProcessTime)
	        VALUES (@ProcessTypeID, 1, getdate())
	        
	END
	
	RETURN
go

