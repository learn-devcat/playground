CREATE PROCEDURE [dbo].[LocationMenuItemsGet]
AS
SET NOCOUNT ON

	SELECT	LM.[LocationMenuItemID], 
			LM.LocationClassID,
			L.[Description] AS LocationName,
			LM.POSMenuItemID,
			MI.[Description] AS MenuItemName
	FROM	dbo.[tblLocationMenuItems] AS LM (NOLOCK)
	JOIN	dbo.tblLocationClass AS L (NOLOCK) ON L.LocationClassID = LM.LocationClassID
	LEFT JOIN dbo.tblMenuItemOHD AS MI (NOLOCK) ON LM.POSMenuItemID = MI.POSMenuItemID
	ORDER BY L.[Description], MI.[Description]

	RETURN
go

