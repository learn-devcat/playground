
CREATE     PROCEDURE dbo.WorkorderDTL_Delete
@User           char(10),
@WorkOrderID    int,
@WorkOrderDTLID int
AS
DECLARE @Err		int,
	@WOnum		varchar(50),
	@DTLDescr	varchar(50)
	--Get detail info for logging
	SELECT 	@WOnum 		= W.WorkorderNumber,
		@DTLDescr 	= DEF.ShortDescription
	FROM	tblWorkorderOHD as W
			LEFT JOIN
		tblWorkorderDTL as DTL on W.WorkorderID = DTL.WorkorderID
			LEFT JOIN
		tblWorkorderDTLdef as DEF on DTL.WorkorderDTLdefID = DEF.WorkorderDTLdefID
    	WHERE   DTL.WorkOrderID    = @WorkOrderID    AND
          	DTL.WorkOrderDTLID = @WorkOrderDTLID
	-- Do the delete
    	DELETE  tblWorkOrderDTL
    	WHERE   WorkOrderID    = @WorkOrderID    AND
            	WorkOrderDTLID = @WorkOrderDTLID
    IF @@Error <> 0 
      BEGIN
        -- TODO: Log the error
        RETURN
      END          
    -- TODO: Log the delete operation.
    SET @Err = @@Error
	
	DECLARE 	@cMsg  char(255),
			@CoreID	int
		SET @CoreID = dbo.GetCoreIDFromUser(@User)
		
		IF( @@Error = 0 )
  			SET @cMsg = 'Deleted Workorder\Item:  <' + RTRIM(@WOnum) + '\' + CAST(@WorkOrderDTLID as varchar(4)) + '>, The logged on user was: ' + @User + ', the item descr. was: ' + @DTLDescr 
 		ELSE
  			SET @cMsg = 'WorkorderDTL_Delete FAILED - Workorder\Item:  <' + RTRIM(@WOnum) + '\' + @WorkOrderDTLID + '>' 
	EXEC dbo.sp_Logit 0 , 0 , 'SYSTEM' , @cMsg, 900
	
    SELECT @cMsg
    RETURN
go

