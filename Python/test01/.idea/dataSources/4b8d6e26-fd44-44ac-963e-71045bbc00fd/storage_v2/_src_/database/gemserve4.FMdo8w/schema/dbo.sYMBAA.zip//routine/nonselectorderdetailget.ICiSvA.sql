CREATE  PROCEDURE [dbo].[NonSelectOrderDetailGet]
@LoginUserID              varchar(250),
@NonSelectOrderID      int

AS
            SET NOCOUNT ON

            SELECT           N.NonSelectItemID,
                        N.NonSelectOrderID,
                        N.MenuItemID,
                        M.[Description] AS 'MenuItemName',
                        M.Cost,
                        M.Price,
                        N.ItemType,
                        N.IsDiet,
                        N.IsFreeText,
                        N.[FreeText]
            FROM   dbo.tblNonSelectDetail AS N (NOLOCK)
		LEFT JOIN dbo.tblMenuItemOHD AS M (NOLOCK) ON M.MenuItemID = N.MenuItemID
            WHERE   N.NonSelectOrderID = @NonSelectOrderID

            RETURN
go

