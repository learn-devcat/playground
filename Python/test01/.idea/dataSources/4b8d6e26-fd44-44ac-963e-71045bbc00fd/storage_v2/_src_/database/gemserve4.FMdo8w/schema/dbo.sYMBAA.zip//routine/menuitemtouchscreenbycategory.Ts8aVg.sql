

CREATE PROCEDURE dbo.MenuItemTouchscreenByCategory
@MenuItemCategoryID int
AS
	SET NOCOUNT ON

	DECLARE @Buttons TABLE (Legend varchar(16) DEFAULT (''),
				Button int,
				Category varchar(32))

	DECLARE @MyCount int,
		@Category varchar(32)

	SELECT @Category = [Description]
	FROM	dbo.tblMenuItemCategory
	WHERE	MenuItemCategoryID = @MenuItemCategoryID

	SET @MyCount = 1
	
	WHILE (@MyCount <=48)
	BEGIN
		INSERT INTO @Buttons(Button, Category)
			VALUES(@MyCount, @Category)

		SET @MyCount = @MyCount + 1
	END

	UPDATE @Buttons
	SET Legend = REPLACE(CASE WHEN LEN(RTRIM(M.Legend)) > 14 THEN 
			LEFT(RTRIM(M.Legend),7) + CHAR(10) + SUBSTRING(RTRIM(M.Legend),8,7)
		WHEN LEN(RTRIM(M.Legend)) > 7 THEN LEFT(RTRIM(M.Legend),7) + CHAR(10) + SUBSTRING(RTRIM(M.Legend),8,LEN(RTRIM(M.Legend))-7)
		ELSE RTRIM(M.Legend) 
		END,',',' ')
	FROM	@Buttons AS B
		JOIN dbo.tblMenuItem_Touchscreen AS M ON B.Button = dbo.GetTSLocation(M.RowStart,M.ColStart)
	WHERE	M.MenuCategoryID = @MenuItemCategoryID 


	SELECT * FROM @Buttons ORDER BY Button
	RETURN
go

