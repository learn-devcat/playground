
CREATE FUNCTION dbo.NoOrderStatus
(
@Default char(3),
@CurrentDate datetime,
@DateOffset int,
@WaveID int,
@DietID int
)


RETURNS char(3)
AS

	BEGIN
	    DECLARE @WarnMinutes int,
	            @CriticalMinutes int,
	            @Status int,
	            @EndTime    char(5)

	DECLARE @MyWaves TABLE (WaveID int)

		INSERT INTO @MyWaves 
			SELECT W.WaveID FROM dbo.tblWave AS W (NOLOCK)
				JOIN dbo.tblDietWave AS DW (NOLOCK) ON W.WaveID = DW.WaveID AND DW.DietID = @DietID
				WHERE W.MealPeriodID = @WaveID
	            
	    IF NOT EXISTS (SELECT DietWaveID FROM dbo.tblDietWave (NOLOCK) WHERE DietID = @DietID AND WaveID IN (SELECT WaveID FROM @MyWaves))
            RETURN @Default	        
	                
	            
        SELECT TOP 1  @EndTime = EndTime,
                @WarnMinutes = WarningMinutes,
                @CriticalMinutes = CriticalMinutes
        FROM    tblWave
        WHERE   WaveID IN (SELECT WaveID FROM @MyWaves)
	ORDER BY EndTime DESC

        IF ( @CurrentDate > DATEADD(mi,-@CriticalMinutes, dbo.dDatePlusNewTime(@CurrentDate + @DateOffset,@EndTime)) )
        BEGIN
            SELECT  @Default = ActionID
            FROM    tblActions
            WHERE   ActionKey = 'NOORDERCRITICAL'
        END
        ELSE IF ( @CurrentDate > DATEADD(mi,-@WarnMinutes, dbo.dDatePlusNewTime(@CurrentDate + @DateOffset,@EndTime)) )
        BEGIN
            SELECT  @Default = ActionID
            FROM    tblActions
            WHERE   ActionKey = 'NOORDERWARN'
        END

	    RETURN @Default
	END
go

