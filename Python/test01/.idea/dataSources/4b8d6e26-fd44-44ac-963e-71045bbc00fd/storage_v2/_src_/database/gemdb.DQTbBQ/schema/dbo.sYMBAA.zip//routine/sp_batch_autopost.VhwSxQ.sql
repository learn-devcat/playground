

CREATE PROCEDURE dbo.sp_Batch_AutoPost
@User		char(10),
@BatchID	char(10)
AS
	DECLARE	@Date	as datetime
	SET @Date = getdate()
	EXEC dbo.sp_Batch_Post @User, @BatchID, @Date
go

