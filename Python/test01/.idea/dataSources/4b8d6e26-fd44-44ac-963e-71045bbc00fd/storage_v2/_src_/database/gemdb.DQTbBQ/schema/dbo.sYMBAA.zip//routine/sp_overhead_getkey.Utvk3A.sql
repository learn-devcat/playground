


CREATE  PROCEDURE dbo.sp_Overhead_GetKey
@User		char(10),
@SearchKey	varchar(32)
AS
	SELECT dbo.GetOverheadItem( @SearchKey ) AS sValue
go

