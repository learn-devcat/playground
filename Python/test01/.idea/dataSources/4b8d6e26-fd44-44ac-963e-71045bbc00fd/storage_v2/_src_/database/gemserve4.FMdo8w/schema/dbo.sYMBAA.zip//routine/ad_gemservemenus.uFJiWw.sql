


CREATE PROCEDURE dbo.ad_GEMserveMenus

AS
	DECLARE @ParentID	int

	INSERT INTO cfgWebMenus (ParentID, Description, MenuAction, MenuImage, MenuHoverImage, Sequence, IsSeparator, IsDisabled, IsChecked, MenuGroup, ActionID)
		VALUES(null, 'Patients', null, null, null, null, 0,0,0,0,150000)

	SET @ParentID = SCOPE_IDENTITY()
	
	INSERT INTO cfgWebMenus (ParentID, Description, MenuAction, MenuImage, MenuHoverImage, Sequence, IsSeparator, IsDisabled, IsChecked, MenuGroup, ActionID)
		VALUES(@ParentID, 'Manage Patients', '../Patients/Patients.aspx', null, null, null, 0,0,0,0,150005)

	INSERT INTO cfgWebMenus (ParentID, Description, MenuAction, MenuImage, MenuHoverImage, Sequence, IsSeparator, IsDisabled, IsChecked, MenuGroup, ActionID)
		VALUES(@ParentID, 'Group Discharge', '../Patients/GroupDischarge.aspx', null, null, null, 0,0,0,0,150010)
	

	INSERT INTO cfgWebMenus (ParentID, Description, MenuAction, MenuImage, MenuHoverImage, Sequence, IsSeparator, IsDisabled, IsChecked, MenuGroup, ActionID)
		VALUES(null, 'Order Status', null, null, null, null, 0,0,0,0,151000)

	SET @ParentID = SCOPE_IDENTITY()
	
	INSERT INTO cfgWebMenus (ParentID, Description, MenuAction, MenuImage, MenuHoverImage, Sequence, IsSeparator, IsDisabled, IsChecked, MenuGroup, ActionID)
		VALUES(@ParentID, 'Main', '../Orders/OrderStatus.aspx?MapID=101', null, null, null, 0,0,0,0,151005)
	
	INSERT INTO cfgWebMenus (ParentID, Description, MenuAction, MenuImage, MenuHoverImage, Sequence, IsSeparator, IsDisabled, IsChecked, MenuGroup, ActionID)
		VALUES(null, 'Administrative', null, null, null, null, 0,0,0,0,152000)
	
	SET @ParentID = SCOPE_IDENTITY()

	INSERT INTO cfgWebMenus (ParentID, Description, MenuAction, MenuImage, MenuHoverImage, Sequence, IsSeparator, IsDisabled, IsChecked, MenuGroup, ActionID)
		VALUES(@ParentID, 'Manage Diets', '../Administrative/Diets.aspx', null, null, null, 0,0,0,0,152010)
	
	INSERT INTO cfgWebMenus (ParentID, Description, MenuAction, MenuImage, MenuHoverImage, Sequence, IsSeparator, IsDisabled, IsChecked, MenuGroup, ActionID)
		VALUES(@ParentID, 'Manage Waves', '../Administrative/Waves.aspx', null, null, null, 0,0,0,0,152020)

	INSERT INTO cfgWebMenus (ParentID, Description, MenuAction, MenuImage, MenuHoverImage, Sequence, IsSeparator, IsDisabled, IsChecked, MenuGroup, ActionID)
		VALUES(@ParentID, 'Setup', '../Administrative/Overhead.aspx', null, null, null, 0,0,0,0,152030)
	
	INSERT INTO cfgWebMenus (ParentID, Description, MenuAction, MenuImage, MenuHoverImage, Sequence, IsSeparator, IsDisabled, IsChecked, MenuGroup, ActionID)
		VALUES(null, 'Logoff', '../Common/Logon.aspx', null, null, null, 0,0,0,0,155000)
go

