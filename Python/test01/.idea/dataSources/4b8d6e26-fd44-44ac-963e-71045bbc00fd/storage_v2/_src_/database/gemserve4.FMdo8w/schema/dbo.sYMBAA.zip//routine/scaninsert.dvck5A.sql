


CREATE PROCEDURE dbo.ScanInsert
@OrderID	int,
@RoomID		int,
@ScanTime	datetime,
@ActionID	int,
@BatchID	varchar(20) = 'system'
AS

	SET NOCOUNT ON

	INSERT INTO dbo.tblScan (BatchID, OrderID, RoomID, ScanTime, ActionID)
		VALUES (@BatchID, @OrderID, @RoomID, @ScanTime, @ActionID)

	RETURN
go

