CREATE FUNCTION dbo.GetMealPeriodByWave(@WaveID int)
RETURNS int
BEGIN
	DECLARE @Return	int

	SELECT @Return = MealPeriodID
	FROM dbo.tblWave
	WHERE WaveID = @WaveID

	RETURN ISNULL(@Return, 0)
END
go

