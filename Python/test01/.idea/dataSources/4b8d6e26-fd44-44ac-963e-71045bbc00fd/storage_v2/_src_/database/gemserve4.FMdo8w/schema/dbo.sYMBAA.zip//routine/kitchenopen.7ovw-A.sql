CREATE FUNCTION [dbo].[KitchenOpen]
(
	@KitchenId	INT,
	@Today		DATETIME
)
RETURNS INT
AS
BEGIN
	DECLARE @Return INT
	
	IF EXISTS (
		SELECT 1 FROM dbo.tblKitchenTimes (NOLOCK)
		WHERE KitchenId = @KitchenId
			AND DATEPART(dw,@Today) = [Day]
			AND dbo.TimeString(@Today) BETWEEN StartTime AND EndTime)
		SET @Return = 1
	ELSE
		SET @Return = 0

	RETURN @Return
END
go

