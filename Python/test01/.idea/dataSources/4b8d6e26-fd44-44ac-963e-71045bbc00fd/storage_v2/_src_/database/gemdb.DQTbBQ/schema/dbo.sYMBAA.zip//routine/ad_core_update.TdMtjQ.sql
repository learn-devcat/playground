

CREATE PROCEDURE dbo.ad_Core_Update
@User			char(10),
@CoreID		int,
@Active		bit,
@Description		varchar(32),
@Category		char(10),
@SWKEY		char(20),
@SWPIN		char(20),
@myIP			char(15),
@ExceptionIP		char(15),
@SysOptions		char(10),
@CycleNo		int
AS
	UPDATE	cfgCore
	SET		Active = @Active,
			Description = @Description,
			Category = @Category,
			SWKEY = @SWKEY,
			SWPIN = @SWPIN,
			myIP = @myIP,
			ExceptionIP = @ExceptionIP,
			SysOptions = @SysOptions,
			CycleNo = @CycleNo
	WHERE	CoreID = @CoreID
go

