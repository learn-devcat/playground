

CREATE PROCEDURE dbo.sp_Delete_Address
@AddressID		char(10),
@AccountNo		char(19)
AS
	DELETE	tblAccountAddress
	WHERE 	(AddressID=@AddressID AND AccountNo=@AccountNo)
go

