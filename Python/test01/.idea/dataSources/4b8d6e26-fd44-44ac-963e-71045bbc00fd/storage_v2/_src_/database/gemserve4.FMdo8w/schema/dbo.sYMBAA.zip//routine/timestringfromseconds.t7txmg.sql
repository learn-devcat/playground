

CREATE FUNCTION [dbo].[TimeStringFromSeconds](@Input as integer)
RETURNS varchar(25)
AS
BEGIN

        DECLARE @Hours int,
                @Minutes int,
                @Seconds int
        
        SET @Minutes = @Input / 60
        SET @Seconds = @Input % 60
        SET @Hours = @Minutes / 60
        SET @Minutes = @Minutes % 60

        RETURN CAST(@Hours AS varchar(2)) + ':' + 
                RIGHT('0' + CAST(@Minutes AS varchar(2)), 2) + ':' + 
                RIGHT('0' + CAST(@Seconds AS varchar(2)), 2)
END
go

