

CREATE PROCEDURE dbo.sp_Date_Get
@User			char(10),
@DateID		int,
@AccountNo		char(19),
@BadgeNo		char(19)=''
AS
	IF (@BadgeNo = '')
		SELECT	D.DateID,
				D.AccountNo,
				D.BadgeNo,
				D.[Date],
				DC.Description
		FROM		tblDateOHD AS D INNER JOIN
				tblDateClass AS DC
		ON		D.DateID = DC.DateID
		WHERE	(D.DateID = @DateID AND
				 D.AccountNo = @AccountNo)
	ELSE
		SELECT	D.DateID,
				D.AccountNo,
				D.BadgeNo,
				D.[Date],
				DC.Description
		FROM		tblDateOHD AS D INNER JOIN
				tblDateClass AS DC
		ON		D.DateID = DC.DateID
		WHERE	(D.DateID = @DateID AND
				 D.AccountNo = @AccountNo AND
  				 D.BadgeNo = @BadgeNo)
	
	DECLARE 	@cMsg  char(255),
			@CoreID	int
	SET @CoreID = dbo.GetCoreIDFromUser(@User)
	SET @cMsg = 'Retrieved date for AccountNo <' + RTRIM(@AccountNo) + '>'
	EXEC dbo.sp_Logit 4 , @CoreID , @User , @cMsg
go

