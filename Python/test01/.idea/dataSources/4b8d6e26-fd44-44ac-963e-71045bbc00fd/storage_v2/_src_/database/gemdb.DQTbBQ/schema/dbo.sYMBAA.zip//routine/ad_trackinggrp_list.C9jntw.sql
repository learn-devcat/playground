

CREATE PROCEDURE dbo.ad_TrackingGrp_List
@User		char(10)
AS
	SELECT 	TrackingGrp,
			Description
	FROM		tblTrackingOHD
	ORDER BY	Description
go

