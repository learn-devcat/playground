

CREATE PROCEDURE dbo.MapDetailDelete    
@MAPNumber  int

AS
    DELETE dbo.tblMapData WHERE MAPNumber = @MAPNumber
go

