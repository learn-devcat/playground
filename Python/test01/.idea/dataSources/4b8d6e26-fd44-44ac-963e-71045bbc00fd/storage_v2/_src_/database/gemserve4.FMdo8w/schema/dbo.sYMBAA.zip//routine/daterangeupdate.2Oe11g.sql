CREATE   PROCEDURE dbo.DateRangeUpdate
@Description varchar(50),
@BeginCode varchar(500),
@EndCode varchar(500),
@DateRangeID int = -1

AS
	SET NOCOUNT ON 
	
	IF (@DateRangeID = -1)
	BEGIN
		INSERT INTO dbo.tblDateRange([Description], BeginCode, EndCode)
		     VALUES(@Description, @BeginCode, @EndCode)
	END
	ELSE
	BEGIN
		UPDATE 	dbo.tblDateRange
		SET 	[Description] = @Description,
			BeginCode = @BeginCode,
			EndCode = @EndCode
		WHERE   DateRangeID = @DateRangeID
	END

	RETURN
go

