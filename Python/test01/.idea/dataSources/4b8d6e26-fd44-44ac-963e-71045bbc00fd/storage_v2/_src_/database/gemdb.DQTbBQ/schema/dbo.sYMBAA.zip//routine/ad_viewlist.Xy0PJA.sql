

CREATE PROCEDURE dbo.ad_ViewList
AS
	SELECT Name 
	FROM sysobjects
	WHERE xtype = 'V' 
	AND category <> 2 
	ORDER BY Name
go

