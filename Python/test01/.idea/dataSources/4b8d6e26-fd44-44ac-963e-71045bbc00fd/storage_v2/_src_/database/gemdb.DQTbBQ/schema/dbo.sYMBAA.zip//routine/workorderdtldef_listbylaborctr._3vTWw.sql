
CREATE       PROCEDURE dbo.WorkorderDTLDef_ListByLaborCtr
@User		char(10), 
@LocationID    	int,
@LaborCenterID	int	
AS
	SELECT	DEF.WorkOrderDTLDefID,
		DEF.LocationID,
		DEF.WorkOrderDTLClassID,
		DEF.EmployeeClassID,
		DEF.ShortDescription,
		DEF.Description,
		DEF.SkillLevel,
		DEF.Price,
		DEF.Cost,
		DEF.EstimatedHours,
		DEF.LeadTime,
		DEF.TransID,
		L.Description as 'LaborCenterName'
    	FROM   	tblWorkOrderDTLDef as DEF
			LEFT JOIN
		tblLaborCenter as L ON L.LaborCenterID = DEF.LaborCenterID
	WHERE	DEF.LaborCenterID = @LaborCenterID
    	Order BY  WorkOrderDTLClassID, WorkOrderDTLDefID, EmployeeClassID, SkillLevel
    RETURN
go

