


CREATE PROCEDURE dbo.OrderSETSent
(
    @OrderID int,
    @Sent    int = 1,
    @KitchenId int = 0
)
AS
	SET NOCOUNT ON 

	UPDATE dbo.tblOrderOHD
	SET Sent = @Sent,
		SentToKitchenId = @KitchenId
	WHERE OrderID = @OrderID
   
	IF @@Error = 0
	BEGIN
	    EXEC dbo.UpdateOrderLOG 'System' , @OrderID , 'SEND'
	    
	    SELECT  @Sent = ActionID
	    FROM    dbo.tblActions
	    WHERE   ActionKey = 'SEND'
	    
	    EXEC dbo.UpdatePatientOrderStatus @OrderID, @Sent
	END
	    
	RETURN
go

