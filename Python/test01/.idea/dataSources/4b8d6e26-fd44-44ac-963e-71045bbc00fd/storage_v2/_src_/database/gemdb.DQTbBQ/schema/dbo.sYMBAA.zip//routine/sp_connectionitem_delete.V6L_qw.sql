

CREATE PROCEDURE dbo.sp_ConnectionItem_Delete
@ConnectionID int
AS
	DELETE	cfgConnection
	WHERE	ConnectionID = @ConnectionID
go

