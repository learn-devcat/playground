

CREATE PROCEDURE dbo.gem_TransClassExclusions
@TransClassID int
AS
	DECLARE @TotalOutlet int,
		@Count int,
		@AccountClassID int,
		@OutletNo int,
		@AllOutlet varchar(100),
		@TempOutlet varchar(100),
		@SQL	nvarchar(100)
	
	-- Create a temporary table to hold AccountClasses AND Outlets
	CREATE TABLE #Temp (AccountClassID int, OutletList varchar(100))
	
	INSERT INTO #Temp (AccountClassID)
	 	SELECT AccountClassID
	 	FROM tblAccountClass
	 
	-- Add the correct number of columns to the temporary table for all the TransClasses
	SELECT @TotalOutlet = COUNT(OutletNo) FROM tblOutletOHD
	SET @Count = 0
	
	WHILE @TotalOutlet > 0
	BEGIN
		SET @SQL = 'ALTER TABLE #Temp ADD OutletNo' + CAST(@Count AS varchar(2)) + ' varchar(32)'
		EXEC sp_executesql @SQL
	
		SET @TotalOutlet = @TotalOutlet - 1
		SET @Count = @Count + 1
	END
	
	-- Initialize counters
	SET @Count = 0
	SET @AllOutlet = ''
	
	-- Get a listing of all the Outlets
	DECLARE Outlet cursor FOR
		SELECT OutletNo FROM tblOutletOHD 
		ORDER BY OutletNo
	 
	OPEN Outlet
	 
	FETCH NEXT FROM Outlet INTO @OutletNo
	 
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @AllOutlet = @AllOutlet + CAST(@OutletNo AS varchar(5)) + ','
	
	 	FETCH NEXT FROM Outlet INTO @OutletNo
	END
	
	CLOSE Outlet
	DEALLOCATE Outlet
	
	-- Loop through the temporary table AND UPDATE the Outlet VALUES
	DECLARE AccountClass cursor FOR
		SELECT AccountClassID FROM #Temp
			ORDER BY AccountClassID
	
	OPEN AccountClass
	
	FETCH NEXT FROM AccountClass INTO @AccountClassID
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
	
		SET @TempOutlet = @AllOutlet
		SET @Count = 0
	
		WHILE @TempOutlet <> ''
		BEGIN
			SET @OutletNo = CAST(LEFT(@TempOutlet,CHARINDEX(',',@TempOutlet)-1) AS int)
	
			-- IF the combination exists in our exclusion table, then SET to 1. Otherwise, SET to 0.
			IF EXISTS (SELECT TransClassID FROM tblExclusions
					WHERE OutletNo = @OutletNo AND
						AccountClassID = @AccountClassID AND
						TransClassID = @TransClassID)
	
				SET @SQL = 'UPDATE #Temp SET OutletNo' + CAST(@Count AS varchar(2)) + 
					' = 1 WHERE AccountClassID=' + CAST(@AccountClassID AS varchar(10))
			ELSE
				SET @SQL = 'UPDATE #Temp SET OutletNo' + CAST(@Count AS varchar(2)) + 
					' = 0 WHERE AccountClassID=' + CAST(@AccountClassID AS varchar(10))
	
			EXEC sp_executesql @SQL
	
			SET @Count = @Count + 1
			SET @TempOutlet = RIGHT(@TempOutlet,LEN(@TempOutlet) - CHARINDEX(',',@TempOutlet))
		END
	
		FETCH NEXT FROM AccountClass INTO @AccountClassID
	END
	
	CLOSE AccountClass
	DEALLOCATE AccountClass
	UPDATE #Temp SET OutletList = LEFT(@AllOutlet, LEN(@AllOutlet)-1)
	
	SELECT * FROM #Temp
	
	DROP TABLE #Temp
go

