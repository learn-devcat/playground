

CREATE PROCEDURE dbo.ad_MealPlanOHD_List
@AccountNo		char(19)
AS
	IF (@AccountNo = '')
		SELECT	MealPlanID,
				Name,
				Status,
				SubType,
				Freq,
				InitialNumPeriods,
				FirstDayOfWeek,	
				ReloadQty,
				ReloadBalance
		FROM 		tblPlanOHD 
		ORDER BY	Name
	ELSE
		SELECT DISTINCT	P.MealPlanID,
				P.Name,
				P.Status,
				P.SubType,
				P.Freq,
				P.InitialNumPeriods,
				P.FirstDayOfWeek,	
				P.ReloadQty,
				P.ReloadBalance
		FROM 		tblPlanOHD AS P
				LEFT JOIN tblAccountMeal AS A ON P.MealPlanID = A.MealPlanID AND A.AccountNo <> @AccountNo
		ORDER BY	Name
go

