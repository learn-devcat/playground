

CREATE PROCEDURE dbo.sp_Date_Delete
@User			char(10),
@DateID		int,
@AccountNo		char(19),
@BadgeNo		char(19)=''
AS
	DELETE	tblDateOHD
	WHERE	 (DateID = @DateID AND 
			 AccountNo = @AccountNo AND
			 BadgeNo = @BadgeNo)
	
	DECLARE 	@cMsg  char(255),
			@CoreID	int
	SET @CoreID = dbo.GetCoreIDFromUser(@User)
	SET @cMsg = 'Deleted date record <' + RTRIM(@DateID) + '> for Account No <' + RTRIM(@AccountNo) + '> AND Badge No <' + RTRIM(@BadgeNo) + '>'
	EXEC dbo.sp_Logit 2 , @CoreID , @User , @cMsg
go

