CREATE PROCEDURE dbo.PatientHistoryGet
@PatientVisitID		varchar(50)
AS
	SET NOCOUNT ON

	DECLARE @Today	datetime

	SET @Today = getdate()

		SELECT	R.RoomNumber,
		P.[Date],
		P.[Description],
		P.LoginUserID
	FROM	dbo.tblPatientLog AS P (NOLOCK)
		LEFT JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON P.PatientVisitID = PV.PatientVisitID
		LEFT JOIN dbo.tblRoomOHD AS R (NOLOCK) ON P.RoomID = R.RoomID
	WHERE	 PV.PatientVisitID = @PatientVisitID		
	UNION 
	SELECT  COALESCE(R2.RoomNumber, R.RoomNumber) AS RoomNumber,
		ISNULL(L.[Date], O.PostDate) AS Date,
		A.[Description] + ' for ' + UPPER(RTRIM(W.[Description])) +
			CASE
				WHEN COALESCE(O.Cancelled, 0) = 1 THEN ' (canceled)'
				WHEN O.Sent = 0 and dbo.DateString(O.PostDate) = dbo.DateString(O.OrderDate) THEN ' (Not Sent Yet)'
				ELSE ' (Sent)'
			END  as description,
		L.LoginUserID		
	FROM dbo.tblOrderLOG L (NOLOCK)
		JOIN dbo.tblActions AS A (NOLOCK) ON L.ActionID = A.ActionID
		JOIN dbo.tblOrderOHD AS O (NOLOCK) ON L.OrderID = O.OrderID
		JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON O.PatientVisitID = PV.PatientVisitID
		LEFT JOIN dbo.tblRoomOHD AS R2 (NOLOCK) ON R2.RoomID = O.RoomID
		LEFT JOIN dbo.tblRoomOHD as R (NOLOCK) on R.RoomID = PV.RoomID
		LEFT JOIN dbo.tblWave AS W (NOLOCK) ON W.WaveID = O.WaveID
	WHERE	PV.PatientVisitID = @PatientVisitID AND PV.DischargeDate IS NULL
	ORDER BY [Date] DESC

	RETURN
go

