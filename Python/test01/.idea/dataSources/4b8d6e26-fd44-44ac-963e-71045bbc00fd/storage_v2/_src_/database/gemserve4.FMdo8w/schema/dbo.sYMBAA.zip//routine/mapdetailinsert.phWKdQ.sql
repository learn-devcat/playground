

CREATE PROCEDURE dbo.MapDetailInsert
@MapItemType    int,
@MAPNumber      int,
@Label          varchar(10),
@Row            int,
@Col            int,
@Width          int,
@Height         int,
@Orientation    int,
@ImgSrc         varchar(128),
@Href           varchar(128),
@Prefix         varchar(5) = 'S',
@Layer          int = 1
AS
	SET NOCOUNT ON
	
	INSERT INTO dbo.tblMapData (MapItemType, MAPNumber, Label, Row, Col, Width, Height,
	        Orientation, ImgSrc, Href, Prefix, Layer)
	Values (@MapItemType, @MAPNumber, @Label, @Row, @Col, @Width, @Height,
	        @Orientation, @ImgSrc, @Href, @Prefix, @Layer)
go

