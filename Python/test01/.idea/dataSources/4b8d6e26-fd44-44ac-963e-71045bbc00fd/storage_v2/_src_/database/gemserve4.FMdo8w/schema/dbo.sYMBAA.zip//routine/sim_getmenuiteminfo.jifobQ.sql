CREATE PROCEDURE dbo.sim_GetMenuItemInfo
@CoreID	smallint ,
@User		char(10),
@PatientVisitID varchar(50),
@POSMI	int,
@NumQty	int =1,
@VoidStatus      smallint = 1
AS

Declare @status         	 	varchar(2),
        @PatientMIAllergens	varchar(255),
        @PatientMINutrients	varchar(255),
	@MI			int,
	@PatientID	int

	SET NOCOUNT ON		

	SELECT @PatientID = PV.PatientID
	FROM	dbo.tblPatientVisit AS PV (NOLOCK) 
	WHERE PV.PatientVisitID = @PatientVisitID
	
             Select @status =    Case 
	        when @voidStatus = 0 then 1 
	Else  -1
             End

	SELECT @MI = ISNULL(MenuItemID,0)
	FROM tblMenuItemOHD (NOLOCK)
	WHERE POSMenuItemID = @POSMI

    	
	SET @PatientMIAllergens = ''
 	SET @PatientMINutrients = ''

	-- Get Allergens if exist for this patient and menuitem and limit the return string to a total of 60 characters.  Anything longer will cause a ISL buffer overrun error on the Micros.
	SET @PatientMIAllergens = dbo.PatientMenuItemAllergens(@Mi, @PatientID, ',')
	IF (LEN(@PatientMIAllergens) > 57)
		SET @PatientMIAllergens = LEFT(@PatientMIAllergens, 57) + '...'

   	-- Get Nutrient counts for this menuitem
	SET @PatientMINutrients = dbo.MenuItemNutrients(@Mi,@NumQty,@VoidStatus, ',')

	SELECT Cast(@POSMI as varchar(10)) + char(28) + @PatientMIAllergens + char(28) + @PatientMINutrients
go

