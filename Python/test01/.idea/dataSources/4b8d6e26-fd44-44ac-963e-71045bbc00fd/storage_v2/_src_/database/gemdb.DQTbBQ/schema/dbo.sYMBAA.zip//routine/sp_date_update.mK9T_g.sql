

CREATE PROCEDURE dbo.sp_Date_Update
@User			char(10),
@DateID		int,
@NewDateID		int,
@Date			datetime,
@AccountNo		char(19),
@BadgeNo		char(19)=''
AS
	UPDATE	tblDateOHD
	SET		DateID = @NewDateID,
			AccountNo = @AccountNo,
			BadgeNo = @BadgeNo,
			[Date] = @Date
	WHERE	(DateID = @DateID AND
			 AccountNo = @AccountNo AND
			 BadgeNo = BadgeNo)
	
	DECLARE 	@cMsg  char(255),
			@CoreID	int
	SET @CoreID = dbo.GetCoreIDFromUser(@User)
	SET @cMsg = 'Updated Date ID <' + RTRIM(@NewDateID) + '> for Account No <' + RTRIM(@AccountNo) + ' AND Badge No <' + RTRIM(@BadgeNo) + '>'
	EXEC dbo.sp_Logit 2 , @CoreID , @User , @cMsg
go

