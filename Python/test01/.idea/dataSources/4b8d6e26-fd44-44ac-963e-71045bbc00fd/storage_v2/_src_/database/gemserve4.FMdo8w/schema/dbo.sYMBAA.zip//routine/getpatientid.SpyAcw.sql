
CREATE FUNCTION dbo.GetPatientID(@MedicalRecordID varchar(30))
RETURNS int
AS
BEGIN
	DECLARE @Return	int

	SELECT @Return = PatientID FROM tblPatientOHD (NOLOCK)
	WHERE MedicalRecordID = @MedicalRecordID

	RETURN ISNULL(@Return, -1)
END
go

