CREATE PROCEDURE dbo.HL7_DietUpdateEX
@MedicalRecordID    	varchar(30),
@PatientVisitID         varchar(50),
@DietName           	varchar(50),
@Source             	varchar(100),
@StartsOn		varchar(10),
@Allergies		varchar(500),
@DietNotes		varchar(500),
@TempActiveDate     	varchar(30),
@Modifiers		varchar(4000),
@ModifierNames		varchar(4000) = ''

AS
   BEGIN TRANSACTION
        DECLARE @Msg        	varchar(500),
                @DietID     	int,
                @PatientID  	int,
                @RoomID     	int,
                @Primary    	int,
                @OldDiet    	varchar(50),
                @OldDietID  	int,
                @NewDiet    	varchar(50),
                @ActiveDate 	datetime,
                @MealPeriodID  	int,
                @Period     	varchar(100),
                @BeginTime  	varchar(5),
		        @ProcessType	varchar(25),
		        @Qty		decimal(10,3),
		        @Qty2		decimal(10,3),
		        @NutrientID	int,
		        @Temp		varchar(50),
		        @TempValue	varchar(50),
		        @Calorie2	varchar(10),
		        @KeyIn		varchar(100),
		        @KeyOut		varchar(100),
		        @Description	varchar(100),
		        @ModifierCount		int,
		        @CurrentModifier	varchar(50),
		        @CurrentNutrient	int,
		        @ModifierValue		decimal(10,3),
		        @MyID			int,
		        @EndLoop		bit,
			@ORMSeparator		varchar(10),
		        @PatientDietID		int,
		        @ModifierNotes	varchar(500)

	DECLARE	@DailyNutrientsProcessed TABLE (NutrientID int)
	DECLARE	@NutrientsProcessed TABLE (NutrientID int)
	
	SELECT @ORMSeparator = dbo.GetOverheadValue('ORMSeparator')
	IF (@ORMSeparator = '')
		SET @ORMSeparator = '|'

	-- Set defaults	
	SET @ProcessType = 'HL7'
	SET @ModifierCount = 1
	SET @EndLoop = 0
	SET @ModifierNotes = ''

	DECLARE @Values TABLE (myID int IDENTITY(1,1),
				KeyOut varchar(50),
				TempValue varchar(50))

	-- Get Patient info
    SELECT @PatientID = PV.PatientID,
        @RoomID = PV.RoomID,
        @OldDietID = PV.DietID,
        @OldDiet = D.Description
    FROM dbo.tblPatientVisit AS PV (NOLOCK) 
            JOIN dbo.tblPatientOHD AS P (NOLOCK) ON PV.PatientID = P.PatientID
            LEFT JOIN dbo.tblDietOHD AS D (NOLOCK) ON PV.DietID = D.DietID
            LEFT JOIN dbo.tblRoomOHD AS R (NOLOCK) ON PV.RoomID = R.RoomID
    WHERE PV.PatientVisitID = @PatientVisitID 
        AND P.MedicalRecordID = @MedicalRecordID
        
	IF ( @PatientID IS NULL )
	BEGIN
        SET @Msg = 'Unable to process Diet Order for MedicalRecordID:' + @MedicalRecordID + '. PatientVisitID or MedicalRecordID not found.'
	    GOTO TransError
	END 

        -- Find diet
	SELECT @DietID = dbo.GetHL7DietID(@DietName, @Modifiers)
	    
	IF ( @DietID IS NULL )
	BEGIN
		SET @Msg = 'Unable to process Diet Order for MedicalRecordID:' + @MedicalRecordID + '. Diet:' + @DietName + ' not found.'

		-- Allow processing of just allergies when no diet is assigned
		IF (LEN(RTRIM(@Allergies)) > 0)
		BEGIN
			IF (LEN(@ProcessType) > 10)
				SET @Temp = LEFT(@ProcessType,10)
			ELSE
				SET @Temp = @ProcessType
		
			SET @Allergies = RTRIM(@Allergies)
		
			EXEC dbo.PatientAllergiesUpdate @ProcessType, @PatientID, @Allergies
		END
		GOTO TransError
	END 
	   
	SELECT @NewDiet = D.Description
	FROM dbo.tblXLAT AS X (NOLOCK)
	     LEFT JOIN dbo.tblDietOHD AS D (NOLOCK) ON CAST(X.KeyOut as integer) = D.DietID
	WHERE X.KeyIn = @DietName
	    AND xlatID = 'Diet'
        
    -- Update for patient diet information
    IF NOT EXISTS (SELECT PatientID FROM dbo.tblPatientOHD (NOLOCK) WHERE MedicalRecordID = @MedicalRecordID)
    BEGIN
        SET @Msg = 'Unable to process Diet Order for MedicalRecordID:' + @MedicalRecordID + '. Patient not found.'
		GOTO TransError
    END
        
    -- Adds the diet to the tblPatientDiet table
    -- We have to calculate the active date in order to do this entry
	SET @TempActiveDate = RTRIM(@TempActiveDate)
	SET @ActiveDate = dbo.HL7ConvertDateTime(@TempActiveDate, getdate())

	SET @BeginTime = dbo.TimeString(@ActiveDate)
	SET @MealPeriodID = dbo.GetMealPeriod(@BeginTime)
	SET @Period = dbo.GetMealPeriodShortName(@MealPeriodID)

	-- Insert new diet order
	SET @DietNotes = @ModifierNames + ';' + REPLACE(@DietNotes,';;','')

	IF NOT EXISTS (SELECT 1 FROM dbo.tblPatientDiet
			WHERE PatientVisitID = @PatientVisitID
				AND DietID = @DietID
				AND ActiveDate = @ActiveDate)
	BEGIN
	        INSERT INTO dbo.tblPatientDiet(PatientVisitID, DietID, ActiveDate, Source, Notes)
	            VALUES (@PatientVisitID, @DietID, ISNULL(@ActiveDate,getdate()), @Source, @DietNotes)

		SET @PatientDietID = SCOPE_IDENTITY()
	END
	ELSE
		SELECT @PatientDietID = [ID]
		FROM dbo.tblPatientDiet
		WHERE PatientVisitID = @PatientVisitID
			AND DietID = @DietID
			AND ActiveDate = @ActiveDate

	SET @PatientDietID = SCOPE_IDENTITY()

	-- ***********************************************
	-- * Process Diet Overrides
	-- ***********************************************
	WHILE (@EndLoop = 0)
	BEGIN
		IF (CHARINDEX(',',@Modifiers) > 0)
		BEGIN
			SET @CurrentModifier = SUBSTRING(@Modifiers,1,CHARINDEX(',',@Modifiers)-1)
			SET @Modifiers = SUBSTRING(@Modifiers, CHARINDEX(',',@Modifiers) + 1,LEN(@Modifiers) - LEN(@CurrentModifier))
		END
		ELSE
		BEGIN
			IF (RTRIM(@Modifiers) = '')
				GOTO Allergens

			-- Process the last item
			SET @CurrentModifier = @Modifiers
			SET @EndLoop = 1
		END

		-- Make sure our modifier is filled in
		IF LEFT(@CurrentModifier, 9) = '@Modifier' 
			GOTO NextModifier

		-- Update Diet Notes
		IF EXISTS (SELECT KeyIn FROM dbo.tblXlat WHERE xlatId = 'DietNotes' AND KeyIn = @CurrentModifier)
		BEGIN
			SET @Description = NULL
			SELECT @Description = [Description] FROM dbo.tblXlat WHERE xlatId = 'DietNotes' AND KeyIn = @CurrentModifier
			IF (@Description IS NOT NULL)
				SET @ModifierNotes = @ModifierNotes + ' ' + @ORMSeparator + ' ' + @Description
		END


		-- Get the nutrientID for the modifier
		INSERT INTO @Values(KeyOut, TempValue)
			SELECT KeyOut, [Description]
			FROM dbo.tblXlat
			WHERE KeyIn = @CurrentModifier
				AND xlatID = 'ModifierNutrientID'


	               -- Check for optional status
		SET @Description = NULL
		SET @KeyOut = NULL
		SELECT @Description = Description,
				@KeyOut = KeyOut
		FROM dbo.tblxlat 
		WHERE KeyIn = @CurrentModifier AND xlatId = 'OptionalStatus'

		        IF (@KeyOut IS NOT NULL)
		        BEGIN
		                IF (@KeyOut = '1')
		                        UPDATE dbo.tblPatientOHD SET OptionalStatus1 = ISNULL(@Description, 1) WHERE PatientID = @PatientID
		
		                IF (@KeyOut = '2')
		                        UPDATE dbo.tblPatientOHD SET OptionalStatus2 = ISNULL(@Description, 1) WHERE PatientID = @PatientID
		
		                IF (@KeyOut = '3')
		                        UPDATE dbo.tblPatientOHD SET OptionalStatus3 = ISNULL(@Description, 1) WHERE PatientID = @PatientID
		
		                IF (@KeyOut = '4')
		                        UPDATE dbo.tblPatientOHD SET OptionalStatus4 = ISNULL(@Description, 1) WHERE PatientID = @PatientID
		
					-- Remove the Optional Status information from the notes
					UPDATE dbo.tblPatientDiet SET Notes = REPLACE(Notes, @CurrentModifier,'')
		        END



		-- Get the first item
		SET @Temp = NULL
		SELECT TOP 1 @MyID = MyID,
			@Temp = KeyOut,
			@TempValue = TempValue
		FROM @Values
		ORDER BY myID

		-- Process until all items are done
		WHILE (@Temp IS NOT NULL)
		BEGIN
			-- Get the NutrientID for the modifier
			SELECT @CurrentNutrient = NutrientID
			FROM cfgNutrients (NOLOCK)
			WHERE NutrientID = CAST(@Temp AS int)

			-- update info
			IF (@CurrentNutrient IS NOT NULL)
				INSERT INTO @DailyNutrientsProcessed (NutrientID)
					VALUES (@CurrentNutrient)


			-- Get the nutrient value for the modifier
			SET @ModifierValue = CAST(@TempValue as decimal(10,3))
	
			-- Delete the daily nutrientoverrides for this nutrient and add the new one
			DELETE dbo.tblPatientDailyNutrientOverride 
			FROM dbo.tblPatientDailyNutrientOverride AS PD (NOLOCK)
				JOIN dbo.tblPatientDiet AS P (NOLOCK) ON PD.DietID = P.DietID
				JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON PV.PatientVisitID = P.PatientVisitID 
			WHERE P.ActiveDate <=  ISNULL(@ActiveDate,getdate()) 
				AND P.DietID = @DietID
				AND PD.NutrientID = @CurrentNutrient
				AND PV.PatientVisitID = @PatientVisitID
	
			-- Insert the value into the daily overrides table
			INSERT INTO dbo.tblPatientDailyNutrientOverride(PatientID, NutrientID, DietID, Qty)
	 			VALUES (@PatientID, @CurrentNutrient, @DietID, @ModifierValue)
	
			-- Delete the item just processed
			DELETE @Values WHERE myID = @MyID 

			-- check for more items
			IF EXISTS (SELECT myID FROM @Values)
			BEGIN
				SET @Temp = NULL
				SELECT TOP 1 @MyID = MyID,
					@Temp = KeyOut,
					@TempValue = TempValue
				FROM @Values
				ORDER BY myID
			END
			ELSE
				BREAK
		END

		-- Check for allergens
		SET @Temp = NULL
		SELECT @Temp = KeyOut
		FROM dbo.tblXlat
		WHERE KeyIn = @CurrentModifier
			AND xlatID = 'ModifierAllergenID'

		-- If no allergen applies, then check to see if we have any MealPeriod Overrides
		IF (@Temp IS NULL)
			GOTO MealPeriodOverrides
		ELSE
		BEGIN
			-- Insert an allergen for this patient/modifier combination if it doesn't already exist.
			IF NOT EXISTS(SELECT PatientID FROM dbo.tblPatientAllergens
					WHERE PatientID = @PatientID AND AllergenID = CAST(@Temp AS int))
	
				INSERT INTO dbo.tblPatientAllergens (PatientID, AllergenID)
					VALUES (@PatientID, CAST(@Temp AS int))			
	
			-- Since this modifier is handled, go to the next modifier
			--GOTO NextModifier				
		END

MealPeriodOverrides:
		DECLARE myNutrient cursor FOR
			SELECT DISTINCT KeyIn, KeyOut, [Description]
			FROM dbo.tblXlat 
		WHERE 	LEFT(KeyIn,LEN(@CurrentModifier)) = @CurrentModifier
			AND SUBSTRING(KeyIn,LEN(@CurrentModifier) + 1,1) = '_'
			AND xlatID = 'NutrientByMealPeriod'

		-- Open our cursor
		OPEN myNutrient

		FETCH NEXT FROM myNutrient INTO @KeyIn, @KeyOut, @TempValue

		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			-- Get the NutrientID for the modifier
			SELECT @CurrentNutrient = NutrientID
			FROM cfgNutrients (NOLOCK)
			WHERE NutrientID = CAST(@KeyOut AS int)

			-- update info
			IF (@CurrentNutrient IS NOT NULL)
				INSERT INTO @NutrientsProcessed (NutrientID)
					VALUES (@CurrentNutrient)

			-- Get the quantity and MealPeriodID		
			SET @Qty = -1
			IF (ISNUMERIC(SUBSTRING(@KeyIn,LEN(@CurrentModifier) + 2,LEN(@KeyIn) - (LEN(@CurrentModifier) + 1))) = 1)
				SELECT @Qty = CAST(@TempValue AS decimal(10,3)),
					@MealPeriodID = CAST(SUBSTRING(@KeyIn,LEN(@CurrentModifier) + 2,LEN(@KeyIn) - (LEN(@CurrentModifier) + 1)) as int)

			-- If a Qty is found, then update the override table
			IF (@Qty > -1)
			BEGIN
				-- Check for Wave Overrides -- delete existing ones for the same nutrient we are adding
				DELETE dbo.tblPatientMealPeriodNutrientOverride 
				FROM dbo.tblPatientMealPeriodNutrientOverride
				WHERE NutrientID = @CurrentNutrient
					AND PatientID = @PatientID
					AND MealPeriodID = @MealPeriodID

	 			INSERT INTO dbo.tblPatientMealPeriodNutrientOverride (PatientID, NutrientID, MealPeriodID, Qty)
					SELECT @PatientID, @CurrentNutrient, @MealPeriodID, @Qty
			END
		
			FETCH NEXT FROM myNutrient INTO @KeyIn, @KeyOut, @TempValue
		END

		-- Close the cursor
		CLOSE myNutrient
		DEALLOCATE myNutrient 

NextModifier:

	END

	-- Deletes any previous overrides that existed for this patient/diet combination
	DELETE dbo.tblPatientDailyNutrientOverride 
	FROM dbo.tblPatientDailyNutrientOverride AS PD (NOLOCK)
	        JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON PV.PatientID = PD.PatientID 
            JOIN dbo.tblPatientDiet AS P (NOLOCK) ON P.PatientVisitID = PV.PatientVisitID
	WHERE P.ActiveDate <=  ISNULL(@ActiveDate,getdate()) 
		AND P.DietID = @DietID
		AND PD.NutrientID NOT IN (SELECT NutrientID FROM @DailyNutrientsProcessed)
		AND PV.PatientVisitID = @PatientVisitID

	DELETE dbo.tblPatientMealPeriodNutrientOverride 
	FROM dbo.tblPatientMealPeriodNutrientOverride
	WHERE NutrientID NOT IN (SELECT NutrientID FROM @NutrientsProcessed)
		AND PatientID = @PatientID
	-- ***********************************************
	-- * End Diet Overrides
	-- ***********************************************
Allergens:
	-- ***********************************************
	-- * Process allergens.
	-- * NOTE: If allergens are not received from the
	-- *       Diet data feed, pass in an empty string
	-- *       in the @Allergies variable to bypass.
	-- ***********************************************
	IF (LEN(RTRIM(@Allergies)) > 0)
	BEGIN
		IF (LEN(@ProcessType) > 10)
			SET @Temp = LEFT(@ProcessType,10)
		ELSE
			SET @Temp = @ProcessType

		SET @Allergies = RTRIM(@Allergies)

		EXEC dbo.PatientAllergiesUpdate @ProcessType, @PatientID, @Allergies
	END
	-- ***********************************************
	-- * End Process allergens.
	-- ***********************************************

	-- Process items required if the diet is changing            
	IF(@OldDietID <> @DietID)
	BEGIN
		-- Cancel any future orders ONLY IF we are changing the diet
		-- Insert a log entry into the Order Log for all orders that we are cancelling
	        INSERT INTO dbo.tblOrderLOG ( OrderID ,  ActionID , LoginUserID )
	            SELECT OrderID, 700, @ProcessType
	            FROM    dbo.tblOrderOHD AS O (NOLOCK)
	                    JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON (O.PatientVisitID = PV.PatientVisitID OR O.PatientVisitID = PV.MergedTo)
	            WHERE OrderDate > ISNULL(@ActiveDate,getdate()) 
	                    AND ISNULL(O.Cancelled,0) <> 1
	                    AND PV.PatientVisitID = @PatientVisitID

		-- Deletes all nutrient counts for orders that are being canceled
		DELETE dbo.tblPatientNutrientCount 
		WHERE OrderID IN (SELECT OrderID FROM dbo.tblOrderOHD AS O (NOLOCK)
			JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON (O.PatientVisitID = PV.PatientVisitID OR O.PatientVisitID = PV.MergedTo)
		        WHERE O.OrderDate >  ISNULL(@ActiveDate,getdate())
		                   AND ISNULL(O.Cancelled,0) <> 1
		                    AND PV.PatientVisitID = @PatientVisitID)

	            -- Insert a log entry into the Patient Log for all orders that we are cancelling
	            INSERT INTO dbo.tblPatientLog (EventClassID, LoginUserID, PatientID, RoomID, [Description], [Date])
	                SELECT 7000, @Source, P.PatientID, P.RoomID, @Msg, getdate()
	                FROM    dbo.tblOrderOHD AS O (NOLOCK)
	                        JOIN dbo.tblPatientVisit AS P (NOLOCK) ON O.PatientVisitID = P.PatientVisitID
	                WHERE O.OrderDate > ISNULL(@ActiveDate,getdate()) 
			AND ISNULL(O.Cancelled,0) <> 1
			AND O.PatientVisitID = @PatientVisitID

		                   
   	        -- Set the cancelled flag to 1 for any orders in future waves
	        UPDATE  dbo.tblOrderOHD
	        SET Cancelled = 1,
	            CancelDate = getdate()
	        FROM    dbo.tblOrderOHD AS O (NOLOCK)
	                JOIN tblPatientVisit AS P (NOLOCK) ON (O.PatientVisitID = P.PatientVisitID OR O.PatientVisitID = P.MergedTo)
	        WHERE O.OrderDate > ISNULL(@ActiveDate,getdate())
	                AND ISNULL(O.Cancelled,0) <> 1
		  AND O.PatientVisitID = @PatientVisitID
		
	END

	IF (@ModifierNotes IS NOT NULL AND @ModifierNotes <> '')
		UPDATE dbo.tblPatientDiet
			SET Notes = Notes + ' ::: ' + @ModifierNotes
		WHERE [ID] = @PatientDietID


       SELECT @Period = dbo.DateStringMMDDYYYY(@ActiveDate) + ' ' + KeyOut
        FROM    dbo.tblXLAT (NOLOCK)
        WHERE   KeyIn = @TempActiveDate
                AND xlatID = 'Diet2'


	IF (@DietID IS NOT NULL)
	BEGIN
		WHILE (1=1)
		BEGIN
			IF EXISTS (SELECT 1 FROM dbo.tblPatientDiet WHERE CHARINDEX(@ORMSeparator + @ORMSeparator,Notes) > 0 AND [ID] = @PatientDietID)
				UPDATE dbo.tblPatientDiet SET Notes = REPLACE(COALESCE(Notes,''), @ORMSeparator + @ORMSeparator, @ORMSeparator) WHERE [ID] = @PatientDietID
			ELSE
				BREAK
		END

		UPDATE dbo.tblPatientDiet SET Notes = REPLACE(COALESCE(Notes,''), @DietName, '') WHERE [ID] = @PatientDietID
		UPDATE dbo.tblPatientDiet SET Notes = REPLACE(COALESCE(Notes,''), @ORMSeparator + @ORMSeparator, @ORMSeparator) WHERE [ID] = @PatientDietID
		UPDATE dbo.tblPatientDiet SET Notes = REPLACE(COALESCE(Notes,''), @ORMSeparator + ' ' + @ORMSeparator, @ORMSeparator) WHERE [ID] = @PatientDietID
		UPDATE dbo.tblPatientDiet SET Notes = REPLACE(COALESCE(Notes,''), @ORMSeparator + '  ' + @ORMSeparator, @ORMSeparator) WHERE [ID] = @PatientDietID
		UPDATE dbo.tblPatientDiet SET Notes = '' WHERE LTRIM(RTRIM(COALESCE(Notes,''))) = @ORMSeparator AND [ID] = @PatientDietID
		UPDATE dbo.tblPatientDiet SET Notes = '' WHERE LTRIM(RTRIM(COALESCE(Notes,''))) = '' AND [ID] = @PatientDietID
		UPDATE dbo.tblPatientDiet SET Notes = LEFT(Notes, LEN(Notes) - 1) WHERE RIGHT(COALESCE(Notes,''),1) = @ORMSeparator AND [ID] = @PatientDietID
		UPDATE dbo.tblPatientDiet SET Notes = RIGHT(Notes, LEN(Notes) - 1) WHERE LEFT(COALESCE(Notes,''),1) = @ORMSeparator AND [ID] = @PatientDietID
		UPDATE dbo.tblPatientDiet SET Notes = RIGHT(Notes, LEN(Notes) - 1) WHERE LEN(COALESCE(Notes,'')) > 1 AND  LEFT(COALESCE(Notes,''),1) = ' ' AND [ID] = @PatientDietID
		UPDATE dbo.tblPatientDiet SET Notes = '' WHERE RTRIM(Notes) = @ORMSeparator AND [ID] = @PatientDietID
	END

	-- Log the diet update
	 SET @Msg = ISNULL(UPPER(@NewDiet),'<NOT FOUND>') + ' diet added for ' + dbo.DateString(ISNULL(@ActiveDate,getdate())) + ' ' + 
		dbo.TimeString(ISNULL(@ActiveDate,getdate())) + ' by ' + ISNULL(@Source, 'system')

        EXEC dbo.PatientLOGAdd 7000, @ProcessType, @PatientID, @PatientVisitID, @RoomID, @Msg
        EXEC dbo.ProcessLogInsert @ProcessType            
    COMMIT TRANSACTION
    
    RETURN 
	
TransError:
	-- Handle errors
	ROLLBACK TRANSACTION

	IF ( @Msg IS NULL )
		SET @Msg = 'Unable to process Diet Order for MedicalRecordID:' + @MedicalRecordID + '. Diet:' + ISNULL(UPPER(@NewDiet),'NOT FOUND')

	EXEC dbo.Logit 1, @Msg, 'system'
go

