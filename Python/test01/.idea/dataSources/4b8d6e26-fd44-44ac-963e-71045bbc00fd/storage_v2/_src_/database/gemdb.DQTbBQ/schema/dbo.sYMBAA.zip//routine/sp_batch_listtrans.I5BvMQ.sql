CREATE PROCEDURE [dbo].[sp_Batch_ListTrans]
@User		char(10),
@BatchID	char(10),
@Posted		bit=0
AS

	DECLARE @BatchPostRetentionDays int,
			@GEM2goRetentionDays int
	
	-- Get the number of days to show the posted batches
	SET @BatchPostRetentionDays = COALESCE(dbo.GetOverheadItem('BatchPostRetentionDays'),0)
	
	-- Get the number of days to show the GEM2go batches
	SET @GEM2goRetentionDays = COALESCE(dbo.GetOverheadItem('GEM2goRetentionDays'),0)

	SELECT	B.DetailID,
			B.AccountNo,
			B.BadgeNo,
			ISNULL(B.TransDate, '1-1-1900') as TransDate,
			B.ChkNum,
			B.RefNum,
			ISNULL(B.TransTotal, 0) as TransTotal,
			B.Posted,
			O.OutletName,
			B.TransID,
			D.Description,
			RTRIM(U.FirstName) + dbo.GetMiddleNameDisplay(U.MiddleName,0) + ' ' + RTRIM(U.LastName) AS Name,
			B.ExceptionMessage
	FROM		tblBatch AS B LEFT JOIN
			tblOutletOHD AS O
	ON 		 B.OutletNo = O.OutletNo LEFT JOIN
			tblTransDef AS D
	ON		 B.TransID = D.TransID LEFT JOIN
			tblBadgesOHD AS U
	ON		B.BadgeNo = U.BadgeNo AND
			B.AccountNo = U.AccountNo
	WHERE	 B.BatchID = @BatchID 
		AND ((Posted NOT IN ('P','I') AND @Posted = 0) 
		OR	(Posted IN ('P','I') AND @Posted = 1)
				AND ((@BatchPostRetentionDays <> '0' AND BatchID <> 'GEM2GO'
						AND dbo.dDateOnly(B.LastUpdateDate) >= (dbo.dDateOnly(GETDATE())-@BatchPostRetentionDays))
					OR  (@GEM2goRetentionDays <> '0' AND BatchID = 'GEM2GO'
						AND dbo.dDateOnly(B.LastUpdateDate) >= (dbo.dDateOnly(GETDATE())-@GEM2goRetentionDays))))	
	ORDER BY	 B.TransDate
	
	DECLARE 	@cMsg  char(255),
				@CoreID	int
	SET @CoreID = dbo.GetCoreIDFromUser(@User)
	SET @cMsg = 'Retrieved batch transaction list for Batch ID <' + @BatchID + '>'
	EXEC dbo.sp_Logit 5 , @CoreID , @User , @cMsg
go

