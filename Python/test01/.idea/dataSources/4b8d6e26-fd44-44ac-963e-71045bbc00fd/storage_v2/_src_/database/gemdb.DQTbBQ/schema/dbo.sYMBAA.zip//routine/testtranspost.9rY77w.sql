CREATE PROCEDURE [dbo].[TestTransPost]
    @AcctNo varchar(19),
    @TransTotal money = NULL,
    @OutletNo int = NULL,
    @TransID int = NULL
AS 
    DECLARE @total money,
        @badge varchar(19),
        @outlet int,
        @transNo int,
        @today datetime
			
    SELECT TOP 1
            @badge = tblBadgesOHD.badgeno
    FROM    dbo.tblBadgesOHD
    WHERE   tblBadgesOHD.AccountNo = @AcctNo
    ORDER BY tblBadgesOHD.PrimaryBadge
	
    IF ( @TransTotal IS NULL ) 
        SET @total = 1.00
	
    IF ( @OutletNo IS NULL ) 
        SELECT TOP 1
                @outlet = O.OutletNo
        FROM    dbo.tblOutletOHD AS O
                LEFT JOIN dbo.tblAccountOHD AS A ON A.AccountNo = @AcctNo
                LEFT JOIN dbo.tblAccountClass AS AC ON A.AccountClassID = AC.AccountClassID
        WHERE   ( O.SubType & AC.SubType ) <> 0
        
    IF ( @TransID IS NULL ) 
        SELECT TOP 1
                @transNo = tblTransDef.TransID
        FROM    dbo.tblTransDef
        WHERE   tblTransDef.Payment = 0
                AND tblTransDef.TransClassID IN (
					SELECT  tblAccountTTL.TransClassID
					FROM    dbo.tblAccountTTL
					WHERE   tblAccountTTL.AccountNo = @AcctNo )
                                      
    SET @today = GETDATE()
	
    EXEC dbo.sp_Trans_Post @CoreID = 0, -- int
        @User = 'support', @AccountNo = @AcctNo, @BadgeNo = @badge,
        @TransDate = @today, @OutletNo = @outlet, @RefNum = '1234',
        @CheckNum = '1234', @TransTotal = @total, @Sales1 = @total,
        @Comment = '', @CycleNo = 0, @TransID = @transNo, @Category = '',
        @PaymentNo = 0, @ServeEmpl = 0, @PostEmpl = 0, @Covers = 0,
        @RevCntr = 0, @Correction = 0, @Auditable = 0, @PostDate = '',
        @MealPlanID = 0, @LocationID = 0
go

