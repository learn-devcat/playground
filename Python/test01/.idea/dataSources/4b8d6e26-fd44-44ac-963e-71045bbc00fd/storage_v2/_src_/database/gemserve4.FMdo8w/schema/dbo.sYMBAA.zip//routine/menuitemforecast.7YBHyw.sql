
CREATE PROCEDURE dbo.MenuItemForecast
@MealPeriodID        int,
@StartDate           datetime,
@EndDate             datetime
AS

        SET NOCOUNT ON

        SELECT  MP.[Description] AS MealPeriod,
                M.[Description] AS MenuItem,
                COUNT(OI.POSMenuItemID) AS Total
        FROM    dbo.tblOrderItems AS OI (NOLOCK)
                JOIN dbo.tblOrderOHD AS O (NOLOCK) ON OI.OrderID = O.OrderID
                JOIN dbo.tblMenuItemOHD AS M (NOLOCK) ON M.POSMenuItemID = OI.POSMenuItemID 
                JOIN dbo.tblMealPeriods AS MP (NOLOCK) ON MP.MealPeriodID = @MealPeriodID

        WHERE   O.OrderDate BETWEEN @StartDate AND @EndDate
                AND O.WaveID IN (SELECT WaveID FROM dbo.tblWave WHERE MealPeriodID = @MealPeriodID)
        GROUP BY M.[Description],MP.[Description]

        RETURN
go

