

CREATE PROCEDURE dbo.ButtonXrefDelete
@LoginUserID		varchar(250),
@ID		int
AS

	SET NOCOUNT ON

	DELETE dbo.tblButtonXref 
	WHERE	[ID] = @ID

	RETURN
go

