CREATE PROCEDURE [dbo].[PatientGet]
@SearchString		varchar(400)='',
@PatientVisitID		varchar(50)='',
@IncludeDischarged      bit=0

AS
    SET NOCOUNT ON

    DECLARE 	@Today	datetime,
				@LogDisplayDays int

    SET @Today = getdate()
	SELECT @LogDisplayDays = COALESCE(dbo.GetOverheadValueNull('LogDisplayDays'),30)


    IF (@SearchString <> '')
    BEGIN
        DECLARE @SQL	nvarchar(4000),
            @Rows	int,
            @PatientID int,
            @MergedTo	varchar(50)

        CREATE TABLE #MyPatientID
            (
            PatientID 	int,
            LastName	varchar(50),
            FirstName	varchar(50),
            MiddleInitial	varchar(30),
            PatientVisitID	varchar(50),
            RoomNumber	varchar(50),
            MergedTo	varchar(50),
            MRNMergedTo	varchar(50)
            )

        SET @SQL = 'INSERT INTO #MyPatientID SELECT P.PatientID, P.LastName, P.FirstName, ' + 
                'P.MiddleInitial, PV.PatientVisitID, R.RoomNumber, PV.MergedTo, P.MergedTo FROM dbo.tblPatientOHD AS P ' +
                'JOIN dbo.tblPatientVisit AS PV ON P.PatientID = PV.PatientID ' + 
                'LEFT JOIN dbo.tblRoomOHD AS R ON PV.RoomID = R.RoomID '  + @SearchString +
                ' AND PV.MergedTo IS NULL '

                IF (@IncludeDischarged = 0)
                        SET @SQL = @SQL + 'AND PV.DischargeDate IS NULL '

                SET @SQL = @SQL + 'ORDER BY LastName, FirstName'

        EXEC sys.sp_executesql @SQL

        SELECT @Rows = COUNT(PatientID) FROM #MyPatientID

        IF ( @Rows > 1 )
        BEGIN
            -- If the visit is merged to another visit, make sure we return the MergedTo visit number
            SELECT COALESCE(MergedTo,PatientVisitID) AS PatientVisitID, LastName + ', ' + FirstName + ' ' + 
            MiddleInitial + ' - Room: [' + ISNULL(RoomNumber,'NONE') + 
            '] - Visit No: [' + PatientVisitID + ']' AS PatientPlusVisit FROM #MyPatientID
            WHERE MergedTo IS NULL
            DROP TABLE #MyPatientID
            RETURN
        END
        ELSE
        BEGIN
            -- Merged MRN
            IF EXISTS (SELECT 1 FROM #MyPatientID WHERE MRNMergedTo IS NOT NULL)
            BEGIN
                SELECT @MergedTo = MRNMergedTo,
                    @PatientVisitID = PatientVisitID FROM #MyPatientID
                DELETE #MyPatientID

                INSERT INTO #MyPatientID
                SELECT P.PatientID, P.LastName, P.FirstName, 
                P.MiddleInitial, @PatientVisitID, R.RoomNumber, PV.MergedTo, P.MergedTo FROM dbo.tblPatientOHD AS P
                JOIN dbo.tblPatientVisit AS PV ON P.PatientID = PV.PatientID 
                LEFT JOIN dbo.tblRoomOHD AS R ON PV.RoomID = R.RoomID 
                WHERE P.MedicalRecordID = @MergedTo
            END

            -- If the visit is merged to another visit, make sure we return the MergedTo visit number
            SELECT @PatientVisitID = COALESCE(MergedTo, PatientVisitID) FROM #MyPatientID
        END
            
        DROP TABLE #MyPatientID
    END

    -- Get a specific patient
    IF (@PatientVisitID <> '')
    BEGIN
        SELECT @PatientID = PatientID
        FROM dbo.tblPatientVisit
        WHERE PatientVisitID = @PatientVisitID

        SELECT	COALESCE(P2.PatientID,P.PatientID) AS PatientID,
            PV.PVID,
            PV.PatientClassID,
            PV.PatientVisitID,
            COALESCE(P2.Active, P.Active) AS Active,
            COALESCE(P2.MedicalRecordID, P.MedicalRecordID) AS MedicalRecordID,
            COALESCE(P2.LastName, P.LastName,'') AS LastName,
            COALESCE(P2.FirstName, P.FirstName,'') AS FirstName,
            COALESCE(P2.MiddleInitial, P.MiddleInitial,'') AS MiddleInitial,
            COALESCE(P2.LastName, P.LastName,'') + ', ' + COALESCE(P2.FirstName, P.FirstName,'') + ' ' + COALESCE(P2.MiddleInitial, P.MiddleInitial,'') AS FullName,
            COALESCE(P2.LastName, P.LastName,'') + ', ' + COALESCE(P2.FirstName, P.FirstName,'') + ' ' + COALESCE(P2.MiddleInitial, P.MiddleInitial,'') + ' - Visit:' + PV.PatientVisitID AS PatientPlusVisit,
            R.RoomNumber,
            PV.Bed,
            COALESCE(P2.BadgeNo, P.BadgeNo, '') AS BadgeNo,
            dbo.DateStringMMDDYYYY(COALESCE(P2.BirthDate,P.BirthDate)) AS BirthDate,
            CASE WHEN ISDATE(COALESCE(P2.BirthDate,P.BirthDate)) = 1 THEN
                dbo.PatientAge(COALESCE(P2.BirthDate,P.BirthDate), @Today) 
                ELSE dbo.PatientAge(dbo.DateStringMMDDYYYY(COALESCE(P2.BirthDate,P.BirthDate)), @Today)
            END AS Age,
            COALESCE(P2.Gender,P.Gender) AS Gender,
            PV.EntryDate,
            PV.DischargeDate,
            PV.DietID,
            dbo.PatientAllergenOptions(COALESCE(P2.PatientID,P.PatientID)) AS Allergens,
            COALESCE(P2.Notes,P.Notes) AS Notes,
            COALESCE(P2.Status,P.Status) AS Status,
            PV.NonSelect,
            COALESCE(P2.UserField1,P.UserField1) AS UserField1,
            COALESCE(P2.UserField2,P.UserField2) AS UserField2,
            COALESCE(P2.UserField3,P.UserField3) AS UserField3,
            COALESCE(P2.UserField4, P.UserField4) AS UserField4,
            COALESCE(P2.OnHold,P.OnHold) AS OnHold,
            COALESCE(P2.HoldActiveTime, P.HoldActiveTime) AS HoldActiveTime,
            COALESCE(P2.HoldReleaseTime,P.HoldReleaseTime) AS HoldReleaseTime,
            COALESCE(PD.Id, -1) AS PatientDietID,
            dbo.GetActiveDietNotesEX(@PatientVisitID, @Today, 0) AS DietNotes,
            COALESCE(PD.MenuLevel, 1) AS MenuLevel
        FROM dbo.tblPatientOHD AS P (NOLOCK)
            JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON P.PatientID = PV.PatientID
            LEFT JOIN dbo.tblPatientOHD AS P2 (NOLOCK) ON P.MergedTo = P2.MedicalRecordID
            LEFT JOIN dbo.tblRoomOHD AS R (NOLOCK) ON PV.RoomID = R.RoomID
            LEFT JOIN dbo.tblPatientDiet AS PD ON PD.Id = dbo.GetActivePatientDietID(@PatientVisitID, @Today)
        WHERE PV.PatientVisitID = @PatientVisitID
    
        SELECT	R.RoomNumber,
            P.[Date],
            P.[Description],
            P.LoginUserID
        FROM	dbo.tblPatientLog AS P (NOLOCK)
            LEFT JOIN dbo.tblRoomOHD AS R (NOLOCK) ON P.RoomID = R.RoomID
        LEFT JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON P.PatientVisitID = PV.PatientVisitID
        WHERE	P.PatientID = @PatientID
			AND	P.[Date] > (@Today - @LogDisplayDays)
        UNION 
        SELECT COALESCE(R2.RoomNumber, R.RoomNumber) AS RoomNumber,
            ISNULL(L.[Date], O.PostDate) AS Date,
            A.[Description] + ' for ' + UPPER(RTRIM(W.[Description])) +
                CASE
                    WHEN COALESCE(O.Cancelled, 0) = 1 THEN ' (canceled)'
                    WHEN O.Sent = 0 and dbo.DateString(O.OrderDate) < dbo.DateString(@Today) THEN ' (missed)'
                    WHEN O.Sent = 0 and dbo.DateString(O.PostDate) = dbo.DateString(O.OrderDate) THEN ' (Not Sent Yet)'
                    ELSE ' (Sent)'
                END  as description,
            L.LoginUserID		
        FROM	dbo.tblOrderLOG L (NOLOCK)
            JOIN dbo.tblActions AS A (NOLOCK) ON L.ActionID = A.ActionID
            JOIN dbo.tblOrderOHD AS O (NOLOCK) ON L.OrderID = O.OrderID
            JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON O.PatientVisitID = PV.PatientVisitID
            LEFT JOIN dbo.tblRoomOHD AS R2 (NOLOCK) ON R2.RoomID = O.RoomID
            LEFT JOIN dbo.tblRoomOHD AS R (NOLOCK) ON R.RoomID = PV.RoomID
            LEFT JOIN dbo.tblWave AS W (NOLOCK) ON W.WaveID = O.WaveID
        WHERE	PV.PatientVisitID = @PatientVisitID
			AND	L.[Date] > (@Today - @LogDisplayDays)
        ORDER BY [Date] DESC
    END

    RETURN
go

