CREATE PROCEDURE dbo.HL7ProcessingTaskUpdate
@CommandID	int,
@MessageType	varchar(32),
@Name		varchar(32),
@Description	varchar(500),
@ControlType	int,
@CommandType	int,
@Command	varchar(500),
@ReturnColumn	varchar(200),
@Sequence	int,
@Active	bit

AS
	SET NOCOUNT ON

	IF (@CommandID > 0)
		UPDATE dbo.tblHL7Processing
			SET MessageType = @MessageType,
			[Name] = @Name,
			[Description] = @Description,
			ControlType = @ControlType,
			CommandType = @CommandType,
			Command = @Command,
			ReturnColumn = @ReturnColumn,
			[Sequence] = @Sequence,
			Active = @Active
		WHERE	CommandID = @CommandID
	ELSE
	BEGIN
		INSERT INTO dbo.tblHL7Processing (MessageType, [Name], [Description], ControlType, CommandType, Command, ReturnColumn, [Sequence], Active)
			VALUES (@MessageType, @Name, @Description, @ControlType, @CommandType, @Command, @ReturnColumn, @Sequence, @Active)

		SET @CommandID = SCOPE_IDENTITY()
	END
	
	SELECT @CommandID AS CommandID

	RETURN
go

