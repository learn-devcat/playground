

CREATE PROCEDURE dbo.sp_Connection_NewID
AS
	SELECT	ISNULL(MAX(ConnectionID+1),1)
	FROM		cfgConnection
go

