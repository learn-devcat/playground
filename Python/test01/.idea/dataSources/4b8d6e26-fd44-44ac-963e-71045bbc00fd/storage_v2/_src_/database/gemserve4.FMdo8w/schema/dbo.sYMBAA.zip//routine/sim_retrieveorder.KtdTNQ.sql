

/*
    sim_RetrieveOrder            28-Jan-04   w.j.scott

    This SP works very simuar to the IdleEvent's get order except that we will physically remove the order
    from the DB once we have sent it to the POS.  This allows an previous order to be retrieved, modified and
    then re-sent to the GEM -- (or canceled).
*/
CREATE PROCEDURE [dbo].[sim_RetrieveOrder]
@CoreID as int,
@LoginUserID 	varchar(250),
@WorkstationID int,
@PatientVisitID varchar(50),
@WaveID int,
@WaveDate  varchar(30)
AS
    SET NOCOUNT ON
            
    DECLARE @OrderID int,
        @RoomNumber as varchar(20),
        @SubLevel int,
        @PatientName varchar(50),
        @DietName varchar(50),
        @OrderWorkstationID int,
        @Sent int,
        @Received int,
        @Detail as varchar(4000),
        @Msg as varchar(2200),
        @PatientInfoOnOrder as char(1),
        @OrderDate datetime,
        @StandingOrder bit,
        @DietMenuLevel int,
        @Now datetime

    SELECT @PatientInfoOnOrder = dbo.GetOverheadValue('PatientInfoOnOrder')
    SET @Now = getdate();

    IF ( @PatientInfoOnOrder = '' )
        SET @PatientInfoOnOrder = '0'

    SELECT TOP 1 @OrderID = O.OrderID , 
        @RoomNumber = R.RoomNumber + ISNULL(PV.Bed,''),
            @SubLevel = O.SubLevel,
            @PatientName = P.FullName, 
        @OrderWorkstationID = O.WorkstationID,
            @Detail = dbo.GetOrderDetail(O.OrderID, O.OrderType, 0), 
        @Sent = O.Sent,
        @Received = O.Received,
        @DietName = DT.Description,
        @OrderDate = O.OrderDate,
        @StandingOrder = O.StandingOrder,
        @DietMenuLevel = COALESCE(PD.MenuLevel, DT.MenuLevel, 1)			
    FROM    dbo.tblOrderOHD O
        LEFT JOIN dbo.tblPatientOHD AS P (NOLOCK) ON O.PatientID = P.Patientid
        LEFT JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON O.PatientVisitID = PV.PatientVisitID
            AND PV.MergedTo IS NULL
            AND PV.DischargeDate IS NULL
        LEFT JOIN dbo.tblDietOHD AS DT (NOLOCK) ON PV.DietID = DT.DietID
        LEFT JOIN dbo.tblRoomOHD AS R (NOLOCK) ON PV.RoomID = R.RoomID
        LEFT JOIN dbo.tblPatientDiet AS PD ON PD.Id = dbo.GetPatientDietID(O.PatientVisitID, @Now, dbo.TimeString(@Now))
    WHERE   dbo.dDateOnly(O.OrderDate) = dbo.dDateOnly(@WaveDate)
            AND O.PatientVisitID = @PatientVisitID
            AND O.WaveID = @WaveID
        AND COALESCE(O.Cancelled,0) = 0
                         
    IF( @@RowCount = 0 OR @OrderID IS NULL)
        BEGIN
            SELECT '/Order Not On File' AS rMsg
            RETURN
        END
        
    IF( @Received <> 0)
        BEGIN
            SELECT '/Order Already Sent' AS rMsg
            RETURN
        END
         
   -- EXEC dbo.OrderDelete @OrderID
 
    SELECT @Msg = 'RETRIEVE' + char(28) + cast(@OrderID as varchar(10)) + '^' + @RoomNumber + '^' + 
    CASE
        WHEN @PatientInfoOnOrder = '1' THEN @PatientName 
        ELSE ''
    END + '^' + CAST( @SubLevel as varchar(5)) + '^' +
        @DietName + '^' + dbo.DateString(@OrderDate) + ' ' + dbo.TimeString(@OrderDate) + '^' + @Detail +  '^' + CAST(@DietMenuLevel AS varchar(10)) + char(28) + CAST(@StandingOrder AS char(1)) 

   IF( @Msg is null )
        SELECT '/Unable To Retrieve Order' as rMsg
    ELSE
        SELECT @Msg  rMsg
go

