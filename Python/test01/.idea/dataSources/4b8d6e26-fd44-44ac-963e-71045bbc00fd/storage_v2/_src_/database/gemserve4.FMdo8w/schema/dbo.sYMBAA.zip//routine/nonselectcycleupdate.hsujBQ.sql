
CREATE PROCEDURE [dbo].[NonSelectCycleUpdate]
@LoginUserID	varchar(250),
@CycleID	int,
@Description	varchar(50)
AS
	SET NOCOUNT ON

	IF (@CycleID > 0)
		UPDATE dbo.tblNonSelectCyles
			SET [Description] = @Description
		WHERE CycleID = @CycleID
	ELSE
	BEGIN
		INSERT INTO dbo.tblNonSelectCycles ([Description])
			VALUES (@Description)

		SET @CycleID = SCOPE_IDENTITY()
	END

	SELECT @CycleID AS CycleID

	RETURN
go

