


----------------------------------------------------------------------------------
--
--  OrderLogInsert                  18-Aug-03 w.j.scott
--
--  This proc will insert a new entry into the Order LOG table.  This table contains
--  a listing of all activity on the order table.
--
--
-----------------------------------------------------------------------------------
CREATE PROCEDURE dbo.OrderLOGInsert
(
    @OrderID   int,
    @ActionID  int = 0,
    @UserID    int = 0
)
AS

    set nocount on
    	
	insert into tblOrderLOG ( OrderID ,  ActionID , LoginUserID )
	                 Values (@OrderID , @ActionID , @UserID)
	     
	     
	RETURN
go

