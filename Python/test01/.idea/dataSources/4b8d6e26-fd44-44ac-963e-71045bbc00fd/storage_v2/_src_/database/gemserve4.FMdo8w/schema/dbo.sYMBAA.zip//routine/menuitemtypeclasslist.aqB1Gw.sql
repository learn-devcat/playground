

CREATE PROCEDURE dbo.MenuItemTypeClassList
AS
	SET NOCOUNT ON

	SELECT	MenuItemTypeClassID,
		MI_TYPE_SEQ,
		OBJ_NUM,
		[NAME]
	FROM	dbo.tblMenuItemTypeClass
	WHERE [NAME] IS NOT NULL
	
	RETURN
go

