CREATE  PROCEDURE dbo.PatientReleaseHold
@PatientID	int
AS
	SET NOCOUNT ON	

	DECLARE @Temp		varchar(10),
		@Minutes	int,
		@Today		datetime

	-- Get the current date/time
	SET @Today = getdate()

	-- Get the Hold Window interval
	-- This is used to determine if orders that were due to be sent to the kitchen
	-- prior to the current time are still valid
	-- The default is to send any order that was due to go to the kitchen within the last hour
	SELECT @Temp = dbo.GetOverheadValue('ReleaseHoldWindow')

	IF (@Temp <> '')
		SET @Minutes = CAST(@Temp AS int)
	ELSE
		SET @Minutes = 60

	-- Cancel any order that is in the past and is outside of
	-- our Hold Window interval
	UPDATE dbo.tblOrderOHD
	SET Cancelled = 1
	WHERE PatientID = @PatientID
		AND Sent IS NULL
		AND COALESCE(Retries,0) = 0
		AND OrderDate < DATEADD(mi, -@Minutes, @Today)

	RETURN
go

