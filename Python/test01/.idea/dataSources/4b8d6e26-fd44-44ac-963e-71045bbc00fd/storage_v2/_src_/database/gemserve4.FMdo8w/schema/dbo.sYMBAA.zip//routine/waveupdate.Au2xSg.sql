
CREATE PROCEDURE [dbo].[WaveUpdate]
@LoginUserID		varchar(250),
@WaveID		int,
@MealPeriodID	int,
@BeginTime		char(5),
@EndTime		char(5),
@SubType		int,
@Description		varchar(25),
@MaxOrder		int,
@WarningMinutes		int,
@CriticalMinutes	int

AS

	UPDATE	dbo.tblWave
	SET	MealPeriodID = @MealPeriodID,
		BeginTime = @BeginTime,
		EndTime	= @EndTime,
		SubType = @SubType,
		Description = @Description,	
		MaxOrder = @MaxOrder,
		WarningMinutes = @WarningMinutes,
		CriticalMinutes = @CriticalMinutes
	WHERE	WaveID = @WaveID

	IF (@@ROWCOUNT = 0)
	BEGIN
		INSERT INTO dbo.tblWave (WaveID, MealPeriodID, BeginTime, EndTime, SubType, Description, MaxOrder, WarningMinutes, CriticalMinutes)
			VALUES (@WaveID, @MealPeriodID, @BeginTime, @EndTime, @SubType, @Description, @MaxOrder, @WarningMinutes, @CriticalMinutes)

		
		INSERT INTO dbo.tblLocationWave (LocationClassID, WaveID, Active)
		SELECT LocationClassID, @WaveID, 1
		FROM dbo.tblLocationClass
	END
go

