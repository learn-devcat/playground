





create     PROCEDURE dbo.Employee_GetIDByUser
@User			char(10)
AS
	SELECT  EmployeeID	
        FROM	tblEmployeeOHD 
	WHERE	UserID = @User
go

