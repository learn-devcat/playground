


CREATE PROCEDURE [dbo].[WaveGetForNewDiet]

AS

	SET NOCOUNT ON

	DECLARE @ValidDays int,
		@WaveDays varchar(5),
		@TotalDays int

	SELECT @WaveDays = dbo.GetOverheadValue('Wavedays')
	SELECT @ValidDays = IsNumeric(@WaveDays)

	If @ValidDays = 1
		SET @TotalDays = CAST(@WaveDays as int) + 1
	ELSE
		SET @TotalDays = 1
	

	SELECT	W.WaveID,
		W.Description AS WaveName,
		0 AS Active,
		CASE 
			WHEN dbo.TimeString(BeginTime) < dbo.TimeString(getdate()) AND dbo.TimeString(EndTime) < dbo.TimeString(getdate()) THEN -1
			WHEN dbo.TimeString(BeginTime) < dbo.TimeString(getdate()) AND dbo.TimeString(EndTime) > dbo.TimeString(getdate()) THEN 1
			ELSE 0
		END AS IsCurrentWave,
		@TotalDays AS TotalDays
	FROM	dbo.tblWave AS W (NOLOCK)
	WHERE ShowOnMap <> 0
	ORDER BY W.Description

	RETURN
go

