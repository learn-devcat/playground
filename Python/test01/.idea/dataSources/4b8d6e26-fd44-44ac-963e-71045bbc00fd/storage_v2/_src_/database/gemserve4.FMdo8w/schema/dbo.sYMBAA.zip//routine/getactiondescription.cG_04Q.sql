


CREATE FUNCTION dbo.GetActionDescription(@ActionID int)
RETURNS varchar(50)
AS

BEGIN
	DECLARE @Return varchar(50)

	SELECT @Return = Description
	FROM 	tblActions
	WHERE	ActionID = @ActionID

	RETURN ISNULL(@Return,'Not Found')

END
go

