CREATE FUNCTION dbo.GetHoldStatus(@HoldReleaseTime datetime, @Now datetime)
RETURNS bit
AS
BEGIN
	DECLARE @Return	bit

	IF (@HoldReleaseTime IS NULL)
		SET @Return = 0
	ELSE
		SELECT @Return = CASE WHEN @HoldReleaseTime < @Now THEN 0
			ELSE 1
		END

	RETURN @Return
END
go

