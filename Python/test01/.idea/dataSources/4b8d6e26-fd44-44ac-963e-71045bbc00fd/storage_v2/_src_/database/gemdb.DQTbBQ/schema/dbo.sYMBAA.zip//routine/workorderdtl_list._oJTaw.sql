CREATE     PROCEDURE dbo.WorkorderDTL_List
@User           char(10),
@WorkOrderID    int
AS
    SELECT	DT.ID,                         -- This is the "UNIQUE" ID for each record in the DTL table.
	        DT.WorkorderID,                -- This links back to the WorkOrderOHD
        	DT.WorkOrderDTLID,             -- Unique ID for this DETAIL record within THIS WorkOrder OHD.
	        DT.WorkOrderDTLDefID,          -- This points to the default overhead ...
          	DT.AssigningEmployeeID,
	        DT.AssignmentDate,
        	DT.CompletingEmployeeID,
	        DT.Completed,           
	        DT.Price,
        	DT.Cost,
	        DT.ActualHours,
        	DT.ScheduledStartDate,
	        DT.ActualStartDate,
        	DT.CompletionDate, 
	        DT.Notes,
		DF.ShortDescription
    FROM    	tblWorkOrderDTL DT
			LEFT JOIN
	    	tblWorkOrderDTLdef DF ON DT.WorkOrderDTLDefID = DF.WorkOrderDTLDefID
    WHERE   	WorkOrderID = @WorkOrderID
    ORDER BY 	WorkOrderDTLID
go

