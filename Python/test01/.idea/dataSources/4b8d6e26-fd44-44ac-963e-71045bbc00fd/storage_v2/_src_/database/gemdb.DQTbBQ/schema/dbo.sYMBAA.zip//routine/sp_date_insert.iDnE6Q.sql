

CREATE PROCEDURE dbo.sp_Date_Insert
@User			char(10),
@DateID		int,
@AccountNo		char(19),
@Date			datetime,
@BadgeNo		char(19)=''
AS
	INSERT INTO	tblDateOHD (DateID,AccountNo,BadgeNo,Date)
	VALUES	(@DateID,@AccountNo,@BadgeNo,@Date)
	
	DECLARE 	@cMsg  char(255),
			@CoreID	int
	SET @CoreID = dbo.GetCoreIDFromUser(@User)
	SET @cMsg = 'Created Date record <' + RTRIM(@DateID) + '> for Account No <' + RTRIM(@AccountNo) + '>'
	EXEC dbo.sp_Logit 3 , @CoreID , @User , @cMsg
go

