
CREATE PROCEDURE [dbo].[NonSelectCycleGet]
@CycleID	int
AS
	SET NOCOUNT ON

	IF (@CycleID > 0)
		SELECT CycleID,
			[Description]
		FROM dbo.cfgNonSelectCycles (NOLOCK)
		WHERE CycleID = @CycleID
	ELSE
		SELECT CycleID,
			[Description]
		FROM dbo.cfgNonSelectCycles (NOLOCK)
		ORDER BY [Description]

	RETURN
go

