CREATE PROCEDURE [dbo].[ad_Vendors_Update]
    @ID int,
    @Description varchar(50),
    @Notes varchar(200)
AS 
    UPDATE  dbo.tblVendors
    SET     [Description] = @Description ,
            Notes = @Notes
    WHERE   ID = @ID
go

