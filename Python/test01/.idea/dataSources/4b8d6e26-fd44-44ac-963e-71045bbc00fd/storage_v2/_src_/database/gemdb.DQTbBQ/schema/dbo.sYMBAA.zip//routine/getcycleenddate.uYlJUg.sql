

CREATE FUNCTION dbo.GetCycleEndDate(@CycleNo int)
RETURNS datetime
AS
BEGIN
	DECLARE	@EndDate	datetime,
			@TestDate	datetime
	
	
	SET @EndDate = dbo.GetCycleStartDate(@CycleNo)
	SET @TestDate = dbo.GetCycleStartDate(@CycleNo + 1)
	
	
	SET @EndDate = DATEADD(mi,-1,@TestDate) 
	RETURN @EndDate
END
go

