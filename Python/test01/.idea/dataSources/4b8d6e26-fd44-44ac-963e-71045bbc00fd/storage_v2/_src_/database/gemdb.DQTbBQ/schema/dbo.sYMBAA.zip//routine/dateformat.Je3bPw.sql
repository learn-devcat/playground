

CREATE FUNCTION dbo.DateFormat (@WholeDate datetime , @Format varchar(250) )
RETURNS varchar(250)
AS 
BEGIN 
	-- REPLACE the 4 character formats
	SET @format = REPLACE( @Format , 'yyyy' , datepart( year , @wholedate ))
	-- REPLACE the 2 character formats
	SET @format = REPLACE( @Format , 'yy' , dbo.Lpad(datepart( year , @wholedate )-2000 ,2,'0'))
	SET @format = REPLACE( @Format , 'qq' , datepart( quarter , @wholedate ))
	SET @format = REPLACE( @Format , 'mm' , datepart( month , @wholedate ))
	SET @format = REPLACE( @Format , 'ma' , dbo.Lpad( datepart( month , @wholedate ),2,'0'))
	SET @format = REPLACE( @Format , 'dy' , datepart( dayofyear , @wholedate ))
	SET @format = REPLACE( @Format , 'dd' , datepart( day , @wholedate ))
	SET @format = REPLACE( @Format , 'da' , dbo.Lpad( datepart( day , @wholedate ) , 2 , '0' ))
	SET @format = REPLACE( @Format , 'wk' , datepart( week , @wholedate ))
	SET @format = REPLACE( @Format , 'ww' , datepart( week , @wholedate ))
	SET @format = REPLACE( @Format , 'dw' , datepart( weekday , @wholedate ))
	SET @format = REPLACE( @Format , 'hh' , datepart( hour , @wholedate ))
	SET @format = REPLACE( @Format , 'mi' , datepart( minute , @wholedate ))
	SET @format = REPLACE( @Format , 'ss' , datepart( second , @wholedate ))
	SET @format = REPLACE( @Format , 'ms' , datepart( millisecond , @wholedate ))
	-- Now, REPLACE the things that 'could' cause more format characters.
	SET @format = REPLACE( @Format , 'sm' , substring( 'JANFEBMARAPRMAYJUNJULAUGSEPOCTNOVDEC', (datepart( month , @wholedate )*3)-2 , 3 ))
	SET @format = REPLACE( @Format , 'lm' , RTRIM( substring( 'January February March April May June July August SeptemberOctober November December ', (datepart( month , @wholedate )*9)-8 , 9 )))
	SET @format = REPLACE( @Format , 'dn' , RTRIM( substring( 'Sunday Monday Tuesday WednesdayThursday Friday Saturday ', (datepart( dw , @wholedate )*9)-8 , 9 )))
	RETURN @Format
	 
END
go

