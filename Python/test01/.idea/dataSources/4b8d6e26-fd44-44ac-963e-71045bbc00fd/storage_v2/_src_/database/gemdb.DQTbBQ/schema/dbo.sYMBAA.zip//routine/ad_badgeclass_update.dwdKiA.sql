CREATE PROCEDURE dbo.ad_BadgeClass_Update
@User			char(10),
@BadgeClassID	int,
@Description	varchar(24),
@DailyLimit		money,
@DailyQtyLimit	int,
@Limit			money,
@ExpireDays		int,
@Status			int,
@BumpByValue	int,
@EnableWeb		int
AS 
	UPDATE	tblBadgeClass
	SET		Description = @Description,
			DailyLimit = @DailyLimit,
			DailyQtyLimit = @DailyQtyLimit,
			Limit = @Limit,
			ExpireDays = @ExpireDays,
			Status = @Status,
			BumpByValue = @BumpByValue,
			EnableWeb = @EnableWeb
	WHERE	BadgeClassID = @BadgeClassID
go

