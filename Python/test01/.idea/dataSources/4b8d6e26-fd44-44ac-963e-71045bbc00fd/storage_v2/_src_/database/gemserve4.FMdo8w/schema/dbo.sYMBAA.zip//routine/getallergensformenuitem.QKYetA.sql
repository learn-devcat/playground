

Create    FUNCTION dbo.GetAllergensForMenuItem(@MenuItemID as int)
RETURNS varchar(500)
AS
BEGIN
	Declare @myAllergens Table (AllergenID int,
				    AllergenName varchar(50),
				    Processed int default(0))
	Declare @Return varchar(500),
		@AllergenID int,
		@AllergenName varchar(50)

	Set @Return = ''

	Insert Into	@myAllergens

	Select 	A.AllergenID,
		C.Description,
		0
	From	tblMenuItemAllergens A
			Left Join
		cfgAllergens C (NOLOCK) On A.AllergenID = C.AllergenID
	Where 	A.MenuITemID = @MenuItemID


	While 1 = 1
	Begin
		Select 	top 1 @AllergenID = AllergenID,
			@AllergenName = AllergenName
		From 	@myAllergens
		Where	Processed = 0
		Order By Processed

		If @@Rowcount = 0
			break

		Set @Return = @Return + ', ' + @AllergenName

		Update 	@myAllergens
		Set	Processed = 1
		Where	AllergenID = @AllergenID
	End
	
	Set @Return = Case @Return When '' Then ', No Allergens Found' else @Return end

        Return Right(@Return,Len(@Return) - 2)

END
go

