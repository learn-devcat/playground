
/*
Retrieves the last meal period id
*/

CREATE FUNCTION dbo.GetLastMealPeriodID(@Today datetime)
RETURNS int
AS

BEGIN
	DECLARE @Return int

        DECLARE @MealPeriods TABLE (MealPeriodID int, BeginTime datetime)

        INSERT INTO @MealPeriods
        SELECT MealPeriodID, dbo.MealPeriodStartTime(@Today,MealPeriodID)
        FROM   dbo.tblMealPeriods
	WHERE MealPeriodID NOT IN (SELECT KeyIn FROM dbo.tblXlat WHERE xlatId = 'NoReportMealPeriod')

        SELECT TOP 1 @Return = MealPeriodID
        FROM   @MealPeriods
        ORDER BY BeginTime DESC

        RETURN ISNULL(@Return,-1)
END
go

