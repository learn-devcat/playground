CREATE   PROCEDURE [dbo].[ol_GetAccountWithBalance]
@CoreID as smallint,
@user as char(10),
@AccountNo as char(19),
@BadgeNo as char(19),
@RevenueCenter as int
AS
DECLARE  @LogLevel   int
DECLARE  @Today      datetime,
	      @TempBadge	char(19),
	      @OutletSubType int,
		  @BadgeClassID int,
		  @BadgeBalance money,
		  @GlobalTransOverride money
		  
	SET @LogLevel = 3		-- Default to Read/Access Level	
	SET @Today = getdate()

	SET @BadgeNo = dbo.RemoveBadgeSwipePrefix(@BadgeNo);

	IF EXISTS (SELECT 1 FROM dbo.tblAccountOHD WHERE AccountNo = @AccountNo AND TransOverride = 1)
		SELECT @GlobalTransOverride = TransOverrideAmt
		FROM dbo.tblAccountOHD WHERE AccountNo = @AccountNo AND TransOverride = 1
	
	/*
	== 
	== 	Retrieve an account record with the associated other fields from the supporting tables.  The Limit, DailyLimit, DailyQty fileds
	==	are resolved to the proper limits for this transaction based on 0 = unlimited spending and > 0 being the limiting value.
	==	Limits are passed up the ladder until the lowest limit is enforced.
	== 
	== 8-April-14 JBurt
	==
	==      Added a case statement that returns the global limits and global balance if the ContributeToGlobalBalance flag is enabled
	==      otherwise it will return the limits and balance as it did previously
	==
	==	------------------------------------------------------------------------------------------------------------------------------------------------------------
	==	
	==	5-May-11 RBeverly
	==	
	==		Add call to dbo.Cycles_MakeAllCurrent which updates all cycles in the system, once a day
	==
	==	------------------------------------------------------------------------------------------------------------------------------------------------------------	
	==
	==	10-Nov-05 RBeverly
	==	
	==		* Changed all "zSelect()" functions to "fnMin()" because $0 does not mean unlimited 
	==		  anymore 
	==		* Returned the subtyped compares back to using the "IsAllowed()" function because 
	==		  it will now determine whether the new exclusions table is being used or 
	==		  the original subtyping is being used.
	==
	==	-------------------------------------------------------------------------------------------------------------------------------------------------------------
	==	
	==	08-Sep-04 wjs
	==	
	==		Modified the masking of the subtypes to include the AccountClass and rearanged the
	==		WHERE clause to move most of the conditions into the right-join command
	==
	==	------------------------------------------------------------------------------------------------------------------------------------------------------------
	==	22-Jan-02 wjs
	==	
	==		Modified the return recordset to remove the BADGE credit limits from the overall credit limits and added
	==		individual fields for the badge limits.  This enabled online to enforce the Account level activity as well
	==		as the individual badge level activity.
	==	-----------------------------------------------------------------------------------------------------------------------------------------------------------------	
	==
	==	SubTyp;es are AND'd and only qualifying TTLS are returned.
	*/
	
	EXEC dbo.Cycles_MakeAllCurrent 0

	SELECT @OutletSubType = Subtype
	FROM   tblOutletOHD
	WHERE	 OutletNo = @RevenueCenter

	IF (@@RowCount = 0 )
	    BEGIN
	      SELECT '/Outlet ' + CAST( @RevenueCenter as varchar(6)) + ' Undefined' as ReturnMsg
	      RETURN
	    END

	SELECT @BadgeClassID = BadgeClassid
	FROM   tblBadgesOHD
	WHERE  AccountNo = @AccountNo AND BadgeNo = @BadgeNo

	SELECT   A.accountno, 
	         b.BadgeNo,
		      dbo. Description_FullNameWithMiddle(B.Lastname, A.lastname, '' ,'',1) as LastName , 
		      dbo. Description_FullNameWithMiddle(B.FirstName, A.Firstname, '' ,'',1) as FirstName , 
		      A.NoVerify, 
		      A.AutoOverPost,
		      A.Description as AcctDesc,
		      c.AccountType, 
		      c.trackinggrp, 
		      c.Category,
		      t.TransClassID, 
		      CASE WHEN tc.ContributeToGlobalBalance = 1 THEN dbo.GetGlobalBalance(A.accountNo)
					ELSE T.Balance
			  END AS Balance,
		      t.Qty, 
		      t.lastpaydate,
		      t.lastchgdate,
		      dbo.isDailyMoney( t.DailyBalance ,t.lastchgdate , getdate()) as AccountDailyBalance,
		      CASE WHEN @GlobalTransOverride IS NOT NULL THEN @GlobalTransOverride
				WHEN tc.ContributeToGlobalBalance = 1 THEN c.GlobalLimit
					ELSE dbo.fnMin( bc.Limit , dbo.fnMin( t.Limit , c.Limit ))
			  END AS Limit,
      		  CASE WHEN @GlobalTransOverride IS NOT NULL THEN @GlobalTransOverride
				ELSE dbo.fnMin( t.DailyLimit, c.DailyLimit ) END AS DailyLimit ,
		      DailyQtyLimit = CASE
		            WHEN dbo.fnMin( t.DailyQtyLimit,  c.DailyQtyLimit ) <=  dbo.isDailyQty( t.DailyQty  ,t.lastchgdate , getdate())  then 0
		            ELSE dbo.fnMin( t.DailyQtyLimit,  c.DailyQtyLimit )
		      END ,
		      CASE WHEN @GlobalTransOverride IS NOT NULL THEN @GlobalTransOverride
				ELSE dbo.fnMin( bc.DailyLimit     ,  B.DailyLimit   ) END  AS  BadgeDailyLimit ,
			  dbo.fnMin( bc.DailyQtyLimit  , B.DailyQtyLimit) AS BadgeDailyQtyLimit ,    	
		      tc.Description, TC.Status as TransClassStatus, 
		      tc.SubType as TransClassSubtype, 
		      o.subtype as OutletSubtype, 
		      b.Flagged, 
		      b.Msg, 
		      dbo.isDailyQty( b.DailyQty ,b.lastchgdate , getdate()) AS BadgeDailyQty,
		      dbo.isDailyMoney( b.DailyBalance ,b.lastchgdate , getdate()) AS BadgeDailyBalance, 
		      CASE WHEN @GlobalTransOverride IS NOT NULL THEN @GlobalTransOverride
				ELSE b.TransLimit END AS TransLimit, 
		      a.Bump200 as BumpBy200,
		      CASE WHEN @GlobalTransOverride IS NOT NULL THEN @GlobalTransOverride
				ELSE b.Limit END AS BadgeLimit,
		      ISNULL((SELECT TOP 1 Total FROM tblBadgeTTL BT WHERE BT.AccountNo = @AccountNo AND BT.BadgeNo = @BadgeNo AND dbo.GetCycleByXREF(0,BT.Date,'BC' + CAST(@BadgeClassID AS varchar(10))) = dbo.GetCycleByXREF(0,getdate(),'BC' + CAST(@BadgeClassID AS varchar(10))) order by Date desc ),0) as BadgeBalance,
		      b.Lost, 
		      b.Stolen, 
		      inactive = case  
				      when  A.Inactive = 1  then 1
				      when  B.Inactive = 1 then 1
				      ELSE 0
			      END  , 
      		bc.Status as BadgeClassStatus, 
      		bc.BumpByValue
	
	FROM 	dbo.tblAccountOHD A
		RIGHT JOIN dbo.tblAccountTTL T on  t.accountno = a.accountno AND T.expiredate >= @Today 
		RIGHT JOIN dbo.tblAccountClass C on c.AccountClassID = a.AccountClassID  AND (dbo.IsAllowed(@RevenueCenter,C.AccountClassID,-1) <> 0 )
		RIGHT JOIN dbo.tblBadgesOHD B on B.AccountNo = @AccountNo AND b.BadgeNo = @BadgeNo AND B.expiredate >= @Today AND B.ActiveDate <= @Today 
		RIGHT JOIN dbo.tblBadgeClass BC on BC.BadgeClassID =  b.BadgeClassID 
		RIGHT JOIN dbo.tblOutletOHD as O on O.OutletNo = @RevenueCenter
		RIGHT JOIN dbo.tblTransClass as TC on tc.TransClassID = t.TransClassID AND TC.disablePOSposting = 0 AND (dbo.IsAllowed(O.OutletNo,-1,TC.TransClassID ) <> 0)
	WHERE 	A.AccountNo=@AccountNo AND
		A.expiredate >= @Today AND 
		A.ActiveDate <= @Today 		
	ORDER BY a.AccountNo,t.TransClassID

	DECLARE @cMsg  char(255)
	
	IF (@@rowcount = 0) 
		BEGIN
			SET @cMsg = 'ol_GetAccountWithBalance Account/Badge # ' + RTRIM(@AccountNO) + '/' + RTRIM(@BadgeNo) + ' <No Match>'
			SET @LogLevel = @LogLevel - 1		-- drop logging level to catch failure.
		END
	ELSE
		SET @cMsg = 'ol_GetAccountWithBalance Account/Badge # ' + RTRIM(@AccountNO) + '/' + RTRIM(@BadgeNo)
		
	EXEC dbo.sp_Logit @LogLevel , @CoreID , @User , @cMsg, 925
go

