CREATE PROCEDURE dbo.pos_Account_Insert
@User			char(10),
@AccountNo 		char(19),
@Description 	char(30),
@Status			int,
@Title			char(10),
@FirstName		char(15),
@LastName		char(20),
@Phone 			char(15),
@Fax 			char(15),
@email			varchar(64),
@AccountClassID	int,
@ActiveDate		datetime,
@ExpireDate		datetime
AS
	DECLARE	@Temp	char(10),
			@TempTTL	varchar(20),
			@AccountTTL	varchar(10),
			@TIndex	int
	SELECT 	@Temp = AccountNo
	FROM	tblAccountOHD
	WHERE	AccountNo = @AccountNo
	IF (@@ROWCOUNT = 0)	
	BEGIN
		-- Insert the Account
		INSERT INTO tblAccountOHD (AccountNo, Description, Status, Title, FirstName, LastName, Phone, Fax, email, AccountClassID, ActiveDate, ExpireDate, ModifiedBy)
		VALUES	(@AccountNo,@Description,@Status,@Title,@FirstName,@LastName,@Phone,@Fax,@email,@AccountClassID,@ActiveDate,@ExpireDate, @User)
		
		-- Insert TTL's found in the Overhead table
		SELECT @TempTTL = RTRIM(dbo.GetOverheadItem('AccountTTL'))
		
		WHILE ( @TempTTL <> '' )
		BEGIN
			SET @TIndex = CHARINDEX(',',@TempTTL)
			
			IF ( @TIndex > 0 )
			BEGIN
				SET @AccountTTL = SUBSTRING(@TempTTL,1,@TIndex - 1)
				SET @TempTTL = RIGHT(@TempTTL,LEN(@TempTTL) - @TIndex)
			END
			ELSE
			BEGIN
				SET @AccountTTL = @TempTTL
				SET @TempTTL = ''
			END
			EXEC dbo.sp_AccountTTL_Insert @User, @AccountNo, @AccountTTL
		END
	END
go

