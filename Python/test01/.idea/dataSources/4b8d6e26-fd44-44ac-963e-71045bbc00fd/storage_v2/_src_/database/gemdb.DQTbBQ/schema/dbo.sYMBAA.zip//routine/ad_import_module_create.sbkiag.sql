

CREATE PROCEDURE dbo.ad_Import_Module_Create
@sModuleNum		char(4)
AS
	DECLARE @Error	varchar(100)
	IF @sModuleNum IN (SELECT DISTINCT sModule FROM cfgScriptParams)
	BEGIN
		SET @Error = 'ERROR: Module ' + '"'  + RTRIM(@sModuleNum) + '" already in use, please choose another number AND run the SP again'
		RAISERROR (@Error, 16, 1)
		RETURN
	END
	
	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('AccountTTL','',@sModuleNum)
	
	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('AddBadgeOnImport','',@sModuleNum)

	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('AddBatchRecords','1',@sModuleNum)

	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('BadgeLocationID','0',@sModuleNum)		

	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('DefaultCreditLimit','999999',@sModuleNum)

	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('IgnoreManuallyEditedAccounts','0',@sModuleNum)
			
	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('ImportAcctClass','',@sModuleNum)
	
	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('ImportBadgeClass','',@sModuleNum)
	
	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('ImportDelimiter','44',@sModuleNum)

	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('ImportDisableFlag','111',@sModuleNum)

	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('ImportFields','',@sModuleNum)
		
	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('ImportFile','',@sModuleNum)
	
	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('ImportKeyFields','0',@sModuleNum)
	
	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('ImportPostProc','ie_AccountImport_v4_00',@sModuleNum)

	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('ImportSource','',@sModuleNum)
	
	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('ImportView','vueImportAccount',@sModuleNum)
	
	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('ImportVueFields','',@sModuleNum)	
	
	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('InactivateInFile','0',@sModuleNum)
	
	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('InactivateNewAccts','1',@sModuleNum)
	
	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('InactivateNotInFile','1',@sModuleNum)

	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('InactivateOldBadges','0',@sModuleNum)

	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('LocationID','0',@sModuleNum)

	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('PostProc1','',@sModuleNum)

	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('PrimaryAddressID','100',@sModuleNum)

	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('ReActivateInFile','',@sModuleNum)
	
	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('ScriptType','import',@sModuleNum)
	
	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('StripBadgeZeros','0',@sModuleNum)
	
	INSERT INTO cfgScriptParams (KeyName, sValue, sModule)
	VALUES('UpdateGEMDesktop','0',@sModuleNum)
go

