
CREATE PROCEDURE dbo.MessageGet
@ControlName    varchar(50),
@Language       int         = 0,
@PageID         varchar(50) = ''

AS

	SET NOCOUNT ON

	IF (@Language = 0)
		SET @Language = 1033

        SELECT TOP 1 Message
        FROM dbo.tblMessages
        WHERE ControlName = @ControlName
                AND (Language = 0 OR Language = @Language)
                AND PageID = @PageID
        ORDER BY Language DESC
	
        RETURN
go

