CREATE PROCEDURE dbo.ie_AccountImport
@AccountTTL	varchar(50)='',
@AddBadge	int=0,
@AccountClass	varchar(100)=''
AS
	DECLARE	@BadgeClass		int,
		@StripZeros		int,
		@InactiveOnImport	int,
		@TempAccountClass	varchar(100),
		@TempAccountClassID	int
	SET @TempAccountClass = @AccountClass
	IF (ISNULL(dbo.GetOverheadItem('InactiveOnImport'),1) = '')
		SET @InactiveOnImport = 1
	ELSE
		SELECT @InactiveOnImport = ISNULL(dbo.GetOverheadItem('InactiveOnImport'),1)
	IF (ISNULL(dbo.GetOverheadItem('StripBadgeZeros'),0) = '')
		SET @StripZeros = 0
	ELSE
		SELECT @StripZeros = ISNULL(dbo.GetOverheadItem('StripBadgeZeros'),0)
	IF (@StripZeros = 1)
		UPDATE tblAccountImport SET BadgeNo = dbo.StripLeadingZeros(BadgeNo)
			WHERE LEFT(BadgeNo,1) = '0'
	SET @BadgeClass = CAST(dbo.GetScriptParam('importbadgeclass') as int) 
	-- SET all flags that are not 'M' to 'N' for importing 
	-- Use the AccountClass string IF present.
	IF ( @AccountClass = '' )
	BEGIN
		UPDATE	tblAccountOHD
		SET 	ImpExpFlag = 'N',
				LastUpdateDate = GETDATE()
		WHERE	ImpExpFlag <> 'M'
	END
	ELSE
	BEGIN
		WHILE @TempAccountClass <> ''
		BEGIN
			IF ( CHARINDEX(',', @TempAccountClass) <> 0 )
			BEGIN
				SET @TempAccountClassID = CAST(LEFT(@TempAccountClass, CHARINDEX(',', @TempAccountClass) - 1) AS int)
				SET @TempAccountClass = RIGHT(@TempAccountClass, LEN(@TempAccountClass) - CHARINDEX(',', @TempAccountClass))
			END
			ELSE
			BEGIN
				SET @TempAccountClassID = CAST(@TempAccountClass AS int)
				SET @TempAccountClass = ''
			END
 			UPDATE	tblAccountOHD
 			SET 	ImpExpFlag = 'N',
					LastUpdateDate = GETDATE()
 			WHERE	AccountClassID = @TempAccountClassID
				AND ImpExpFlag <> 'M'
		END
	END
	--SET the ImpExpFlag in the import table to 'N' to prepare for importing
	UPDATE 	tblAccountImport
	SET		ImpExpFlag = 'N'
	--UPDATE existing records in the tblAccountOHD table
	UPDATE	tblAccountOHD
	SET		tblAccountOHD.Description = ISNULL(I.Description, A.Description),
			tblAccountOHD.AccessID = ISNULL(I.AccessID, A.AccessID),
			tblAccountOHD.Status = ISNULL(I.Status, A.Status),
			tblAccountOHD.Title = ISNULL(I.Title, A.Title),
			tblAccountOHD.FirstName = ISNULL(I.FirstName, A.FirstName),
			tblAccountOHD.LastName = ISNULL(I.LastName, A.LastName),
			tblAccountOHD.Phone = ISNULL(I.Phone, A.Phone),
			tblAccountOHD.Fax = ISNULL(I.Fax, A.Fax),
			tblAccountOHD.email = ISNULL(I.email, A.email),
			tblAccountOHD.AccountClassID = ISNULL(dbo.AccountClassLU(I.AccountClassID), A.AccountClassID),
			tblAccountOHD.PIN = ISNULL(I.PIN, A.PIN),
			tblAccountOHD.ActiveDate = ISNULL(I.ActiveDate, A.ActiveDate),
			tblAccountOHD.ExpireDate = ISNULL(I.ExpireDate, A.ExpireDate),
			tblAccountOHD.Process = ISNULL(I.Process, A.Process),
			tblAccountOHD.Reference = ISNULL(I.Reference, A.Reference),
			tblAccountOHD.ImpExpFlag = 'Y',
			tblAccountOHD.Inactive = ISNULL(I.Inactive, A.Inactive),
			tblAccountOHD.NoStatements = ISNULL(I.NoStatements, A.NoStatements),
			tblAccountOHD.NoAging = ISNULL(I.NoAging, A.NoAging),
			tblAccountOHD.NoFinanceChg = ISNULL(I.NoFinanceChg, A.NoFinanceChg),
			tblAccountOHD.NoVerify = ISNULL(I.NoVerify, A.NoVerify),
			tblAccountOHD.NoDetail = ISNULL(I.NoDetail, A.NoDetail),
			tblAccountOHD.Bump200 = ISNULL(I.Bump200, A.Bump200),
			tblAccountOHD.AutoOverpost = ISNULL(I.AutoOverpost, A.AutoOverpost),
			tblAccountOHD.LastUpdateDate = GETDATE()
	FROM	tblAccountOHD AS A, tblAccountImport AS I 
	WHERE	A.AccountNo = I.AccountNo
	--SET the flags in the import table for import records that have been updated in the tblAccountOHD table
	UPDATE 	tblAccountImport
	SET		ImpExpFlag = 'E'
	FROM		tblAccountImport AS I, tblAccountOHD AS A
	WHERE	I.AccountNo = A.AccountNo
			AND A.ImpExpFlag <> 'M'
	--Insert remaining (new) items in the import table into the tblAccountOHD table 
	--Use distinct AND only import the account numbers in case a file has a duplicate
	--account number.
	INSERT INTO 	tblAccountOHD (AccountNo, AccountClassID, ImpExpFlag)
	SELECT DISTINCT AccountNo, 
			ISNULL(dbo.AccountClassLU(AccountClassID),CAST(dbo.GetScriptParam('importacctclass') AS int)),
			'Y'
	FROM	tblAccountImport
	WHERE	AccountNo IS NOT NULL AND
			ISNULL(ImpExpFlag,'') <> 'E'
	--UPDATE the new accounts that were just added with the other information FROM the import table
	UPDATE	tblAccountOHD
	SET		tblAccountOHD.Description = ISNULL(I.Description, A.Description),
			tblAccountOHD.AccessID = ISNULL(I.AccessID, A.AccessID),
			tblAccountOHD.Status = ISNULL(I.Status, A.Status),
			tblAccountOHD.Title = ISNULL(I.Title, A.Title),
			tblAccountOHD.FirstName = ISNULL(I.FirstName, A.FirstName),
			tblAccountOHD.LastName = ISNULL(I.LastName, A.LastName),
			tblAccountOHD.Phone = ISNULL(I.Phone, A.Phone),
			tblAccountOHD.Fax = ISNULL(I.Fax, A.Fax),
			tblAccountOHD.email = ISNULL(I.email, A.email),
			tblAccountOHD.AccountClassID = ISNULL(dbo.AccountClassLU(I.AccountClassID), A.AccountClassID),
			tblAccountOHD.PIN = ISNULL(I.PIN, A.PIN),
			tblAccountOHD.ActiveDate = ISNULL(I.ActiveDate, A.ActiveDate),
			tblAccountOHD.ExpireDate = ISNULL(I.ExpireDate, A.ExpireDate),
			tblAccountOHD.Process = ISNULL(I.Process, A.Process),
			tblAccountOHD.Reference = ISNULL(I.Reference, A.Reference),
			tblAccountOHD.ImpExpFlag = 'Y',
			tblAccountOHD.Inactive = ISNULL(I.Inactive, A.Inactive),
			tblAccountOHD.NoStatements = ISNULL(I.NoStatements, A.NoStatements),
			tblAccountOHD.NoAging = ISNULL(I.NoAging, A.NoAging),
			tblAccountOHD.NoFinanceChg = ISNULL(I.NoFinanceChg, A.NoFinanceChg),
			tblAccountOHD.NoVerify = ISNULL(I.NoVerify, A.NoVerify),
			tblAccountOHD.NoDetail = ISNULL(I.NoDetail, A.NoDetail),
			tblAccountOHD.Bump200 = ISNULL(I.Bump200, A.Bump200),
			tblAccountOHD.AutoOverpost = ISNULL(I.AutoOverpost, A.AutoOverpost),
			tblAccountOHD.LastUpdateDate = GETDATE()
	FROM	tblAccountOHD AS A, tblAccountImport AS I 
	WHERE	A.AccountNo = I.AccountNo
			AND ISNULL(I.ImpExpFlag,'') <> 'E'
			AND A.ImpExpFlag <> 'M'
	--Create AccountTTL's for new accounts
	IF (@AccountTTL <> '')
	BEGIN
		DECLARE 	@Start		int,
				@String	char(3)
				
		SET @Start = 0		
		WHILE (LEN(@AccountTTL) > 0)
			BEGIN
				SELECT @Start = CHARINDEX(',',@AccountTTL)
				IF (ISNULL(@Start,0) = 0)
				BEGIN
					SET @String = @AccountTTL
					BREAK
				END
				ELSE
				BEGIN
					SET @String = LEFT(@AccountTTL, @Start - 1)
				
					INSERT INTO	tblAccountTTL (AccountNo, TransClassID)
					SELECT 	I.AccountNo, CAST(@String AS int)
					FROM		tblAccountImport AS I
					WHERE	I.ImpExpFlag <> 'E'
					SET @AccountTTL = RIGHT(@AccountTTL,LEN(@AccountTTL) - @Start)
				END
			END
		--Final number in string
		INSERT INTO	tblAccountTTL (AccountNo, TransClassID)
		SELECT 	I.AccountNo, CAST(@String AS int)
		FROM		tblAccountImport AS I
		WHERE	I.ImpExpFlag <> 'E'
	END
	--Create Badges for ones that don't exist AND UPDATE existing badges
	IF (@AddBadge <> 0)
	BEGIN 
	
		--UPDATE existing badges
		UPDATE	tblBadgesOHD
		SET		tblBadgesOHD.FirstName = ISNULL(I.FirstName,''),
				tblBadgesOHD.LastName = ISNULL(I.LastName,''),
				tblBadgesOHD.Limit = ISNULL(I.CreditLimit,999999),
				tblBadgesOHD.Inactive = ISNULL(I.Inactive, 0)
		FROM		tblBadgesOHD AS B
				LEFT JOIN
				tblAccountImport AS I
		ON		B.AccountNo = I.AccountNo
				AND B.BadgeNo = I.BadgeNo
		WHERE	I.ImpExpFlag = 'E' 
		--Inactivate existing badges that WHERE not imported for accounts that were imported
		UPDATE	tblBadgesOHD
		SET		Inactive = 1
		FROM		tblBadgesOHD,tblAccountImport AS I
		WHERE	I.ImpExpFlag = 'E' AND 
				(tblBadgesOHD.AccountNo IN (SELECT AccountNo FROM tblAccountImport) 
				AND tblBadgesOHD.BadgeNo NOT IN 
				(SELECT B.BadgeNo FROM tblBadgesOHD AS B,tblAccountImport AS IM WHERE B.AccountNo = IM.AccountNo
				 AND B.BadgeNo = IM.BadgeNo))
									
		--Insert new badges into the tblBadgesOHD table for new accounts
		INSERT INTO	tblBadgesOHD (AccountNo, BadgeNo, FirstName, LastName, BadgeClassID,Limit, Inactive)
		SELECT	I.AccountNo AS Acct, 
				I.BadgeNo AS Badge, 
				ISNULL(I.FirstName,''), 
				ISNULL(I.LastName,''),
				@BadgeClass,
				ISNULL(I.CreditLimit,999999),
				@InactiveOnImport
		FROM		tblAccountImport AS I
		WHERE	ISNULL(I.ImpExpFlag,'Z') <> 'E' 
		--Insert new badges into the tblBadgesOHD table for existing accounts
		INSERT INTO	tblBadgesOHD (AccountNo, BadgeNo, FirstName, LastName, BadgeClassID,Limit, Inactive)
		SELECT	I.AccountNo AS Acct, 
				I.BadgeNo AS Badge, 
				ISNULL(I.FirstName,''), 
				ISNULL(I.LastName,''),
				@BadgeClass,
				ISNULL(I.CreditLimit,999999),
				0
		FROM		tblAccountImport AS I
		WHERE		ISNULL(I.ImpExpFlag,'Z') = 'E' AND I.BadgeNo NOT IN (SELECT BadgeNo FROM tblBadgesOHD WHERE AccountNo = I.AccountNo)
	END
	--SET the flags in the import table for import records that have been updated in the tblAccountOHD table
	UPDATE 	tblAccountImport
	SET		ImpExpFlag = 'A'
	FROM		tblAccountImport AS I, tblAccountOHD AS A
	WHERE	I.AccountNo = A.AccountNo
	--UPDATE existing records in the tblAccountAddress table
	UPDATE 	tblAccountAddress
	SET		tblAccountAddress.Address1 = ISNULL(I.Address1,AD.Address1),
			tblAccountAddress.Address2 = ISNULL(I.Address2,AD.Address2),
			tblAccountAddress.Address3 = ISNULL(I.Address3,AD.Address3),
			tblAccountAddress.Address4 = ISNULL(I.Address4,AD.Address4),
			tblAccountAddress.Address5 = ISNULL(I.Address5,AD.Address5)
	FROM		tblAccountAddress AS AD, tblAccountImport AS I
	WHERE 	AD.AccountNo = I.AccountNo AND
			UPPER(AD.AddressID) = 100
	
	--SET the flags in the import table for import records that have been updated in the tblAccountAddress table
	UPDATE 	tblAccountImport
	SET		ImpExpFlag = 'U'
	FROM		tblAccountImport AS I, tblAccountAddress AS A
	WHERE	I.AccountNo = A.AccountNo AND
			A.AddressID = 100
	--Insert the remaining (new) items into the tblAccountAddress table (non-NULL items only)
	INSERT INTO	tblAccountAddress (AccountNo, AddressID, Address1, Address2, Address3,
						Address4, Address5)
	SELECT	AccountNo,
			100,
			ISNULL(Address1,''),
			ISNULL(Address2,''),
			ISNULL(Address3,''),
			ISNULL(Address4,''),
			ISNULL(Address5,'')
	FROM		tblAccountImport
	WHERE	ImpExpFlag <> 'U'
	
	--DELETE all records in the tblAccountImport table
	DELETE	tblAccountImport
	WHERE	ImpExpFlag = 'A' OR
			ImpExpFlag = 'U'
	-- SET all accounts that were not imported to inactive
	-- Use the AccountClass string IF present. Otherwise, this action will affect all accounts
	IF ( @AccountClass = '' )
	BEGIN
		UPDATE	tblAccountOHD
		SET 	Inactive = 1,
				LastUpdateDate = GETDATE()
		WHERE	ImpExpFlag = 'N'
	END
	ELSE
	BEGIN
		SET @TempAccountClass = @AccountClass
		WHILE @TempAccountClass <> ''
		BEGIN
			IF ( CHARINDEX(',', @TempAccountClass) <> 0 )
			BEGIN
				SET @TempAccountClassID = CAST(LEFT(@TempAccountClass, CHARINDEX(',', @TempAccountClass) - 1) AS int)
				SET @TempAccountClass = RIGHT(@TempAccountClass, LEN(@TempAccountClass) - CHARINDEX(',', @TempAccountClass))
			END
			ELSE
			BEGIN
				SET @TempAccountClassID = CAST(@TempAccountClass AS int)
				SET @TempAccountClass = ''
			END
			UPDATE	tblAccountOHD
			SET 	Inactive = 1,
					LastUpdateDate = GETDATE()
 			WHERE	AccountClassID = @TempAccountClassID
				AND ImpExpFlag = 'N'
		END
	END
	EXEC pub_CreateLoginsFromAccounts
go

