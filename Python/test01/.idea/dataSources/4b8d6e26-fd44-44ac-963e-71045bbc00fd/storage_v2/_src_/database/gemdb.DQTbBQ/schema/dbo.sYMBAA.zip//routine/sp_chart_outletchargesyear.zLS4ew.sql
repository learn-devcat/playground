CREATE PROCEDURE [dbo].[sp_Chart_OutletChargesYear]
	AS

	DECLARE @Today datetime;

	SET @Today = getdate();

	WITH ThisYearsCharges as(
	SELECT o.OutletName, o.OutletNo, sum(d.TransTotal) as YearSumOfCharges, count(d.DetailID) as YearNumberOfCharges, DATEPART(YEAR,@Today) as YearValue
		FROM  tblOutletOHD as o
		INNER JOIN tblDetail as d on d.OutletNo = o.OutletNo 
		INNER JOIN tblTransDef as t on d.TransID = t.TransID
		WHERE  t.Payment = 0
		AND DATEPART(YEAR, d.TransDate) = DATEPART(YEAR,@Today)
		GROUP BY o.OutletNo, o.OutletName
		)
	, ThisYearsPayments as (
	SELECT o.OutletName, o.OutletNo, sum(d.TransTotal) as YearSumOfPayments, count(d.DetailID) as YearNumberOfPayments, DATEPART(YEAR,@Today) as YearValue
		FROM  tblOutletOHD as o
		INNER JOIN tblDetail as d on d.OutletNo = o.OutletNo 
		INNER JOIN tblTransDef as t on d.TransID = t.TransID
		WHERE  t.Payment = 1
		AND DATEPART(YEAR, d.TransDate) = DATEPART(YEAR,@Today)
		GROUP BY o.OutletNo, o.OutletName
	)
	, LastYearsCharges as(
	SELECT o.OutletName, o.OutletNo, sum(d.TransTotal) as YearSumOfCharges, count(d.DetailID) as YearNumberOfCharges, DATEPART(YEAR,@Today)-1 as YearValue
		FROM  tblOutletOHD as o
		INNER JOIN tblDetail as d on d.OutletNo = o.OutletNo 
		INNER JOIN tblTransDef as t on d.TransID = t.TransID
		WHERE  t.Payment = 0
		AND DATEPART(YEAR, d.TransDate) = DATEPART(YEAR,@Today)-1
		GROUP BY o.OutletNo, o.OutletName
		)
	, LastYearsPayments as (
	SELECT o.OutletName, o.OutletNo, sum(d.TransTotal) as YearSumOfPayments, count(d.DetailID) as YearNumberOfPayments, DATEPART(YEAR,@Today)-1 as YearValue
		FROM  tblOutletOHD as o
		INNER JOIN tblDetail as d on d.OutletNo = o.OutletNo 
		INNER JOIN tblTransDef as t on d.TransID = t.TransID
		WHERE  t.Payment = 1
		AND DATEPART(YEAR, d.TransDate) = DATEPART(YEAR,@Today)-1
		GROUP BY o.OutletNo, o.OutletName
	)

	select o.OutletName, 
	o.OutletNo as OutletNO,  
	COALESCE(tc.YearNumberOfCharges, 0) as ThisYearNumberOfCharges, 
	cast(COALESCE(tc.YearSumOfCharges, 0.0000) as money) as ThisYearSumOfCharges, 
	COALESCE(tp.YearNumberOfPayments,0) as ThisYearNumberOfPayments, 
	cast(COALESCE(tp.YearSumOfPayments,0.0000) as money) as ThisYearSumOfPayments, 
	DATEPART(YEAR,@Today) as ThisYearValue,
	COALESCE(lc.YearNumberOfCharges, 0) as LastYearNumberOfCharges, 
	cast(COALESCE(lc.YearSumOfCharges, 0.0000) as money) as LastYearSumOfCharges, 
	COALESCE(lp.YearNumberOfPayments,0) as LastYearNumberOfPayments, 
	cast(COALESCE(lp.YearSumOfPayments,0.0000) as money) as LastYearSumOfPayments, 
	DATEPART(YEAR,@Today)-1 as LastYearValue
	FROM tblOutletOHD as o
	LEFT JOIN ThisYearsPayments as tp on o.OutletNo = tp.OutletNo
	LEFT JOIN ThisYearsCharges as tc on o.OutletNo = tc.OutletNo
	LEFT JOIN LastYearsPayments as lp on o.OutletNo = lp.OutletNo
	LEFT JOIN LastYearsCharges as lc on o.OutletNo = lc.OutletNo
	Order By OutletNo
		
	RETURN 0


go

