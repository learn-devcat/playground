

CREATE FUNCTION dbo.GetMealPeriodShortNameForOrder(@OrderID int)
RETURNS varchar(50)
BEGIN
	DECLARE @Return	varchar(50)

	SELECT @Return = COALESCE(M.ShortName,M.[Description],'Not Found')
	FROM	dbo.tblOrderOHD AS O
		JOIN dbo.tblWave AS W ON O.WaveID = W.WaveID
		JOIN dbo.tblMealPeriods AS M ON M.MealPeriodID = W.MealPeriodID
	WHERE 	O.OrderID = @OrderID

	RETURN @Return
END
go

