CREATE PROCEDURE [dbo].[sim_PatientNotes]
@PatientVisitID	varchar(20),
@WaveID			int,
@WaveDate		datetime
AS
	SET NOCOUNT ON

DECLARE    @string VARCHAR(3000),
           @length INT,
		   @string_length INT,
           @output        VARCHAR(3000),
           @trailing_char CHAR(1),
           @leading_char  CHAR(1),
           @maxRows		  INT,
           @found		  INT,
           @tempOutput	  VARCHAR(80),
           @count		  INT,
		   @Notes		  VARCHAR(3000),
		   @DietNotes	  VARCHAR(3000)

	SET @count = 0  
	SET @maxRows = 11
	SET @length = 55

	SELECT	@Notes = RTRIM(CAST(P.Notes AS VARCHAR(3000))),
			@DietNotes = RTRIM(COALESCE(dbo.GetActiveDietNotesEX(@PatientVisitID, @WaveDate, @WaveID),''))
	FROM dbo.tblPatientOHD AS P (NOLOCK)
		JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON P.PatientID = PV.PatientID
	WHERE PV.PatientVisitID = @PatientVisitID

	--Add diet notes to the string for evaluation if diet notes exists
	IF (LEN(@DietNotes) > 0)
		SET @string = @DietNotes

	--Add the patient notes to string for evaluation if the patient notes exist
	IF (LEN(@Notes) > 0)
	BEGIN
		-- Append the patient notes to the diet notes if the diet notes already exist
		IF (LEN(@string)>0)
			SET @string = @string + '$$' + @Notes
		ELSE
			SET @string = @Notes
	END

	-- identify the line feeds - CHAR(10) and remove the carriage returns - CHAR(13)
	IF (CHARINDEX(CHAR(10),@string) <> 0) OR (CHARINDEX(CHAR(13),@string) <> 0)
	BEGIN
		SET @string = REPLACE(@string,CHAR(10),'$$')
		SET @string = REPLACE(@string,CHAR(13),'')
	END
  
	SET CONCAT_NULL_YIELDS_NULL OFF
 
	SET @string_length = LEN(@string)

	-- determine the row breakpoints for the notes  
	WHILE (@string_length > @length)
	BEGIN
		IF (@count >= @maxRows)
			BREAK
		IF (CHARINDEX('$$', LEFT(@string,(@length + 1))) > 0)
		BEGIN
			-- This section handles embedded line feeds
			-- find first occurence of the line feeds and break there 
			SET @found = CHARINDEX('$$',LEFT(@string,(@length + 1)))
			SET @tempOutput = SUBSTRING(@string, 1, @found - 1)
			SET @output = @output + @tempOutput + CHAR(28)
			SET @string = RIGHT(@string, LEN(@string) - (@found + 1))
			SET @string_length = LEN(@string)
			SET @count = @count + 1
		END
		ELSE 
		BEGIN
			-- This section handles parsing the string when there are no embedded line feeds
			SET @trailing_char = SUBSTRING(LEFT(@string,(@length + 1)),(@length + 1),1)
			SET @leading_char = SUBSTRING(LEFT(@string,@length),@length,1)
		    
			IF (@leading_char = ' ' OR @trailing_char = ' ')
			  BEGIN
				SET @tempOutput = SUBSTRING(@string,1,@length)
				SET @output = @output + @tempOutput + CHAR(28)
				SET @string = SUBSTRING(@string, (LEN(@tempOutput) + 1), (LEN(@string) - LEN(@tempOutput)+ 1))
				SET @string_length = LEN(@string)
				SET @count = @count + 1
			  END
			ELSE
			BEGIN
			    -- find the first occurrence of a pipe '|' or blank space before the trailing space
				DECLARE @i INT,
						@j INT  --Used for removing pipe '|' or blank spaces if needed
				SET @j = 2
				-- search for a pipe character before the trailing space
				SET @i = CHARINDEX('|',REVERSE(SUBSTRING(@string,1,@length)))
				--no pipe character found so look for a blank space
				IF (@i = 0)
					SET @i = CHARINDEX(' ',REVERSE(SUBSTRING(@string,1,@length)))
				--no blank space found
				IF (@i = 0)
					SET @j = 1
				SET @output = @output + SUBSTRING(@string,1,(@length - @i)) + CHAR(28)
				SET @string = SUBSTRING(@string,(@length - @i + @j),(LEN(@string) - (@length - @i + @j - 1)))
				SET @count = @count + 1
			END
		END
	END

	-- This section handles the remaining string.
	-- We still need to check for embedded line feeds
	WHILE (CHARINDEX('$$', @string) > 0)
	BEGIN
		IF (@count >= @maxRows)
			BREAK
		-- find first occurence of the line feed and break there
		SET @found = CHARINDEX('$$',LEFT(@string,(@length + 1)))
		SET @tempOutput = SUBSTRING(@string, 1, @found - 1)
		SET @output = @output + @tempOutput + CHAR(28)
		SET @string = RIGHT(@string, LEN(@string) - (@found + 1))
		SET @string_length = LEN(@string)
		SET @count = @count + 1
	END

	-- If we have a file separator on the end of our return string, remove it
	IF (RIGHT(@output, 1) = CHAR(28))
		SET @output = LEFT(@output, LEN(@output) - 1)

	-- Add the ... if there is still some string left
	IF ((@count >= @maxRows) AND (LEN(@string) > 0))
	BEGIN
		SET @output = @output + CHAR(28) + '...'
		SET @count = @count + 1
	END
	ELSE IF ((LEN(RTRIM(@string)) > 0) AND (@Count = 0))
	BEGIN
		--there are notes but there is no split needed so increment the count
		SET @output = @string
		SET @count = @count + 1
	END
	ELSE IF (LEN(RTRIM(@string)) > 0)
	BEGIN
		--append the remaining notes
		SET @output = @output + CHAR(28) + @string
		SET @count = @count + 1
	END

	SELECT CAST(@count AS varchar(2)) + CHAR(28) + @output
go

