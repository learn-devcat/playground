CREATE PROCEDURE [dbo].[StatusFlagDelete]
@LoginUserId VARCHAR (250), @StatusFlagID INT
AS
DELETE dbo.tblStatusFlags
	WHERE StatusFlagID = @StatusFlagID
go

