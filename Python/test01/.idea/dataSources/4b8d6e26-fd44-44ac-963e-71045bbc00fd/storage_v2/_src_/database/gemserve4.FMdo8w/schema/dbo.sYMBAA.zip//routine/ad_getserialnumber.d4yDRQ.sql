CREATE PROCEDURE [dbo].[ad_GetSerialNumber]
	@DBID	int 
AS

	SELECT SerialNumber
	FROM GEM.dbo.tblDatabases
	WHERE DatabaseID = @DBID
	
	RETURN
go

