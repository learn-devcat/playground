

CREATE PROCEDURE [dbo].[ad_TransClass_Get_EX]
@User				char(10),
@TransClassID		int
AS 
	SELECT	TransClassID,
			Description,
			Status,
			DisablePOSPosting,
			DeclBalMode,
			AddToBadgeBalance,
			SubType,
			EnableTimepay,
			Limit,
			MinTransaction,
			MaxTransaction,
			MaxPeriods,
			MinPayment,
			RecurChgClassID,
			TransID,
			RecurChgPayTransID,
			Breakpoints,
			Automatic,
			ContributeToGlobalBalance,
			CheckShowAccountBalance, 
			CheckShowAccountBalanceLabel, 
			CheckShowAccountRemainingBalance, 
			CheckShowAccountRemainingBalanceLabel, 
			CheckShowAccountDailyBalance, 
			CheckShowAccountDailyBalanceLabel, 
			CheckShowAccountRemainingDailyBalance, 
			CheckShowAccountRemainingDailyBalanceLabel, 
			CheckShowAccountQuantity, 
			CheckShowAccountQuantityLabel, 
			CheckShowAccountQuantityRemaining, 
			CheckShowAccountQuantityRemainingLabel, 
			ChecksShowReverseSign
	FROM	tblTransClass
	WHERE	TransClassID = @TransClassID
go

