

CREATE PROCEDURE dbo.DietMealPeriodNutrientDelete
@LoginUserID		varchar(250),
@DietID		int,
@NutrientID	int,
@MealPeriodID	int
AS
	SET NOCOUNT ON

	DELETE dbo.tblDietMealPeriodNutrients
	WHERE	DietID = @DietID
		AND NutrientID = @NutrientID
		AND MealPeriodID = @MealPeriodID

	RETURN
go

