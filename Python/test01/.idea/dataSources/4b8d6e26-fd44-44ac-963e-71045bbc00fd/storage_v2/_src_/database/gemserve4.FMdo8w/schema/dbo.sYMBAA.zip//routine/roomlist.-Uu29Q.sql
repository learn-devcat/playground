


CREATE PROCEDURE [dbo].[RoomList]
@LocationClassID	int=0

AS
	SET NOCOUNT ON

	IF ( @LocationClassID = 0 )
		SELECT	R.RoomID,
			R.RoomNumber,
			R.RoomClassID,
			R.LocationClassID,
			R.PhoneNumber,
			R.IP,
			R.Privilege,
			R.Diet,
			R.Notes,
			L.Description AS LocationClass
		FROM dbo.tblRoomOHD AS R (NOLOCK)
		JOIN dbo.tblLocationClass AS L (NOLOCK) ON R.LocationClassID = L.LocationClassID
		ORDER BY R.LocationClassID, R.RoomNumber	
	ELSE
		SELECT	R.RoomID,
			R.RoomNumber,
			R.RoomClassID,
			R.LocationClassID,
			R.PhoneNumber,
			R.IP,
			R.Privilege,
			R.Diet,
			R.Notes,
			L.Description AS LocationClass
		FROM dbo.tblRoomOHD AS R (NOLOCK)
		JOIN dbo.tblLocationClass AS L (NOLOCK) ON R.LocationClassID = L.LocationClassID
		WHERE	R.LocationClassID = @LocationClassID
		ORDER BY R.RoomNumber	
	
	RETURN
go

