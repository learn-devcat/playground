


CREATE PROCEDURE [dbo].[ad_Location_InsertEX]
    @User char(10),
    @LocationID int,
    @Description varchar(50),
    @DefaultChargeOutlet int,
    @DefaultPaymentOutlet int,
    @DefaultWorkOrderOutlet int,
	@TimeZone varchar(50),
	@UserCode1 varchar(50),
	@UserCode2 varchar(50),
	@UserCode3 varchar(50),
	@UserCode4 varchar(50),
	@UserCode5 varchar(50)
AS 
    INSERT  INTO cfgLocations
            (
              LocationID,
              Description,
              DefaultChargeOutlet,
              DefaultPaymentOutlet,
              DefaultWorkOrderOutlet,
			  TimeZone,
			  UserCode1,
			  UserCode2,
			  UserCode3,
			  UserCode4,
			  UserCode5
              )
    VALUES  (
              @LocationID,
              @Description,
              @DefaultChargeOutlet,
              @DefaultPaymentOutlet,
              @DefaultWorkOrderOutlet,
			  @TimeZone,
			  @UserCode1,
			  @UserCode2,
			  @UserCode3,
			  @UserCode4,
			  @UserCode5
            )
            
	EXEC dbo.gem_UserAddLocation 'support', @LocationID
go

