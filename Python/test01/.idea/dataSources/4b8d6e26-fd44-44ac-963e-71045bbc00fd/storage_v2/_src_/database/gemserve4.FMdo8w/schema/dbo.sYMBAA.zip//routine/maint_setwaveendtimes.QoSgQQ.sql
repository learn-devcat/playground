CREATE PROCEDURE dbo.maint_SetWaveEndTimes
@WaveLength		int = 14
AS

	SET NOCOUNT ON

	UPDATE dbo.tblWave
	SET EndTime = dbo.TimeString(DATEADD(mi,@WaveLength,dbo.dDatePlusNewTime(getdate(),BeginTime)))
go

