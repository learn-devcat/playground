
CREATE  PROCEDURE dbo.WorkorderDTLClass_Insert
@User                   char(10),
@WorkOrderDTLClassID    int,
@Description            varchar(50)
AS 
	INSERT INTO tblWorkorderDTLClass
	            (WorkOrderDTLClassID, Description)
          VALUES(@WorkOrderDTLClassID, @Description)
go

