

CREATE PROCEDURE dbo.sp_Page_Security
@PageClass		varchar(50)
AS
	SELECT	SecurityLevel
	FROM		cfgPages
	WHERE	PageName=@PageClass
go

