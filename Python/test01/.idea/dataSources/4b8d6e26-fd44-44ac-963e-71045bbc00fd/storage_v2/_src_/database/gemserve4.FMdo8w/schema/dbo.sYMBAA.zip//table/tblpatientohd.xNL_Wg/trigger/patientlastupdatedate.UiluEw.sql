CREATE TRIGGER PatientLastUpdateDate ON dbo.tblPatientOHD FOR INSERT, UPDATE    
AS
      UPDATE    dbo.tblPatientOHD
       SET              LastUpdateDate = getdate()
       FROM         Inserted AS I JOIN
                              dbo.tblPatientOHD AS P ON I.PatientID = P.PatientID
go

