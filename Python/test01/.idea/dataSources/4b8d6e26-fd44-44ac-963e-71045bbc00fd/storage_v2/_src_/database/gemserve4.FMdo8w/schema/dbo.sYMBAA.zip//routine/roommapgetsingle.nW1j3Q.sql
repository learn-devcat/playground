CREATE PROCEDURE [dbo].[RoomMapGetSingle]
@MapNumber  int,
@WaveID     int,
@DateOffset int

AS
	SET NOCOUNT ON

	DECLARE	@SentOrderBuffer	int,
		@MealPeriodID		int,
		@PatientStatus		varchar(200),
		@Status1		varchar(50),
		@Status2		varchar(50),
		@Status3		varchar(50),
		@Status4		varchar(50),
		@PatientStatusOnMap	varchar(50),
		@Today			datetime,
		@MealPeriodEndTime		datetime,
		@OrderOffsetDate		datetime

	SET @Today = getdate()
	SET @OrderOffsetDate = dbo.dDateOnly(@Today + @DateOffset)

	SELECT @SentOrderBuffer = dbo.GetOverheadValue('SentOrderBuffer')
	SELECT @PatientStatus = dbo.GetStatusFlagsForDashboard()
	SELECT @PatientStatusOnMap = dbo.GetOverheadValue('PatientStatusOnMap')

	IF (CHARINDEX(',',@PatientStatus) > 0)	
	BEGIN
		SET @Status1 = LEFT(@PatientStatus,CHARINDEX(',',@PatientStatus)-1)
		SET @PatientStatus = RIGHT(@PatientStatus,LEN(@PatientStatus) - LEN(@Status1) - 1)

		SET @Status2 = LEFT(@PatientStatus,CHARINDEX(',',@PatientStatus)-1)
		SET @PatientStatus = RIGHT(@PatientStatus,LEN(@PatientStatus) - LEN(@Status2) - 1)

		SET @Status3 = LEFT(@PatientStatus,CHARINDEX(',',@PatientStatus)-1)
		SET @PatientStatus = RIGHT(@PatientStatus,LEN(@PatientStatus) - LEN(@Status3) - 1)

		SET @Status4 = @PatientStatus
	END
	ELSE
	BEGIN
		SET @Status1 = ''
		SET @Status2 = ''
		SET @Status3 = ''
		SET @Status4 = ''
	END
	
	DECLARE @PatientStatusFlags AS TABLE (
		ID INT IDENTITY(1,1),
		PatientID int,
		Status1 varchar(10),
		Status2 varchar(10),
		Status3 varchar(10),
		Status4 varchar(10)
	)

	IF (@PatientStatusOnMap = 1)
	BEGIN
		INSERT INTO @PatientStatusFlags
		SELECT PSF.PatientID,
				MAX(CASE WHEN SF.[Description] = @Status1 THEN 'Status1' Else '' END) AS Status1,
				MAX(CASE WHEN SF.[Description] = @Status2 THEN 'Status2' ELSE '' END) AS Status2,
				MAX(CASE WHEN SF.[Description] = @Status3 THEN 'Status3' ELSE '' END) AS Status3,
				MAX(CASE WHEN SF.[Description] = @Status4 THEN 'Status4' ELSE '' END) AS Status4
		FROM dbo.tblPatientStatusFlags AS PSF
		JOIN dbo.tblStatusFlags AS SF (NOLOCK) ON PSF.StatusFlagID = SF.StatusFlagID
		WHERE PSF.PatientID IN (SELECT PatientID FROM dbo.tblPatientVisit WHERE (DischargeDate IS NULL) AND (RoomID IS NOT NULL) AND (MergedTo IS NULL))
		GROUP BY PSF.PatientID
	END
	
	IF ( @SentOrderBuffer = '' )
		SET @SentOrderBuffer = 30
	
	-- Get the current meal period if none was sent in
	IF (@WaveID = 0)
		SELECT @MealPeriodID = dbo.GetMealPeriod(@Today)
	ELSE
		SET @MealPeriodID = @WaveID
		
	SET @MealPeriodEndTime = dbo.MealPeriodEndTime(@OrderOffsetDate,@MealPeriodID)
	
	-- ORDERS
	DECLARE @Orders TABLE (
		OrderID int,
		PatientVisitID varchar(50),
		PostDate datetime,
		Received bit,
		Cancelled bit,
		WaveID	int
		)

		INSERT INTO @Orders
		SELECT OrderID, PatientVisitID, PostDate, Received, COALESCE(Cancelled,0), O.WaveID
		FROM dbo.tblOrderOHD AS O (NOLOCK)
		JOIN dbo.tblWave AS W (NOLOCK) ON O.WaveID = W.WaveID
		WHERE W.MealPeriodID = @MealPeriodID
    			AND O.OrderDate BETWEEN @OrderOffsetDate AND (@OrderOffsetDate + 1)
				AND COALESCE(O.OrderType,1) = 1
	-- END ORDERS

	SELECT	ISNULL(P.PatientID,0) AS PatientID,
			M.MapItemType, 	        -- See notes above.
			M.Label,                  -- Generic label
			M.Row,                    -- Where this item should be on a imaginary grid.
			M.Col,
			M.Height,
			M.Width,
			M.ImgSrc,                 -- The picture to be displayed, when not a room type.
			M.Href,                   -- Link to an included item to be included on the rendering.
			M.Layer,
			M.Prefix,
			CASE
				WHEN PV.EntryDate > @MealPeriodEndTime THEN '000'
				WHEN PV.DietID = -1 THEN '102'
				WHEN D.NPO = 1 AND LC.ShowNPO = 1 THEN '101'
				WHEN P.OnHold = 1 THEN '380'
				WHEN PV.ROOMID IS NULL THEN '000'
				WHEN H.Cancelled = 1 THEN '105'
				WHEN L.ActionID IS NULL THEN dbo.NoOrderStatus('100',@Today, @DateOffset, @MealPeriodID, PV.DietID)
				WHEN (L.ACTIONID = 210 AND DATEDIFF(s,H.PostDate,@Today) < @SentOrderBuffer AND H.Received = 0) THEN '205'
				ELSE CAST(L.ACTIONID as varchar(3))
			END AS Status,
				M.Orientation & 255 as Orientation,
			O.MapNumber AS MapNumber,
			O.Title AS MapTitle,
			O.SubTitle AS MapSubtitle,
			O.Description AS MapDescription,
			O.CssSrc AS MapCSS,
			O.Href AS MapHref,
			R.RoomNumber,
			R.RoomID,
			1 AS TotalOrders,
			H.OrderID,
			COALESCE(PSF.Status1,'') AS Status1,
			COALESCE(PSF.Status2,'') AS Status2,
			COALESCE(PSF.Status3,'') AS Status3,
			COALESCE(PSF.Status4,'') AS Status4,			
			@Status1 AS Status1Description,
			@Status2 AS Status2Description,
			@Status3 AS Status3Description,
			@Status4 AS Status4Description
	FROM dbo.tblMapOHD as O (NOLOCK)
		LEFT JOIN dbo.tblMapData AS M (NOLOCK) ON M.MapNumber = O.MapNumber
		LEFT JOIN dbo.tblRoomOHD AS R (NOLOCK) ON R.RoomNumber = M.Label 
		LEFT JOIN dbo.tblLocationClass AS LC (NOLOCK) ON R.LocationClassID = LC.LocationClassID

		LEFT JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON PV.RoomID = R.RoomID 
			AND PV.MergedTo IS NULL 
			AND PV.DischargeDate IS NULL
			AND O.MapNumber <> 101

		LEFT JOIN dbo.tblPatientOHD AS P (NOLOCK) ON P.PatientID = PV.PatientID
		LEFT JOIN @PatientStatusFlags AS PSF ON P.PatientID = PSF.PatientID
		LEFT JOIN dbo.tblDietOHD AS D (NOLOCK) ON D.DietID = dbo.GetActiveDiet(PV.PatientVisitID, @Today)
		LEFT JOIN @Orders AS H ON H.PatientVisitID = PV.PatientVisitID 
		LEFT JOIN dbo.tblWave AS W (NOLOCK) ON H.WaveID = W.WaveID
		LEFT JOIN (SELECT ORDERID, MAX(ACTIONID) AS ACTIONID 
				FROM dbo.tblOrderLOG (NOLOCK)
				GROUP BY ORDERID) AS L ON H.OrderID = L.OrderID
	WHERE O.MapNumber = @MapNumber
		AND O.Inactive = 0
	ORDER BY M.Priority, M.Label, Status DESC

	RETURN
go

