

CREATE PROCEDURE dbo.ie_tblAccountImport_Fix
AS
	IF not exists (SELECT name FROM syscolumns WHERE name='ImportID')
	BEGIN
		ALTER TABLE tblAccountImport
			ADD ImportID int IDENTITY(1,1) NOT NULL
			CONSTRAINT PK_ImportID PRIMARY KEY
	END
go

