


CREATE PROCEDURE dbo.UserSettingsGet
	(
        @LoginUserID		varchar(250),
        @SettingName    varchar(100),
        @Page           varchar(100)=''
	)
AS
    SET NOCOUNT ON
    
    SELECT  SettingValue
    FROM    dbo.cfgUserSettings (NOLOCK)
    WHERE   LoginUserID = @LoginUserID
            AND SettingName = @SettingName
            AND Page = @Page

	RETURN
go

