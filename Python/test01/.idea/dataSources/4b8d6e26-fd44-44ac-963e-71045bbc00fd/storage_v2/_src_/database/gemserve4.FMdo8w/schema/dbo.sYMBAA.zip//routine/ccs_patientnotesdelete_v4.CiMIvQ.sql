
CREATE PROCEDURE [dbo].[CCS_PatientNotesDelete_v4]
@PatientVisitID varchar(50),
@Source         varchar(50)

AS
    DECLARE @PatientID	int,
	@Msg        varchar(250),
	@RoomID	    int

    -- If this patient does not exist in our system, then log an error
    IF NOT EXISTS (SELECT 1 FROM dbo.tblPatientVisit WHERE PatientVisitID = @PatientVisitID) 
    BEGIN
        SET @Msg = 'Unable to delete all patient notes for PatientVisitID:' + @PatientVisitID + '. PatientVisitID does not exist.'
        GOTO TransError
    END

    -- Get PatientID 
    SELECT @PatientID = PatientID,
       @RoomID = RoomID
    FROM dbo.tblPatientVisit
    WHERE PatientVisitID = @PatientVisitID
    
    -- Delete the patient notes
	UPDATE tblPatientOHD
	SET Notes = ''
	WHERE PatientID = @PatientID

    -- Log that the patient notes have been deleted
    SET @Msg = 'All patient notes have been deleted for PatientVisitID:' + @PatientVisitID 
    EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, @PatientVisitID, @RoomID, @Msg

    RETURN
    
TransError:

    IF ( @Msg IS NULL )    
       	SET @Msg = 'Unable to delete all patient notes for PatientVisitID:' + @PatientVisitID
        
    EXEC dbo.Logit 1, @Msg, 'system'


go

