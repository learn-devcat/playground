

CREATE PROCEDURE dbo.OrderKioskGet
@OrderID	int
AS

	SET NOCOUNT ON

	SELECT	O.OrderID,
		O.LocationID,
		O.WorkstationID,
		O.OutletNo,
		O.WaveID,
		O.OrderEmployeeName,
		O.OrderDate,
		O.SubTotal,
		O.DeliveryCharge,
		O.Tip,
		E.OrderName,
		E.DeliveryDate,
		E.DeliveryDirections,
		E.Comments
	FROM	dbo.tblOrderOHD AS O (NOLOCK)
		JOIN dbo.tblOrderEX AS E (NOLOCK) ON O.OrderID = E.OrderID
	WHERE	O.OrderID = @OrderID

	RETURN
go

