CREATE PROCEDURE [dbo].[sp_Task_RemoveForUser]
	@User char(10),
	@TaskId int
AS

	DECLARE @UserRole	int,
			@Msg		varchar(50)
	
	-- get the user's max role id
	SELECT @UserRole = MAX(PrivilegeClassId)
	FROM dbo.tblPrivilegeClassMembers
	WHERE UserID = @User;

	DELETE T 
	FROM dbo.Tasks AS T
	LEFT JOIN dbo.TaskOHD AS O ON T.TaskId = O.TaskId
	WHERE T.TaskId = @TaskId
		AND T.EntryId = @User
		AND @UserRole >= O.MinPrivilegeClass
go

