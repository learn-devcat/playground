CREATE PROCEDURE dbo.ol_GetBadgeEX
@CoreID		smallint = 1,
@User		char(10),
@BadgeNo 	char (19),
@RevenueCenter	int
AS
	DECLARE @LogLevel int
	DECLARE @Today datetime

	SET @BadgeNo = dbo.RemoveBadgeSwipePrefix(@BadgeNo);
	
	SET @LogLevel = 3		-- Default to Read/Access Level	
	SET @Today = getdate()
	SELECT	B.BadgeNo, B.AccountNo, B.Status, B.PrimaryBadge, dbo.DateOnly(B.ActiveDate) AS ActiveDate,
			dbo.DateOnly(B.ExpireDate) AS ExpireDate,B.BadgeClassID, 
			B.Title, B.FirstName, B.LastName, dbo.Description_FullNameWithMiddle( a.Description, b.firstname, b.lastname, b.MiddleName, 1) AS Name, 
			B.Limit, B.DailyLimit, B.ImagePath,
			A.Description, dbo.FullNameWithMiddle(A.Title, A.FirstName, A.LastName, a.MiddleName, 1) AS AcctName, B.Flagged, B.Msg
	FROM  		dbo.tblBadgesOHD B
			LEFT JOIN dbo.tblOutletOHD AS O ON O.OutletNo = @RevenueCenter 
			LEFT JOIN dbo.tblAccountOHD A ON A.AccountNo = B.AccountNo AND ( A.ActiveDate <= @Today AND A.ExpireDate >= @Today ) AND A.Inactive = 0
			RIGHT JOIN dbo.tblAccountClass AC on A.AccountClassID = AC.AccountClassID AND (dbo.IsAllowed(O.OutletNo, AC.AccountClassID, -1) <> 0)
			
	WHERE   	B.BadgeNo = @BadgeNo 
			AND B.activedate <= @Today 
			AND B.expiredate >= @Today 
			AND B.BadgeClassID > 0            /* I don't remember why this is here */

	DECLARE @cMsg  char(255)
	
	IF( @@rowcount = 0 ) 
		BEGIN
			SET @cMsg = 'ol_GetBadge Badge # ' + RTRIM(@BadgeNo) + ' <No Match>'
			SET @LogLevel = @LogLevel - 1		-- drop logging level to catch failure.
		END
	ELSE
		SET @cMsg = 'ol_GetBadge Badge # ' + RTRIM(@BadgeNo)
	EXEC dbo.sp_Logit @LogLevel , @CoreID , @User , @cMsg, 925
go

