

CREATE PROCEDURE dbo.gem_UserAddLocation
@UserID		varchar(10),
@LocationID	int
AS
	IF NOT EXISTS (SELECT UserID FROM cfgUserLocations WHERE UserID = @UserID AND LocationID = @LocationID)
		INSERT INTO cfgUserLocations (UserID, LocationID)
			VALUES (@UserID, @LocationID)
go

