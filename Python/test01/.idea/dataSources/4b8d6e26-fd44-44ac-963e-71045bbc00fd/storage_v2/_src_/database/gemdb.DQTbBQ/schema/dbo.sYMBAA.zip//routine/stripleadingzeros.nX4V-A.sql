


CREATE  FUNCTION dbo.StripLeadingZeros (@sString varchar(50)) 
RETURNS varchar(50)
AS 
BEGIN 
	WHILE LEFT(@sString,1) = '0'
	BEGIN
		SET @sString = RIGHT(RTRIM(@sString), LEN(RTRIM(@sString)) - 1)
	END
	
	RETURN @sString
END
go

