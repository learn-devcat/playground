
CREATE PROCEDURE dbo.GEM_SecurityLinksDelete
@LoggedInUser  varchar(250),
@RoleID        int

AS

	DELETE dbo.tblSecurityRoleActions WHERE RoleID = @RoleID
        
        RETURN
go

