
CREATE   PROCEDURE dbo.WorkorderDTL_SetActualStartDate
@User               char(10),
@WorkOrderID        int,
@WorkOrderDTLID     int,
@ActualStartDate datetime
AS
    SET @ActualStartDate = ISNULL( @ActualStartDate , getdate())      -- IF no date, SET to today.
    UPDATE  tblWorkOrderDTL
       SET  ActualStartDate  = @ActualStartDate
    WHERE   WorkOrderID = @WorkOrderID AND
            WorkOrderDTLID = @WorkOrderDTLID
    RETURN
go

