

CREATE FUNCTION dbo.Description_FullName(@Description varchar(32),
					@FirstName char(15),
					@LastName char(20))
RETURNS varchar(35)
AS
BEGIN
	
	DECLARE	@ReturnString	varchar(32)
	IF (RTRIM(@Description)='') 
		SET @ReturnString = RTRIM(@FirstName) + ' ' + RTRIM(@LastName) 
	ELSE 
		SET @ReturnString = RTRIM(@Description)
	
	RETURN @ReturnString
END
go

