CREATE PROCEDURE [dbo].[debugLogit]
@msg		VARCHAR(2000),
@category	VARCHAR(50) = ''
AS

IF EXISTS (SELECT * FROM master.dbo.sysdatabases WHERE name = N'GEMtemp')
BEGIN
	IF EXISTS (SELECT * FROM GEMtemp.dbo.sysobjects WHERE name LIKE '%tblDebug%')
	BEGIN
		INSERT GEMtemp.dbo.tblDebug
		VALUES  ( @msg, @category )
	END
END
go

