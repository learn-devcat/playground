

CREATE PROCEDURE dbo.ad_ActiveAutoProcesses
AS
	SELECT 	F.RecurFuncID,
			F.Description,
			R.NextDate,
			F.LastRunDate
	FROM 		tblRecurFunctions AS F
			JOIN tblRecurChgClass AS R
	ON 		F.ClassID = R.ClassID
	WHERE 	F.Active <> 0 
			AND R.Active <> 0
	ORDER BY	R.NextDate,F.RecurFuncID
go

