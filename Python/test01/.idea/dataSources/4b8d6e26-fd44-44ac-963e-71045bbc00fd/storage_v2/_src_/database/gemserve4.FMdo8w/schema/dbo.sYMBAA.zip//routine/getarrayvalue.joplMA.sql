
CREATE FUNCTION [dbo].[GetArrayValue](@item as varchar(500),@element as int, @separator as char(1))
RETURNS varchar(50)
AS
BEGIN
	DECLARE @Return	varchar(50),
			@Start as int,
			@Count as int

	SET @Start = 1
	SET @Count = 1

	WHILE (1=1)
	BEGIN
		IF (CHARINDEX(@separator, @item, @Start) - @Start < 0)
			SET @Return = SUBSTRING(@item, @Start, LEN(@item) - @Start + 1)
		ELSE
			SET @Return = SUBSTRING(@item, @Start, CHARINDEX(@separator, @item, @Start) - @Start)

		IF (@Count = @element)
			BREAK

		SET @Count = @Count + 1
		SET @Start = CHARINDEX(@separator, @item, @Start) + 1
	END

	RETURN @Return
END
go

