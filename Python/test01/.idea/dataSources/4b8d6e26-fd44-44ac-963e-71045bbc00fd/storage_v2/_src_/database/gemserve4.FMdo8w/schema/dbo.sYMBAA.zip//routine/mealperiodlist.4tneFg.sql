


CREATE PROCEDURE dbo.MealPeriodList

AS
	SET NOCOUNT ON

	SELECT  MealPeriodID, 
		    Description,
		    ShortName
	FROM	dbo.tblMealPeriods
	ORDER BY Description

	RETURN
go

