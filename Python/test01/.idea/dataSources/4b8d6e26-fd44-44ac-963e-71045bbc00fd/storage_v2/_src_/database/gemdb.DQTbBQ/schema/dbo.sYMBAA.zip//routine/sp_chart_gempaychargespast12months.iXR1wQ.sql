CREATE PROCEDURE [dbo].[sp_Chart_GEMpayChargesPast12Months]
	@StartDate DateTime 
AS
	SET NOCOUNT ON

	DECLARE @Data TABLE (MonthName varchar(30), YearMonth nvarchar(6), ChargesTotal money) 
	INSERT INTO @Data
	VALUES('January', '201801','31054.93'),
	('February', '201802','34282.17'),
	('March', '201803','33339.28'),
	('April', '201704','24106.77'),
	('May', '201705','26894.01'),
	('June', '201706','24353.09'),
	('July', '201707','22987.32'),
	('August', '201708','28867.42'),
	('September', '201709','29102.33'),
	('October', '201710','30328.00'),
	('November', '201711','31900.82'),
	('December', '201712','27224.22')

	--SELECT [MonthName], YearMonth, ChargesTotal 
	--FROM @Data
	--ORDER BY YearMonth

	--EXEC dbo.sp_Chart_GEMpayChargesPast12Months '2017-12-14'


	SELECT      PM.MonthName, CONVERT(nvarchar(6), PM.MonthlyDate, 112) AS YearMonth, SUM(D.ChargesTotal) ChargesTotal
	FROM   (SELECT * FROM dbo.GetDatesForPrevious12Months (@StartDate)) as PM
	JOIN @Data AS D
	--LEFT JOIN (SELECT tblDetail.* 
	--FROM tblDetail 
	--INNER JOIN tblTransDef 
	--ON tblDetail.TransID = tblTransDef.TransID AND tblDetail.TransID = tblTransDef.TransID AND tblTransDef.Payment = 0) as dtl
	--on CONVERT(nvarchar(6), PM.MonthlyDate, 112) = CONVERT(nvarchar(6), dtl.TransDate, 112) 
	on CONVERT(nvarchar(6), PM.MonthlyDate, 112) = D.YearMonth 
	GROUP BY
	PM.MonthName, CONVERT(nvarchar(6), PM.MonthlyDate, 112)
	Order BY CONVERT(nvarchar(6), PM.MonthlyDate, 112)


RETURN 0


go

