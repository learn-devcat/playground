
CREATE        PROCEDURE dbo.WorkorderOHD_Get
@User			char(10),
@WorkorderID    int
AS
	DECLARE	@OpeningEmployeeName		VarChar(60),
		@ClosingEmployeeName		VarChar(60),
		@CompletingEmployeeName		VarChar(60),
		@InspectingEmployeeName		VarChar(60),
		@OpeningEmployeeID		int,
		@ClosingEmployeeID		int
		
		
	
	SET @OpeningEmployeeName = (SELECT RTRIM(LastName) + ', ' + RTRIM(FirstName) 
	FROM tblEmployeeOHD 
	WHERE EmployeeID = (SELECT OpeningEmployeeID
				FROM    tblWorkOrderOHD
   				 WHERE   WorkOrderID = @WorkOrderID))
	SET @ClosingEmployeeName = (SELECT RTRIM(LastName) + ', ' + RTRIM(FirstName) 
	FROM tblEmployeeOHD 
	WHERE EmployeeID = (SELECT ClosingEmployeeID
				FROM    tblWorkOrderOHD
   				 WHERE   WorkOrderID = @WorkOrderID))
	SET @CompletingEmployeeName = (SELECT RTRIM(LastName) + ', ' + RTRIM(FirstName) 
	FROM tblEmployeeOHD 
	WHERE EmployeeID = (SELECT CompletingEmployeeID
				FROM    tblWorkOrderOHD
   				 WHERE   WorkOrderID = @WorkOrderID))
	SET @InspectingEmployeeName = (SELECT RTRIM(LastName) + ', ' + RTRIM(FirstName) 
	FROM tblEmployeeOHD 
	WHERE EmployeeID = (SELECT InspectingEmployeeID
				FROM    tblWorkOrderOHD
   				 WHERE   WorkOrderID = @WorkOrderID))
	
	SELECT  WorkOrderID,
	        WorkOrderNumber,
	        LocationID,
	        WorkorderClassID,
	        ShortDescription, 
	        PO,
	        Description,
	        OpenDate,
	        OpeningEmployeeID,
		@OpeningEmployeeName as OpeningEmployeeName,
	        ClosingDate,
	        ClosingEmployeeID,
		@ClosingEmployeeName as ClosingEmployeeName,
	        Closed,
	        CompletionDate,
	        CompletingEmployeeID,
		@CompletingEmployeeName as CompletingEmployeeName,
	        Completed,
	        Inspected,
		InspectedDate,
	        InspectingEmployeeID,
		@InspectingEmployeeName as InspectingEmployeeName,
	        EstimatedHours,
	        ActualHours,
	        AccountNo,
	        TransID,
	        Notes,
	        TotalCharge,
		AdjustTotalAmt,
		TotalChargePosted,
		AltCharge,
		AltTransID,
		AdjustmentReason,
		LaborCenterID
    FROM    tblWorkOrderOHD
    WHERE   WorkOrderID = @WorkOrderID
    RETURN
go

