CREATE PROCEDURE [dbo].[Micros_MenuItemDeleteRange]
@UserID		varchar(250),
@StartObjectNumber int=0,
@EndObjectNumber int=0,
@SetOverheadKey bit=1

AS
	SET NOCOUNT ON
	
	DECLARE @Msg varchar(200),
			@ObjectNumber int,
			@Return int
	
	SET @Return = 0	
	
	IF ((@StartObjectNumber = 0) OR (@StartObjectNumber > @EndObjectNumber))
	BEGIN
		SET @Return = -1
		SET @Msg = 'Invalid Starting POS Object Number!'
		GOTO Finished	
	END
	
	IF (@EndObjectNumber = 0)
	BEGIN
		SET @Return = -2
		SET @Msg = 'Invalid Ending POS Object Number!'
		GOTO Finished	
	END
	
	--Delete Menu Items from Micros
	DELETE	MicrosMenuItems
	WHERE	obj_num BETWEEN @StartObjectNumber AND @EndObjectNumber

	--Reset the POSMenuItemObjectNum key to value of @StartObjectNumber if @SetOverheadKey is enabled (default setting)
	IF (@SetOverheadKey = 1)
	BEGIN
		UPDATE dbo.cfgOverhead
		SET Value = CAST(@StartObjectNumber as varchar(50))
		WHERE KeyID = 'POSMenuItemObjectNum'
		
		IF (@@ROWCOUNT = 0)
			INSERT INTO dbo.cfgOverhead (KeyID, Value, Sequence, Description)
			VALUES ('POSMenuItemObjectNum', CAST(@StartObjectNumber as varchar(50)), '7009', 'Next POS Menu Item Object Number')
	END
	
	SET @Msg = 'Deleted all Micros menu items between object number[' + CAST(@StartObjectNumber AS varchar(50)) + '] and [' + CAST(@EndObjectNumber AS varchar(50)) + '].'

Finished:
	EXEC dbo.Logit 9000,@Msg,@UserID
	
	RETURN @RETURN
go

