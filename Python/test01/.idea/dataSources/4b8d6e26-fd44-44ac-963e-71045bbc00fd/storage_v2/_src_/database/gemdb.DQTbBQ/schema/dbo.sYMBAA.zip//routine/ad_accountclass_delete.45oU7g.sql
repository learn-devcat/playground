

CREATE PROCEDURE dbo.ad_AccountClass_Delete
@User			char(10),
@AccountClassID	int
AS
	DELETE	tblAccountClass
	WHERE	AccountClassID = @AccountClassID
go

