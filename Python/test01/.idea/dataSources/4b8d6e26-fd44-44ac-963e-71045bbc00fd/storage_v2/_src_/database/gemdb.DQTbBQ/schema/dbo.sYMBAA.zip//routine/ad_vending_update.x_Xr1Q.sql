CREATE PROCEDURE [dbo].[ad_Vending_Update]
	@ID int ,
    @Description varchar(50) ,
    @VendorID int ,
    @MachineTAG varchar(16) ,
    @AccountClassID int ,
    @BadgeClassID int ,
    @OutletNo int ,
    @TransID int ,
    @LocationID int ,
    @InActive bit ,
    @RefundAllowed bit ,
    @MaxItemPrice money ,
    @Comment varchar(255)
AS 
    UPDATE  dbo.tblVendingDTL
    SET     [Description] = @Description ,
            VendorID = @VendorID ,
            MachineTAG = @MachineTAG ,
            AccountClassID = @AccountClassID ,
            BadgeClassID = @BadgeClassID ,
            OutletNo = @OutletNo ,
            TransID = @TransID ,
            LocationID = @LocationID ,
            InActive = @InActive ,
            RefundAllowed = @RefundAllowed ,
            MaxItemPrice = @MaxItemPrice ,
            Comment = @Comment
	WHERE	ID = @ID
go

