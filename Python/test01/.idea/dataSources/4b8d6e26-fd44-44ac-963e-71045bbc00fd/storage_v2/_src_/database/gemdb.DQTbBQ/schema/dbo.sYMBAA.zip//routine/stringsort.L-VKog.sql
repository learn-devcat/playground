

CREATE FUNCTION dbo.StringSort (@String1 varchar(255),@String2 varchar(255)) 
RETURNS varchar(255)
AS 
BEGIN 
	DECLARE	@Return	varchar(255)
	IF (RTRIM(@String1) = '')
		SET @Return = RTRIM(@String2)
	ELSE
		SET @Return = RTRIM(@String1)
	RETURN @Return
END
go

