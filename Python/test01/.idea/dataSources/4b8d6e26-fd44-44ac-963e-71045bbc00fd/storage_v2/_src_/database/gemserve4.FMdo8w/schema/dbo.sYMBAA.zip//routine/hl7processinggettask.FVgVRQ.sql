CREATE PROCEDURE dbo.HL7ProcessingGetTask
@CommandID	int
AS
	SET NOCOUNT ON

	SELECT CommandID,
		MessageType,
		[Name],
		[Description],
		ControlType,
		CommandType,
		Command,
		ReturnColumn,
		[Sequence],
		Active
	FROM dbo.tblHL7Processing
	WHERE CommandID = @CommandID

	RETURN
go

