


CREATE PROCEDURE dbo.gn_UpdateGEMNetLogin
@LoggedInUserID	varchar(20),
@UserName	varchar(50),
@Pass		varchar(50),
@FullName	varchar(50),
@DefaultVDir	varchar(100),
@DefaultOutlet	int = 1,
@CoreID	int = 1	
AS
	UPDATE	GEMNet..tblAccountLogin
	SET	Pass = @Pass,
		FullName = @FullName,
		DefaultVDir = @DefaultVDir,
		DefaultOutlet = @DefaultOutlet,
		CoreID = @CoreID
	WHERE	UserName = @UserName
	IF (@@ROWCOUNT = 0)
		INSERT INTO GEMNet..tblAccountLogin (UserName, Pass, FullName, DefaultVDir, DefaultOutlet, CoreID)
		VALUES (@UserName, @Pass, @FullName, @DefaultVDir, @DefaultOutlet, @CoreID)
go

