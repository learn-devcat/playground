CREATE    PROCEDURE dbo.LaborCenter_Insert
@User      	char(10),
@LaborCenterID	int,
@LocationID	int,
@Description  	varchar(50)
AS 
	INSERT INTO	tblLaborCenter
	            	(LaborCenterID, LocationID, Description)
             VALUES 	(@LaborCenterID, @LocationID, @Description)
go

