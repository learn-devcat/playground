CREATE PROCEDURE dbo.RoomMapOptionalStatus
@MapNumber  	int,
@OptionNumber	int

AS
	SET NOCOUNT ON

	DECLARE @PatientStatus		varchar(200),
		@Status1		varchar(50),
		@Status2		varchar(50),
		@Status3		varchar(50),
		@Status4		varchar(50)

	SELECT @PatientStatus = dbo.GetStatusFlagsForDashboard()

	IF (CHARINDEX(',',@PatientStatus) > 0)	
	BEGIN
		SET @Status1 = LEFT(@PatientStatus,CHARINDEX(',',@PatientStatus)-1)
		SET @PatientStatus = RIGHT(@PatientStatus,LEN(@PatientStatus) - LEN(@Status1) - 1)

		SET @Status2 = LEFT(@PatientStatus,CHARINDEX(',',@PatientStatus)-1)
		SET @PatientStatus = RIGHT(@PatientStatus,LEN(@PatientStatus) - LEN(@Status2) - 1)

		SET @Status3 = LEFT(@PatientStatus,CHARINDEX(',',@PatientStatus)-1)
		SET @PatientStatus = RIGHT(@PatientStatus,LEN(@PatientStatus) - LEN(@Status3) - 1)

		SET @Status4 = @PatientStatus
	END
	ELSE
	BEGIN
		SET @Status1 = ''
		SET @Status2 = ''
		SET @Status3 = ''
		SET @Status4 = ''
	END
	
	DECLARE @PatientStatusFlags AS TABLE (
		ID INT IDENTITY(1,1),
		PatientID int,
		Status1 varchar(10),
		Status2 varchar(10),
		Status3 varchar(10),
		Status4 varchar(10)
	)

	INSERT INTO @PatientStatusFlags
	SELECT PSF.PatientID,
			MAX(CASE WHEN SF.[Description] = @Status1 THEN 'Status1' Else '' END) AS Status1,
			MAX(CASE WHEN SF.[Description] = @Status2 THEN 'Status2' ELSE '' END) AS Status2,
			MAX(CASE WHEN SF.[Description] = @Status3 THEN 'Status3' ELSE '' END) AS Status3,
			MAX(CASE WHEN SF.[Description] = @Status4 THEN 'Status4' ELSE '' END) AS Status4
	FROM dbo.tblPatientStatusFlags AS PSF
	JOIN dbo.tblStatusFlags AS SF (NOLOCK) ON PSF.StatusFlagID = SF.StatusFlagID
	WHERE PSF.PatientID IN (SELECT PatientID FROM dbo.tblPatientVisit WHERE (DischargeDate IS NULL) AND (RoomID IS NOT NULL) AND (MergedTo IS NULL))
	GROUP BY PSF.PatientID

	SELECT	ISNULL(P.PatientID,0) AS PatientID,
		M.MapItemType, 	        -- See notes above.
		M.Label,                  -- Generic label
	        M.Row,                    -- Where this item should be on a imaginary grid.
	        M.Col,
	        M.Height,
	        M.Width,
	        M.ImgSrc,                 -- The picture to be displayed, when not a room type.
	        M.Href,                   -- Link to an included item to be included on the rendering.
	        M.Layer,
	        'S' AS Prefix,
		CASE 
			WHEN ISNULL(P.PatientID,0) = 0 THEN '000'			
			WHEN @OptionNumber = 1 AND PSF.Status1 = 'Status1' THEN '901'
			WHEN @OptionNumber = 2 AND PSF.Status2 = 'Status2' THEN '901'
			WHEN @OptionNumber = 3 AND PSF.Status3 = 'Status3' THEN '901'
			WHEN @OptionNumber = 4 AND PSF.Status4 = 'Status4' THEN '901'
			ELSE '900'
		END AS Status,
	        M.Orientation & 255 as Orientation,
		    O.MapNumber AS MapNumber,
		    O.Title AS MapTitle,
		    O.SubTitle AS MapSubtitle,
		    O.Description AS MapDescription,
		    O.CssSrc AS MapCSS,
		    O.Href AS MapHref,
		    R.RoomNumber,
		   R.RoomID,
		  0 AS TotalOrders,
		COALESCE(PSF.Status1,'') AS Status1,
		COALESCE(PSF.Status2,'') AS Status2,
		COALESCE(PSF.Status3,'') AS Status3,
		COALESCE(PSF.Status4,'') AS Status4,
		@Status1 AS Status1Description,
		@Status2 AS Status2Description,
		@Status3 AS Status3Description,
		@Status4 AS Status4Description
    FROM dbo.tblMapOHD as O (NOLOCK)
        LEFT JOIN dbo.tblMapData AS M (NOLOCK) ON M.MapNumber = O.MapNumber
		LEFT JOIN dbo.tblRoomOHD AS R (NOLOCK) ON R.RoomNumber = M.Label
		LEFT JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON PV.RoomID = R.RoomID
			AND PV.MergedTo IS NULL
			AND PV.DischargeDate IS NULL
		LEFT JOIN dbo.tblPatientOHD AS P (NOLOCK) ON P.PatientID = PV.PatientID
		LEFT JOIN @PatientStatusFlags AS PSF ON P.PatientID = PSF.PatientID
	WHERE M.MapNumber = @MapNumber
	ORDER BY M.Label, Status DESC

	RETURN
go

