

CREATE PROCEDURE dbo.pos_Trans_Post
@CoreID	int,
@User		char(10),
@AccountNo	char(19),
@BadgeNo	char(19),
@TransDate	datetime,
@OutletNo	int,
@RefNum	char(6),
@ChkNum	char(6),
@TransTotal	money,
@Sales1	money,
@Comment	varchar(40),
@CycleNo	int,
@TransID	int,
@MealPlanID	int,
@Category 	char(10)=' ',
@PaymentNo	int=0,
@ServeEmpl	int=0,
@PostEmpl	int=0,
@Covers	smallint=0,
@RevCntr	int=0,
@Sales2	money=0,
@Sales3	money=0,
@Sales4	money=0,
@Sales5	money=0,
@Sales6	money=0,
@Sales7	money=0,
@Sales8	money=0,
@Sales9	money=0,
@Sales10	money=0,
@Sales11	money=0,
@Sales12	money=0,
@Sales13	money=0,
@Sales14	money=0,
@Sales15	money=0,
@Sales16	money=0,
@Tax1		money=0,
@Tax2		money=0,
@Tax3		money=0,
@Tax4		money=0,
@Dsc		money=0,
@Svc		money=0,
@SvcA		money=0,
@Correction	bit=0,
@Auditable	bit=0,
@PostDate	datetime = ''
AS
	DECLARE	@TempTransID	int,
		@Amount	money,
		@TempOutletNo	int,
		@Error		int,
		@ErrorMsg	varchar(100)
	IF (@CoreID = 0)
		SET @CoreID = 1
	IF (@OutletNo = 0)
		RAISERROR ('No valid Outlet',16,1)
	SELECT	@TempTransID = TransID,
			@Amount = Preset
	FROM	tblTransDef
	WHERE	TransID = @TransID
	IF (@TransTotal = 0)
	BEGIN
		SET @TransTotal = @Amount
		SET @Sales1 = @Amount
	END
	SELECT 	@TempOutletNo = OutletNo
	FROM	tblOutletOHD
	WHERE	OutletNo = @OutletNo
	IF (ISNULL(@TempTransID,0) = 0)
	BEGIN
		RAISERROR ('No valid TransID',16,1)
		RETURN
	END
	ELSE IF (ISNULL(@TempOutletNo,0) = 0)
	BEGIN
		RAISERROR ('No valid Outlet', 17,1)
		RETURN
	END
	ELSE
	BEGIN
		EXEC @Error=sp_Trans_Post @CoreID,@User,@AccountNo,@BadgeNo,@TransDate,@OutletNo,@RefNum,@ChkNum,@TransTotal,
							@Sales1,@Comment,@CycleNo,@TransID,@Category,@PaymentNo,@ServeEmpl,@PostEmpl,@Covers,
							@RevCntr,@Sales2,@Sales3,@Sales4,@Sales5,@Sales6,@Sales7,@Sales8,@Sales9,@Sales10,
							@Sales11,@Sales12,@Sales13,@Sales14,@Sales15,@Sales16,@Tax1,@Tax2,@Tax3,@Tax4,
							@Dsc,@Svc,@SvcA,@Correction,@Auditable,'',@MealPlanID
		IF (@Error <> 2627 AND @Error <> 0)
		BEGIN
			SET @ErrorMsg = 'SQL Error ' + CAST(@Error AS varchar(25))
			RAISERROR (@ErrorMsg,18,1)
		END
	END
go

