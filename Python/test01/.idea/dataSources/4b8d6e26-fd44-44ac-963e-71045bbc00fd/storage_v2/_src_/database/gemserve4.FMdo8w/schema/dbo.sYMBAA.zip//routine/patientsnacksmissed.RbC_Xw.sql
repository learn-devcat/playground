CREATE FUNCTION [dbo].[PatientSnacksMissed](@PatientID int,@LastOrder datetime,@Now datetime)
RETURNS int
BEGIN

	DECLARE	@Total		int,
		@DietID		int,
		@CurrentWave	int,
		@CurrentMealPeriod	int,
		@EndTime	char(5),
		@TempWave	int,
		@TempDate	datetime,
		@Return		int,
		@TotalMealPeriods int,
		@BetweenDays	int,
		@MissedMeals	int,
		@CurrentDate	datetime,
		@EntryDate	datetime,
		@MealCount	int,
		@PatientVisitID	varchar(50)

	SET @Total = 0
	
	SELECT TOP 1 @PatientVisitID = PatientVisitID
	FROM dbo.tblPatientVisit
	WHERE PatientID = @PatientID
		AND DischargeDate IS NULL
	ORDER BY EntryDate DESC

	SELECT @EntryDate = EntryDate
	FROM dbo.tblPatientVisit
	WHERE PatientVisitID = @PatientVisitID

	DECLARE @Temp TABLE (MealPeriodID int)

	SET @CurrentDate = @LastOrder

	-- Get meals missed on previous days
	WHILE (dbo.dDateOnly(@CurrentDate) < dbo.dDateOnly(@Now))
	BEGIN
		DELETE @Temp

		INSERT INTO @Temp
		SELECT DISTINCT W.MealPeriodID
		FROM	dbo.tblDietWave AS DW (NOLOCK)
			JOIN dbo.tblWave AS W (NOLOCK) ON DW.WaveID = W.WaveID AND DW.DietID = @DietID
			JOIN dbo.tblMealPeriods AS M (NOLOCK) ON W.MealPeriodID = M.MealPeriodID
		WHERE M.MealPeriodID IN (SELECT CAST(KeyOut as int) FROM dbo.tblxlat WHERE xlatID = 'SnackMealPeriod')
			AND dbo.dDatePlusNewTime(@CurrentDate,W.BeginTime) > @EntryDate
	
		SET @TotalMealPeriods = @@ROWCOUNT
				
		SELECT @MissedMeals = @TotalMealPeriods - COUNT(O.OrderID)
		FROM	dbo.tblOrderOHD AS O
			JOIN dbo.tblWave AS W ON O.WaveID = W.WaveID
			JOIN @Temp AS M ON W.MealPeriodID = M.MealPeriodID
		WHERE	dbo.dDateOnly(O.OrderDate) = dbo.dDateOnly(@LastOrder)
			AND O.PatientID = @PatientID

		IF (@MissedMeals > 0)
			SET @Total = @Total + @MissedMeals

		SET @CurrentDate = DATEADD(d,1,@CurrentDate)
	END

	DELETE @Temp

	INSERT INTO @Temp
	SELECT DISTINCT W.MealPeriodID
	FROM dbo.tblWave AS W 
		JOIN dbo.tblMealPeriods AS M (NOLOCK) ON W.MealPeriodID = M.MealPeriodID
	WHERE M.MealPeriodID IN (SELECT CAST(KeyOut as int) FROM dbo.tblxlat WHERE xlatID = 'SnackMealPeriod')
		AND W.EndTime <= dbo.TimeString(@Now)
		AND dbo.dDatePlusNewTime(@CurrentDate,W.BeginTime) > @EntryDate

	SELECT @TotalMealPeriods = @@ROWCOUNT
	SET @MealCount = 0

	-- Get meals missed on the current day
	SELECT @MealCount = COUNT(O.OrderID)
	FROM	dbo.tblOrderOHD AS O
		JOIN dbo.tblWave AS W ON O.WaveID = W.WaveID
		JOIN @Temp AS M ON W.MealPeriodID = M.MealPeriodID
	WHERE	M.MealPeriodID IN (SELECT MealPeriodID FROM @Temp)
		AND dbo.dDateOnly(O.OrderDate) = dbo.dDateOnly(@Now)
		AND O.OrderDate <= @Now
		AND O.PatientID = @PatientID

	IF (@TotalMealPeriods > 0)
		SET @MissedMeals = @TotalMealPeriods - @MealCount
	ELSE
		SET @MissedMeals = 0

	RETURN ISNULL(@Total + ISNULL(@MissedMeals,0),0)
END
go

