
CREATE           PROCEDURE dbo.WorkorderOHD_Insert_EX
@User			char(10),
@LocationID	        int,
@AccountNo          	char(19)		
AS
SET NOCOUNT ON
DECLARE @ident			int,
	@Err			int,
	@LoggedOnEmployeeID	int,
	@OpenDate		DateTime
SET @LoggedOnEmployeeID = dbo.GetEmployeeIDByUserID(@User)
SET @OpenDate = getdate()
--Insert only enough fields to create a record AND RETURN the identity field.
    INSERT tblWorkOrderOHD
          	(AccountNo, LocationID, OpenDate, OpeningEmployeeID)
   	  VALUES(@AccountNo, @LocationID, @OpenDate, @LoggedOnEmployeeID)
    IF @@Error <> 0 
      BEGIN
	SET @Err = @@Error
	SELECT 'Error: ' + CAST(@Err as varChar(20))
        -- TODO: Log the error here AND exit.
        RETURN
      END
    SET @ident = @@IDENTITY --as WorkOrderID
	SELECT @ident
    RETURN
go

