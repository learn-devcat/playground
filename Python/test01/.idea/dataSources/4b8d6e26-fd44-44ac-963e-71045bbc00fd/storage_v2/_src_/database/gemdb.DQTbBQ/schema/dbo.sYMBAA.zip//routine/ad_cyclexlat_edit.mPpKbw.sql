


CREATE  PROCEDURE dbo.ad_CycleXlat_Edit
@User			char(10),
@ExistingXlatID		char(10),
@ExistingCycleNo	int,
@XlatID			char(10),
@CycleNo		int,
@BeginDate		datetime,
@EndDate		datetime,
@DELETE			bit = 0


AS 
	DECLARE @Message varchar(255)

	IF @DELETE = 1
		GOTO DODELETE

	IF NOT EXISTS(SELECT * 	FROM dbo.tblCycleXlat
		      WHERE	XlatID = @ExistingXlatID AND
				CycleNo = @ExistingCycleNo)  	
	BEGIN
		INSERT dbo.tblCycleXlat 
		VALUES(@XlatID, @BeginDate, @EndDate, @CycleNo)

		SET  @Message = 'New Cycle Xlat Item Added: ' + @XlatID + '(' + @CycleNo +  ')'
				   + Cast(@BeginDate as varchar(30)) + ' - ' + Cast(@EndDate as varchar(30))
		EXEC dbo.sp_Logit 9, 1, @User, @Message, 1010	
		SELECT @Message AS 'Rtn'
	END
	ELSE
	BEGIN

		UPDATE	dbo.tblCycleXlat
		SET	XlatID = @XlatID,
			BeginDate = @BeginDate,
			EndDate = @EndDate,
			CycleNo = @CycleNo
	      	WHERE  	XlatID = @ExistingXlatID AND
			CycleNo = @ExistingCycleNo

		SET  @Message = 'Cycle Xlat Item Changed to: ' + @XlatID + '(' + @CycleNo +  ')'
				   + Cast(@BeginDate as varchar(30)) + ' - ' + Cast(@EndDate as varchar(30))

	EXEC dbo.sp_Logit 9, 1, @User, @Message, 1010	
	SELECT @Message AS 'Rtn'

	RETURN
	END

	DODELETE:
 	DELETE	dbo.tblCycleXlat
       	WHERE  	xlatID = @ExistingXlatID AND
 		CycleNo = @ExistingCycleNo

	SET  @Message = 'Cycle Xlat Item Deleted: ' + @XlatID + '(' + @CycleNo +  ')'
			   + Cast(@BeginDate as varchar(30)) + ' - ' + Cast(@EndDate as varchar(30))

	EXEC dbo.sp_Logit 9, 1, @User, @Message, 1010	
	SELECT @Message AS 'Rtn'
go

