


CREATE FUNCTION dbo.GetMaxNutrientForMealPeriod(@DietID int, @NutrientID int, @MealPeriodID int)
RETURNS decimal(10,3)
AS
BEGIN
	DECLARE @Return decimal(10,3)

	SELECT @Return = COALESCE(DM.Qty, N.DefaultQty)
	FROM dbo.tblDietMealPeriodNutrients AS DM (NOLOCK) 
		JOIN dbo.cfgNutrients AS N (NOLOCK) ON N.NutrientID = @NutrientID
	WHERE DM.DietID = @DietID 
		AND DM.MealPeriodID = @MealPeriodID

	RETURN COALESCE(@Return,0)
END
go

