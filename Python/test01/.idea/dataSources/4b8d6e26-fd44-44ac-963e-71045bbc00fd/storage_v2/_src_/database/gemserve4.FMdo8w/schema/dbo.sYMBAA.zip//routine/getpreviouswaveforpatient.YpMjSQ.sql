

CREATE FUNCTION dbo.GetPreviousWaveForPatient(@WaveID int,@PatientID int)
RETURNS int
AS

BEGIN
	DECLARE @Return int,
		@BeginTime varchar(5),
		@MealPeriodID	int

	SELECT @BeginTime = BeginTime,
		@MealPeriodID = MealPeriodID
	FROM tblWave
	WHERE WaveID = @WaveID

	SELECT TOP 1 @Return = W.WaveID
	FROM tblWave AS W
		JOIN tblDietWave AS DW ON W.WaveID = DW.WaveID AND DW.Active = 1
		JOIN tblPatientOHD AS P ON P.PatientID = @PatientID 
		JOIN dbo.tblPatientVisit AS PV ON P.PatientID = PV.PatientID
		JOIN dbo.tblPatientDiet AS PD (NOLOCK) ON PV.PatientVisitID = PD.PatientVisitID AND PD.DietID = DW.DietID
	WHERE W.EndTime <= @BeginTime
		AND W.MealPeriodID <> @MealPeriodID
	ORDER BY W.EndTime DESC

	RETURN ISNULL(@Return,-1)
END
go

