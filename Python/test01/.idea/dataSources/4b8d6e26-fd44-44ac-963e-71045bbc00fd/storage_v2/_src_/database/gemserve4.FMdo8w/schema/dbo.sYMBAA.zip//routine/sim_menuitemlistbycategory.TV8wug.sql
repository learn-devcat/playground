





CREATE PROCEDURE dbo.sim_MenuItemListByCategory
@CoreID		int,
@LoginUserID		varchar(250),
@PatientID	varchar(50),
@CategoryID	int

AS
	DECLARE @MyString varchar(4000)
	--Items, char(28), menuitemid, text, row, col, width,height,color, font
	-- row, col, height, width, font, menuitemid, iconid, iconplacement"c", color, text
	
	SET @MyString = 'success' + char(28) + '2' + 
		char(28) + '1,1,2,4,2,1005,1,C,17,Grits' +
		char(28) + '1,5,2,4,2,1010,1,C,17,Eggs'

	SELECT @MyString
go

