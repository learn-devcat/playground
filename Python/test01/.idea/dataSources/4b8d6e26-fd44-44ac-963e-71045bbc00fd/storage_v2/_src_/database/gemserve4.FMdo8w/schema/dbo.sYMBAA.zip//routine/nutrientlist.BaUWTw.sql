CREATE PROCEDURE dbo.NutrientList

AS
	SET NOCOUNT ON

	SELECT 	NutrientID,
		[Description],
		DefaultQty,
		DefaultUnit
	FROM	dbo.cfgNutrients (NOLOCK)
	ORDER BY [Description]

	RETURN
go

