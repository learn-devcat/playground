




CREATE   PROCEDURE [dbo].[ad_BadgeClass_GetName]
@BadgeClassID	int
AS
	SELECT	ISNULL([Description], 'Badge Class Not Found')
	FROM	tblBadgeClass 
	WHERE	BadgeClassID = @BadgeClassID
go

