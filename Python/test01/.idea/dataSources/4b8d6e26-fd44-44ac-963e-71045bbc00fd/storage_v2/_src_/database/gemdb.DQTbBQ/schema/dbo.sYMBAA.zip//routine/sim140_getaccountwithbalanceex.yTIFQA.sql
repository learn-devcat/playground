CREATE PROCEDURE [dbo].[sim140_GetAccountWithBalanceEX]
@CoreID smallint,
@user char(10),
@AccountNo char(19),
@BadgeNo char(19),
@RevenueCenter int,
@TransID int,
@Return varchar(max)='' OUTPUT
AS
	DECLARE 	@loglevel 	int, 
		@Today 		datetime,
		@tempbadge	char(19),
		@ParentSP	varchar(100),
		@DailyQty		int,
		@AccountDailyBalance	money,
		@DailyLimit		      	money,
		@AcctBalance		   	money,
		@Limit			      	money,
		@DailyQtyLimit		   	int,
		@BadgeDailyBalance		money,
		@BadgeDailyLimit	   	money,
		@BadgeDailyQty		   	int,
		@BadgeDailyQtyLimit		int,
		@BadgeBalance		   	money,
		@BadgeLimit		      	money,
		@TransLimit		      	money,
		@Lost			        char(1),
		@Stolen			      	char(1),
		@InactiveAcct		   	char(1),
		@InactiveBadge		   	char(1),
		@AccountName		   	varchar(35),
		@AccountCurrentQty		int,
		@AccountQtyLimit	   	money,
		@AccountCategory	   	varchar(10),
		@AvailableBalance	   	money,
		@Reason			      	int,
		@AutoServiceCharge		bit,
		@TaxExempt				bit,
		@AutoDiscount			bit,
		@AccountClassID			int,
		@AcctType				int,
		@AcctBalOnCheck			bit,
		@AcctRemBalOnCheck		bit,
		@AcctDailyBalOnCheck	bit,
		@AcctRemDailyBalOnCheck	bit,
		@AcctQTYOnCheck      	bit,
		@AcctQTYRemOnCheck   	bit,
		@AcctReceiptTransProfileDisplay int,
		@AcctTransClassSelectList varchar(50),
		@GlobalLimitOnCheck bit,
		@GlobalLimitOnCheckLabel varchar(50),
		@GlobalRemainingBalanceOnCheck bit,
		@GlobalRemainingBalanceOnCheckLabel varchar(50),
		@GlobalBalanceOnCheck bit,
		@GlobalBalanceOnCheckLabel varchar(50),
		@BadgeClassID			int,
		@BadgeStatus			int,
		@BadgeBalOnCheck		bit,
		@BadgeRemBalOnCheck		bit,
		@BadgeDailyBalOnCheck	bit,
		@BadgeRemDailyBalOnCheck bit,
		@TransClassID			int,
		@GlobalBalance			money,
		@GlobalLimit			money,
		@GlobalTransOverride	money

		DECLARE @AllTransClassBalances AS TABLE	(
		TransClassID 			int,
		DailyQty 				int, 
		AccountDailyBalance 	money,
		DailyLimit 				money,
		AcctBalance 			money,
		AcctAvailableBalance 	money,
		Limit 					money,
		DailyQtyLimit 			int,
		BadgeDailyBalance 		money,
		BadgeDailyLimit 		money,
		BadgeDailyQty 			int,
		BadgeDailyQtyLimit 		int,
		BadgeBalance 			money,
		BadgeLimit 				money,
		TransLimit 				money,
		Lost 					int,
		Stolen 					int,
		InactiveAcct 			int,
		InactiveBadge 			int,
		AccountName 			varchar(100),
		AccountCurrentQty 		money,
		AccountQtyLimit  		money,
		AccountCategory  		varchar(20),
		GlobalLimit 			varchar(20),
		CheckShowAccountBalance					bit,
		CheckShowAccountBalanceLabel 			varchar(10),
		CheckShowAccountRemainingBalance 		bit,
		CheckShowAccountRemainingBalanceLabel 	varchar(10),
		CheckShowAccountDailyBalance 			bit,
		CheckShowAccountDailyBalanceLabel 		varchar(10),
		CheckShowAccountRemainingDailyBalance 	bit,
		CheckShowAccountRemainingDailyBalanceLabel varchar(10),
		CheckShowAccountQuantity 				bit,
		CheckShowAccountQuantityLabel 			varchar(10),
		CheckShowAccountQuantityRemaining 		bit,
		CheckShowAccountQuantityRemainingLabel 	varchar(10),
		IsDecliningBalance 						bit,
		ChecksShowReverseSign 					bit
		);

		SET @ParentSP = @Return
		SET @loglevel = 1		-- default to read/access level	
		SET @today = dbo.GetDateLocalTime()


		-- Removes badge swipe character if it exists in @BadgeNo
		SET @BadgeNo = dbo.RemoveBadgeSwipePrefix(@BadgeNo);

		-- update all system cycles. Runs only once a day - added 5-5-2011 RBeverly
		EXEC dbo.Cycles_MakeAllCurrent		

		-- Get the bits for showing items on the receipt
		SELECT @AcctType = AccountType, 
		@AcctReceiptTransProfileDisplay = ReceiptTransProfileDisplay , 
		@AcctTransClassSelectList = SelectedTransProfilesOnReceipt,
		@GlobalLimitOnCheck = GlobalLimitOnCheck,
		@GlobalLimitOnCheckLabel = GlobalLimitOnCheckLabel,
		@GlobalRemainingBalanceOnCheck = GlobalRemainingBalanceOnCheck,
		@GlobalRemainingBalanceOnCheckLabel = GlobalRemainingBalanceOnCheckLabel,
		@GlobalBalanceOnCheck = GlobalBalanceOnCheck,
		@GlobalBalanceOnCheckLabel = GlobalBalanceOnCheckLabel
		FROM tblAccountClass
		WHERE AccountClassID IN (SELECT AccountClassID FROM tblAccountOHD WHERE AccountNo = @AccountNo)

		SELECT @BadgeStatus = Status   FROM tblBadgeClass
		WHERE BadgeClassID IN (SELECT BadgeClassID FROM tblBadgesOHD WHERE BadgeNo = @BadgeNo AND AccountNo = @AccountNo)

		SELECT @TransClassID = TransClassID FROM tblTransDef
		WHERE  TransID = @TransID

		IF EXISTS (SELECT 1 FROM dbo.tblAccountOHD WHERE AccountNo = @AccountNo AND TransOverride = 1)
			SELECT @GlobalTransOverride = TransOverrideAmt
			FROM dbo.tblAccountOHD WHERE AccountNo = @AccountNo AND TransOverride = 1

		-- Catch a situation WHERE the TransID does not exist.  27-Aug-08 wjs
		IF (ISNULL( @TransClassID , 0 ) = 0 )
		BEGIN
			SELECT '/Invalid Trans ID: ' + CAST( @TransID as varchar(10))
			RETURN
		END

		-- This should never happen, but catch a non existant account. 27-Aug-08 wjs
		IF (ISNULL( @AcctType  , -1 ) = -1 )
		BEGIN
			SELECT '/Invalid Account Type For Account: ' + @AccountNo
		END

		SET @AutoServiceCharge = @AcctType & 1
		SET @TaxExempt = @AcctType & 2
		SET @AutoDiscount = @AcctType & 4
		SET @AcctBalOnCheck = @AcctType & 8
		SET @AcctRemBalOnCheck = @AcctType & 16
		SET @AcctDailyBalOnCheck = @AcctType & 32
		SET @AcctRemDailyBalOnCheck = @AcctType & 64
		SET @AcctQTYOnCheck = @AcctType & 128
		SET @AcctQTYRemOnCheck = @AcctType & 256
		SET @BadgeBalOnCheck = @BadgeStatus & 8
		SET @BadgeRemBalOnCheck = @BadgeStatus & 16
		SET @BadgeDailyBalOnCheck = @BadgeStatus & 32
		SET @BadgeRemDailyBalOnCheck = @BadgeStatus & 64
					
		-- Insert Balances for all Trans Profiles into a table variable.
		INSERT INTO @AllTransClassBalances
		SELECT
			T.TransClassID AS TransClassID,
			T.DailyQty AS DailyQty,
			dbo.isDailyMoney( t.DailyBalance ,t.lastchgdate , @Today) AS AccountDailyBalance,
			dbo.fnMin( t.DailyLimit, c.DailyLimit ) AS DailyLimit,
			T.Balance AS AcctBalance,
			dbo.fnMin(dbo.fnMin(dbo.fnMin(dbo.fnMin( b.TransLimit, (dbo.fnMin( t.Limit , c.Limit ) - T.Balance)), (b.Limit - ISNULL(BT.Total,0))), (dbo.fnMin( t.DailyLimit, c.DailyLimit ) - dbo.isDailyMoney( t.DailyBalance ,t.lastchgdate , @Today))), (dbo.fnMin( bc.DailyLimit ,  B.DailyLimit ) - dbo.isDailyMoney( b.DailyBalance ,b.lastchgdate , @Today))) as AcctAvailableBalance,
			dbo.fnMin( t.Limit , c.Limit ) as Limit,
			dbo.fnMin( t.DailyQtyLimit,  c.DailyQtyLimit ) as DailyQtyLimit,
			dbo.isDailyMoney( b.DailyBalance ,b.lastchgdate , @Today) as BadgeDailyBalance,
			dbo.fnMin( bc.DailyLimit ,  B.DailyLimit ) as BadgeDailyLimit,
			dbo.isDailyMoney( b.DailyQty ,b.lastchgdate , @Today) as BadgeDailyQty,
			dbo.fnMin( bc.DailyQtyLimit  , B.DailyQtyLimit) as BadgeDailyQtyLimit,
			ISNULL(BT.Total,0) as BadgeBalance,
			b.Limit as BadgeLimit,
			b.TransLimit as TransLimit,
			CAST(b.Lost as char(1)) as Lost,
			CAST(b.Stolen as char(1)) as Stolen,
			CAST(A.Inactive as char(1)) as InactiveAcct,
			CAST(B.Inactive as char(1)) as InactiveBadge,
			CASE WHEN A.User3 = 'UseBadgeName' THEN
				RTRIM(B.LastName) + ', ' + RTRIM(B.FirstName)
			ELSE
				CASE 
					WHEN RTRIM(A.LastName) = '' THEN RTRIM(A.Description)
				ELSE RTRIM(A.LastName) + ', ' + RTRIM(A.FirstName)
				END
			END as AccountName,
			T.Qty as AccountCurrentQty,
			T.QtyLimit as AccountQtyLimit,	
			C.Category as AccountCategory,	
			C.GlobalLimit as GlobalLimit,
			TC.CheckShowAccountBalance,
			TC.CheckShowAccountBalanceLabel,
			TC.CheckShowAccountRemainingBalance,
			TC.CheckShowAccountRemainingBalanceLabel,
			TC.CheckShowAccountDailyBalance,
			TC.CheckShowAccountDailyBalanceLabel,
			TC.CheckShowAccountRemainingDailyBalance,
			TC.CheckShowAccountRemainingDailyBalanceLabel,
			TC.CheckShowAccountQuantity,
			TC.CheckShowAccountQuantityLabel,
			TC.CheckShowAccountQuantityRemaining,
			TC.CheckShowAccountQuantityRemainingLabel,
			TC.DeclBalMode,
			TC.ChecksShowReverseSign
		FROM 	tblAccountOHD A
			LEFT  JOIN tblAccountTTL T on  t.accountno = a.accountno
			RIGHT JOIN tblAccountClass C on c.AccountClassID = a.AccountClassID 
			RIGHT JOIN tblBadgesOHD B on B.AccountNo = @AccountNo AND b.BadgeNo = @BadgeNo
			RIGHT JOIN tblBadgeClass BC on BC.BadgeClassID =  b.BadgeClassID 
			RIGHT JOIN tblTransClass as TC on tc.TransClassID = t.TransClassID
			RIGHT JOIN tblOutletOHD as O on O.OutletNo = @RevenueCenter
			LEFT JOIN tblBadgeTTL BT on A.AccountNo = BT.AccountNo AND BT.BadgeNo = @BadgeNo 
				AND dbo.GetCycleByXREF(0,BT.Date,'BC' + CAST(B.BadgeClassID AS varchar(10))) = dbo.GetCycleByXREF(0,@Today,'BC' + CAST(B.BadgeClassID AS varchar(10)))
		WHERE 	A.AccountNo=@AccountNo
			AND	 A.expiredate >= @Today 
			AND  A.ActiveDate <= @Today  
			AND  B.expiredate >= @Today  
			AND  B.ActiveDate <= @Today  
			AND  T.expiredate >= @Today  
			AND  TC.disablePOSposting = 0  
			AND ([dbo].AccountTTL_IsActive(T.AccountNo,T.TransClassID)=1)
			AND  (( O.Subtype & TC.SubType) <> 0) 
		ORDER BY a.AccountNo,t.TransClassID

		-- Get the current trans class balance AND qty VALUES. This supports old sim functionality.
		SELECT  @DailyQty = AB.DailyQty,
			@AccountDailyBalance = AB.AccountDailyBalance,
			@DailyLimit = AB.DailyLimit,
			@AcctBalance = AB.AcctBalance,
			@Limit = AB.Limit,
			@DailyQtyLimit = AB.DailyQtyLimit,
			@BadgeDailyBalance = AB.BadgeDailyBalance,
			@BadgeDailyLimit = AB.BadgeDailyLimit,
			@BadgeDailyQty = AB.BadgeDailyQty,
			@BadgeDailyQtyLimit = AB.BadgeDailyQtyLimit,
			@BadgeBalance = AB.BadgeBalance,
			@BadgeLimit = AB.BadgeLimit,
			@TransLimit = AB.TransLimit,
			@Lost = AB.Lost,
			@Stolen = AB.Stolen,
			@InactiveAcct = AB.InactiveAcct,
			@InactiveBadge = AB.InactiveBadge,
			@AccountName = AB.AccountName,
			@AccountCurrentQty = AB.AccountCurrentQty,
			@AccountQtyLimit = AB.AccountQtyLimit,	
			@AccountCategory = AB.AccountCategory,	
			@GlobalLimit = AB.GlobalLimit
		FROM 	@AllTransClassBalances as AB
		WHERE AB.TransClassID = @TransClassID
		ORDER BY AB.TransClassID

		SET @GlobalBalance = dbo.GetGlobalBalance(@AccountNo)

		-- Update all Limits to the Global Override Amt. if it is set
		IF (@GlobalTransOverride IS NOT NULL)
		BEGIN
			SET @TransLimit = @GlobalTransOverride
			SET @Limit = @GlobalTransOverride
			SET @BadgeLimit = @GlobalTransOverride
			SET @DailyLimit = @GlobalTransOverride
			SET @BadgeDailyLimit = @GlobalTransOverride
		END

		-- Get the limit with the lowest value
		SELECT @AvailableBalance = dbo.fnMin(dbo.fnMin(dbo.fnMin(dbo.fnMin( @TransLimit, (@Limit - @AcctBalance)), (@BadgeLimit - @BadgeBalance)), (@DailyLimit - @AccountDailyBalance)), (@BadgeDailyLimit - @BadgeDailyBalance))

		-- Get the ordinal of the lowest item
		SELECT @Reason = dbo.MinOrdinal(@TransLimit,(@Limit - @AcctBalance),(@BadgeLimit - @BadgeBalance),(@DailyLimit - @AccountDailyBalance),
		  (@BadgeDailyLimit - @BadgeDailyBalance))

		--Start Get labeled balances for each trans profile.

		-- turn off Account trans profile balances that should not be display.
		IF @AcctReceiptTransProfileDisplay = 1 -- Trans Profile for current transaction
		BEGIN
			-- Turn off the account balances for those that are not the current trans profile.
			UPDATE 	@AllTransClassBalances
			SET  	CheckShowAccountBalance = 0,
					CheckShowAccountRemainingBalance = 0,
					CheckShowAccountDailyBalance = 0,
					CheckShowAccountRemainingDailyBalance = 0,
					CheckShowAccountQuantity = 0,
					CheckShowAccountQuantityRemaining = 0
			WHERE 	TransClassID <> @TransClassID

		END
		--ELSE IF @AcctReceiptTransProfileDisplay = 2 -- All Trans Profiles on the account -- do nothing because we are showing all trans profiles.
		ELSE IF @AcctReceiptTransProfileDisplay = 3 -- Trans Profile for the current trans action plus selected trans profiles.
		BEGIN
		-- Turn off the account balances for those that are not the current trans profile or in the select list.
			UPDATE 	@AllTransClassBalances
			SET  	CheckShowAccountBalance = 0,
					CheckShowAccountRemainingBalance = 0,
					CheckShowAccountDailyBalance = 0,
					CheckShowAccountRemainingDailyBalance = 0,
					CheckShowAccountQuantity = 0,
					CheckShowAccountQuantityRemaining = 0
			WHERE 	TransClassID <> @TransClassID
				AND TransClassID NOT IN (
					SELECT field 
					FROM dbo.GetTableFromDelimitedString(@AcctTransClassSelectList,',')
					)	
		END
		ELSE IF @AcctReceiptTransProfileDisplay = 4 -- Only the selected trans profiles.
		BEGIN

				-- Turn off the account balances for those that are not in the select list.
			UPDATE	@AllTransClassBalances
			SET  	CheckShowAccountBalance = 0,
					CheckShowAccountRemainingBalance = 0,
					CheckShowAccountDailyBalance = 0,
					CheckShowAccountRemainingDailyBalance = 0,
					CheckShowAccountQuantity = 0,
					CheckShowAccountQuantityRemaining = 0
			WHERE 	TransClassID NOT IN (
					SELECT field 
					FROM dbo.GetTableFromDelimitedString(@AcctTransClassSelectList,',')
					)	
		END

		--Create a table variable to hold all the balance lines.
		DECLARE @BalanceLines TABLE(TransClassID int, Label varchar(20), Value varchar(20))

		-- select a union of all the balances that should be displayed. Order by Trans Class.
		-- TO DO NEED TO HAVE MORE CONTROL OVER SORT ORDER THAN JUST TRANSCLASS
		INSERT INTO @BalanceLines
		--Account Balance
		SELECT 	TransClassID, 
				CheckShowAccountBalanceLabel AS Label, 
				CASE WHEN ChecksShowReverseSign = 0 THEN
					CAST(AcctBalance as varchar(20))
				ELSE
					CAST(0-AcctBalance as varchar(20))
				END	AS Value
		FROM  	@AllTransClassBalances
		WHERE 	CheckShowAccountBalance = 1 
			AND @AcctBalOnCheck =1
		UNION
		--Account Remaining Balance
		SELECT 	TransClassID, 
				CheckShowAccountRemainingBalanceLabel AS Label, 
				CASE WHEN ChecksShowReverseSign = 0 THEN
					CAST(AcctAvailableBalance as varchar(20))
				ELSE
					CAST(0-AcctAvailableBalance as varchar(20))
				END AS Value
		FROM  	@AllTransClassBalances
		WHERE 	CheckShowAccountRemainingBalance = 1 
			AND @AcctRemBalOnCheck = 1
		UNION 
		--Account Daily Balance
		SELECT 	TransClassID, 
				CheckShowAccountDailyBalanceLabel AS Label, 
				CASE WHEN ChecksShowReverseSign = 0 THEN
					CAST(AccountDailyBalance as varchar(20)) 
				ELSE
					CAST(0-AccountDailyBalance as varchar(20)) 
				END	AS Value
		FROM 	@AllTransClassBalances
		WHERE 	CheckShowAccountDailyBalance = 1 
			AND @AcctDailyBalOnCheck = 1
		UNION 
		-- Account Daily Balance Remaining
		-- TO DO COULD NOT FIND HOW THIS IS CURRENTLY USED OR CALCULATED. Not using for now.
		--SELECT TransClassID, CheckShowAccountRemainingDailyBalanceLabel AS Label, CAST('0' as varchar(20)) AS Value
		--FROM @AllTransClassBalances
		--WHERE CheckShowAccountRemainingDailyBalance = 1 AND @AcctRemDailyBalOnCheck = 1
		--UNION
		-- Account Quantity
		SELECT 	TransClassID, 
				CheckShowAccountQuantityLabel as Label, 
				CAST(CAST(AccountCurrentQty as int) as varchar(20)) AS Value
		FROM 	@AllTransClassBalances
		WHERE 	CheckShowAccountQuantity = 1 
			AND @AcctQTYOnCheck = 1
		UNION
		-- Account Quantity Remaining
		SELECT 	TransClassID, 
				CheckShowAccountQuantityRemainingLabel as Label, 
				CAST(CAST(AccountQtyLimit - AccountCurrentQty as int) as varchar(20)) AS Value
		FROM 	@AllTransClassBalances
		WHERE 	CheckShowAccountQuantityRemaining = 1 
			AND @AcctQTYRemOnCheck = 1
		UNION
		-- Badge Balance
		-- TO DO Get this label from tblBadgeClass
		SELECT 	TOP 1 999999 AS TransClassID, 
				'B/Bal: ' AS Label, 
				CAST(BadgeBalance AS varchar(20)) AS Value
		FROM 	@AllTransClassBalances
		WHERE 	@BadgeBalOnCheck = 1
		UNION
		-- Badge Balance Remaining
		-- TO DO Get this label from tblBadgeClass
		SELECT 	TOP 1 999999 AS TransClassID, 
				'B/RB: ' AS Label, 
				CAST(BadgeLimit - BadgeBalance AS varchar(20)) AS Value
		FROM 	@AllTransClassBalances
		WHERE 	@BadgeRemBalOnCheck = 1
		UNION
		-- Badge Daily Balance
		-- TO DO Get this label from tblBadgeClass
		SELECT 	TOP 1 999999 AS TransClassID, 
				'B/DB: ' AS Label, 
				CAST(BadgeDailyBalance AS varchar(20)) AS Value
		FROM 	@AllTransClassBalances
		WHERE 	@BadgeDailyBalOnCheck = 1
		UNION
		-- Badge Daily Balance Remaining
		-- TO DO Get this label from tblBadgeClass
		SELECT 	TOP 1 999999 AS TransClassID, 
				'B/DBR: ' AS Label, 
				CAST(BadgeDailyLimit - BadgeDailyBalance AS varchar(20)) AS Value
		FROM 	@AllTransClassBalances
		WHERE 	@BadgeRemDailyBalOnCheck = 1
		UNION
		-- Global Limit
		SELECT 	-3, 
				@GlobalLimitOnCheckLabel as Label, 
				CAST(@GlobalLimit as varchar(20)) AS Value
		WHERE 	@GlobalLimitOnCheck = 1
		UNION
		-- Global Balance
		SELECT 	-2, 
				@GlobalBalanceOnCheckLabel as Label, 
				CAST(@GlobalBalance as varchar(20)) AS Value
		WHERE 	@GlobalBalanceOnCheck = 1
		UNION
		-- Global Balance Remaining
		SELECT 	-1, 
				@GlobalRemainingBalanceOnCheckLabel as Label, 
				CAST(@GlobalLimit - @GlobalBalance as varchar(20)) AS Value
		WHERE 	@GlobalRemainingBalanceOnCheck = 1
		--Order complete union by TransClassID
		ORDER BY TransClassID

		--Select * from @BalanceLines

		--TO DO CHECK FOR CONSITENCY OF SEPARATOR CHARACTER ^ % |
		--Create Variable that holds the balance labels. Order by Trans Class.
		DECLARE @BalanceLabels Varchar(200)
		-- Make a pipe | separated list of balance labels.
		SELECT @BalanceLabels = COALESCE(@BalanceLabels +'|','') + Label
		FROM @BalanceLines
		ORDER BY TransClassID

		--Create Variable that holds the balance values. Order by Trans Class.
		DECLARE @BalanceValues Varchar(200)
		-- Make a pipe | separated list of balance values.
		SELECT @BalanceValues = COALESCE(@BalanceValues +'|','') + Value
		FROM @BalanceLines
		ORDER BY TransClassID

		-- End Get labeled balances for each transprofile.

		--Select results as single string to return to SIM.
	   
		SELECT @Return =
			RTRIM(@AccountNo) + CHAR(28) + 
			RTRIM(@BadgeNo) + CHAR(28) + 

			-- Account stuff
			CAST(@AcctBalance as varchar(25)) + CHAR(28) +
			CAST(@AccountDailyBalance as varchar(25)) + CHAR(28) +
			CAST(@Limit as varchar(25)) + CHAR(28) +
			CAST(@DailyLimit as varchar(25)) + CHAR(28) +

			-- Badge stuff
			CAST(@BadgeBalance as varchar(25)) + CHAR(28) +
			CAST(@BadgeDailyBalance as varchar(25)) + CHAR(28) +
			CAST(@BadgeLimit as varchar(25)) + CHAR(28) +
			CAST(@BadgeDailyLimit as varchar(25)) + CHAR(28) +

			-- Authorized amount
			CAST(@AvailableBalance as varchar(25)) + CHAR(28) +

			CAST(@DailyQty as varchar(10)) + CHAR(28) +
			CAST(@DailyQtyLimit as varchar(10)) + CHAR(28) +

			CAST( @BadgeDailyQty as varchar(10)) + CHAR(28) + -- as BadgeDailyQty,
			CAST(@BadgeDailyQtyLimit as varchar(10))  + CHAR(28) + -- as BadgeDailyQtyLimit ,

			@Lost + CHAR(28) + 
			@Stolen + CHAR(28) +  
			@InactiveAcct + CHAR(28) + 
			@InactiveBadge + CHAR(28) + 
			CAST(@Reason as char(1)) + CHAR(28) + 

			CAST(@AcctBalOnCheck as char(1)) + CHAR(28) +
			CAST(@AcctRemBalOnCheck as char(1)) + CHAR(28) +
			CAST(@AcctDailyBalOnCheck as char(1)) + CHAR(28) +
			CAST(@AcctRemDailyBalOnCheck as char(1)) + CHAR(28) +
			CAST(@AcctQTYOnCheck as char(1)) + char(28) + 
			CAST(@AcctQTYRemOnCheck as char(1)) + char(28) + 

			CAST(@BadgeBalOnCheck as char(1)) + CHAR(28) +
			CAST(@BadgeRemBalOnCheck as char(1)) + CHAR(28) +
			CAST(@BadgeDailyBalOnCheck as char(1)) + CHAR(28) +
			CAST(@BadgeRemDailyBalOnCheck as char(1)) + CHAR(28) +
			@AccountName + CHAR(28) +
			CAST(@AutoServiceCharge as char(1)) + CHAR(28) +
			CAST(@TaxExempt as char(1)) + CHAR(28) + 
			CAST(@AutoDiscount as char(1)) + CHAR(28) +
			CAST(@TransLimit as varchar (25)) + CHAR(28) +
			CAST(@AccountCurrentQty as varchar (10)) + CHAR(28) +
			CAST(@AccountQtyLimit as varchar(25)) + CHAR(28) +
			@AccountCategory + CHAR(28) +
			CAST(@GlobalLimit as varchar(25)) + CHAR(28) +
			CAST(@GlobalBalance as varchar(25)) + CHAR(28) +
			'END'       -- Our end of record marker just to ensure all of our data stays lined up as this format is VERY fragile.
			-- other fields added to end for gempay control of balance items on receipt.
			+ char(28) + 
			COALESCE(@BalanceLabels,'') + char(28) +
			COALESCE(@BalanceValues,'') + char(28) +
			'END2'+      -- Our end of record marker just to ensure all of our data stays lined up as this format is VERY fragile.
			CHAR(28) +
			CHAR(28) +
			'END3'

		DECLARE @cMsg  char(255)

		IF( @@rowcount = 0 ) 
		BEGIN
			SET @cMsg = 'sim140_GetAccountWithBalanceEX Account/Badge # ' + RTRIM(@AccountNO) + '/' + RTRIM(@BadgeNo) + ' <No Match>'
			SET @LogLevel = @LogLevel - 1		-- drop logging level to catch failure.
		END
		ELSE
			SET @cMsg = 'sim140_GetAccountWithBalanceEX Account/Badge # ' + RTRIM(@AccountNO) + '/' + RTRIM(@BadgeNo)

		EXEC sp_Logit @LogLevel , @CoreID , @User , @cMsg

		IF (@ParentSP <> 'dbo.sim140_TransPostEX')
			SELECT @Return
go

