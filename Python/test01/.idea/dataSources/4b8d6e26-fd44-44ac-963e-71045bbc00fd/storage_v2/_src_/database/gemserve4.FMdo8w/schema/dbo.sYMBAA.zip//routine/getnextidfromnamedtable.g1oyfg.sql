-- =============================================
-- Author:		Richard Beverly
-- Create date: 2-10-2010
-- Description:	* Proc returns the first integer id not found in a table's id column.
--				* This proc deosn't look at the max id, but loops through the id column one by one
--				  to find the first available id. If the existing ids were 1,2,4,5,6 - the proc would return 3
--				* IDs are sorted ascending
--				* Lowest id is expected to be no lower than 1
--				* Value is returned as an output param
-- Parameters:	@TableName - varchar(50) - Name of table to be queried
--				@IdColumnName - varchar(50) - Name of the table's ID column
--				@NextId - int OUT - Output parameter; will be set to the next available id
-- Example:		DECLARE @MyNewId int
--				EXECUTE dbo.GetNextIdFromNamedTable 'dbo.tblMyTable', 'MyColumn', @MyNewId OUTPUT
--				SELECT @MyNewId AS 'Next Available ID'
-- =============================================
CREATE PROCEDURE [dbo].[GetNextIdFromNamedTable]
	@TableName			varchar(50),
	@IdColumnName		varchar(50),
	@NextId				int OUTPUT
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @sql		nvarchar(1000),
			@ParamDef	nvarchar(500),
			@NewId		int
	
	/* lowest id is expected to be no lower than 1*/
	SET @sql = N'SET @NextIdOUT = 0
			     WHILE 1=1 
				 BEGIN 
					SET @NextIdOUT = @NextIdOUT + 1  
					IF NOT EXISTS (SELECT * FROM ' + @TableName + N' WHERE ' + @IdColumnName + N' = @NextIdOUT)  
						BREAK 
				 END '
	SET @ParamDef = N'@NextIdOUT int OUTPUT'
					
	EXECUTE sys.sp_executesql @sql, @ParamDef, @NextIdOUT = @NewId OUTPUT
		
	SET @NextId = @NewId
	
	SELECT @NewId AS NextID
END
go

