
CREATE  PROCEDURE dbo.sp_Account_InsertNewOutletClassTTLs
@User			char(10),
@AccountNo 		char(19)
AS
	DECLARE @OutletClassTable TABLE (ClassID int, Processed bit)
	DECLARE @TransClassTable TABLE (ClassID int, Processed bit)
	DECLARE	@TempOutletClassID int,
			@TempTransClassID int
			
	INSERT	@OutletClassTable
	SELECT	OutletClassID, 0
	FROM	tblOutletClass

	INSERT	@TransClassTable
	SELECT	TransClassID, 0
	FROM	tblTransClass

	--Initialize the temp tables
	UPDATE	@OutletClassTable
	SET		Processed = 0

	UPDATE	@TransClassTable
	SET		Processed = 0

	WHILE 'TransClassLoop' = 'TransClassLoop' --endless loop designed to be broken when there are no more items to process
	BEGIN
		SELECT	TOP 1 @TempTransClassID = ClassID
		FROM	@TransClassTable
		WHERE	Processed <> 1
		
		-- No more classes to process, we're outta here!
		IF @@ROWCOUNT < 1
			BREAK

		WHILE 'OutletClassLoop' = 'OutletClassLoop' --endless loop
		BEGIN
			SELECT	TOP 1 @TempOutletClassID = ClassID
			FROM	@OutletClassTable
			WHERE	Processed <> 1
		
			-- No more classes to process, we're outta here!
			IF @@ROWCOUNT < 1
				BREAK
			
			-- BEGIN work ==============================================
			
			-- IF the outlet class TTL in question doesn't exist, add it
			IF NOT EXISTS (SELECT	* 
							FROM	tblAccountOutletClassTTL
							WHERE	AccountNo = @AccountNo AND 
									OutletClassID = @TempOutletClassID AND
									TransClassID = @TempTransClassID)
				EXEC dbo.sp_AccountOutletClassTTL_Insert @User, @AccountNo, @TempOutletClassID, @TempTransClassID

			-- END work  ==============================================

			-- flag the prcessed class
			UPDATE	@OutletClassTable
			SET		Processed = 1
			WHERE	ClassID = @TempOutletClassID
		END
		
		-- flag the prcessed class
		UPDATE	@TransClassTable
		SET		Processed = 1
		WHERE	ClassID = @TempTransClassID
		
		-- reset all outlet class item flags
		UPDATE	@OutletClassTable
		SET		Processed = 0

	END
go

