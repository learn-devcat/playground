
CREATE     PROCEDURE dbo.WorkorderOHD_PostCharge
@User           char(10),
@WorkOrderID    int,
@EmployeeID     int,
@CDate          datetime
AS
DECLARE @TransDate      datetime,
        @WorkOrderNumber varchar(50),
        @AccountNo      char(19),
        @BadgeNo        char(19),
        @OutletNo       int,
        @OHDTransID     int,
        @CheckNo        varchar(6),
        @OHDTransTotal  money,
        @PostResult     int,
	@msg		varchar(100)
    SET @TransDate = ISNULL( @CDate , getdate())
    -- Retrieve the Transaction Details  
    SELECT @OHDTransTotal = O.TotalCharge,
           @OHDTransID    = O.TransID,
           @AccountNo     = O.AccountNo,
           @OutletNo      = L.DefaultWorkOrderOutlet,
           @WorkOrderNumber = O.WorkOrderNumber
      FROM tblWorkOrderOHD O 
      LEFT JOIN cfgLocations L  on O.LocationID = L.LocationID
     WHERE O.WorkOrderID = @WorkOrderID 
     -- Now, resolve the Badge Number, since we need one of these...
    SELECT  Top 1
            @BadgeNo = BadgeNo
      FROM  tblBadgesOHD
     WHERE  AccountNo = @AccountNo AND
            ActiveDate <= @TransDate AND
            ExpireDate >= @TransDate AND
            Inactive = 0
    ORDER BY PrimaryBadge 
--SET @msg = @User + ', ' + CAST(@WorkOrderID as varchar) + ', ' + CAST(@EmployeeID as varchar) + ', ' + CAST(@CDate as varchar)
	SET @msg = CAST(@TransDate as varchar)
	EXEC dbo.sp_Logit 2 , 1 , @User , @msg, 900  
    -- Now, we should have all our detail -- so let's try to post this thing.
   EXEC @PostResult =  dbo.sp_Trans_Post 0 , @User, @AccountNo, @BadgeNo, @TransDate, @OutletNo, 
                                    	'WO' , 'OHD', @OHDTransTotal, @OHDTransTotal, @WorkOrderNumber, 
                                       	0 , @OHDTransID , '', 0 , 0, @EmployeeID 
    SELECT @PostResult as ReturnMessage
    RETURN
go

