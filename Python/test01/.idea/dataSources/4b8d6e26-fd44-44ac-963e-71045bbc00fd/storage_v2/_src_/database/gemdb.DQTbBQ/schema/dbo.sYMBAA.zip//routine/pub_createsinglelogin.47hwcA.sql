

CREATE PROCEDURE dbo.pub_CreateSingleLogin
    @AccountNo char(19),
    @LastName varchar(30),
    @Reset int = 0
AS 
    SET NOCOUNT ON
    DECLARE @Len int,
        @pubID varchar(50)
	--No lastname? outta here
    IF ( LEN(@LastName) = 0 ) 
        RETURN
    -- IF resetting pw, delete original login
    IF ( @Reset = 1 ) 
        DELETE  GEMPublic..tblAccountLogins
        WHERE   AccountNo = @AccountNo
    -- IF delete failed, outta here
    IF EXISTS ( SELECT  AccountNo
                FROM    GEMPublic..tblAccountLogins
                WHERE   AccountNo = @AccountNo ) 
        RETURN 
	
	-- get the publicID IF it exists
    SELECT  @pubID = ISNULL(PublicID, AccountNo)
    FROM    dbo.tblAccountOHD
    WHERE   AccountNo = @AccountNo
	
    INSERT  INTO GEMPublic..tblAccountLogins
            (
              UserID,
              AccountNo,
              Password,
              UserQuestion,
              UserAnswer
            )
    VALUES  (
              @pubID,
              @AccountNo,
              CAST(LOWER(RTRIM(@LastName)) AS varbinary(25)),
              'What is my lastname',
              @LastName
            )
go

