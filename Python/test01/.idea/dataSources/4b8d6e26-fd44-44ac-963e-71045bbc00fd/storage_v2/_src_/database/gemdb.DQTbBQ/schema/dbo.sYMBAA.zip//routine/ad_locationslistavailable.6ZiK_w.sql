
CREATE  PROCEDURE dbo.ad_LocationsListAvailable
@UserID	varchar(10)
AS
	SELECT 	LocationID, Description
	FROM 	cfgLocations
	WHERE 	LocationID  IN (SELECT LocationID FROM cfgUserLocations WHERE UserID = @UserID)
	ORDER BY Description
go

