
CREATE FUNCTION [dbo].[PrioritizeDietList]
(@DietList VARCHAR (4000))
RETURNS VARCHAR (4000)
AS
BEGIN
	DECLARE @Start		int,
		@Item		varchar(200),
		@ItemPriority	int,
		@Return		varchar(4000),
		@Done 		int,
		@Count		int,
		@ORMSeparator	varchar(10),
		@DietPrefix	int,
		@DietPrefixValue	varchar(100),
		@TempID		int

	SELECT @ORMSeparator = COALESCE(dbo.GetOverheadValueNull('ORMSeparator'),'|')
	SET @Done = 0
	SET @Count = 1

	IF EXISTS (SELECT 1 FROM dbo.cfgOverhead WHERE KeyID = 'DietPrefix')
		SELECT @DietPrefix = dbo.GetOverheadValue('DietPrefix')
	ELSE
		SET @DietPrefix = 0

	IF (CHARINDEX(@ORMSeparator, @DietList) = 0)
	BEGIN
		SET @Return = @DietList
		GOTO Finish
	END
	ELSE
	BEGIN
		DECLARE @Diets TABLE (DietID int IDENTITY(1,1),DietName varchar(200), DietPriority int)

		SET @Start = 1

		WHILE (@Done = 0)
		BEGIN
			IF (CHARINDEX(@ORMSeparator, @DietList, @Start) > 0)
			BEGIN
				SELECT @Item = SUBSTRING(@DietList, @Start, CHARINDEX(@ORMSeparator, @DietList, @Start) - @Start)
				SET @Start = @Start + LEN(@Item) + 1
			END
			ELSE
			BEGIN
				SET @Item = SUBSTRING(@DietList, @Start, LEN(@DietList) - @Start + 1)
				SET @Done = 1
			END
	
			IF EXISTS (SELECT 1 FROM dbo.tblXlat WHERE xlatid = 'DietPriority' AND KeyIn = @Item)
			BEGIN
				-- Item is in the Diet Priority listing, so process
				INSERT INTO @Diets (DietName, DietPriority)
				SELECT DISTINCT @Item, CASE WHEN @DietPrefix = @Count THEN -100 ELSE KeyOut END
				FROM dbo.tblXlat 
				WHERE xlatid = 'DietPriority'
					AND KeyIn = @Item
			END	
			ELSE
			BEGIN
				IF @Item <> ''
				BEGIN
					INSERT INTO @Diets (DietName, DietPriority)
					SELECT @Item, CASE WHEN @DietPrefix = @Count THEN -100 ELSE 100000 END
				END
			END

			SET @Count = @Count + 1
					
		END

		-- Wrap the string back up
		IF EXISTS (SELECT 1 FROM @Diets)
		BEGIN
			SET @Return = ''
			
			SELECT @Return = COALESCE(@Return + @ORMSeparator, '') + 
				CAST(DietName AS varchar(200))
			FROM @Diets
			ORDER BY DietPriority ASC, DietID ASC	
		END
		ELSE
			SET @Return = @DietList
	END

Finish:
	IF (RIGHT(@Return, 1) = @ORMSeparator)
		SET @Return = LEFT(@Return,LEN(@Return)-1)
	
	IF (LEFT(@Return, 1) = @ORMSeparator)
		SET @Return = RIGHT(@Return,LEN(@Return)-1)

	RETURN @Return
END

go

