

CREATE PROCEDURE dbo.ad_AccountClass_Insert
@User			char(10),
@AccountClassID	int,
@Name		char(16),
@Category		char(10)
AS
	INSERT INTO	tblAccountClass
			(AccountClassID, Name, Category)
	VALUES	(@AccountClassID, @Name, @Category)
go

