CREATE PROCEDURE [dbo].[PatientOrderItems]
@OrderID	int
AS
	SET NOCOUNT ON

	SELECT O.OrderItemID,
		M.[Description],
		O.Consumption
	FROM dbo.tblOrderItems AS O (NOLOCK)
	JOIN dbo.tblMenuItemOHD AS M (NOLOCK) ON O.POSMenuItemID = M.POSMenuItemID
	WHERE O.OrderID = @OrderID
		AND LEFT(M.[Description],1) <> '*'
	ORDER BY OrderItemID
go

