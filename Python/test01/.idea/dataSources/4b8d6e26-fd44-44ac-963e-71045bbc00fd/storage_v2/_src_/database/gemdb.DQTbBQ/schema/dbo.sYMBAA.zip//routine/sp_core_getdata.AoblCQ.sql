

CREATE PROCEDURE dbo.sp_Core_GetData
@CoreID int
AS
	SELECT	CoreID, Active, Description, Category, SWKEY, SWPIN, MyIP, ExceptionIP,SysOptions,CycleNo
	FROM		cfgCore
	WHERE	CoreID = @CoreID
go

