

CREATE PROCEDURE dbo.ad_Connection_List
AS
	SELECT	ConnectionID, InterfaceID, Active, Description + ' - Port ' + CAST(MyPort AS varchar(10)) AS Description, Category, ComPort, Baud,
			DataBits, StopBits, Parity, ComInit, InterfaceType, ModemActive, PhoneNumber,
			ConnectionType, MyPort, RemoteIP, RemotePort, xlat,SysOptions,
			InquireProc,AuthorizationProc, PostingProc,
            		ModemSetup, WaitCarrier, ModemDialPrefix, ModemDownTime, ModemUpTime, LicenseKey
	FROM		cfgConnection
	ORDER BY	InterfaceID, ConnectionID
go

