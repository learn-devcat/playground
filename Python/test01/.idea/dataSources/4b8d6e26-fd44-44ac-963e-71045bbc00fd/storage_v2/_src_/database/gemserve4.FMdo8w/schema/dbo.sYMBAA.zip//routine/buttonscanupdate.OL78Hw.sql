CREATE PROCEDURE [dbo].[ButtonScanUpdate]
@BatchID varchar(10)  = 'system'
AS

	DECLARE @ScanTime 	datetime,
		@ActionID 	int,
		@OrderID  	int,
		@ScanRecordID 	int,
		@SentActionID 	int,
		@PostStatus 	char(1),
		@Msg 		varchar(128),
		@Temp 		varchar(100),
		@ScanWindow 	int,
		@LoginUserID		varchar(50),
		@ErrorCount		int
   
	SET NOCOUNT ON 

	/* PostStatus: N - Needs Processing  P - Processed   E - Error    */
	
  	EXEC dbo.logit 40000,'Run SP: ButtonScanUpdate Begin','System'

	-- Get the number of minutes a button scan is valid.
	SELECT @Temp = dbo.GetOverheadValue('ScanWindow')
	IF(ISNUMERIC(@Temp) = 1)
		SET @ScanWindow = CAST(@Temp AS int)
	ELSE
		-- Set to the default value, since no overhead item found.
		SET @ScanWindow = 180
	
	-- First, clean up any previous POSTED entries. (just like we do for our batch file)
	DELETE dbo.tblButtonScans 
	WHERE  PostStatus = 'P' AND UPPER(BatchID) = UPPER(@BatchID)
	
	-- No Action ID, so setup some status here -- Just so we DON'T get non actionalbe
	-- Items in our cursor.  Ignore items with error.
	UPDATE dbo.tblButtonScans
	   SET PostStatus = 'N'
	WHERE  UPPER(BatchID) = UPPER(@BatchID) AND COALESCE(PostStatus,' ') <> 'E'
		
   	-- We are tracking the items that were sent to the POS 
	-- for the linking OrderID to which we'll attach this delivery.
	SELECT @SentActionID = ActionID
	FROM   dbo.tblActions
	WHERE  ActionKEY = 'SEND'
	
	IF(@SentActionID IS NULL)
	BEGIN
		EXEC dbo.logit 0,'Action ID for ButtonScanUpdate Not Found','ErrorSys'
		RETURN
	END
	
	DECLARE ButtonScans cursor FOR
		SELECT	S.[ID], 
			OH.OrderID, 
			S.ScanTime, 
			S.PostStatus,
			S.EmployeeID
		FROM	dbo.tblButtonScans AS S 
			LEFT JOIN dbo.tblButtonXref AS X ON X.ButtonID = S.ButtonID
			LEFT JOIN dbo.tblRoomOHD AS R ON R.RoomNumber = X.RoomNumber
			LEFT JOIN dbo.tblPatientVisit AS P ON R.RoomID  = P.RoomID
				AND (COALESCE(P.DischargeDate,getdate()) >= S.ScanTime)
			LEFT JOIN dbo.tblOrderOHD AS OH ON OH.PatientVisitID = P.PatientVisitID
		        AND (OH.OrderType = 1)
				AND (COALESCE(OH.Cancelled, 0) = 0)
				AND (COALESCE(OH.Delivered, 0) = 0)
			LEFT JOIN dbo.tblOrderLog AS OL ON OL.OrderID = OH.OrderID 
		        AND (OL.ActionID = @SentActionID)  
		WHERE 	(DATEDIFF(mi, OL.[Date],S.ScanTime) >= 0)			
		        AND (DATEDIFF(mi, OL.[Date],S.ScanTime) <= @ScanWindow)
		        AND COALESCE(S.PostStatus,' ') = 'N'
		        AND UPPER(S.BatchID) = UPPER(@BatchID)
   	
	OPEN ButtonScans
	
	FETCH NEXT FROM ButtonScans INTO @ScanRecordID, @OrderID, @ScanTime, @PostStatus, @LoginUserID

	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		-- Set this OrderID to Delivered (500) based on the last setting, but is dynamic in the proc.
		EXEC OrderSETDelivered @OrderID, 1 , @LoginUserID, @ScanTime
        
		IF(@@ERROR > 0)       -- This will most likely never be called since the previous proc eats it.
		BEGIN
			SET @Msg = 'System Error: ' + CAST(@@ERROR AS varchar(10))
			EXEC logit 99999, @Msg , 'ErrorSys'
		END
		ELSE
		BEGIN
			UPDATE dbo.tblButtonScans
			SET PostStatus = 'P'
			WHERE CURRENT OF ButtonScans
		END
	         
		FETCH NEXT FROM ButtonScans INTO @ScanRecordID, @OrderID, @ScanTime, @PostStatus, @LoginUserID
	END
	   
	CLOSE ButtonScans
	DEALLOCATE ButtonScans

	-- Change the poststatus for scans that did not process to an error status
	UPDATE dbo.tblButtonScans
	SET PostStatus = 'E'
	WHERE PostStatus = 'N'
	
	SET @ErrorCount = @@ROWCOUNT
	
	-- Log the count of the items that did not process
	IF(@ErrorCount > 0)
	BEGIN
		SET @Msg = 'GEMtrak Error: No orders found for ' + CAST(@ErrorCount AS varchar(10)) + ' item(s).'
		EXEC logit 99999, @Msg, 'ErrorSys'
	END
	
	-- Clean up table by deleting all error scans that are older than 3 days
	DELETE dbo.tblButtonScans
	WHERE DATEADD(d,3,ScanTime) <= getdate() AND PostStatus = 'E'
          
  	EXEC dbo.logit 40001,'Run SP: ButtonScanUpdate Complete','System'
	
	RETURN
go

