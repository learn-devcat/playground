
CREATE PROCEDURE dbo.MenuItemTouchScreenAddForImport
@LoginUserID			varchar(250),
@MenuItemID		int,
@DietName		varchar(50),
@MenuCategoryName	varchar(50),
@Location		int,
@NextScreenName		varchar(50)='',
@NextScreen	int=null,
@Height		int=3,
@Width		int=4,
@Font		int=5,
@Color		int=23,
@IconPlacement	char(1)='C',
@IconID		int=1

AS
	SET NOCOUNT ON
	DECLARE 	@RowStart		int,
			@ColStart		int,
			@DietID			int,
			@MenuItemCategoryID	int,
			@Legend		varchar(16)

	SELECT @DietID = POSDietID
	FROM	dbo.tblDietOHD
	WHERE	POSDescription = @DietName

	SELECT @MenuItemCategoryID = MenuItemCategoryID
	FROM	dbo.tblMenuItemCategory
	WHERE	[Description] = @MenuCategoryName

	SELECT @Legend = POSLegend
	FROM	dbo.tblMenuItemOHD
	WHERE	MenuItemID = @MenuItemID

	SELECT @NextScreen = MenuItemCategoryID
	FROM 	dbo.tblMenuItemCategory
	WHERE	[Description] = @NextScreenName

	SET @RowStart = dbo.GetTSRow(@Location)
	SET @ColStart = dbo.GetTSCol(@Location)

	IF (@NextScreen = 0)
		SET @NextScreen = null
	
	INSERT INTO dbo.tblMenuItem_TouchScreen (MenuItemID, DietID, MenuCategoryID, Active,
			RowStart, ColStart, Height, Width, Font, Color, IconPlacement,
			IconID, Legend, KeyType, Modified, NextScreen)
		VALUES (@MenuItemID, @DietID, @MenuItemCategoryID, 1,
			@RowStart, @ColStart, @Height, @Width, @Font, @Color, @IconPlacement,
			@IconID, @Legend, 3, 1, @NextScreen)

	RETURN
go

