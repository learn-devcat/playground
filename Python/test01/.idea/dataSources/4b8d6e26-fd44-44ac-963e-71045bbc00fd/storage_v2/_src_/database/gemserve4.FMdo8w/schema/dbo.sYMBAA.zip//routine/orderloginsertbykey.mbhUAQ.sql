


----------------------------------------------------------------------------------
--
--  OrderLogInsertByKey                  18-Aug-03 w.j.scott
--
--  This proc will insert a new entry into the Order LOG table.  This table contains
--  a listing of all activity on the order table.
--
--
-----------------------------------------------------------------------------------
CREATE PROCEDURE dbo.OrderLOGInsertByKey
(
    @OrderID   int,
    @ActionKey varChar(25) = '',
    @UserID    int = 0
)
AS

    set nocount on

declare @ActionID int

    select @ActionID = ActionID from tblActions where ActionKey = @ActionKEY
    
	insert into tblOrderLOG ( OrderID ,  ActionID , LoginUserID )
	                 Values (@OrderID , @ActionID , @UserID)
	     
	RETURN
go

