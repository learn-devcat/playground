




CREATE   PROCEDURE [dbo].[ad_TransXref_Get]
@id	int = -1
AS 
	IF @id = -1
	BEGIN
		SELECT 	[id], 
			CASE WHEN LocationID IS NULL THEN 'all' ELSE CAST( LocationID AS VARCHAR(20)) END AS 'LocationID', 
			CASE WHEN OutletNo IS NULL THEN 'all' ELSE CAST( OutletNo AS VARCHAR(20)) END AS 'OutletNo', 
			AccountClassID, 
			BadgeClassID, 
			SIMtype, 
			POSTenderKey, 
			TransID, 
			AltPOSTenderKey, 
			AltTransID, 
			Payload, 
			POSkeyType1, 
			POSKeyType2, 
			POSKeyType3, 
			POSKey1, 
			POSKey2, 
			POSKey3, 
			POSKeyValue1, 
			POSKeyValue2, 
			POSKeyValue3, 
			POSDiscount, 
			POSDiscountAmt, 
			POSServiceCharge, 
			POSServiceChargeAmt, 
			POSTaxExempt
		FROM	dbo.tblTransXREF
	END
	ELSE
	BEGIN
		SELECT 	[id], 
			CASE WHEN LocationID IS NULL THEN 'all' ELSE CAST( LocationID AS VARCHAR(20)) END AS 'LocationID', 
			CASE WHEN OutletNo IS NULL THEN 'all' ELSE CAST( OutletNo AS VARCHAR(20)) END AS 'OutletNo', 
			AccountClassID, 
			BadgeClassID, 
			SIMtype, 
			POSTenderKey, 
			TransID, 
			AltPOSTenderKey, 
			AltTransID, 
			Payload, 
			POSkeyType1, 
			POSKeyType2, 
			POSKeyType3, 
			POSKey1, 
			POSKey2, 
			POSKey3, 
			POSKeyValue1, 
			POSKeyValue2, 
			POSKeyValue3, 
			POSDiscount, 
			POSDiscountAmt, 
			POSServiceCharge, 
			POSServiceChargeAmt, 
			POSTaxExempt
		FROM	dbo.tblTransXREF
		WHERE	[id] = @ID
	END
go

