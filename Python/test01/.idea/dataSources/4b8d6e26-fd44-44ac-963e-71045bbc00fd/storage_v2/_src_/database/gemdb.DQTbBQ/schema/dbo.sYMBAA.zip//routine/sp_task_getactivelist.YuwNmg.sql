CREATE PROCEDURE [dbo].[sp_Task_GetActiveList]
	@User char(10)
AS

	DECLARE @UserRole int
	
	-- get the user's max role id
	SELECT	@UserRole = MAX(PrivilegeClassId)
	FROM	dbo.tblPrivilegeClassMembers
	WHERE	UserID = @User;

	-- only selects active items -- 
	SELECT	O.*,
			M.[Message] AS ShortDescription
	FROM	dbo.TaskOHD AS O
	JOIN	dbo.Tasks AS T ON O.TaskId = T.TaskId
		AND T.EntryId = @User
	LEFT JOIN dbo.tblMessages AS M ON O.TaskName = M.ID 
		AND PageID = 'Tasks'
	WHERE	@UserRole >= O.MinPrivilegeClass
	ORDER BY O.CategoryId, O.Sequence, O.TaskType, O.MessageID;
go

