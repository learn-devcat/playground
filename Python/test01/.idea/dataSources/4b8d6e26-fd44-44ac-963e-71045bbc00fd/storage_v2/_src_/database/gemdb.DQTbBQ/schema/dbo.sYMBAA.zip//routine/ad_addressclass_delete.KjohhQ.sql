

CREATE PROCEDURE dbo.ad_AddressClass_Delete
@User			char(10),
@AddressClassID	int
AS
	DELETE	tblAddressClass
	WHERE	AddressID = @AddressClassID
go

