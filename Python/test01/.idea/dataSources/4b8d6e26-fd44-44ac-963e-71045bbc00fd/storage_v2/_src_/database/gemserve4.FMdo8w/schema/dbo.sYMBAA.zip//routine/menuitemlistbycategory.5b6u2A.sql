

CREATE PROCEDURE dbo.MenuItemListByCategory
@MenuItemCategoryID	int

AS
	SET NOCOUNT ON

	SELECT DISTINCT M.MenuItemID,
		M.[Description],
		COALESCE(M.Cost,0) AS Cost,
		COALESCE(M.Price, 0) AS Price,
		M.POSMenuItemID,
		M.POSMenuItemSEQ,
		M.POSLegend, 
		M.MajorGroupSequence, 
		M.FamilyGroupSequence, 
		M.MenuItemGroupSequence,
		M.MenuItemTypeSequence, 
		M.MenuLevelClassSequence, 
		M.PrinterDefClassSequence,
		M.CrossReference1, 
		M.CrossReference2
	FROM	dbo.tblMenuItemOHD AS M (NOLOCK)
		JOIN dbo.tblMenuItem_Touchscreen AS T (NOLOCK) ON M.MenuItemID = T.MenuItemID
	WHERE 	T.MenuCategoryID = @MenuItemCategoryID
	ORDER BY M.[Description]		
	
	RETURN
go

