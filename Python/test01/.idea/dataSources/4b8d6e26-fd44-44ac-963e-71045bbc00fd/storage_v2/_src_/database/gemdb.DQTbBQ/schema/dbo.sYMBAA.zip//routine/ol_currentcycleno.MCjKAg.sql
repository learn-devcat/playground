



CREATE PROCEDURE dbo.ol_CurrentCycleNo 
@CoreID   int
as 
	SELECT dbo.CurrentCycleNo( @CoreID )
go

