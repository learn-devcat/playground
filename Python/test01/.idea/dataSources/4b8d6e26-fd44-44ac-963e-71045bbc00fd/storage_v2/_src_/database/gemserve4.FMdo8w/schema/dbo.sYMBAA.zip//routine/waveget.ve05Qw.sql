


CREATE PROCEDURE dbo.WaveGet
@SearchString	varchar(200),
@WaveID		int = 0

AS
	SET NOCOUNT ON

	IF ( @SearchString <> '' )
	BEGIN
		DECLARE @SQL	nvarchar(4000)

		SET @SQL = 'SELECT WaveID, ISNULL(BeginTime,'''') AS BeginTime, ISNULL(EndTime,'''') AS EndTime, ' + 
				'ISNULL(SubType,-1) AS SubType, ISNULL(Description,'''') AS Description, ' +
				'ISNULL(MaxOrder,99) AS MaxOrder, ISNULL(WarningMinutes,0) AS WarningMinutes, ' + 
				'ISNULL(CriticalMinutes,0) AS CriticalMinutes FROM dbo.tblWave (NOLOCK) ' + @SearchString

		EXEC sys.sp_executesql @SQL
	END
	ELSE
	BEGIN
		SELECT	WaveID,	
			ISNULL(BeginTime,'') AS BeginTime,
			ISNULL(EndTime,'') AS EndTime,
			ISNULL(SubType,-1) AS SubType,
			ISNULL(Description,'') AS Description,
			ISNULL(MaxOrder,99) AS MaxOrder,
			ISNULL(WarningMinutes,0) AS WarningMinutes,
			ISNULL(CriticalMinutes,0) AS CriticalMinutes
		FROM	dbo.tblWave (NOLOCK)
		WHERE	WaveID = @WaveID
	END

	RETURN
go

