CREATE PROCEDURE [dbo].[UpdateOrderLog]
@LoginUserID	varchar(250),
@OrderID   int,
@ActionID  SQL_variant,
@DietID int = NULL,
@RoomID int = NULL,
@LogDate   datetime = NULL
AS
	SET NOCOUNT ON 
	
	DECLARE @Description varchar(30)

	-- Let's make sure this action ID exists in the table before we add this thing ...
	IF (SUBSTRING(CAST(@ActionID as varchar(30)),1,1) >= '0' AND SUBSTRING(CAST(@ActionID as varchar(30)), 1, 1) <= '9')	
		SELECT @ActionID = ActionID
		FROM dbo.tblActions (NOLOCK)
		WHERE ActionID = CAST(@ActionID as int)
	ELSE
		SELECT @ActionID = ActionID
		FROM dbo.tblActions (NOLOCK)
		WHERE ActionKEY = @ActionID

	SET @LogDate = COALESCE(@LogDate, getdate())	
    
	IF (@@ROWCOUNT = 0)    
	BEGIN
		SET @Description = 'ACTION-' + CAST(@ActionID as varchar(10))
		INSERT INTO dbo.tblActions (ActionID, ActionKEY, Description)
			VALUES (CAST(@ActionID as int), @Description, @Description)
	END

	IF EXISTS (SELECT 1 FROM dbo.tblOrderLog WHERE OrderID = @OrderID AND ActionID = CAST(@ActionID as int))
		UPDATE dbo.tblOrderLOG SET [Date] = @LogDate
		WHERE OrderID = @OrderID
			AND ActionID = CAST(@ActionID as int)		
	ELSE
		INSERT INTO dbo.tblOrderLOG (LoginUserID, OrderID, ActionID, [Date], DietID, RoomID)
		VALUES(@LoginUserID, @OrderID, CAST(@ActionID as int), @LogDate, @DietID, @RoomID)	

	RETURN
go

