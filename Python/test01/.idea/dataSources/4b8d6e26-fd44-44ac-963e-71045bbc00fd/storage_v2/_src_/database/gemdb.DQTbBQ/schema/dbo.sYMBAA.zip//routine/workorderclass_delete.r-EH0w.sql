
CREATE  PROCEDURE dbo.WorkOrderClass_Delete
@User               char(10),
@WorkorderClassID   int
AS
	DELETE  tblWorkorderClass
	WHERE   WorkorderClassID = @WorkorderClassID
go

