

CREATE FUNCTION dbo.AccountClassOUT (@TempClass int)
RETURNS varchar(10)
AS 
BEGIN 
	DECLARE @TempOUT varchar(10) 
	SELECT @TempOUT=ISNULL(XRef,'') FROM tblAccountClass WHERE
	AccountClassID = @TempClass
	 
	RETURN @TempOUT
END
go

