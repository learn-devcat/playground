CREATE PROCEDURE dbo.NutrientUpdate
@LoginUserID	varchar(250),
@NutrientID		int,
@Description	varchar(50),
@DefaultQty		int,
@DefaultUnit	varchar(25)

AS
	SET NOCOUNT ON

	UPDATE 	dbo.cfgNutrients
		SET 	[Description] = @Description,
			DefaultQty = @DefaultQty,
			DefaultUnit = @DefaultUnit
	WHERE 	NutrientID = @NutrientID

	IF (@@ROWCOUNT = 0)
		INSERT INTO dbo.cfgNutrients (NutrientID, [Description], DefaultQty, DefaultUnit)
			VALUES (@NutrientID, @Description, @DefaultQty, @DefaultUnit)	

	RETURN
go

