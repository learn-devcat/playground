CREATE PROCEDURE [dbo].[sp_Dashboard_Get]
@User			char(10)
AS

SELECT ID,Name,UserID,PageURL,SerializedRequestData,UserHidden,SortPosition,
COALESCE((
SELECT PrivilegeActionID From tblDashboardPages Where UserID = 'GLOBAL' and PageURL = d.PageURL
),d.PrivilegeActionID) As PrivilegeActionID
,

GoToURL,
COALESCE((
SELECT AllowInteraction From tblDashboardPages Where UserID = 'GLOBAL' and PageURL = d.PageURL
),d.AllowInteraction) As AllowInteraction,
AbsoluteTop,
AbsoluteLeft
FROM tblDashboardPages as d 
WHERE ((d.UserID='GLOBAL' 
AND d.UserHidden<>1
AND d.PageURL not in (SELECT PageURL FROM tblDashboardPages WHERE UserID =@User)) 
OR (d.UserID =@User AND d.UserHidden<>1))
AND (PrivilegeActionID IS NULL or dbo.IsPermitted(@User,PrivilegeActionID) >0 ) 
Order By ISNULL(AbsoluteTop,99999), ISNULL(AbsoluteLeft,99999),SortPosition
go

