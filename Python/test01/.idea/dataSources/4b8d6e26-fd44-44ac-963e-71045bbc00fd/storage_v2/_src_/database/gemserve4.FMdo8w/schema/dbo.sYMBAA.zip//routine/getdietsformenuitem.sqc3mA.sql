CREATE     FUNCTION dbo.GetDietsForMenuItem(@MenuItemID as int)
RETURNS varchar(500)
AS
BEGIN
	Declare @myDiets Table (DietID int,
				DietName varchar(50),
				Processed int default(0))
	Declare @Return varchar(500),
		@DietID int,
		@DietName varchar(50)

	Set @Return = ''

	Insert Into	@myDiets

	Select 	T.DietID,
		D.POSDescription AS [Description],
		0
	From	tblMenuItem_TouchScreen T
			Left Join
		tblDietOHD D (NOLOCK) On T.DietID = D.POSDietID
	Where 	T.MenuItemID = @MenuItemID
		AND T.Active = 1
		AND T.RowStart > 0
		AND T.ColStart > 0		


	While 1 = 1
	Begin
		Select 	top 1 @DietID = DietID,
			@DietName = DietName
		From 	@myDiets
		Where	Processed = 0
		Order By Processed

		If @@Rowcount = 0
			break

		Set @Return = @Return + ', ' + @DietName

		Update 	@myDiets
		Set	Processed = 1
		Where	DietID = @DietID
	End

	Set @Return = Case @Return When '' Then ', No Diets Found' else @Return end

        Return Right(@Return,Len(@Return) - 2)

END
go

