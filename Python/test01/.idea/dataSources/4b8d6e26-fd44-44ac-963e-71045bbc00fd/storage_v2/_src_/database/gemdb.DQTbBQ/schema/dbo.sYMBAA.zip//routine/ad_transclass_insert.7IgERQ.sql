


CREATE PROCEDURE dbo.ad_TransClass_Insert
@User				char(10),
@TransClassID		int,
@Description		varchar(25),
@Status				int,
@DisablePOSPosting	bit,
@DeclBalMode		bit,
@AddToBadgeBalance	int,
@SubType		int
AS 
	INSERT INTO	tblTransClass
				(TransClassID,Description,Status,DisablePOSPosting,DeclBalMode, AddToBadgeBalance, SubType)
	VALUES		(@TransClassID,@Description,@Status,@DisablePOSPosting,@DeclBalMode, @AddToBadgeBalance, @SubType)
go

