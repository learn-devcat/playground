


----------------------------------------------------------------------------------
--
--  GetWaveID                  15-Aug-03 w.j.scott
--
--  Get the selected WaveID based on the passed Time and SubType.  The 
--  SubType is a BITMAP field, where the first 7 bits are the Days of
--  the WEEK and the remaining BITS can be assigned as desired.
--
--      NOTE:  If NO matches are made, either by time or because of 
--             a matching SubType, a 0 is returned.
--
-----------------------------------------------------------------------------------
CREATE FUNCTION dbo.GetWaveID
(
    @Time char(5),
    @SubType int
)
RETURNS int
AS
	BEGIN
	    declare @WaveID int
		select @WaveID = WaveID 
		  from tblWave 
		 where BeginTime <= @Time and
		       EndTime > @Time and
		       ( SubType & @SubType ) > 0
		   
	RETURN IsNuLL( @WaveID , 0 )
	END
go

