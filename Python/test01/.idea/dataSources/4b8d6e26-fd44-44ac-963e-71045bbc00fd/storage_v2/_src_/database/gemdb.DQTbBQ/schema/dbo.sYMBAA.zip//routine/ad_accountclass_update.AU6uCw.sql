

CREATE PROCEDURE dbo.ad_AccountClass_Update
@User			char(10),
@AccountClassID	int,
@Name		char(16),
@Status		int,
@Category		char(10),
@Flags		char(10),
@AccountType		int,
@ExpireDays		int,
@TrackingGrp		int,
@DailyLimit		money,
@DailyQtyLimit		int,
@Limit			money,
@Xref			char(32),
@CycleXrefID		varchar(32),
@SubType		int = -1,
@IncludeAtTerm		int = 1,
@Department		bit = 0
AS
	UPDATE	tblAccountClass
	SET		Name = @Name,
			Status = @Status,
			Category = @Category,
			Flags = @Flags,
			AccountType = @AccountType,
			ExpireDays = @ExpireDays,
			TrackingGrp = @TrackingGrp,
			DailyLimit = @DailyLimit,
			DailyQtyLimit = @DailyQtyLimit,
			Limit = @Limit,
			Xref = @Xref,
			CycleXrefID = @CycleXrefID,
			SubType = @SubType,
			IncludeAtTerm = @IncludeAtTerm,
			Department = @Department
			--LocationID = @LocationID
	WHERE	AccountClassID = @AccountClassID
go

