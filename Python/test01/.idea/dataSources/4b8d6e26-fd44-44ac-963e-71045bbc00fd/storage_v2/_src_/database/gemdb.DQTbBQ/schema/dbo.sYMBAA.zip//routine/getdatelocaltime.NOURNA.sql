CREATE FUNCTION [dbo].[GetDateLocalTime]()
		RETURNS DATETIME
		AS
		BEGIN
			DECLARE @OffsetMinutes INT,
					@ReturnValue DATETIME,
					@OffsetUseDST INT,
					@DstStart DATETIME,
					@DstEnd DATETIME;

			SET @OffsetMinutes = COALESCE(NULLIF(dbo.GetOverheadItem('OffsetMinutes'),''), -1); -- default to negative 1 to indicate the offset has not been configured.
			SET @OffsetUseDST = COALESCE(NULLIF(dbo.GetOverheadItem('OffsetUseDST'),''), 0);
	
			If(@OffsetMinutes = -1) -- negative 1 indicates the offset minutes are not configured and we should use dbo.GetDateLocalTime().
			BEGIN
				SET @ReturnValue = GETDATE();
			END
			ELSE
			BEGIN
				SET @ReturnValue = DATEADD(mi, @OffsetMinutes, GETUTCDATE());
				-- If system is set to use DST then make adjustment for that time.
				If (@OffsetUSEDST = 1)
				BEGIN
					SET @DstStart = dbo.GetDstStart(DATEPART(yyyy,GETUTCDATE()))
					SET @DstEnd = dbo.GetDstEnd(DATEPART(yyyy,GETUTCDATE()))
			
					-- Is the ReturnValue within DST
					-- Note: This function will never return a time between 2am and 3am on March 13th. That hour is skipped with DST. 
					--		 This function will repeat the hour between 1am and 2am on November 6th. That hour is repeated with DST.
					--		 http://www.timeanddate.com/time/dst/transition.html
					If (@ReturnValue >= @DstStart AND DateADD(HH, 1,@ReturnValue) <= @DstEnd)
					BEGIN

						--Add an hour to @ReturnValue for DST
						SET @ReturnValue = DateADD(HH,1,@ReturnValue)
					END

				END
			END
			-- Return the result of the function
			RETURN @ReturnValue;
		END

go

