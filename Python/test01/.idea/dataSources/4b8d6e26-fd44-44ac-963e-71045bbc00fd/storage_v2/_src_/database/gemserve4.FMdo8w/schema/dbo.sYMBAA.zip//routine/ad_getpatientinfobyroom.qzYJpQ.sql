


CREATE PROCEDURE dbo.ad_GetPatientInfoByRoom
@RoomNumber varchar(10),
@Bed	varchar(10) = '%'
AS
	SET NOCOUNT ON

	SELECT P.*
	FROM    dbo.tblPatientOHD AS P (NOLOCK) 
	    JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON P.PatientID = PV.PatientID
			AND PV.MergedTo IS NULL
		JOIN dbo.tblRoomOHD AS R (NOLOCK) ON PV.RoomID = R.RoomID
	WHERE R.RoomNumber = @RoomNumber
		AND PV.Bed LIKE @Bed
		AND PV.DischargeDate IS NULL

	EXEC dbo.ad_GetOrdersByRoom @RoomNumber
go

