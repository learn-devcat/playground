

CREATE PROCEDURE [dbo].[CCS_DietUpdate2_v4]
@PatientVisitID	varchar(50),
@Source	varchar(100),
@DietName	varchar(4000),
@ActiveDate	varchar(50),
@ExpirationDate	varchar(50),
@OrderType	varchar(50),
@ConnectionName varchar(50)='',
@TransactionIdentifier varchar(50)='',
@HoldActiveTime varchar(50)='',
@HoldReleaseTime varchar(50)=''

AS
	SET NOCOUNT ON

	DECLARE	@Msg        		varchar(500),
		@PatientID		int,
		@RoomID			int,
        @OldDietID  		int,
		@OldActiveDate		datetime,
		@CancelDate		datetime,
		@DietID			int,
		@NewDiet		varchar(50),
		@ProcessType		varchar(10),
		@MedicalRecordID	varchar(50),
		@BeginTime  		varchar(5),
		@MealPeriodID		int,
		@Period			varchar(100),
		@PatientDietID		int,
		@OldPatientDietID 	int,
		@TempLen		int,
		@ORMSeparator		varchar(10),
		@SetActive		datetime,
		@TempOrderID		int,
		@LastOrderID		int


	-- If ordertype is blank, assume it is a new order
	IF (@OrderType = '')
		SET @OrderType = 'NW'

	-- Check to see if order type exists in XLAT table
	IF EXISTS (SELECT 1 FROM dbo.tblXlat WHERE xlatId = 'ORMOrderType')
	BEGIN
		IF NOT EXISTS (SELECT 1 FROM dbo.tblXlat WHERE KeyIn = @OrderType AND xlatId = 'ORMOrderType')
		BEGIN
			SET @PatientDietID = -1
			SET @Msg = 'Diet order ignored for non-processed order type [' + @OrderType + ']. PatientVisitID [' + @PatientVisitID + '].'
			GOTO TransError
		END
	END
	
	-- Check to see if order should be cancelled
	IF EXISTS (SELECT 1 FROM dbo.tblXlat WHERE xlatId = 'CancelOrderType' AND KeyIn = @OrderType)
	BEGIN
		SELECT @CancelDate = dbo.HL7ConvertDateTime (@ExpirationDate,getdate())
		-- Do not allow the cancellation to happen in the past
		IF (@CancelDate < getdate())
			SET @CancelDate = getdate()
		EXEC dbo.CCS_DietCancel_v4 @PatientVisitID, @TransactionIdentifier, @Source, @CancelDate
		SET @PatientDietID = -1
		GOTO EndDietUpdate
	END

	SELECT @ORMSeparator = COALESCE(dbo.GetOverheadValueNull('ORMSeparator'),'|')

	IF (@ActiveDate = '1/1/1900' or ISDATE(@ActiveDate) = 0) 
	BEGIN
		SET @SetActive = getdate()
		SET @ActiveDate = ''
	END

	SET @ProcessType = 'ORM-O01'

	SELECT @OldDietID = dbo.GetActiveDiet(@PatientVisitID,@ActiveDate)
	
	-- Get Patient info
    SELECT @PatientID = PV.PatientID,
	       @RoomID = PV.RoomID
    FROM dbo.tblPatientVisit AS PV (NOLOCK)
	JOIN dbo.tblPatientOHD AS P (NOLOCK) ON PV.PatientID = P.PatientID
   	WHERE PV.PatientVisitID = @PatientVisitID 

		-- Check for Order Hold/Release
	IF EXISTS (SELECT 1 FROM dbo.tblXLAT WHERE xlatID = 'HoldType' AND KeyIn = @OrderType)
	BEGIN
		EXEC dbo.CCS_Hold_v4 @PatientID, @PatientVisitID, @Source, @RoomID, @HoldActiveTime, @HoldReleaseTime, @OrderType
		SET @PatientDietID = -1
		GOTO EndDietUpdate
	END
	
	IF (@PatientID IS NULL)
	BEGIN
		SET @PatientDietID = -1
	    SET @Msg = 'Unable to process Diet Order for Patient Visit ID: [' + @PatientVisitID + ']. Patient Visit ID not found.'
	    GOTO TransError
	END 

	-- Attempt to find the diet
	SELECT @DietID = dbo.GetHL7DietID(@DietName, '')

	IF (@DietID IS NULL)
	BEGIN
		SET @PatientDietID = -1
		SET @Msg = 'Unable to process Diet Order for MedicalRecordID:' + @MedicalRecordID + '. Diet:' + LEFT(@DietName, 400) + ' not found.'
		GOTO TransError
	END 

	-- Get the existing active diet information for patient
	SELECT 	@OldPatientDietID = [ID],
			@OldActiveDate = ActiveDate
	FROM 	dbo.tblPatientDiet
	WHERE [ID] = dbo.GetActivePatientDietID(@PatientVisitID, getdate())
	
	-- Get the name of the new diet
	SELECT @NewDiet = [Description]
	FROM dbo.tblDietOHD
	WHERE DietID = @DietID

      	-- Adds the diet to the tblPatientDiet table
        -- We have to calculate the active date in order to do this entry
	IF (@ActiveDate <> '')
	BEGIN
		SELECT @SetActive = CAST(@ActiveDate AS datetime)
		SELECT @MealPeriodID = dbo.GetMealPeriod(@SetActive)
		SELECT @Period = [Description] FROM dbo.tblMealPeriods WHERE MealPeriodID = @MealPeriodID
		SELECT @BeginTime = dbo.TimeString(dbo.MealPeriodStartTime(getdate(), @MealPeriodID))
	END

	-- Check to see if TransactionIdentifier already exists
	SELECT @PatientDietID = [ID]
	FROM dbo.tblPatientDiet
	WHERE PatientVisitID = @PatientVisitID
		AND TransactionIdentifier = @TransactionIdentifier

	IF (@PatientDietID IS NULL)
	BEGIN
	    INSERT INTO dbo.tblPatientDiet(PatientVisitID, DietID, ActiveDate, Source, TransactionIdentifier)
			VALUES (@PatientVisitID, @DietID, ISNULL(@SetActive, getdate()), @Source, @TransactionIdentifier)

		SET @PatientDietID = SCOPE_IDENTITY()
	END
	ELSE
	BEGIN
		UPDATE dbo.tblPatientDiet
			SET DietID = @DietID,
			ActiveDate = COALESCE(@SetActive, ActiveDate),
			PostDate = getdate(),
			CancelDate = NULL,
			UpdateDate = getdate(),
			UpdateID = 'HL7'
		WHERE PatientVisitID = @PatientVisitID
		AND TransactionIdentifier = @TransactionIdentifier
	END

	-- Check to see if Diet is changing  and if diet has the same or newer active date than current diet          
    IF(@OldDietID <> @DietID AND COALESCE(@OldActiveDate, '1/1/1900') <= @SetActive)
	BEGIN
		-- Cancel any future orders ONLY IF we are changing the diet AND the active date is the same or newer than the current active date
		--  Set up the LastOrderID variable for the loop
		SET @LastOrderID = 0
		
		-- Insert a log entry into the Order Log for all orders that we are cancelling
		WHILE (1=1)
		BEGIN
			-- Clear our temporary variable
			SET @TempOrderID = NULL

			-- Get the next Order ID to process
			SELECT 	TOP 1 @TempOrderID = OrderID
			FROM	dbo.tblOrderOHD AS O
				JOIN dbo.tblPatientVisit AS P ON (O.PatientVisitID = P.PatientVisitID OR O.PatientVisitID = P.MergedTo)
			WHERE O.OrderDate > ISNULL(@SetActive,getdate()) 
					AND ISNULL(O.Cancelled,0) <> 1
					AND ISNULL(O.Received,0) <> 1
					AND O.OrderType = 1
    				AND O.PatientVisitID = @PatientVisitID
					AND OrderID > @LastOrderID
			ORDER BY OrderID

			-- Make sure we still have rows to process
			IF (@TempOrderId IS NULL)
				BREAK

			-- Add the log entry
			EXEC dbo.UpdateOrderLog @ProcessType, @TempOrderID , 700

			-- Set our control variable
			SET @LastOrderID = @TempOrderID
		END

		-- Deletes all nutrient counts for orders that are being canceled.
		DELETE dbo.tblPatientNutrientCount 
		WHERE OrderID IN (SELECT OrderID FROM dbo.tblOrderOHD AS O (NOLOCK)
			JOIN dbo.tblPatientVisit AS P (NOLOCK) ON (O.PatientVisitID = P.PatientVisitID OR O.PatientVisitID = P.MergedTo)
	       	WHERE O.OrderDate >= ISNULL(@SetActive,getdate()) 
                    	AND ISNULL(O.Cancelled,0) <> 1
			AND COALESCE(O.Received,0) <> 1
		    	AND O.PatientVisitID = @PatientVisitID)

		-- Insert a log entry into the Patient Log for all orders that we are cancelling
		SET @Msg = ' Order cancelled due to Diet Change. Order ID: '
		INSERT INTO dbo.tblPatientLog (EventClassID, LoginUserID, PatientID, PatientVisitID, RoomID, [Description], [Date])
		SELECT 7000, @Source, P.PatientID, P.PatientVisitID, P.RoomID, M.[Description] + @Msg + CAST(O.OrderID AS varchar(30)), getdate()
		FROM dbo.tblOrderOHD AS O (NOLOCK)
		        JOIN dbo.tblPatientVisit AS P (NOLOCK) ON O.PatientVisitID = P.PatientVisitID
				JOIN dbo.tblWave AS W (NOLOCK) ON O.WaveID = W.WaveID
				JOIN dbo.tblMealPeriods AS M (NOLOCK) ON W.MealPeriodID = M.MealPeriodID
		WHERE O.OrderDate >= ISNULL(@SetActive,getdate()) 
			AND ISNULL(O.Cancelled,0) <> 1
			AND COALESCE(O.Received,0) <> 1
			AND O.OrderType = 1
			AND O.PatientVisitID = @PatientVisitID

	        -- Set the cancelled flag to 1 for any orders in future waves
	        UPDATE  dbo.tblOrderOHD
	        SET Cancelled = 1,
	            CancelDate = getdate(),
		    LastUpdateBy = @Source
	        FROM    dbo.tblOrderOHD AS O (NOLOCK)
	                JOIN tblPatientVisit AS P (NOLOCK) ON (O.PatientVisitID = P.PatientVisitID OR O.PatientVisitID = P.MergedTo)
	        WHERE O.OrderDate >= ISNULL(@SetActive,getdate())
	                AND ISNULL(O.Cancelled,0) <> 1
			AND COALESCE(O.Received,0) <> 1
			AND O.OrderType = 1
		  	AND O.PatientVisitID = @PatientVisitID

		-- Update Optional Patient Status flags based on DietID from XLAT table
		IF EXISTS (SELECT KeyIn FROM dbo.tblXLAT WHERE xlatID = 'OptionalStatus' AND KeyIn = CAST(@DietID AS varchar(10)))
		BEGIN
			EXEC dbo.CCS_PatientStatusUpdate_v4 @PatientID, @PatientDietID, @DietID, @Source
		END
	END
	
	-- Log the diet update
	SET @Msg = ISNULL(UPPER(@NewDiet),'<NOT FOUND>') + ' diet added for ' + dbo.DateString(ISNULL(@SetActive,getdate())) + ' ' + 
		dbo.TimeString(ISNULL(@SetActive,getdate())) + ' by ' + ISNULL(@Source, 'system') + '. Transaction identifier [' + 
		ISNULL(@TransactionIdentifier,'<NOT FOUND>') + '].'

	EXEC dbo.PatientLOGAdd 7000, @ProcessType, @PatientID, @PatientVisitID, @RoomID, @Msg

	EXEC dbo.ProcessLogInsert @ProcessType
		
	SELECT @PatientDietID AS PatientDietID

	GOTO EndDietUpdate

TransError:
	IF (@Msg IS NULL)
		SET @Msg = 'Unable to process Diet Order for Patient Visit ID: [' + @PatientVisitID + ']. Diet:' + ISNULL(UPPER(@NewDiet),'NOT FOUND')

EndDietUpdate:
	EXEC dbo.Logit 1, @Msg, 'system'

	SET @ConnectionName = 'Idt' + @ConnectionName
	EXEC dbo.WorkstationUpdateByID @ConnectionName

	SELECT @PatientDietID AS PatientDietID

	RETURN @PatientDietID


go

