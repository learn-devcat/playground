
/*
Retrieves the datetime for the end of the Meal Period that is immediately before the one passed in.
*/

CREATE FUNCTION dbo.GetPreviousMealPeriodID(@MealPeriodID int, @Today datetime)
RETURNS int
AS

BEGIN
	DECLARE @Return int,
		@BeginTime varchar(5),
                @EndTime varchar(5)

        SELECT  @BeginTime = dbo.TimeString(dbo.MealPeriodStartTime(@Today,@MealPeriodID))
        SELECT  @EndTime = dbo.TimeString(dbo.MealPeriodEndTime(@Today,@MealPeriodID))

        -- Get all mealperiods that are before the current one
        DECLARE @MealPeriods TABLE (MealPeriodID int, EndTime varchar(5))

         INSERT INTO @MealPeriods
        SELECT MealPeriodID, dbo.TimeString(dbo.MealPeriodEndTime(@Today,MealPeriodID))
        FROM   dbo.tblMealPeriods
        WHERE dbo.TimeString(dbo.MealPeriodEndTime(@Today,MealPeriodID)) < @BeginTime
                AND MealPeriodID <> @MealPeriodID AND MealPeriodID NOT IN (SELECT KeyIn FROM dbo.tblXlat WHERE xlatId = 'NoReportMealPeriod')

        SELECT TOP 1 @Return = MealPeriodID
        FROM   @MealPeriods
        ORDER BY EndTime DESC

        RETURN ISNULL(@Return,-1)
END
go

