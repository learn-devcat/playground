
CREATE PROCEDURE dbo.PatientNameByMRN
@MedicalRecordID	varchar(50),
@IncludeDischarged      bit=0

AS
	SET NOCOUNT ON

        IF (@IncludeDischarged = 1)
        BEGIN
		SELECT ISNULL(P.LastName,'') + ', ' + ISNULL(P.FirstName,'') + ' ' + ISNULL(P.MiddleInitial,'') AS FullName
		FROM	dbo.tblPatientOHD AS P (NOLOCK)
		WHERE P.MedicalRecordID = @MedicalRecordID
        END
        ELSE
        BEGIN
		SELECT ISNULL(P.LastName,'') + ', ' + ISNULL(P.FirstName,'') + ' ' + ISNULL(P.MiddleInitial,'') AS FullName
		FROM	dbo.tblPatientOHD AS P (NOLOCK)
			JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON P.PatientID = PV.PatientID
		WHERE P.MedicalRecordID = @MedicalRecordID
			AND PV.DischargeDate IS NULL
	END

	RETURN
go

