
CREATE PROCEDURE [dbo].[PrivilegesGet]
@Roles AS varchar(1000)

AS
	SET NOCOUNT ON

	SELECT DISTINCT A.ActionID, A.ActionKey
	FROM    dbo.tblSecurityRoleActions AS R (NOLOCK)
                JOIN dbo.tblSecurityActions AS A (NOLOCK) ON A.ActionID = R.ActionID
        WHERE   R.RoleID IN (SELECT RoleID FROM GEM.dbo.GetUserRolesFromString(@Roles))

        RETURN
go

