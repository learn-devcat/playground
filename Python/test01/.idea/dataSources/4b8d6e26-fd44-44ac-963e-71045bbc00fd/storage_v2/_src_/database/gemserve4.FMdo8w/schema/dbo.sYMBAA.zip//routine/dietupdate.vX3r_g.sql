CREATE PROCEDURE [dbo].[DietUpdate]
@LoginUserID		varchar(250),
@DietID		int,
@Description	varchar(50),
@AltDescription	varchar(50),
@POSDietID	int,
@POSDescription	varchar(50),
@Active		int,
@NPO		int=0,
@MenuLevel	int=0

AS
	SET NOCOUNT ON
	DECLARE @POSMenuEditing	int,
			@POSDietPrefix	varchar(10),
			@iPOSDietID		int,
			@Return			int
	
	-- Check to see if the MICROS editing is allowed - default is not allowed (0)
	SET @POSMenuEditing = COALESCE(dbo.GetOverheadValueNull('POSMenuEditing'),'0')	
	
	-- Set Return Error Code to no errors by default
	SET @Return = 0
	
	-- Check to see if editing is allowed on the MICROS to update the diet
	IF(@POSMenuEditing = '1') AND (@DietID > 0)
	BEGIN
		-- Get the number to be added to the DietId to create the POS Diet ID on the MICROS
		SET @POSDietPrefix = COALESCE(dbo.GetOverheadValueNull('POSDietPrefix'),'9000000')
		
		-- Set the POS Diet ID that will be used on the MICROS
		SET @iPOSDietID = @POSDietPrefix + @DietID
		
		-- Set the diet name that will be used on the MICROS and limit it to 16 characters
		SET @AltDescription = LEFT(COALESCE(@AltDescription, @Description),16)
		
		-- Write the Diet Info to the Micros
		EXEC @Return = dbo.Micros_DietUpdate @LoginUserID, @iPOSDietID, @AltDescription
		 
	END	

	-- If no errors, then update the diet in GEMserve
	IF(@Return = 0)
	BEGIN
		--Update the diet in GEMserve
		UPDATE	dbo.tblDietOHD
		SET	Description = @Description,
			AltDescription = @AltDescription,
			POSDietID = @POSDietID,
			POSDescription = @POSDescription,
			Active = @Active,
			NPO=@NPO,
			MenuLevel = @MenuLevel
		WHERE	DietID = @DietID

		IF (@@ROWCOUNT > 0)
		BEGIN
			--If the diet is being inactivated then cancel all related patient diets
			IF (@Active = 0)
				EXEC dbo.DietCancelForInactiveDiet @LoginUserID, @DietID
		END
		ELSE
		BEGIN
			-- No diet exists... insert a new diet
			INSERT INTO dbo.tblDietOHD (DietID, Description, AltDescription, POSDietID, POSDescription, Active, NPO, MenuLevel)
			VALUES (@DietID, @Description, @AltDescription, @POSDietID, @POSDescription, @Active, @NPO, @MenuLevel)
		END
	END
	
	--Return 0 if no errors otherwise return error code from Micros_DietUpdate
	SELECT COALESCE(@Return, 0)
	RETURN
go

