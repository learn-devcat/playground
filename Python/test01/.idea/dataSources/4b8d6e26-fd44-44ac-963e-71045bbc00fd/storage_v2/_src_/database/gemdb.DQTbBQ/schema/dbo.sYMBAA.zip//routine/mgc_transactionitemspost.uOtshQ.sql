CREATE PROCEDURE [dbo].[mgc_TransactionItemsPost]
	@CoreID					int,
	@User					char(10),
	@TransactionId			varchar(400),
	@TransactionItems		varchar(max)

	AS
	/*This stored procedure posts the receipt from the Sim to the mgcTransactionsItems table
	  The format of the TransactionItems should be:
		 Qty|Description|Amount|POSId|ItemType^
		 i.e.(2|Hazelnut Latte|8.32|5007412|M^1|Coffee-Black|1.57|5000520|M^)
	  Each field in the TransactionItems string should be separated by a pipe '|'
	  Each record in the TransactionsItems string should be separated by a carat '^'
	  The TransactionId MUST exist in the tblDetail table
	*/
 
		DECLARE @FieldDelimiter			char(1),
				@RecordDelimiter		char(1),
				@TotalTransacations		int,
				@CurrentTransacation	varchar(max),
				@Qty					int,
				@Description			varchar(100),
				@Amount					decimal(10,2),
				@POSId					varchar(100),
				@ItemType				varchar(10),
				@Sequence				int,
				@Msg					varchar(255)

			SET @FieldDelimiter = '|'
			SET	@RecordDelimiter = '^'

			DECLARE @TempTransactionIds AS TABLE(
				TransactionId	varchar(38),
				Id				int
			)

			--Separate Transaction Ids into separate rows
			INSERT INTO @TempTransactionIds 
			SELECT * FROM dbo.GetTableFromDelimitedString(@TransactionId, @FieldDelimiter)

			--Get the first transactionId as the parent transaction
			SELECT	@TransactionId = dbo.IsGuid(TransactionId)
			FROM	@TempTransactionIds
			WHERE	Id = 1	

			IF (EXISTS (SELECT 1 FROM dbo.tblDetail WHERE DetailID = @TransactionId) OR 
				EXISTS (SELECT 1 FROM dbo.tblDetail_NonGempay WHERE DetailID = @TransactionId))		
			BEGIN
				DECLARE @TempTransactionItems AS TABLE(
					TransactionItem	varchar(max),
					Id	int
				)

				--Separate TransactionsItems into separate rows
				INSERT INTO @TempTransactionItems
				SELECT * FROM dbo.GetTableFromDelimitedString(@TransactionItems, @RecordDelimiter)

				--Split TransactionItems into columns and insert them into table
				;WITH Receipt AS 
				( 
					SELECT	@TransactionId AS [TransactionId], 
							NULL AS [ParentTransactionId], 
							NULLIF(NewXML.value('/M[1]', 'int'),'') AS [Qty],
							NULLIF(NewXML.value('/M[2]', 'varchar(100)'),'') AS [Description],
							CAST(NULLIF(NewXML.value('/M[3]', 'varchar(25)'),'') AS decimal(10,2)) AS [Amount],
							NULLIF(NewXML.value('/M[4]', 'varchar(100)'),'') AS [POSId],
							NULLIF(NewXML.value('/M[5]', 'varchar(10)'),'') AS [ItemType],
							10 * ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Sequence]
					FROM @TempTransactionItems AS t1
					CROSS APPLY (SELECT XMLEncoded=(SELECT TransactionItem AS [*] FROM @TempTransactionItems AS t2 WHERE t1.Id = t2.ID FOR XML PATH (''))) EncodeXML
					CROSS APPLY (SELECT NewXML=CAST('<M>' + REPLACE(XMLEncoded,@FieldDelimiter,'</M><M>')+'</M>' AS XML)) AS CastXML
				)
				INSERT INTO dbo.mgcTransactionItems (TransactionId, ParentTransactionId, Qty, Description, Amount, POSId, ItemType, Sequence)
				SELECT	[TransactionID],
						[ParentTransactionId],
						[Qty],
						[Description],
						[Amount],
						[POSId],
						[ItemType],
						[Sequence]
				FROM Receipt 
				UNION ALL
				SELECT	dbo.IsGuid(TransactionID) AS [TransactionId],
						@TransactionId AS [ParentTransactionId],
						NULL AS [Qty],
						'CHILD TRANSACTION' AS [Description],
						NULL AS [Amount],
						NULL AS [POSId],
						'K' AS [ItemType],
						10000 * ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Sequence]
				FROM @TempTransactionIds
				WHERE Id > 1
		
				--Log the receipt
				SET @Msg = 'Posting Receipt Detail for DetailID: ' + CAST(@TransactionID AS VARCHAR(38))		
				EXEC dbo.sp_Logit 1, @CoreID, @User, @Msg, 2000		
			END
			ELSE
			BEGIN
				SET @Msg = 'Cannot post GEMconnect transaction because the detail transaction does not exist - Transaction ID: [' + COALESCE(CAST(@TransactionID AS varchar(100)),'NULL') + ']'
				EXEC sp_Logit 1, @CoreID, @User, @Msg, 2000
			END

go

