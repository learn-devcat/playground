CREATE PROCEDURE [dbo].[OrderCancel]
@PatientVisitID			varchar(50),
@Source					varchar(50),
@CancelDate				datetime=null
AS

	DECLARE @Msg		varchar(500),
			@PatientID	int,
			@RoomID		int,
			@Today		datetime,
			@CancelMealOnDietCancel int,
			@ProcessType varchar(10)

	SET @ProcessType = 'System' 

	-- Get overhead key to determine if cancelled diets should also cancel future orders
	SELECT @CancelMealOnDietCancel = COALESCE(dbo.GetOverheadValueNull('CancelMealOnDietCancel'),1)
	IF (@CancelMealOnDietCancel = 1)
	BEGIN
		-- Set the cancel date of the diet
		IF (@CancelDate IS NULL) OR (@CancelDate <= getdate())
			SET @Today = getdate()
		ELSE
			SET @Today = @CancelDate

		-- Get the PatientID
		SELECT @PatientID = PatientID,
				@RoomID = RoomID
		FROM	dbo.tblPatientVisit
		WHERE PatientVisitID = @PatientVisitID
		
		-- If this patient does not exist in our system, then log an error
		IF (@PatientID IS NULL)
		BEGIN
		    SET @Msg = 'Unable to cancel orders for Patient Visit ID: [' + @PatientVisitID + '].' + '. Patient ID not found.'
		    GOTO TransError
		END 

		-- Cancel all patient orders for this patient visit that are in the future. Do not cancel guest/parent/stork orders linked to PatientVisit
		-- Insert a log entry into the Order Log for all orders that we are cancelling
		INSERT INTO dbo.tblOrderLOG (OrderID, ActionID, LoginUserID)
			SELECT 	OrderID, 700, @ProcessType
			FROM	dbo.tblOrderOHD AS O (NOLOCK)
				JOIN dbo.tblPatientVisit AS P (NOLOCK) ON (O.PatientVisitID = P.PatientVisitID OR O.PatientVisitID = P.MergedTo)
			WHERE O.OrderDate >= @Today  
					AND ISNULL(O.Cancelled,0) <> 1
				AND COALESCE(O.Received,0) <> 1
				AND O.OrderType = 1
					AND O.PatientVisitID = @PatientVisitID
					
		-- Deletes all nutrient counts for orders that are being canceled.
		DELETE dbo.tblPatientNutrientCount 
		WHERE OrderID IN (SELECT OrderID FROM dbo.tblOrderOHD AS O (NOLOCK)
			JOIN dbo.tblPatientVisit AS P (NOLOCK) ON (O.PatientVisitID = P.PatientVisitID OR O.PatientVisitID = P.MergedTo)
			WHERE O.OrderDate >= @Today 
						AND ISNULL(O.Cancelled,0) <> 1
				AND COALESCE(O.Received,0) <> 1
				AND O.PatientVisitID = @PatientVisitID)

		-- Insert a log entry into the Patient Log for all orders that we are cancelling
		SET @Msg = ' Order cancelled due to Manual Diet Change. Order ID: '
		INSERT INTO dbo.tblPatientLog (EventClassID, LoginUserID, PatientID, PatientVisitID, RoomID, [Description], [Date])
		SELECT 7000, @Source, P.PatientID, P.PatientVisitID, P.RoomID, M.[Description] + @Msg + CAST(O.OrderID AS varchar(30)), getdate()
		FROM dbo.tblOrderOHD AS O (NOLOCK)
				JOIN dbo.tblPatientVisit AS P (NOLOCK) ON O.PatientVisitID = P.PatientVisitID
				JOIN dbo.tblWave AS W (NOLOCK) ON O.WaveID = W.WaveID
				JOIN dbo.tblMealPeriods AS M (NOLOCK) ON W.MealPeriodID = M.MealPeriodID
		WHERE O.OrderDate >= @Today 
		AND ISNULL(O.Cancelled,0) <> 1
		AND COALESCE(O.Received,0) <> 1
		AND O.OrderType = 1
		AND O.PatientVisitID = @PatientVisitID				
					
		-- Set the cancelled flag to 1 for any orders in future waves			
		UPDATE dbo.tblOrderOHD
		SET Cancelled = 1,
				CancelDate = getdate(),
				LastUpdateBy = @Source
		WHERE	PatientVisitID = @PatientVisitID
				AND ISNULL(Cancelled,0) <> 1
				AND COALESCE(Sent,0) <> 1
				AND OrderDate >= @Today
				AND OrderType = 1
	END
	RETURN
	
TransError:

	IF (@Msg IS NULL)    
			SET @Msg = 'Unable to cancel orders for Patient Visit ID: [' + @PatientVisitID + '].'
       
    EXEC dbo.Logit 1, @Msg, 'system'

	RETURN
go

