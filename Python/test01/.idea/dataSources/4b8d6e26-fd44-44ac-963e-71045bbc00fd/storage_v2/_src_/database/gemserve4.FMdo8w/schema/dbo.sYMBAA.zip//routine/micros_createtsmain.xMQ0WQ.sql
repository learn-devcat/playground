CREATE PROCEDURE [dbo].[Micros_CreateTSMain]
@TouchScreen integer

AS
	SET NOCOUNT ON

	DECLARE @Name varchar(16)

	-- Create the touchscreen name
	SET @Name = 'GEM_' + CAST(@TouchScreen AS varchar(12))

 	INSERT INTO MicrosTouchScreenDef(ts_scrn_seq,obj_num, name, ts_layout_seq, pos_type, screen_type)
 	VALUES(@TouchScreen, @TouchScreen, @Name, 10001 , 3, 'P')

	RETURN
go

