CREATE PROCEDURE dbo.HL7_PatientMerge
@MedicalRecordID	varchar(32),
@OldMedicalRecordID	varchar(32),
@Source			varchar(32),
@PatientVisitID		varchar(50)='',
@OldPatientVisitID	varchar(50)=''
AS
	SET NOCOUNT ON
	DECLARE @PatientID	int,
		@RoomID		int,
		@Msg		varchar(100),
		@Msg2		varchar(200),
		@Processed	bit,
		@Today	datetime

	SET @Today = getdate()

	SELECT @PatientID = PatientID
	FROM dbo.tblPatientOHD
	WHERE MedicalRecordID = @OldMedicalRecordID

	IF (@PatientID IS NOT NULL)
	BEGIN
		IF NOT EXISTS (SELECT PatientID FROM dbo.tblPatientOHD WHERE MedicalRecordID = @MedicalRecordID)
		BEGIN
			SET @Msg = 'Unable to process Merge for MedicalRecordID: ' + @MedicalRecordID + '. Patient not found.'
			EXEC dbo.Logit 1, @Msg, 'system'
		END
		ELSE
		BEGIN
			UPDATE dbo.tblPatientOHD
			SET MergedTo = @MedicalRecordID,
				LastUpdateBy = @Source
			WHERE MedicalRecordID = @OldMedicalRecordID

			SET @Msg2 = 'Merged patient information for ' + @OldMedicalRecordID + ' to ' + @MedicalRecordID + '.'
			EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, '', 0, @Msg2
	    		EXEC dbo.ProcessLogInsert @Source

			SET @Processed = 1
		END
	END

	-- Check for PatientVisit merge
	IF (@PatientVisitID <> '') 
	BEGIN
		UPDATE dbo.tblPatientVisit
		SET MergedTo = @PatientVisitID,
			LastUpdateBy = @Source
		WHERE PatientVisitID = @OldPatientVisitID

		SET @Msg2 = 'Merged patient visit information for Patient Visit ' + @OldPatientVisitID + ' to ' + @PatientVisitID + '.'

		------------------------------
		-- BEGIN PATIENT MERGE HISTORY
		------------------------------
		-- Update tblOrderOHD
		INSERT INTO dbo.tblPatientVisitMergeHistory (TableID, PatientVisitID, OldPatientVisitID)
			SELECT 1, @PatientVisitID, PatientVisitID
			FROM dbo.tblOrderOHD
			WHERE PatientVisitID = @OldPatientVisitID

		UPDATE dbo.tblOrderOHD
		SET PatientVisitID = @PatientVisitID
		WHERE PatientVisitID = @OldPatientVisitID

		-- Update tblPatientDiet
		INSERT INTO dbo.tblPatientVisitMergeHistory (TableID, PatientVisitID, OldPatientVisitID)
			SELECT 2, @PatientVisitID, PatientVisitID
			FROM dbo.tblPatientDiet
			WHERE PatientVisitID = @OldPatientVisitID

		UPDATE dbo.tblPatientDiet
		SET PatientVisitID = @PatientVisitID
		WHERE PatientVisitID = @OldPatientVisitID

		-- Update tblPatientLog
		INSERT INTO dbo.tblPatientVisitMergeHistory (TableID, PatientVisitID, OldPatientVisitID)
			SELECT 3, @PatientVisitID, PatientVisitID
			FROM dbo.tblPatientLog
			WHERE PatientVisitID = @OldPatientVisitID

		UPDATE dbo.tblPatientLog
		SET PatientVisitID = @PatientVisitID
		WHERE PatientVisitID = @OldPatientVisitID
		------------------------------
		-- END PATIENT MERGE HISTORY	
		------------------------------			

		SELECT @PatientID = PatientID
		FROM dbo.tblPatientVisit
		WHERE PatientVisitID = @PatientVisitID

		IF (@PatientID IS NULL)
			SELECT @PatientID = PatientID
			FROM dbo.tblPatientVisit
			WHERE PatientVisitID = @OldPatientVisitID



		SELECT @PatientID = PatientID
		FROM dbo.tblPatientVisit
		WHERE PatientVisitID = @PatientVisitID

		EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, '', 0, @Msg2
		EXEC dbo.ProcessLogInsert @Source

		SET @Processed = 1
	END


	IF (COALESCE(@Processed, 0) = 0)
	BEGIN
		SET @Msg = 'Unable to process Merge for MedicalRecordID:' + @OldMedicalRecordID
		EXEC dbo.Logit 1, @Msg, 'system'
	END

	RETURN
go

