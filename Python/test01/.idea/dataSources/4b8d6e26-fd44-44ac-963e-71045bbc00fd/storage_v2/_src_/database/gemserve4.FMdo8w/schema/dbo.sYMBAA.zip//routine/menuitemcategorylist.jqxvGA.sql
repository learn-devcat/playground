
CREATE PROCEDURE dbo.MenuItemCategoryList
@SortByID	int=0

AS
	IF (@SortByID = 1)
		SELECT MenuItemCategoryID,
			[Description]
		FROM	dbo.tblMenuItemCategory
		ORDER BY MenuItemCategoryID
	ELSE
		SELECT MenuItemCategoryID,
			[Description]
		FROM	dbo.tblMenuItemCategory
		ORDER BY [Description]
go

