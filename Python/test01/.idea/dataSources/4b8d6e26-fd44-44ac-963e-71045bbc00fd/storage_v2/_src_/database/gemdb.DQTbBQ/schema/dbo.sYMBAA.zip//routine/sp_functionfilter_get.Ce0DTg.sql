

CREATE PROCEDURE dbo.sp_FunctionFilter_Get
@User		char(10),
@FunctionID	int
AS
	DECLARE	@FilterString		varchar(100),
			@AcctClassString	varchar(150),
			@AccountClassID	int
	DECLARE	FTemp cursor FOR
			SELECT AccountClassID
			FROM	tblAccountFunction
			WHERE RecurFuncID = @FunctionID
	OPEN FTemp
	FETCH NEXT FROM FTemp INTO @AccountClassID
	SET @AcctClassString = ' AND ('
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @AcctClassString = @AcctClassString +  'AccountClassID = ' + CAST(@AccountClassID AS varchar(4)) + ' OR '
		FETCH NEXT FROM FTemp INTO @AccountClassID
	END
	CLOSE FTemp
	DEALLOCATE FTemp
	IF (LEN(@AcctClassString) > 6)
		SET @AcctClassString = SUBSTRING(@AcctClassString, 1, LEN(@AcctClassString) - 3) + ')'
	ELSE
		SET @AcctClassString = ''
	
	--Get the filter string for the function
	SELECT	@FilterString = F.FilterString
	FROM		tblRecurFunctions AS R
			JOIN
			cfgFilterStrings AS F
	ON		R.FilterID = F.FilterID
	WHERE	R.RecurFuncID = @FunctionID
	--Concatenate the filter string AND the accountclass string AND RETURN
	IF (@FilterString = '') AND LEN(@AcctClassString) > 7
		SELECT  ' WHERE ' + SUBSTRING(@AcctClassString, 7, LEN(@AcctClassString) - 7) AS FilterString
	ELSE
		--SELECT TRING(@FilterString, 1, LEN(@FilterString) - 1) + @AcctClassString  AS FilterString
		SELECT @FilterString + @AcctClassString  AS FilterString
go

