

CREATE PROCEDURE dbo.sp_GiftCard_GetData
@User				char(10),
@AccountNo 			char (19),
@AccountClassID		int
AS
	
	SELECT	A.AccountNo,
			A.Title,
			A.FirstName,
			A.MiddleName,
			A.LastName,
			A.Phone,
			A.ActiveDate,
			A.ExpireDate,
			CASE TC.DeclBalMode
				WHEN 1 THEN -T.Balance
				ELSE T.Balance
			END AS Balance
	FROM		tblAccountOHD AS A
			LEFT JOIN tblAccountTTL AS T
	ON		A.AccountNo = T.AccountNo		
			LEFT JOIN
			tblTransClass AS TC
	ON		T.TransClassID = TC.TransClassID
	WHERE	A.AccountNo = @AccountNo AND
			A.AccountClassID = @AccountClassID
	
	DECLARE 	@cMsg  char(255),
			@CoreID	int
	SET @CoreID = dbo.GetCoreIDFromUser(@User)
	SET @cMsg = 'Retrieved information for GiftCard No <' + RTRIM(@AccountNo) + '>'
	EXEC dbo.sp_Logit 4 , @CoreID , @User , @cMsg
go

