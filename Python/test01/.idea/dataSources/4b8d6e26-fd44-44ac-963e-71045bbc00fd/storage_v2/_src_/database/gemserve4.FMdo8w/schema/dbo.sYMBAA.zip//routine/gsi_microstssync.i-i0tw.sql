
CREATE PROCEDURE [dbo].[GSI_MicrosTsSync]
@LoginUserID		varchar(250)

AS
	SET NOCOUNT ON

	DECLARE @SQL nvarchar(4000)
	
	SET @SQL = 'DECLARE @Count 			int,
		@TouchScreen		int,
		@NextScreen		int,
		@POSDietID		int,
		@Name			varchar(16),
		@MaxTouchScreens	int,
		@TemplateID		int

	-- Get number of touchscreens being updated
	SELECT @Name = dbo.GetOverheadValue(''MicrosMaxTouchScreens'')
	IF (@Name = '''')
		SET @MaxTouchScreens = 30
	ELSE
		SET @MaxTouchScreens = CAST(@Name as int)

	-- Get all POS diets that have to be processed
	DECLARE Diets cursor FOR
		SELECT DISTINCT POSDietID FROM dbo.tblDietOHD WHERE ISNULL(NPO,0) = 0 AND DietID > 0 ORDER BY POSDietID

	OPEN Diets
	FETCH NEXT FROM Diets INTO @POSDietID

	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @Count = 1
	
		-- This was originally set to 20 during the initial testing for future expansion	
		WHILE(@Count <= @MaxTouchScreens)
		BEGIN
			-- Set the touchscreen number
			SET @TouchScreen = (@POSDietID * 100) + @Count
			SET @NextScreen = (@POSDietID * 100)

			-- If we have any keys to add to this touchscreen, then process
 			IF EXISTS (SELECT TOP 1 MenuItemID
					FROM 	dbo.tblMenuItem_TouchScreen (NOLOCK)
					WHERE	DietID = @POSDietID
						AND MenuCategoryID = @Count
						AND Active = 1
						AND Modified = 1)
			BEGIN
				-- Deletes previous touchscreen for this diet/category
				EXEC dbo.Micros_TSDelete @TouchScreen

				-- Creates new touchscreen based on template 1000 for this diet/category
				IF(@POSDietID < 500)
					SET @TemplateID = 1000 + CAST(LEFT(CAST(@POSDietID AS varchar(5)),1) AS int)
				ELSE
					SET @TemplateID = 1000
					
				EXEC dbo.Micros_CreateTSFromTemplate @TouchScreen, @TemplateID
		
				-- Adds new menu keys to the new touchscreen
				EXEC dbo.Micros_TSInsertKey @TouchScreen, @NextScreen
			END
		
			SET @Count = @Count + 1
		END

		FETCH NEXT FROM Diets INTO @POSDietID
	END

	CLOSE Diets
	DEALLOCATE Diets'
	
	EXEC sp_executesql @SQL

	RETURN
go

