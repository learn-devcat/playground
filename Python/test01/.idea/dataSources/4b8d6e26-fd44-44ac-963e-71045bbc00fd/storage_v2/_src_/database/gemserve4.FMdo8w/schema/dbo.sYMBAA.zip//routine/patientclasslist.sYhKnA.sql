


CREATE PROCEDURE dbo.PatientClassList

AS
	SELECT 	PatientClassID,
		[Description],
		AutoDischargeInterval,
		Status
	FROM	dbo.tblPatientClass
	ORDER BY PatientClassID
go

