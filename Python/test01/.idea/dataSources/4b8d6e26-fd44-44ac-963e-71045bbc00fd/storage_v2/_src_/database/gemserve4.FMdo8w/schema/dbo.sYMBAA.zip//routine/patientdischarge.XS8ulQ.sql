CREATE PROCEDURE dbo.PatientDischarge
@LoginUserID		varchar(250),
@PatientVisitID	    varchar(50),
@DischargeDate  	datetime

AS
    SET NOCOUNT ON

    BEGIN TRANSACTION
        DECLARE @Msg                varchar(250),
		@PatientID	int,
		@RoomID	int
        
        -- If this patient does not exist in our system, then log an error
        IF NOT EXISTS (SELECT PatientVisitID FROM dbo.tblPatientVisit WHERE PatientVisitID = @PatientVisitID) 
        BEGIN
            SET @Msg = 'Unable to process discharge for PatientVisitID' + @PatientVisitID + '. PatientVisitID does not exist.'
            GOTO TransError
        END
    
        -- Cancel all orders linked to this patient visit
	    UPDATE  dbo.tblOrderOHD
	        SET Cancelled = 1
	    WHERE   PatientVisitID = @PatientVisitID
	    
	    -- Archive Patient
        UPDATE dbo.tblPatientVisit
        SET DischargeDate = @DischargeDate,
            ArchiveDate = @DischargeDate,
			LastUpdateBy = @LoginUserID
        WHERE PatientVisitID = @PatientVisitID
        
	    SET @Msg = 'Discharge processed for PatientVisitID:' + @PatientVisitID
	    EXEC dbo.Logit 1, @Msg, @LoginUserID

	SELECT @PatientID = PatientID,
		@RoomID = RoomID
	FROM dbo.tblPatientVisit
	WHERE PatientVisitID = @PatientVisitID

	-- Delete all diet overrides for this patient if not active visit exists
	DELETE dbo.tblPatientDailyNutrientOverride
	WHERE PatientID = @PatientID
	AND PatientID NOT IN (SELECT PatientID FROM dbo.tblPatientVisit WHERE PatientID = @PatientID AND DischargeDate IS NULL)

	DELETE dbo.tblPatientMealPeriodNutrientOverride
	WHERE PatientID = @PatientID
	AND PatientID NOT IN (SELECT PatientID FROM dbo.tblPatientVisit WHERE PatientID = @PatientID AND DischargeDate IS NULL)
	-- End Delete	

	SET @Msg = 'Discharged patient'

	EXEC dbo.PatientLOGAdd 7000, @LoginUserID, @PatientID, @PatientVisitID, @RoomID, @Msg
	    
	    EXEC dbo.ProcessLogInsert 'system'
    COMMIT TRANSACTION	    
    RETURN
    
TransError:
	ROLLBACK TRANSACTION

	IF ( @Msg IS NULL )    
        SET @Msg = 'Unable to process Discharge for PatientVisitID:' + @PatientVisitID
        
    EXEC dbo.Logit 1, @Msg, 'system'
go

