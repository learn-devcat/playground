


CREATE PROCEDURE dbo.ProcessTypeGet
@ProcessTypeID	int

AS

	SELECT ProcessTypeID,
		[Description],
		Source
	FROM	dbo.cfgProcessTypes (NOLOCK)
	WHERE ProcessTypeID = @ProcessTypeID

	RETURN
go

