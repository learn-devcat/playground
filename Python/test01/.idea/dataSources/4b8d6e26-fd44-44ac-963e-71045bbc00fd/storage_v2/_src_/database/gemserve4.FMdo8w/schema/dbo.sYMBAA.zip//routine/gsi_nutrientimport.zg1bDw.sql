
CREATE PROCEDURE [dbo].[GSI_NutrientImport]
@LoginUserID		varchar(250),
@NutrientID	int,
@Description	varchar(50),
@DefaultQty	int

AS
	SET NOCOUNT ON

	UPDATE 	dbo.cfgNutrients
		SET 	[Description] = @Description,
			DefaultQty = @DefaultQty
	WHERE 	NutrientID = @NutrientID

	IF (@@ROWCOUNT = 0)
		INSERT INTO dbo.cfgNutrients (NutrientID, [Description], DefaultQty)
			VALUES (@NutrientID, @Description, @DefaultQty)	

	RETURN
go

