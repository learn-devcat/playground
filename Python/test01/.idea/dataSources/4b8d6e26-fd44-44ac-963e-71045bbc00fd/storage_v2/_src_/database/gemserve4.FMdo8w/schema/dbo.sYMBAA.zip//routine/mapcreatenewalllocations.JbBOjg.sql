

CREATE PROCEDURE [dbo].[MapCreateNewAllLocations]
@DeleteExisting	bit=0

AS

	DECLARE @TempLocationClassID int,
			@LocationClassID int,
			@ExcludeFromDashboard bit
	
		SELECT @LocationClassID = LocationClassID, 
			@ExcludeFromDashboard = COALESCE(ExcludeFromDashboard,0)
		FROM dbo.tblLocationClass
		WHERE LocationClassID IN (SELECT MIN(LocationClassID) FROM dbo.tblLocationClass)
		ORDER BY LocationClassID

	WHILE (1=1)
	BEGIN
		IF (@ExcludeFromDashboard = 0)
			EXEC dbo.MapCreateNewFromLocation @LocationClassID, '', @DeleteExisting

		SET @TempLocationClassID = NULL
		
		SELECT @TempLocationClassID = LocationClassID, 
			@ExcludeFromDashboard = COALESCE(ExcludeFromDashboard,0)
		FROM dbo.tblLocationClass
		WHERE LocationClassID = (SELECT TOP 1 LocationClassID 
			FROM dbo.tblLocationClass
			WHERE LocationClassID > @LocationClassID
			ORDER BY LocationClassID)
			
		IF (@TempLocationClassID IS NULL)
			BREAK
		ELSE
			SET @LocationClassID = @TempLocationClassID			
	END

	RETURN
go

