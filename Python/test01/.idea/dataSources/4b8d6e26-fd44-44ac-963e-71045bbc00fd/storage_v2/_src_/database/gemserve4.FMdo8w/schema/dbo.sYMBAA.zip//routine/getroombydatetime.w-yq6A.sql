



CREATE  FUNCTION [dbo].[GetRoomByDateTime](@PatientID int, @DateTimeToCheck datetime, @CurrentDate datetime)

RETURNS int

AS
	BEGIN
		DECLARE @Return AS int
		
		-- Get only one record... the latest
		SELECT 	TOP 1 @Return = RoomID
		FROM	dbo.tblPatientVisit
		WHERE	@DateTimeToCheck BETWEEN EntryDate AND ISNULL(DischargeDate, @CurrentDate)
			AND PatientID = @PatientID
			AND RoomID IS NOT NULL
		ORDER BY EntryDate DESC

		RETURN @Return
	END
go

