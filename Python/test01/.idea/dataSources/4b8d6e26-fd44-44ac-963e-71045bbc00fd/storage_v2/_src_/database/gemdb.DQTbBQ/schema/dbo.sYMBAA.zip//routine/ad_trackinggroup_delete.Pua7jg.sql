

CREATE PROCEDURE dbo.ad_TrackingGroup_Delete
@User			char(10),
@TrackingGrp		int
AS
	DELETE	tblTrackingOHD
	WHERE	TrackingGrp = @TrackingGrp
go

