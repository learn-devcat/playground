CREATE PROCEDURE [dbo].[PatientLookup]

		@patientVisitID NVARCHAR(50),

	/*=============================================================================*/
	 -- All @includes parameters are enabled by default
	 -- Set @include parameter to 0 to disable an individual @include
	 -------------------------------------------------------------------------------
		@includeDiet BIT = 1,
		@includePatientNotes BIT = 1,
		@includePatientAllergens BIT = 1,
		@includeOrderInfo BIT = 1,
		@includePatientLog BIT = 1

AS
BEGIN

	/*=============================================================================*/
	 -- TEST PatientVisitID
	 -------------------------------------------------------------------------------
		IF (@PatientVisitID = '')
			GOTO Finish;


	/*=============================================================================*/
	-- SET PatientID
	-------------------------------------------------------------------------------
		DECLARE @PatientID INT;
		
		SELECT @PatientID = PatientID
		FROM dbo.tblPatientVisit
		WHERE PatientVisitID = @PatientVisitID;


	/*=============================================================================*/
	-- GET Paitient Information
	-------------------------------------------------------------------------------
		BEGIN
			SELECT
				pv.PatientVisitID, pv.PatientID, pc.Description [PatientClass],
				p.MedicalRecordID, p.FullName, r.RoomNumber,
				pv.Bed, r2.RoomNumber [PreviousRoom],
				pv.PreviousBed, pv.EntryDate, pv.DischargeDate, p.Notes
 
			FROM dbo.tblPatientVisit pv
				JOIN dbo.tblPatientOHD p ON pv.PatientID = p.PatientID
				LEFT JOIN dbo.tblRoomOHD r ON pv.RoomID = r.RoomID
				JOIN dbo.tblPatientClass pc ON pv.PatientClassID = pc.PatientClassID
				LEFT JOIN dbo.tblRoomOHD r2 ON pv.PreviousRoomID = r2.RoomID
 
			WHERE pv.PatientVisitID = @PatientVisitID
		END;


		IF (@@ROWCOUNT = 0)
			GOTO Finish;


	/*=============================================================================*/
	-- GET Diet Information
	-------------------------------------------------------------------------------
		IF (@IncludeDiet = 1)
			BEGIN
				SELECT
					d.DietID, d.Description, pd.ID, pd.PatientVisitID,
					pd.DietID, pd.ActiveDate, pd.PostDate, pd.Source, pd.Notes, 
					pd.Cancelled, pd.CancelDate, pd.TransactionIdentifier,
					pd.UpdateDate, pd.UpdateID, pd.MenuLevel

				FROM dbo.tblPatientDiet pd
					JOIN dbo.tblDietOHD d ON pd.DietID = d.DietID

				WHERE pd.PatientVisitID = @PatientVisitID
					ORDER BY pd.ActiveDate DESC, pd.PostDate DESC
			END;


	/*=============================================================================*/
	-- GET Patient Notes
	-------------------------------------------------------------------------------
		IF (@IncludePatientNotes = 1)
			BEGIN
				SELECT
					NoteID, PatientVisitID, NoteType, ActiveDate, 
					PostDate, Source, Notes, Cancelled, CancelDate, 
					TransactionIdentifier, UpdateDate, UpdateID 
	
				FROM dbo.tblPatientNotes

				WHERE PatientVisitID = @PatientVisitID
					ORDER BY ActiveDate DESC, PostDate DESC
			END;


	/*=============================================================================*/
	-- GET Patient Allergens
	-------------------------------------------------------------------------------
		IF (@IncludePatientAllergens = 1)
			BEGIN
				SELECT 
					pa.AllergenID, a.Description [Allergy]
  
				FROM dbo.tblPatientAllergens pa
					JOIN dbo.cfgAllergens a ON pa.AllergenID = a.AllergenID
  
				WHERE pa.PatientID = @PatientID
			END;


	/*=============================================================================*/
	-- GET Patient Order Information
	-------------------------------------------------------------------------------
		IF (@IncludeOrderInfo = 1)
			BEGIN
				SELECT 
					OrderID, LocationID, WorkstationID, OutletNo,
					WaveID, RoomID, MainLevel, SubLevel, OrderEmployee,
					OrderEmployeeName, DeliveryEmployee, OrderDate, PostDate,
					SentDate, PatientID, PatientVisitID, Sent, Received,
					Prepared, InRoute, Delivered, Complete, SentTime,
					Subtotal, DeliveryCharge, Tip, CheckNo, TransTotal,
					Cancelled, CancelDate, Retries, StandingOrder, NonSelectOrder,
					ArchiveDate, EnteredBy, EnteredDate, LastUpdateBy,
					LastUpdateDate, Rush, OrderType, OrderedFor, SentToKitchenId,
					DietId, TransactionIdentifier
	
				FROM dbo.tblOrderOHD

				WHERE PatientVisitID = @PatientVisitID
					ORDER BY OrderID DESC
			END;


	/*=============================================================================*/
	-- GET Patient Logs
	-------------------------------------------------------------------------------
		IF (@IncludePatientLog = 1)
			BEGIN
				SELECT
					ID, PatientID, PatientVisitID,
					RoomID, Date, LoginUserID,
					EventClassID, Description
		
				FROM dbo.tblPatientLog
		
				WHERE PatientID = @PatientID
					ORDER BY Date DESC
			END;


	/*=============================================================================*/
	 Finish:

END
go

