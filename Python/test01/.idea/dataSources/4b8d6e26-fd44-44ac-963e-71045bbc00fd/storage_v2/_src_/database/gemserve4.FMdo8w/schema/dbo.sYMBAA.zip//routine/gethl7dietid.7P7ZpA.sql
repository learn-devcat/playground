
CREATE FUNCTION [dbo].[GetHL7DietID](@DietName varchar(4000), @Modifiers varchar(4000))
RETURNS int
AS
BEGIN
	DECLARE @DietPriority	varchar(10),
		@ORMSeparator	varchar(10),
		@Return		int,
		@TempLen	int

	SELECT @DietPriority = COALESCE(dbo.GetOverheadValueNull('DietPriority'),'0')
	SELECT @ORMSeparator = COALESCE(dbo.GetOverheadValueNull('ORMSeparator'),'|')

	IF (@DietPriority = '1')
	BEGIN
		-- Use Diet Priority with @DietName variable
		SET @DietName = dbo.PrioritizeDietList(@DietName)

		-- Strip off end diet names until a combination matches an xlat entry
		IF (CHARINDEX(@ORMSeparator, @DietName) = 0)
		BEGIN
			-- Resolve the Diet ID
			SELECT @Return = KeyOut
			FROM    dbo.tblXLAT (NOLOCK)
			WHERE   KeyIn = @DietName
			        AND xlatID = 'Diet'

			GOTO Finish
		END
		ELSE
		BEGIN
			WHILE (1=1)
			BEGIN
				SELECT @Return = KeyOut
				FROM    dbo.tblXLAT (NOLOCK)
				WHERE   KeyIn = @DietName
				        AND xlatID = 'Diet'
		
				IF (@Return IS NOT NULL)
					BREAK
				
				IF (CHARINDEX(@ORMSeparator,@DietName)) > 0
				BEGIN
					SET @TempLen = LEN(REVERSE(SUBSTRING(REVERSE(@DietName),1,CHARINDEX(@ORMSeparator,REVERSE(@DietName))-1)))
					SET @DietName = LEFT(@DietName,LEN(@DietName) - @TempLen - 1)
				END
				ELSE
				BEGIN
					-- Unable to resolve Diet, so exit the loop
					BREAK
				END
			END
		END			
	END
	ELSE
	BEGIN
		IF (@DietPriority = '2')
		BEGIN
			-- Use Diet Priority with @Modifiers variable
			SET @Modifiers = dbo.PrioritizeDietList(@Modifiers)

			-- Strip off end diet names until a combination matches an xlat entry
			IF (CHARINDEX(@ORMSeparator, @Modifiers) = 0)
			BEGIN
				-- Resolve the Diet ID
				SELECT @Return = KeyOut
				FROM    dbo.tblXLAT (NOLOCK)
				WHERE   KeyIn = @Modifiers
				        AND xlatID = 'Diet'
	
				GOTO Finish
			END
			ELSE
			BEGIN
				WHILE (1=1)
				BEGIN
					SELECT @Return = KeyOut
					FROM    dbo.tblXLAT (NOLOCK)
					WHERE   KeyIn = @Modifiers
					        AND xlatID = 'Diet'
			
					IF (@Return IS NOT NULL)
						BREAK
					
					IF (CHARINDEX(@ORMSeparator,@Modifiers)) > 0
					BEGIN
						SET @TempLen = LEN(REVERSE(SUBSTRING(REVERSE(@Modifiers),1,CHARINDEX(@ORMSeparator,REVERSE(@Modifiers))-1)))
						SET @Modifiers = LEFT(@Modifiers,LEN(@Modifiers) - @TempLen - 1)
					END
					ELSE
					BEGIN
						-- Unable to resolve Diet, so exit the loop
						BREAK
					END
				END
			END			
		END
		ELSE
		BEGIN
			-- Strip off end diet names until a combination matches an xlat entry
			IF (CHARINDEX(@ORMSeparator, @DietName) = 0)
			BEGIN
				-- Resolve the Diet ID
				SELECT @Return = KeyOut
				FROM    dbo.tblXLAT (NOLOCK)
				WHERE   KeyIn = @DietName
				        AND xlatID = 'Diet'
	
				GOTO Finish
			END
			ELSE
			BEGIN
				WHILE (1=1)
				BEGIN
					SELECT @Return = KeyOut
					FROM    dbo.tblXLAT (NOLOCK)
					WHERE   KeyIn = @DietName
					        AND xlatID = 'Diet'
			
					IF (@Return IS NOT NULL)
						BREAK
					
					IF (CHARINDEX(@ORMSeparator,@DietName)) > 0
					BEGIN
						SET @TempLen = LEN(REVERSE(SUBSTRING(REVERSE(@DietName),1,CHARINDEX(@ORMSeparator,REVERSE(@DietName))-1)))
						SET @DietName = LEFT(@DietName,LEN(@DietName) - @TempLen - 1)
					END
					ELSE
					BEGIN
						-- Unable to resolve Diet, so exit the loop
						BREAK
					END
				END
			END			
		END
	END

Finish:

	RETURN @Return
END
go

