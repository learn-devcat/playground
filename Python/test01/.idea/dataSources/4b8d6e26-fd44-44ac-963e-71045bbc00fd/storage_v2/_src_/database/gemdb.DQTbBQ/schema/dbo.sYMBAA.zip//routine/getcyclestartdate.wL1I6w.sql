

CREATE FUNCTION dbo.GetCycleStartDate(@CycleNo int)
RETURNS datetime
AS
BEGIN
	DECLARE 	@WhatDate 	datetime,
			@AfterMidnight	bit
	
	SELECT 	@WhatDate=dbo.dDateOnly(dbo.MidnightAdjustDate(XoverDate,AfterMidnight))
	FROM 		tblCycleLog 
	WHERE 	CycleNo=@CycleNo
	RETURN 	ISNULL(@WhatDate,CAST('01/01/1980' AS datetime))
END
go

