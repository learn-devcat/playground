CREATE FUNCTION [dbo].[GetMenuItemsFromStatus](@OrderID int)
RETURNS @POSMenuItems TABLE (POSMenuItemID varchar(50))
AS
BEGIN
/* How should I handle Patient Merges? */

	DECLARE @Notes varchar(max),
			@PatientVisitID varchar(50),
			@PatientID	int,
			@DietID int,
			@LocationClassID int,
			@OrderDate	datetime,
			@WaveID	int, 
			@OrderType int

	-- Set the variables from the patient order
	SELECT	@PatientID = O.PatientID,
			@PatientVisitID = O.PatientVisitID,
			@OrderDate = O.OrderDate,
			@WaveID = O.WaveID,
			@DietID = O.DietID,
			@LocationClassID = L.LocationClassID,
			@OrderType = O.OrderType
	FROM	dbo.tblOrderOHD AS O
	JOIN	dbo.tblPatientVisit AS PV ON O.PatientVisitId = PV.PatientVisitId
	JOIN	dbo.tblRoomOHD AS R ON PV.RoomID = R.RoomID
	JOIN	dbo.tblLocationClass AS L ON R.LocationClassID = L.LocationClassID
	WHERE	OrderID = @OrderID;

	-- Get menu items linked to tblPatientStatus
	IF (@OrderType = 1)
	BEGIN
		IF EXISTS (SELECT 1 FROM dbo.tblPatientStatusFlags WHERE PatientID = @PatientID)
			INSERT INTO @POSMenuItems
			SELECT KeyOut
			FROM dbo.tblXLAT
			WHERE xlatID = 'StatusPOSMenuItem'
				AND KeyIn IN (SELECT CAST(StatusFlagID AS varchar(10)) FROM dbo.tblPatientStatusFlags WHERE PatientID = @PatientID)
			ORDER BY RIGHT('0000' + [Description],4)

		-- Get menu items linked to tblDietMenuItems for the Patient's Diet
		INSERT INTO @POSMenuItems
		SELECT POSMenuItemID
		FROM dbo.tblDietMenuItems
		WHERE DietID = @DietID
			AND POSMenuItemID NOT IN (SELECT POSMenuItemID FROM @POSMenuItems)
	END

	-- Get menu items linked to tblLocationMenuItems for the Patient's Location regardless of order type
	INSERT INTO @POSMenuItems
	SELECT POSMenuItemID
	FROM dbo.tblLocationMenuItems
	WHERE LocationClassID = @LocationClassID
		AND POSMenuItemID NOT IN (SELECT POSMenuItemID FROM @POSMenuItems)

	RETURN
END
go

