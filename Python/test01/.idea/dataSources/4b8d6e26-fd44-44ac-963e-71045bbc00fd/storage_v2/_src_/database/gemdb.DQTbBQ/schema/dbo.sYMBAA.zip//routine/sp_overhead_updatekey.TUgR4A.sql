

CREATE PROCEDURE dbo.sp_Overhead_UpdateKey
@User		char(10),
@oKey		varchar(32),
@sValue	varchar(255)
AS
	UPDATE 	cfgOverhead
	SET		sValue = @sValue
	WHERE	oKey = @oKey
go

