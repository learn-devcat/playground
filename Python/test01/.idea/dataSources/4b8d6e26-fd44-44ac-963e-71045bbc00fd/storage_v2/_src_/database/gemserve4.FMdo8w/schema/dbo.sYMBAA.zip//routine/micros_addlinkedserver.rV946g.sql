CREATE PROCEDURE [dbo].[Micros_AddLinkedServer]
@ServerName	varchar(100) = 'Micros',
@DSN varchar(100) = 'micros',
@MicrosDBUserName varchar(100) = 'dba',
@MicrosDBPassword varchar(100) = '$upp0rt2'
AS
	DECLARE @SQL nvarchar(1000),
			@TotalSynonyms	 int,
			@CurrentRow	int,
			@SynonymName varchar(50),
			@MicrosTable varchar(50)

	--Set Overhead Key for Linked Micros Server Name
	IF EXISTS(SELECT 1 FROM dbo.cfgOverhead WHERE KeyID = 'MicrosServerName')
		UPDATE dbo.cfgOverhead
		SET Value = @ServerName
		WHERE KeyID = 'MicrosServerName'
	ELSE
		INSERT INTO dbo.cfgOverhead
		VALUES('MicrosServerName', @ServerName, '6500', 'Name of Linked Micros Server')
		
	--Create the Linked Server
	IF NOT EXISTS (SELECT 1 FROM sys.servers WHERE [name] = @ServerName)
	BEGIN
		EXEC [master].[dbo].[sp_addlinkedserver] @ServerName, ' ', 'MSDASQL', @DSN
		EXEC [master].[dbo].[sp_addlinkedsrvlogin] @ServerName, 'false', 'gemuser', @MicrosDBUserName, @MicrosDBPassword
	END
	
	DECLARE @TempSynonyms AS TABLE 
	(
			[ID] INT IDENTITY(1,1),
			[SynonymName]			varchar(50),
			[MicrosTable]			varchar(50)
	)

	INSERT INTO @TempSynonyms (SynonymName, MicrosTable)
	SELECT 'MicrosMenuItems', 'micros.mi_def'
	UNION ALL
	SELECT 'MicrosMenuItemType', 'micros.mi_type_class_def'
	UNION ALL
	SELECT 'MicrosMenuLevel', 'micros.mlvl_class_def'
	UNION ALL
	SELECT 'MicrosPrinterClass', 'micros.prn_class_def'
	UNION ALL
	SELECT 'MicrosTouchScreenDef', 'micros.ts_scrn_def'
	UNION ALL
	SELECT 'MicrosTouchScreenKeyDef', 'micros.ts_key_def'
	UNION ALL
	SELECT 'MicrosMajorGroupDef', 'micros.maj_grp_def'
	UNION ALL
	SELECT 'MicrosMenuItemGroupDef', 'micros.mi_grp_def'
	UNION ALL
	SELECT 'MicrosFamilyGroupDef', 'micros.fam_grp_def'
	UNION ALL
	SELECT 'MicrosCheckDetail', 'micros.chk_dtl'
	UNION ALL
	SELECT 'MicrosTransactionDetail', 'micros.trans_dtl'
	UNION ALL
	SELECT 'MicrosKdsDetail', 'micros.kds_dtl'
	UNION ALL
	SELECT 'MicrosOrderDeviceDef', 'micros.order_device_def'
	UNION ALL
	SELECT 'MicrosRevenueCenterDef', 'micros.rvc_def'

	SET @TotalSynonyms = @@ROWCOUNT
	
	-- Set up loop
	SET @CurrentRow = 1
	
	WHILE (@CurrentRow <= @TotalSynonyms)
	BEGIN
		
		SELECT	@SynonymName = SynonymName,
				@MicrosTable = MicrosTable
		FROM	@TempSynonyms
		WHERE	[ID] = @CurrentRow
		
		IF NOT EXISTS (SELECT 1 FROM sys.synonyms WHERE name = @SynonymName)
		BEGIN
			SET @SQL = 'CREATE SYNONYM ' + @SynonymName + ' FOR [' + @ServerName + ']..' + @MicrosTable
			EXEC(@SQL)
		END
		SET @CurrentRow = @CurrentRow + 1
	END	
	
	RETURN
go

