
CREATE          PROCEDURE dbo.WorkorderDTLDef_List
@User			char(10), 
@LocationID     int,
@ShowAll	bit
AS
IF (@ShowAll = 1)
	BEGIN
		SELECT	DEF.WorkOrderDTLDefID,
			DEF.LocationID,
			DEF.WorkOrderDTLClassID,
			DEF.EmployeeClassID,
			DEF.ShortDescription,
			DEF.Description,
			DEF.SkillLevel,
			DEF.Price,
			DEF.Cost,
			DEF.EstimatedHours,
			DEF.LeadTime,
			DEF.TransID,
			DEF.LaborCenterID,
			L.Description as 'LaborCenterName'
	    	FROM   	tblWorkOrderDTLDef as DEF
				LEFT JOIN
			tblLaborCenter as L ON L.LaborCenterID = DEF.LaborCenterID AND DEF.LocationID = L.LocationID
	    	Order BY  DEF.LaborCenterID, WorkOrderDTLClassID, WorkOrderDTLDefID, EmployeeClassID, SkillLevel
	END
ELSE
	BEGIN
		SELECT	DEF.WorkOrderDTLDefID,
			DEF.LocationID,
			DEF.WorkOrderDTLClassID,
			DEF.EmployeeClassID,
			DEF.ShortDescription,
			DEF.Description,
			DEF.SkillLevel,
			DEF.Price,
			DEF.Cost,
			DEF.EstimatedHours,
			DEF.LeadTime,
			DEF.TransID,
			DEF.LaborCenterID,
			L.Description as 'LaborCenterName'	
	    	FROM   	tblWorkOrderDTLDef as DEF
				LEFT JOIN
			tblLaborCenter as L ON L.LaborCenterID = DEF.LaborCenterID AND DEF.LocationID = L.LocationID
	    	WHERE   DEF.LocationID IN (SELECT LocationID FROM cfgUserLocations WHERE UserID = @User) or
	            	DEF.LocationID = 0
	    	Order BY  DEF.LaborCenterID, WorkOrderDTLClassID, WorkOrderDTLDefID, EmployeeClassID, SkillLevel	
	END
    RETURN
go

