

Create PROCEDURE dbo.gem_OutletExclusions
@OutletNo int
AS
	DECLARE @TotalTransClass int,
		@Count int,
		@AccountClassID int,
		@TransClassID int,
		@AllTransClass varchar(100),
		@TempTransClass varchar(100),
		@SQL	nvarchar(100)
	
	-- Create a temporary table to hold AccountClasses AND TransClasses
	CREATE TABLE #Temp (AccountClassID int, TransClassList varchar(100))
	
	INSERT INTO #Temp (AccountClassID)
	 	SELECT AccountClassID
	 	FROM tblAccountClass
	 
	-- Add the correct number of columns to the temporary table for all the TransClasses
	SELECT @TotalTransClass = COUNT(TransClassID) FROM tblTransClass
	SET @Count = 0
	
	WHILE @TotalTransClass > 0
	BEGIN
		SET @SQL = 'ALTER TABLE #Temp ADD TransClass' + CAST(@Count AS varchar(2)) + ' varchar(32)'
		EXEC sp_executesql @SQL
	
		SET @TotalTransClass = @TotalTransClass - 1
		SET @Count = @Count + 1
	END
	
	-- Initialize counters
	SET @Count = 0
	SET @AllTransClass = ''
	
	-- Get a listing of all the Transclasses
	DECLARE TransClass cursor FOR
		SELECT TransClassID FROM tblTransClass 
		ORDER BY TransClassID
	 
	OPEN TransClass
	 
	FETCH NEXT FROM TransClass INTO @TransClassID
	 
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @AllTransClass = @AllTransClass + CAST(@TransClassID AS varchar(5)) + ','
	
	 	FETCH NEXT FROM TransClass INTO @TransClassID
	END
	
	CLOSE TransClass
	DEALLOCATE TransClass
	
	-- Loop through the temporary table AND UPDATE the TransClass VALUES
	DECLARE AccountClass cursor FOR
		SELECT AccountClassID FROM #Temp
			ORDER BY AccountClassID
	
	OPEN AccountClass
	
	FETCH NEXT FROM AccountClass INTO @AccountClassID
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
	
		SET @TempTransClass = @AllTransClass
		SET @Count = 0
	
		WHILE @TempTransClass <> ''
		BEGIN
			SET @TransClassID = CAST(LEFT(@TempTransClass,CHARINDEX(',',@TempTransClass)-1) AS int)
	
			-- IF the combination exists in our exclusion table, then SET to 1. Otherwise, SET to 0.
			IF EXISTS (SELECT OutletNo FROM tblExclusions
					WHERE OutletNo = @OutletNo AND
						AccountClassID = @AccountClassID AND
						TransClassID = @TransClassID)
	
				SET @SQL = 'UPDATE #Temp SET TransClass' + CAST(@Count AS varchar(2)) + 
					' = 1 WHERE AccountClassID=' + CAST(@AccountClassID AS varchar(10))
			ELSE
				SET @SQL = 'UPDATE #Temp SET TransClass' + CAST(@Count AS varchar(2)) + 
					' = 0 WHERE AccountClassID=' + CAST(@AccountClassID AS varchar(10))
	
			EXEC sp_executesql @SQL
	
			SET @Count = @Count + 1
			SET @TempTransClass = RIGHT(@TempTransClass,LEN(@TempTransClass) - CHARINDEX(',',@TempTransClass))
		END
	
		FETCH NEXT FROM AccountClass INTO @AccountClassID
	END
	
	CLOSE AccountClass
	DEALLOCATE AccountClass
	
	UPDATE #Temp SET TransClassList = LEFT(@AllTransClass,LEN(@AllTransClass)-1)
	SELECT * FROM #Temp
	
	DROP TABLE #Temp
go

