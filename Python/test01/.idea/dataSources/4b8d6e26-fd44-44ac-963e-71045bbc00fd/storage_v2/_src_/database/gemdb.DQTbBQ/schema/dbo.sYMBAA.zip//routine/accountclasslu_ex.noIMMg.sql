CREATE FUNCTION [dbo].[AccountClassLU_EX] (@TempClass varchar(32))
RETURNS int
AS 
BEGIN 
	DECLARE @TempID int
	-- Looks up the Account Class using the Xref field.
	-- If no match is found, see if it is a legit account class id, then return it,
	-- else return NULL
	SELECT @TempID = AccountClassID FROM tblAccountClass WHERE Xref=@TempClass
	IF(@TempID IS NULL)
	BEGIN
		IF(ISNUMERIC(@TempClass) > 0)
			SELECT @TempID = AccountClassID FROM tblAccountClass WHERE AccountClassID = CAST(@TempClass AS int)
	END
		
	RETURN @TempID
END
go

