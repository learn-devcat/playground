


CREATE PROCEDURE dbo.WaveListForDiet
@DietID		int
AS
	SET NOCOUNT ON
	
	SELECT DW.WaveID, W.[Description] FROM dbo.tblDietWave AS DW (NOLOCK)
		JOIN dbo.tblWave AS W ON DW.WaveID = W.WaveID
	WHERE DW.DietID = @DietID
	ORDER BY W.BeginTime
go

