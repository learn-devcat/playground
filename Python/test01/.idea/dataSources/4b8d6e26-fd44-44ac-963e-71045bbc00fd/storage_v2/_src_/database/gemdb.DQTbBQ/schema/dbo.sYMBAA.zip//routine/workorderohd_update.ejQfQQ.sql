
CREATE               PROCEDURE dbo.WorkorderOHD_Update
@User			    char(10),
@LocationID	        int,	
@WorkOrderID	    	int,
@WorkOrderNumber	varchar(25),
@WorkorderClassID	int,
@ShortDescription	varchar(50),
@PO	                varchar(25),
@Description	    varchar(250),
@OpenDate	        datetime,	
@OpeningEmployeeID	int,	
@ClosingDate        datetime,	
@ClosingEmployeeID  int,
@Closed             bit,
@CompletionDate     datetime ,
@CompletingEmployeeID   int	 = 0,
@Completed          bit	= 0,
@Inspected          bit	 = 0,
@InspectingEmployeeID   int = 0,
@EstimatedHours     money = 0,
@ActualHours        money = 0,
@AccountNo          char(19) = '',
@TransID            int	 = 0,
@TotalCharge        money = 0,
@AdjustTotalAmt		money = 0,
@TotalChargePosted	bit = 0,
@AltCharge		money = 0,
@AltTransID		int = 0,
@AdjustmentReason	VarChar(250) = '',
@LaborCenterID		int
AS
SET NOCOUNT ON
DECLARE @ErrorNum	int
	UPDATE	tblWorkorderOHD
	SET   
	    
        WorkOrderNumber       = @WorkOrderNumber,	
        LocationID	          = @LocationID	,        
        WorkorderClassID	  = @WorkorderClassID,	
        ShortDescription	  = @ShortDescription,	
        PO	                  = @PO,	               
        Description           = @Description,	  
        OpenDate	          = @OpenDate,	        	
        OpeningEmployeeID	  = @OpeningEmployeeID	,
        ClosingDate           = @ClosingDate ,       	
        ClosingEmployeeID     = @ClosingEmployeeID , 
        Closed                = @Closed ,            
        CompletionDate        = @CompletionDate ,   
        CompletingEmployeeID  = @CompletingEmployeeID,
        Completed             = @Completed ,         
        Inspected             = @Inspected ,         
        InspectingEmployeeID  = @InspectingEmployeeID,
        EstimatedHours        = Round(@EstimatedHours, 2),   
        ActualHours           = Round(@ActualHours,2),
        AccountNo             = @AccountNo,         
        TransID               = @TransID,       
        TotalCharge           = @TotalCharge,  
	AdjustTotalAmt		= @AdjustTotalAmt,
	TotalChargePosted	= @TotalChargePosted,
	AltCharge		= @AltCharge,
	AltTransID		= @AltTransID,
	AdjustmentReason	= @AdjustmentReason,
	LaborCenterID		= @LaborCenterID
    WHERE WorkOrderID = @WorkOrderID 
    IF @@Error <> 0 
      BEGIN
	SET @ErrorNum = @@Error
	SELECT @ErrorNum
        -- TODO: Log the error here AND exit.
        RETURN
      END
    SET @ErrorNum = @@Error
    SELECT @ErrorNum
    RETURN
go

