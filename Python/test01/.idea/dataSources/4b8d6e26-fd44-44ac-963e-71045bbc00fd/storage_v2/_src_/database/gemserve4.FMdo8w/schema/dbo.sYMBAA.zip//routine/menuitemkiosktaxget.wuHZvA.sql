

CREATE PROCEDURE dbo.MenuItemKioskTaxGet
@MenuItemKioskID	int
AS
	SET NOCOUNT ON

	SELECT	MenuItemKioskTaxID,
		MenuItemKioskID,
		TaxLevel,
		Taxable
	FROM	dbo.tblMenuItemKioskTax
	WHERE	MenuItemKioskID = @MenuItemKioskID
	ORDER BY TaxLevel

	RETURN
go

