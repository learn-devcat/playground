CREATE PROCEDURE [dbo].[HL7_PatientAdmit]
@MedicalRecordID	varchar(30),
@PatientVisitID     varchar(50),
@LastName		    varchar(30),
@FirstName		    varchar(30),
@MiddleInitial		varchar(30),
@RoomNumber		    varchar(50),
@EntryDate		    varchar(25),
@Source             varchar(50),

@Bed			    varchar(20)='',
@BirthDate		    varchar(25)=null,
@Gender			    varchar(10)=null,

@PatientClass		varchar(32)='',
@Location		    varchar(50)='',
@DischargeDate		varchar(50)=''

AS
	DECLARE @PatientClassID	int	

	DECLARE @Msg varchar(250),
	        @RoomID	int,
		    @CurrentRoomID int,
		    @CurrentBed varchar(20),
	        @PatientID int,
		    @Temp varchar(100),
		    @MergedTo varchar(32),
		@Today datetime

	SET @Today = getdate()
	
	IF(LTRIM(@MedicalRecordID) = '')
	BEGIN
		SET @Msg = 'Unable to process Admit. Blank MedicalRecordID for ' + @Source
	  	EXEC dbo.Logit 1, @Msg, 'system'
		RETURN
	END
	
	IF(LTRIM(@PatientVisitID) = '')
	BEGIN
		SET @Msg = 'Unable to process Admit. Blank PatientVisitID for ' + @Source
	  	EXEC dbo.Logit 1, @Msg, 'system'
		RETURN
	END

	-- Skip updates for patients already discharged
	SET @DischargeDate = REPLACE(@DischargeDate,'"','')
	IF(@DischargeDate <> '@DischargeDate' AND @DischargeDate <> '')
	BEGIN
		SET @Msg = 'Update record ignored for discharged patient.  -  ' + @Source
	  	EXEC dbo.Logit 1, @Msg, 'system'
		RETURN
	END

	IF(@Bed = '')
		SET @Bed = NULL

	SELECT  @CurrentRoomID = RoomID,
		    @CurrentBed = Bed
	FROM	dbo.tblPatientVisit
	WHERE	PatientVisitID = @PatientVisitID

	IF (@RoomNumber = '')
		SET @RoomNumber = @Location

	SELECT @RoomID = dbo.RoomID(@RoomNumber, @Bed)

	SET @EntryDate = dbo.HL7ConvertDateTime(@EntryDate, getdate())

	SELECT @PatientClassID = dbo.PatientClassLookup(@PatientClass)

	IF EXISTS (SELECT PatientVisitID FROM dbo.tblPatientVisit (NOLOCK) WHERE PatientVisitID = @PatientVisitID)
	BEGIN
		-- Update the existing patient
		SELECT  @PatientID = PatientID
		FROM dbo.tblPatientVisit (NOLOCK)
		WHERE PatientVisitID = @PatientVisitID

		IF(@PatientID IS NULL)
			RETURN

		SELECT @MergedTo = MergedTo FROM dbo.tblPatientOHD WHERE MedicalRecordID = @MedicalRecordID

       		 -- Update the master patient record
		UPDATE dbo.tblPatientOHD
		SET LastName = @LastName,
			FirstName = @FirstName,
			MiddleInitial = @MiddleInitial,
			BirthDate = @BirthDate,
			Gender = @Gender,
			PatientClassID = @PatientClassID,
			MergedTo = CASE 
				WHEN @Source = 'ADT-A08' THEN NULL
				ELSE MergedTo
				END,
			LastUpdateBy = @Source
		FROM	dbo.tblPatientOHD
		WHERE MedicalRecordID = @MedicalRecordID
		
        		-- Update the Patient Visit record
		UPDATE dbo.tblPatientVisit
		SET 	DischargeDate = NULL,
			RoomID = COALESCE(@RoomID, @CurrentRoomID),
			PatientClassID = @PatientClassID,
			Bed = COALESCE(@Bed,Bed),
			LastUpdateBy = @Source
		FROM	dbo.tblPatientVisit
		WHERE PatientVisitID = @PatientVisitID

		IF(@CurrentRoomID <> COALESCE(@RoomID, @CurrentRoomID))
		BEGIN
			UPDATE dbo.tblPatientVisit
			SET PreviousRoomID = @CurrentRoomID,
				LastUpdateBy = @Source
			WHERE PatientVisitID = @PatientVisitID

			IF(@Bed IS NOT NULL)
				UPDATE dbo.tblPatientVisit
				SET PreviousBed = @CurrentBed,
					LastUpdateBy = @Source
				WHERE PatientVisitID = @PatientVisitID

			EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, @PatientVisitID, @RoomID, 'Updated patient location.'
		END

		IF (@MergedTo IS NOT NULL)
			EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, @PatientVisitID, @RoomID, 'Unmerged patient.'

		EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, @PatientVisitID, @RoomID, 'Updated patient information.'
		EXEC dbo.ProcessLogInsert @Source
	END
	ELSE
	BEGIN
		IF (@EntryDate = '')
			SET @EntryDate = getdate()		
			
        IF EXISTS (SELECT PatientID FROM dbo.tblPatientOHD WHERE MedicalRecordID = @MedicalRecordID)		
	BEGIN	
            -- Update the master patient record
		    UPDATE dbo.tblPatientOHD
		    SET LastName = @LastName,
			    FirstName = @FirstName,
			    MiddleInitial = @MiddleInitial,
			    BirthDate = @BirthDate,
			    Gender = @Gender,
			    PatientClassID = @PatientClassID,
			    MergedTo = CASE 
				    WHEN @Source = 'ADT-A08' THEN NULL
				    ELSE MergedTo
				    END,
			    LastUpdateBy = @Source
		    FROM	dbo.tblPatientOHD
		    WHERE MedicalRecordID = @MedicalRecordID	

		SELECT @PatientID = PatientID FROM dbo.tblPatientOHD WHERE MedicalRecordID = @MedicalRecordID		
	END
        ELSE			
        BEGIN
		    INSERT INTO dbo.tblPatientOHD (Active, MedicalRecordID, LastName, FirstName, 
			    MiddleInitial, BirthDate, Gender, EnteredBy, PatientClassID, LastUpdateBy)
		    VALUES (1, @MedicalRecordID, @LastName, @FirstName, 
			    @MiddleInitial, @BirthDate, @Gender, @Source, @PatientClassID, @Source)
			
		    SELECT @PatientID = SCOPE_IDENTITY()
		END
		
		-- Add patient visit record
		INSERT INTO dbo.tblPatientVisit (PatientVisitID, PatientID, PatientClassID, RoomID, Bed, 
				EntryDate, NonSelect, EnteredBy, LastUpdateBy)
		VALUES (@PatientVisitID, @PatientID, @PatientClassID, @RoomID, @Bed, getdate(), 0, @Source, @Source)

    	EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, @PatientVisitID, @RoomID, 'Admitted patient.'
		EXEC dbo.ProcessLogInsert @Source
	END

	RETURN

DuplicateAdmit:
	IF ( @Msg IS NULL )
		SET @Msg = 'Unable to process Admit for MedicalRecordID:' + @MedicalRecordID

	    EXEC dbo.Logit 1, @Msg, 'system'
go

