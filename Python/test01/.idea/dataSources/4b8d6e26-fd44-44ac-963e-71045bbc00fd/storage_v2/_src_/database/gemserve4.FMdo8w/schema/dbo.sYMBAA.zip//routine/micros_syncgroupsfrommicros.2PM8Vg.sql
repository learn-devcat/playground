CREATE PROCEDURE [dbo].[Micros_SyncGroupsFromMicros]
AS
	DECLARE @SQL nvarchar(4000),
			@MicrosServerName varchar(50),
			@RoomServiceObjNum int
			
	SET @MicrosServerName = COALESCE(dbo.GetOverheadValueNull('MicrosServerName'),'Micros')
	
	--EXEC dbo.Micros_AddLinkedServer
	
	-- Check the overhead table and get the object number for Room Service in the Revenue Center Def
	SET @RoomServiceObjNum = COALESCE(dbo.GetOverheadValueNull('RoomServiceObjNum'),'-1')

	INSERT INTO dbo.tblMenuItemMajorGroup (Maj_Grp_Seq,Obj_Num,[Name])
	        SELECT Maj_Grp_Seq, Obj_Num, [Name] FROM MicrosMajorGroupDef
	                WHERE Maj_Grp_Seq NOT IN (SELECT Maj_Grp_Seq FROM dbo.tblMenuItemMajorGroup)
	
	INSERT INTO dbo.tblMenuItemFamilyGroup(Fam_Grp_Seq, Obj_Num, [Name])
	        SELECT Fam_Grp_Seq, Obj_Num, [Name] FROM MicrosFamilyGroupDef 
	                WHERE Fam_Grp_Seq NOT IN (SELECT Fam_Grp_Seq FROM dbo.tblMenuItemFamilyGroup)
	
	INSERT INTO dbo.tblMenuItemGroup(Mi_Grp_Seq, Obj_Num, [Name])
	        SELECT Mi_Grp_Seq, Obj_Num, [Name] FROM MicrosMenuItemGroupDef 
	                WHERE Mi_Grp_Seq NOT IN (SELECT Mi_Grp_Seq FROM dbo.tblMenuItemGroup)
	
	INSERT INTO dbo.tblMenuItemMenuLevelClass(Mlvl_Class_Seq, Obj_Num, [Name])
	        SELECT Mlvl_Class_Seq, Obj_Num, [Name] FROM MicrosMenuLevel 
	                WHERE Mlvl_Class_Seq NOT IN (SELECT Mlvl_Class_Seq FROM dbo.tblMenuItemMenuLevelClass)
	
	INSERT INTO dbo.tblMenuItemPrinterClass(Prn_Def_Class_Seq, Obj_Num, [Name])
	        SELECT Prn_Def_Class_Seq, Obj_Num, [Name] FROM MicrosPrinterClass 
	                WHERE Prn_Def_Class_Seq NOT IN (SELECT Prn_Def_Class_Seq FROM dbo.tblMenuItemPrinterClass)
	
	SET @SQL = 'INSERT INTO dbo.tblMenuItemTypeClass(Mi_Type_Seq, Obj_Num, [Name])
	 SELECT * FROM OPENQUERY(['+ @MicrosServerName +'],''SELECT	MI_TYPE_SEQ,
		OBJ_NUM,
		[NAME]
	 FROM	micros.MI_TYPE_CLASS_DEF
	 WHERE [NAME] IS NOT NULL'')
	 WHERE Mi_Type_Seq NOT IN (SELECT Mi_Type_Seq FROM dbo.tblMenuItemTypeClass)'
	           
	EXEC sp_executesql @SQL
	
	IF (@RoomServiceObjNum <> -1)
	BEGIN
		-- Get the Main Menu Levels used for Diet Consistency (Levels 1-6) 
		INSERT INTO dbo.tblDietConsistency (Main_Mlvl_Seq, Consistency)
		SELECT REPLACE(REPLACE(Main_Mlvl_Seq, 'main_mlvl_',''),'_name','') AS Main_Mlvl_Seq, Consistency
		FROM
			(SELECT main_mlvl_1_name, main_mlvl_2_name, main_mlvl_3_name, main_mlvl_4_name, main_mlvl_5_name, main_mlvl_6_name
				FROM MicrosRevenueCenterDef WHERE obj_num = @RoomServiceObjNum) AS MRCD
		UNPIVOT
			(Consistency FOR Main_Mlvl_Seq IN
				(main_mlvl_1_name, main_mlvl_2_name, main_mlvl_3_name, main_mlvl_4_name, main_mlvl_5_name, main_mlvl_6_name)
			) AS unpvt
		WHERE (Consistency NOT IN ('1','2','3','4','5','6',''))
			AND (Main_Mlvl_Seq NOT IN (SELECT Main_Mlvl_Seq FROM dbo.tblDietConsistency))
	END
		
	RETURN
go

