CREATE    PROCEDURE dbo.LaborCenter_Update
@User      	char(10),
@LaborCenterID	int,
@LocationID	int,
@Description  	varchar(50)

AS 
	UPDATE	tblLaborCenter
	SET	LocationID	= @LocationID,
		Description	= @Description
	WHERE	LaborCenterID	= @LaborCenterID
go

