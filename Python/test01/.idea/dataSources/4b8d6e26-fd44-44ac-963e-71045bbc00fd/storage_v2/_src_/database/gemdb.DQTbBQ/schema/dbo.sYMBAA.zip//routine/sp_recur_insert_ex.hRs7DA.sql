	
CREATE   PROCEDURE [dbo].[sp_Recur_Insert_EX]
@User			char(10),
@AccountNo		char(19),
@AcctClassID	int,
@TransID		int,
@OutletNo		int,
@ClassID		int,
@Description	char(24),
@Amount			money,
@Percent		money,
@Minimum		bit,
@Balance		bit,
@PastDue		bit,
@TrackSlotNum	int,
@TrackIDNum		int,
@Tax1			bit,
@Tax2			bit,
@Tax3			bit,
@Tax4			bit,
@Active			bit,
@AllowNegAmt		bit,
@BatchID		char(10),
@ExpiredAccountsOnly	bit,
@PostToAltAccount	bit,
@AltAccountNo		varchar(19),
@AltBadgeNo		varchar(19),
@AltTransID		int,
@AltOutletNo	int,
@UseOutletClassBal BIT,
@Formula		VARCHAR(500),
@BalanceMax		money


AS 

SET NOCOUNT ON
DECLARE @ID as uniqueidentifier
	INSERT INTO	tblRecurChg
		(AccountNo, AcctClassID, TransID, OutletNo, ClassID, Description, Amount, [Percent], Minimum,
		Balance, PastDue, TrackSlotNum, TrackIDNum, Tax1, Tax2, Tax3, Tax4, Active, AllowNegAmt, BatchID,
		ExpiredAccountsOnly, PostToAltAccount, AltAccountNo, AltBadgeNo, AltTransID, AltOutletNo, UseOutletClassBal, Formula, BalanceMax)
	VALUES	(@AccountNo, @AcctClassID, @TransID, @OutletNo, @ClassID, @Description, @Amount, @Percent, @Minimum,
		@Balance, @PastDue, @TrackSlotNum, @TrackIDNum, @Tax1, @Tax2, @Tax3, @Tax4, @Active, @AllowNegAmt, @BatchID,
		@ExpiredAccountsOnly, @PostToAltAccount, @AltAccountNo, @AltBadgeNo, @AltTransID, @AltOutletNo, @UseOutletClassBal, @Formula, CASE WHEN @BalanceMax = 0 THEN NULL ELSE @BalanceMax END)

	DECLARE @ident as int
 	SET @ident = SCOPE_IDENTITY()

	SELECT 	@ID = RecurID
	FROM	tblRecurChg
	WHERE	AutoID = @ident

	IF @@ROWCOUNT < 1
		SELECT '0' as 'RETURN'
	ELSE
		SELECT @ID as 'RETURN'
go

