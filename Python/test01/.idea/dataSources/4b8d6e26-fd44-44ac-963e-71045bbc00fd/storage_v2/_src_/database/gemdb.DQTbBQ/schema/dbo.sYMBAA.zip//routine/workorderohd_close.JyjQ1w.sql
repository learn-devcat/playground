
CREATE        PROCEDURE dbo.WorkorderOHD_Close
@User                   char(10),
@WorkorderID            int,
@EmployeeID             int = 0,
@CDate                  datetime
AS
DECLARE		@ClosingDate    		datetime,
		@PostChargeWhenWOClosed		bit,
		@PostAltCharge			bit,
		@WorkOrderClassID		int,
		@TotalChargePosted		bit,
		@PostItemChargesWhenWOClosed	bit,
		@WorkOrderDTLID 		int,
		@FetchStatus			int,
		@msg				varchar(255),
		@RowCount			int
	SELECT 	@WorkOrderClassID = WorkOrderClassID,
		@TotalChargePosted = TotalChargePosted
	FROM 	tblWorkOrderOHD
	WHERE	WorkorderID = @WorkorderID
	SELECT 	@PostChargeWhenWOClosed = PostChargeWhenWOClosed,
		@PostAltCharge = PostAltCharge,
		@PostItemChargesWhenWOClosed = PostItemChargesWhenWOClosed
	FROM	tblWorkOrderClass
	WHERE	WorkorderClassID = @WorkOrderClassID
	IF	@PostChargeWhenWOClosed > 0 AND @TotalChargePosted = 0
	BEGIN
		EXEC WorkOrderOHD_PostCharge @User , @WorkOrderID, @EmployeeID, @CDate
	END
	-- IF WO class is SET to post items when the WO is closed, this will handle it
	IF 	@PostItemChargesWhenWOClosed > 0 AND @TotalChargePosted = 0
	BEGIN
	
		SELECT 	TOP 1 @WorkOrderDTLID = WorkOrderDTLID
		FROM	tblWorkorderDTL
		WHERE	WorkorderID = @WorkorderID AND Posted <> 1
		SET @rowcount = @@rowcount
		While (@rowcount > 0)
		BEGIN
			UPDATE 	tblWorkorderDTL
			SET	Posted = 1
			WHERE	WorkOrderDTLID = @WorkOrderDTLID AND WorkorderID = @WorkorderID
			EXEC dbo.WorkorderDTL_PostCharge @User, @WorkOrderID, @WorkOrderDTLID, @EmployeeID, @CDate		
			SELECT 	TOP 1 @WorkOrderDTLID = WorkOrderDTLID
			FROM	tblWorkorderDTL
			WHERE	WorkorderID = @WorkorderID AND Posted <> 1
			
			SET @rowcount = @@rowcount
			
		END
	END
    SET @ClosingDate = ISNULL( @CDate , getdate())
    -- Condtion also includes Closed, so IF already closed @@rowcount will = 0.
    UPDATE  tblWorkOrderOHD
        SET Closed = 1,
            ClosingEmployeeID = @EmployeeID,
            ClosingDate       = @ClosingDate
      WHERE WorkOrderID = @WorkOrderID AND
            Closed      = 0
    -- TODO: Record the UPDATE failure here ... could be because reccount = 0  or 
    --       @@Error is SET --
	SELECT @@Error as ReturnMsg
    RETURN
go

