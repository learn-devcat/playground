

CREATE PROCEDURE dbo.sp_Recur_ClassCharges
@User		char(10)
AS 
	DECLARE	@CoreID				int
			
	--Get the CoreID for the specified user
	SET @CoreID	= dbo.GetCoreIDFromUser(@User)
	
	--Get the recurring charges that are class charges
	SELECT	R.RecurID,
			R.ClassID,
			R.Description, 
			C.NextDate, 
			C.Frequency,
			R.Amount,
			R.[Percent],
			R.Minimum,
			R.Balance,
			R.PastDue,
			R.TrackIDNum,
			R.TrackSlotNum,
			R.AcctClassID,
			R.TransID,
			T.Preset,
			A.Name
	FROM	tblRecurChgClass AS C INNER JOIN
			tblRecurChg AS R
	ON		C.ClassID = R.ClassID LEFT JOIN
			tblAccountClass AS A
	ON		R.AcctClassID = A.AccountClassID LEFT JOIN
			tblTransDef AS T
	ON		R.TransID = T.TransID		
	WHERE	R.AccountNo = ''
	ORDER BY	R.AcctClassID
go

