

CREATE PROCEDURE dbo.MenuItemPrinterClassList
AS
	SET NOCOUNT ON
	
	SELECT	MenuItemPrinterClassID,
		PRN_DEF_CLASS_SEQ,
		OBJ_NUM,
		[NAME]
	FROM 	dbo.tblMenuItemPrinterClass
	WHERE [NAME] IS NOT NULL

	RETURN
go

