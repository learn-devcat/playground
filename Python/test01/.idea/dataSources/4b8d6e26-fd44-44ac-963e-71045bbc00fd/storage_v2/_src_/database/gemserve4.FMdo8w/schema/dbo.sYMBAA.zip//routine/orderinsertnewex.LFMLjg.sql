
CREATE PROCEDURE [dbo].[OrderInsertNewEX] 
@OrderID  int OUTPUT,
@PatientVisitID varchar(50),
@WaveID int,
@OrderDetail varchar(2000),
@LocationID int,
@WorkstationID int = 0,
@OutletNo int = 0,
@OrderEmployee int = 0,
@OrderEmployeeName varchar(30),
@OrderDate datetime = NULL,           -- if this is null, the database defaults to now.
@SubLevel int = 0,
@StandingOrder bit = 0,
@CheckNo varchar(20) = '',
@Subtotal money = 0,
@DeliveryCharge money = 0,
@Tip money = 0,
@OrderType	int = 0,
@OrderedFor	varchar(16) = '',
@DietId	int=0

AS
	SET NOCOUNT ON

	DECLARE @POSMenuItemID int,
		@ItemType int,
		@PatientID int,
		@Error int,
        @RoomID int,
		@Current int,
		@Next int,
		@Last int,
		@MinDiet int,
		@MaxDiet int,
		@IsDiet bit,
		@Rush	bit,
		@BeginTime varchar(5),
		@ReturnCode int

	SET @ReturnCode = 0

	--Set the order date to the BeginTime of the wave
	SELECT @OrderDate = dbo.dDatePlusNewTime(dbo.dDateOnly(COALESCE(@OrderDate, getdate())), BeginTime)
	FROM dbo.tblWave
	WHERE WaveID = @WaveID

	IF(@OrderDate IS NULL)            -- ensure we have a valid order date.
	    SET @OrderDate = getdate()

	EXEC dbo.Logit 1, @OrderDetail, 'system'

	SELECT @PatientVisitID = COALESCE(MergedTo, PatientVisitID)
	FROM dbo.tblPatientVisit
	WHERE PatientVisitID = @PatientVisitID

	-- Determine the first and last diet so we can mark the added items
	-- in the item file as diets or not.
	SELECT @MaxDiet = MAX(DietID) + 9000000,
		@MinDiet = MIN(DietID) + 9000000
	FROM dbo.tblDietOHD (NOLOCK) 
	WHERE DietID > 0 

	SELECT @PatientID = PatientID,
			@RoomID = RoomID
	FROM dbo.tblPatientVisit
	WHERE PatientVisitID = @PatientVisitID

	-- Check for Rush orders
	IF (CHARINDEX('458774',@OrderDetail) > 0)
		SET @Rush = 1
	ELSE
		SET @Rush = 0

	INSERT INTO dbo.tblOrderOHD (LocationID, WorkstationID, OutletNo, WaveID, OrderEmployee, 
			OrderEmployeeName, OrderDate, CheckNo, PatientID, PatientVisitID, SubLevel, 
			Subtotal, DeliveryCharge, Tip, StandingOrder, RoomID, Rush, OrderType, OrderedFor, DietId) 
	VALUES  (@LocationID,@WorkstationID,@OutletNo,@WaveID,@OrderEmployee,
			@OrderEmployeeName,@OrderDate,@CheckNo,@PatientID,@PatientVisitID,@SubLevel,
			@SubTotal,@DeliveryCharge,@Tip, @StandingOrder, @RoomID, @Rush, @OrderType, @OrderedFor, @DietId)

	SET @Error = @@ERROR
	
	IF(@Error = 0)
	BEGIN
		-- Send the new orderID back to the caller.
		SET @OrderID = SCOPE_IDENTITY()
			
		SET @Last = 0
		SET @Next = 1
		SET @Current = 0
		
		WHILE (1=1)
		BEGIN
			SET @Current = CHARINDEX(',' , @OrderDetail , @Current)
	
			IF(@Current > 0)
			BEGIN
				SET @Next = CHARINDEX(',' , @OrderDetail , @Current+1)
				IF(@Next <= 0)
					SET @Next = LEN(@OrderDetail)+1
			  	
				SET @ItemType = CAST(SUBSTRING(@OrderDetail , @Last , (@Current - @Last)) AS int)

				SET @POSMenuItemID = CAST(SUBSTRING(@OrderDetail , @Current + 1 , (@Next - @Current)-1) AS int)

				IF(@POSMenuItemID >= @MinDiet AND @POSMenuItemID <= @MaxDiet)
					SET @IsDiet = 1
				ELSE		
					SET @IsDiet = 0

				SET @Last = @Next + 1
				SET @Current = @Last
			END
			ELSE
			BEGIN
			  	BREAK
			END		

			INSERT INTO dbo.tblOrderItems (OrderID, POSMenuItemID, ItemType, IsDiet)
				VALUES (@OrderID, @POSMenuItemID, @ItemType , @IsDiet)

			SELECT @Error = @@Error
			IF (@Error <> 0)
			BEGIN
				SET @ReturnCode = @Error
				GOTO Finished
			END

		END
	END
	ELSE
	BEGIN
		SET @ReturnCode = @Error
		GOTO Finished
	END
                     
    	EXEC dbo.UpdateOrderLog @OrderEmployeeName, @OrderID , 'ADDORDER'

Finished:
	RETURN @ReturnCode
go

