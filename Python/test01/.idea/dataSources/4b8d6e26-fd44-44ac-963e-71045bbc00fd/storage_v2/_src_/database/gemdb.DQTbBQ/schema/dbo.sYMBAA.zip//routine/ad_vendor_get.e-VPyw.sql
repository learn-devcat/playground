CREATE PROCEDURE [dbo].[ad_Vendor_Get] @ID int
AS 
    SELECT  ID ,
            Description ,
            Notes
    FROM    dbo.tblVendors
    WHERE   ID = @ID
go

