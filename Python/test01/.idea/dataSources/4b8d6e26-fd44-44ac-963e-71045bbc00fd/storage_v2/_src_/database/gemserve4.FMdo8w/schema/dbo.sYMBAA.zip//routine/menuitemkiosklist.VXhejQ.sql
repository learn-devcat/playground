

CREATE PROCEDURE dbo.MenuItemKioskList
@MenuItemKioskClassID	int=0
AS

	SET NOCOUNT ON

	DECLARE @Msg	varchar(200)

	IF (@MenuItemKioskClassID > 0)
		SELECT	K.MenuItemKioskID,
			K.MenuItemID,
			M.POSMenuItemID,
			K.MenuItemKioskClassID,
			M.[Description],
			K.ShortName,
			K.ImageUrl,
			M.Cost
		FROM	dbo.tblMenuItemKiosk AS K
			JOIN dbo.tblMenuItemOHD AS M ON K.MenuItemID = M.MenuItemID
		WHERE	K.MenuItemKioskClassID = @MenuItemKioskClassID
		ORDER BY K.ShortName
	ELSE	
		SELECT	K.MenuItemKioskID,
			K.MenuItemID,
			M.POSMenuItemID,
			K.MenuItemKioskClassID,
			M.[Description],
			K.ShortName,
			K.ImageUrl,
			M.Cost
		FROM	dbo.tblMenuItemKiosk AS K
			JOIN dbo.tblMenuItemOHD AS M ON K.MenuItemID = M.MenuItemID
		ORDER BY K.MenuItemKioskClassID


	SET @Msg ='Selected menu items for ClassID: ' +  CAST(@MenuItemKioskClassID as varchar(20))

	EXEC dbo.Logit 18,@Msg,'Kiosk'
	RETURN
go

