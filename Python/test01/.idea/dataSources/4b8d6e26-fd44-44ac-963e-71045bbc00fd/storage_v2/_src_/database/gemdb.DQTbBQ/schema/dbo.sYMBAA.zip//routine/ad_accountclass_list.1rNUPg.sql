

CREATE PROCEDURE [dbo].[ad_AccountClass_List]
@User		char(10)
AS
	SELECT	AccountClassID,
			Name,
			Status,
			Category,
			Flags,
			AccountType,
			ExpireDays,
			TrackingGrp,
			DailyLimit,
			DailyQtyLimit,
			Limit,
			Xref,
			importmodule,
			exportmodule,
			CycleXREFID,
			SubType,
			IncludeAtTerm,
			EnableTimepay,
			GlobalLimit,
			Department
	FROM		tblAccountClass
	ORDER BY	AccountClassID
go

