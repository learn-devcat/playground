

CREATE PROCEDURE dbo.sp_Audit_List
@User		char(10),
@AccountNo	char(19)
AS 
	SELECT	D.DetailID,
			D.TransDate,
			D.TransTotal,
			
			TD.Description
			
	FROM	tblDetail AS D LEFT JOIN
			tblTransDef AS TD
	ON		D.TransID = TD.TransID
	WHERE	D.Auditable = 1 AND
			D.AuditDate = NULL AND
			D.AccountNo = @AccountNo
go

