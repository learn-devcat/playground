CREATE  PROCEDURE [dbo].[sim140_CustomHeader1]
@CoreID smallint,
@user char(10),
@Location int,                -- Where is this charge coming from?
@BadgeNo char(19),
@AccountNo char(19),          -- Who is this charge coming from?
@TransID int,                 -- Not used here...
@RevenueCenter int,           -- Revenue center of the inquire
@CheckNumber varchar(20),     -- Not used here...
@AmountTendered money,         -- Not used here...
@WorkstationID int
AS

	SET NOCOUNT ON

	-- Removes badge swipe character if it exists in @BadgeNo
	SET @BadgeNo = dbo.RemoveBadgeSwipePrefix(@BadgeNo);

	DECLARE @Message as varchar(max)

	   ----------------------------------------------------------
	   --
	   --    You are allowed 6 lines of 30 characters for 
	   --    Header rows.
	   --
	   --    Any result > 11 lines will automatically be printed
	   --    and printer output is limited to 32 or 40 colums
	   --    depending on the setting in the device file
	   --
	   --    The very first value is the # of entries in this
	   --    data set.
	   -- 
	   ----------------------------------------------------------

	SELECT @Message=
	RTRIM(A.FirstName) + ' ' + RTRIM(A.LastName) + ' (' + RTRIM(A.Fax) + ')'
	FROM dbo.tblBadgesOHD as B
	JOIN dbo.tblAccountOHD as A on A.accountno = B.accountno
	WHERE B.badgeno = @BadgeNo


	--set @Message = 
	-- 12345678901234567890123456789012345678901234567890
	-- 'Special Account Inquiry^' +
	-- '================================================' + '^' + 
	-- ' Account: ' + RTRIM(@AccountNo) + '^' + 
	--' Badge: ' + RTRIM(@BadgeNo) + '^' + 
	-- ' ^' + 
	-- ' Balance: 34.19 Balance: 34.19' + '^' + 
	-- ' Balance: 34.19 Balance: 34.19' + '^' + 
	-- ' Balance: 34.19 Balance: 34.19' + '^' + 
	-- ' Balance: 34.19 Balance: 34.19' + '^' + 
	-- ' Balance: 34.19 Balance: 34.19' + '^' + 
	-- '================================================' 

	SELECT CAST(LEN(@Message)-LEN(REPLACE( @Message, '^', '' ))+1 as varchar(5)) + '^' + @Message
go

