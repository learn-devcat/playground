
CREATE PROCEDURE [dbo].[GSI_DietWaveImport]
@LoginUserID		varchar(250),
@DietName	varchar(50),
@WaveID		int

AS
	SET NOCOUNT ON
	DECLARE @DietID		int

	SELECT @DietID = DietID
	FROM	dbo.tblDietOHD
	WHERE	[Description] = @DietName

	INSERT INTO dbo.tblDietWave (DietID, WaveID, Active)
		VALUES (@DietID, @WaveID, 1)

	RETURN
go

