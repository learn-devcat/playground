

CREATE FUNCTION dbo.EndDate (@Selection int, @CurrentDate datetime)  
RETURNS datetime
AS
BEGIN 
	DECLARE @Return datetime
	
	SELECT @Return = CASE @Selection
			WHEN 0 THEN			--Today
				dbo.dDateOnly(@CurrentDate)
			WHEN 1 THEN			--Yesterday
				dbo.dDateOnly(@CurrentDate-1)
			WHEN 2 THEN			--This week
				dbo.dDateOnly((@CurrentDate - ((DATEPART(dw,@CurrentDate)) - 1)) + 6) + ' 23:59:59.997'
			WHEN 3 THEN			--Last week
				dbo.dDateOnly(@CurrentDate - (DATEPART(dw,@CurrentDate))) + ' 23:59:59:997'
			WHEN 4 THEN			--This month
				dbo.dDateOnly(DATEADD(m,1,@CurrentDate) - ((DATEPART(d,DATEADD(m,1,@CurrentDate)))))
			WHEN 5 THEN			--Last month
				dbo.dDateOnly(@CurrentDate - (DATEPART(d,@CurrentDate)))
			WHEN 6 THEN			--This year
				DATEADD(yy,1,dbo.dDateOnly(@CurrentDate - (DATEPART(y,@CurrentDate))))
			WHEN 7 THEN			--Last year
				dbo.dDateOnly(@CurrentDate - (DATEPART(y,@CurrentDate)))
	END
	
	SET @Return = dbo.dDatePlusNewTime(@Return,'23:23:59.997')	
	RETURN @Return
END
go

