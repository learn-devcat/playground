



CREATE PROCEDURE dbo.WaveList

AS
	SET NOCOUNT ON

	SELECT	W.WaveID,	
		W.MealPeriodID,
		P.[Description] AS MealPeriod,
		W.BeginTime,
		W.EndTime,
		W.SubType,
		W.[Description],
		W.MaxOrder,
		W.WarningMinutes,
		W.CriticalMinutes
	FROM	dbo.tblWave AS W (NOLOCK)
		JOIN dbo.tblMealPeriods AS P (NOLOCK) ON W.MealPeriodID = P.MealPeriodID
	ORDER BY W.[Description]

	RETURN
go

