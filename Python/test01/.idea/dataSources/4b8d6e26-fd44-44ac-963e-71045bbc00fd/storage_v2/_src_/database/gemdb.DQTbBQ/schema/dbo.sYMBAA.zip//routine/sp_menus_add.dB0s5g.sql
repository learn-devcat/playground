

CREATE PROCEDURE dbo.sp_Menus_Add
@MenuID		int=0,
@SubMenuID		int=0,
@Description		varchar(128),
@URL			varchar(255),
@SecurityLevel		int=5555,
@MenuGroup		int=0,
@Source		char(2)=NULL
AS
	INSERT INTO	cfgMenus (MenuID,SubMenuID,Description,URL,SecurityLevel,MenuGroup,Source)
	VALUES	(@MenuID,@SubMenuID,@Description,@URL,@SecurityLevel,@MenuGroup,@Source)
go

