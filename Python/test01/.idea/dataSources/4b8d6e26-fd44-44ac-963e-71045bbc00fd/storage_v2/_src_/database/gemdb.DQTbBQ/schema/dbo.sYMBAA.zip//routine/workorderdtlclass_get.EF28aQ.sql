
CREATE    PROCEDURE dbo.WorkOrderDTLClass_Get
@User                   char(10),
@WorkOrderDTLClassID    int
AS
	SELECT      WorkOrderDTLClassID,
                Description
	FROM        tblWorkorderDTLClass
	WHERE       WorkOrderDTLClassID = @WorkOrderDTLClassID
go

