CREATE PROCEDURE [dbo].[RoomMapGetEX]
@MapNumber INT, @WaveID INT, @DateOffset INT
AS
SET NOCOUNT ON

	DECLARE @MapID			int,
			@MealPeriodID	int,
			@Today			datetime,
			@ParentRow		bit,
			@SentOrderBuffer	int,
			@MealPeriodEndTime datetime,
			@OrderOffsetDate		datetime,
			@CurrentRow		int,
			@TotalMaps		int

	DECLARE @Orders TABLE (
		OrderID int,
		PatientVisitID varchar(50),
		PostDate datetime,
		Received bit,
		Cancelled bit,
		WaveID	int
		)
	
	DECLARE @OrderLog TABLE (
		OrderID int,
		ActionID int	
		)

	DECLARE @PatientVisit TABLE(
		PatientVisitID varchar(50),
		PatientID int,
		RoomID	int,		
		EntryDate datetime,
		DischargeDate datetime,
		MergedTo int,		
		DietID	int		
		)
	
	DECLARE @Maps TABLE(
		[ID] int IDENTITY(1,1),
		MapID int
		)
		
	IF (@MapNumber = 101)
		SET @ParentRow = 1
	ELSE
		SET @ParentRow = 0

	-- Setup global variables
	SET @Today = getdate()
	SET @OrderOffsetDate = dbo.dDateOnly(@Today + @DateOffset)

	SELECT @SentOrderBuffer = dbo.GetOverheadValue('SentOrderBuffer')
 
	IF (@WaveID = 0)
		SELECT @MealPeriodID = dbo.GetMealPeriod(@Today)
	ELSE
		SET @MealPeriodID = @WaveID

	SET @MealPeriodEndTime = dbo.MealPeriodEndTime(@OrderOffsetDate,@MealPeriodID)

	IF (@ParentRow = 1)
		GOTO Parent

	-- If this map has embedded maps, process all of the data at once.
	IF NOT EXISTS (SELECT 1	FROM dbo.tblMapData 
				WHERE MapItemType = 110 
				AND MapNumber = @MapNumber)
	BEGIN
		EXEC dbo.RoomMapGetSingle @MapNumber, @WaveID, @DateOffset
		GOTO Finish
	END
	
	-- Only get orders when we are not at the parent level
Parent:
		INSERT INTO @Orders
		SELECT OrderID, PatientVisitID, PostDate, Received, COALESCE(Cancelled,0), O.WaveID
		FROM dbo.tblOrderOHD AS O (NOLOCK)
		JOIN dbo.tblWave AS W (NOLOCK) ON O.WaveID = W.WaveID
		WHERE W.MealPeriodID = @MealPeriodID
				AND O.OrderDate BETWEEN @OrderOffsetDate AND (@OrderOffsetDate + 1)
				AND COALESCE(O.OrderType,1) = 1
		ORDER BY O.PatientVisitID
				
		INSERT INTO @OrderLog
		SELECT ORDERID, MAX(ACTIONID) AS ACTIONID
		FROM dbo.tblOrderLOG (NOLOCK)
		WHERE OrderID IN (SELECT OrderID FROM @Orders)
		GROUP BY ORDERID
		
		INSERT INTO @PatientVisit
		SELECT PatientVisitID,	PatientID, RoomID, EntryDate, DischargeDate, MergedTo, DietID
		FROM dbo.tblPatientVisit
		WHERE RoomID IS NOT NULL
			AND MergedTo IS NULL 
			AND DischargeDate IS NULL
		ORDER BY RoomID	
		
		INSERT INTO @Maps
		SELECT LEFT(ImgSrc,3)
		FROM dbo.tblMapData 
		WHERE MapItemType = 110 
			AND MapNumber = @MapNumber
		ORDER BY Priority, Label
		
		SET @TotalMaps = @@ROWCOUNT
		
		SET @CurrentRow = 1

	IF (@ParentRow = 1)
		EXEC dbo.RoomMapGetSingle @MapNumber, @WaveID, @DateOffset
	-- END Orders

	IF ( @SentOrderBuffer = '' )
		SET @SentOrderBuffer = 30

	WHILE (@CurrentRow <= @TotalMaps)
	BEGIN
	
		SELECT @MapID = MapID
		FROM @Maps
		WHERE [ID] = @CurrentRow
		
		SELECT	ISNULL(P.PatientID,0) AS PatientID,
			M.MapItemType, 	        -- See notes above.
				M.Label,                  -- Generic label
				M.Row,                    -- Where this item should be on a imaginary grid.
				M.Col,
				M.Height,
				M.Width,
				M.ImgSrc,                 -- The picture to be displayed, when not a room type.
				M.Href,                   -- Link to an included item to be included on the rendering.
				M.Layer,
				M.Prefix,
			    CASE
				    WHEN PV.EntryDate > @MealPeriodEndTime THEN '000'
				    WHEN PV.DietID = -1 THEN '102'
				    WHEN D.NPO = 1 AND LC.ShowNPO = 1 THEN '101'
					WHEN P.OnHold = 1 THEN '380'
				    WHEN PV.ROOMID IS NULL THEN '000'
				    WHEN H.Cancelled = 1 THEN '105'
				    WHEN L.ActionID IS NULL THEN dbo.NoOrderStatus('100',@Today, @DateOffset, @MealPeriodID, PV.DietID)
				    WHEN (L.ACTIONID = 210 AND DATEDIFF(s,H.PostDate,@Today) < @SentOrderBuffer AND H.Received = 0) THEN '205'
				    ELSE CAST(L.ACTIONID as varchar(3))
			    END AS Status,
					M.Orientation & 255 as Orientation,
				O.MapNumber AS MapNumber,
				O.Title AS MapTitle,
				O.SubTitle AS MapSubtitle,
				O.Description AS MapDescription,
				O.CssSrc AS MapCSS,
				O.Href AS MapHref,
				R.RoomNumber,
				R.RoomID,
				1 AS TotalOrders,
				H.OrderID
		FROM dbo.tblMapOHD as O (NOLOCK)
        	LEFT JOIN dbo.tblMapData AS M (NOLOCK) ON M.MapNumber = O.MapNumber
			LEFT JOIN dbo.tblRoomOHD AS R (NOLOCK) ON R.RoomNumber = M.Label 
			LEFT JOIN dbo.tblLocationClass AS LC (NOLOCK) ON R.LocationClassID = LC.LocationClassID
			LEFT JOIN @PatientVisit AS PV ON PV.RoomID = R.RoomID 
				AND PV.MergedTo IS NULL 
				AND PV.DischargeDate IS NULL
				AND O.MapNumber <> 101
			LEFT JOIN dbo.tblPatientOHD AS P (NOLOCK) ON P.PatientID = PV.PatientID
			LEFT JOIN dbo.tblDietOHD AS D (NOLOCK) ON D.DietID = dbo.GetActiveDiet(PV.PatientVisitID, @Today)
			LEFT JOIN @Orders AS H ON H.PatientVisitID = PV.PatientVisitID 
			LEFT JOIN dbo.tblWave AS W (NOLOCK) ON H.WaveID = W.WaveID
			LEFT JOIN @OrderLog AS L ON H.OrderID = L.OrderID
		WHERE O.MapNumber = @MapID
			AND O.Inactive = 0
		ORDER BY M.Priority, M.Label, Status DESC
		
		SET @CurrentRow = @CurrentRow + 1
				
	END

	Finish:
go

