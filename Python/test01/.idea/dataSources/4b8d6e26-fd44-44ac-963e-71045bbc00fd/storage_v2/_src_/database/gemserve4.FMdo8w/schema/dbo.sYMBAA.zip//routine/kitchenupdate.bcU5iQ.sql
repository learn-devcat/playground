CREATE PROCEDURE [dbo].[KitchenUpdate]
	@LoginUserId		VARCHAR(250),
	@KitchenId			INT,
	@Description		VARCHAR(250)=NULL,
	@OrderTypeId		INT=NULL,
	@OfflineRuleId		INT=NULL,
	@AlternateKitchenId	INT=NULL,
	@Active				BIT=NULL,
	@LicenseKey			VARCHAR(50)=NULL,
	@NewId				INT=NULL
	
AS
	SET NOCOUNT ON
	
	DECLARE @LocationClassId int,
			@RoomNumber varchar(10),
			@PatientId int,
			@PVID int,
			@Temp varchar(100),
			@Temp2 varchar(50),
			@Today datetime,
			@cnt int

	SET @Today = getdate()
	
	IF (@KitchenId > 0)
	BEGIN
		UPDATE dbo.tblKitchens
			SET Description = COALESCE(@Description, Description),
			OrderTypeId = COALESCE(@OrderTypeId, OrderTypeId),
			OfflineRuleId = COALESCE(@OfflineRuleId, OfflineRuleId),
			AlternateKitchenId = COALESCE(@AlternateKitchenId, AlternateKitchenId),
			Active = COALESCE(@Active, Active),
			LicenseKey = @LicenseKey
		WHERE KitchenId = @KitchenId
		
		IF NOT (@LicenseKey IS NULL)
			UPDATE dbo.tblKitchens
			SET CSValue = CHECKSUM(KitchenId, Description, LicenseKey)
			WHERE KitchenId = @KitchenId
			
		-- If this kitchen is set to Inactive, update all Locations to another Kitchen			
		IF (@Active = 0)
		BEGIN
			-- since we're deactivating this kitchen, we need to make sure no other kitchens are using this kitchen as an alternate kitchen
			-- logically, this sets the offline rule to "cancel order"
			UPDATE dbo.tblKitchens 
			SET AlternateKitchenId = 0 
			WHERE AlternateKitchenId = @KitchenId
			
			IF EXISTS (SELECT 1 FROM dbo.tblLocationClass WHERE KitchenId = @KitchenId)
				SELECT TOP 1 @NewId = KitchenId FROM dbo.tblKitchens WHERE Active = 1 ORDER BY KitchenId
				
				IF NOT (@NewID IS NULL)
					UPDATE dbo.tblLocationClass SET KitchenId = @NewId WHERE KitchenId = @KitchenId
		END
	END
	ELSE
	BEGIN
		IF (@NewId IS NULL)
			EXEC dbo.GetNextIdFromNamedTable 'dbo.tblKitchens', 'KitchenId', @NewId OUTPUT
	
		INSERT INTO dbo.tblKitchens (KitchenId, Description, OrderTypeId, OfflineRuleId, AlternateKitchenId, Active, LicenseKey)
			VALUES (@NewId, @Description, @OrderTypeId, @OfflineRuleId, @AlternateKitchenId, @Active, @LicenseKey)	
			
		SET @KitchenId = @NewId	
		
		UPDATE dbo.tblKitchens
		SET CSValue = CHECKSUM(KitchenId, Description, LicenseKey)
		WHERE KitchenId = @KitchenId
		
		-- Make sure a psuedo-location exists for Dr. Orders from this kitchen
		IF NOT EXISTS (SELECT 1 FROM dbo.tblLocationClass (NOLOCK) WHERE Description = 'Dr-Kitch' + CAST(@KitchenId AS varchar(1)))
		BEGIN
			INSERT INTO dbo.tblLocationClass (Description, Active, ShowNPO, KitchenId, ExcludeFromDashboard)
				VALUES ('Dr-Kitch' + CAST(@KitchenId AS varchar(1)), 1, 1, @KitchenId, 1)
			
			SET @LocationClassID = SCOPE_IDENTITY()	
		END				
		ELSE
			SELECT @LocationClassID = LocationClassID
			FROM dbo.tblLocationClass (NOLOCK)
			WHERE Description = 'Dr-Kitch' + CAST(@KitchenId AS varchar(1))
		
		-- Make sure a room exists for Dr. Orders from this kitchen
		IF NOT EXISTS (SELECT 1 FROM dbo.tblRoomOHD (NOLOCK) WHERE RoomNumber = 'Dr-Kitch' + CAST(@KitchenId AS varchar(1)))
			INSERT INTO dbo.tblRoomOHD(RoomNumber, RoomClassID, LocationClassID)
				VALUES ('Dr-Kitch' + CAST(@KitchenId AS varchar(1)), 0, @LocationClassID)
			
		SET @RoomNumber = 'Dr-Kitch' + CAST(@KitchenId AS varchar(1))
				
		-- Make sure a psuedo-patient exists for Dr. Orders from this kitchen
		-- Patient Update will add a PatientOHD record, a PatientVisit record and a PatientDiet record
		-- Patient OHD record
		SELECT @PatientId = PatientId
		FROM dbo.tblPatientOHD (NOLOCK)
		WHERE MedicalRecordId = CAST(@KitchenId AS varchar(1))
		
		-- Patient Visit record
		SELECT @PVID = PVID
		FROM dbo.tblPatientVisit (NOLOCK)
		WHERE PatientVisitId = CAST(@KitchenId AS varchar(1))
		
		IF (@PatientId IS NULL)
			SET @PatientId = -1
		
		IF (@PVID IS NULL)
			SET @PVID = -1
		
		SET @Temp = 'Order' + CAST(@KitchenId AS varchar(1))
		SET @Temp2 = CAST(@KitchenId AS varchar(1))
		
		EXEC dbo.PatientUpdate @LoginUserId, @PatientId, @PVID, @Temp2, 10, 1, @Temp2, @Temp, 'Dr.', '', @RoomNumber, '', '', '', 0, @Today, 500, 0
		
		--add a default kitchen time for each day of the week
		SET @cnt = 1
		WHILE @cnt < 8
			BEGIN
				EXEC dbo.KitchenTimeUpdate @LoginUserId, 0, @KitchenId, @cnt, @StartTime = '00:00', @EndTime = '23:59'
				SET @cnt = @cnt + 1
			END		
	END
	
	SELECT @KitchenId AS KitchenId

	RETURN @KitchenId
go

