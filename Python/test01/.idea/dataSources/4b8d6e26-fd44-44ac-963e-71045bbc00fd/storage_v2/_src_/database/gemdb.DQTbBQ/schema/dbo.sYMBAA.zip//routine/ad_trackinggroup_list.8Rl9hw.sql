

CREATE PROCEDURE dbo.ad_TrackingGroup_List
@User		char(10)
AS
	SELECT 	TrackingGrp,
			Description
	FROM		tblTrackingOHD
	ORDER BY	TrackingGrp
go

