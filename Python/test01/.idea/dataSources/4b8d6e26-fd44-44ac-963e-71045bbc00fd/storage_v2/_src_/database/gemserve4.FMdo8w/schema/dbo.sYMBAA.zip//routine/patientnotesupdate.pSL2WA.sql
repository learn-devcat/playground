

CREATE PROCEDURE dbo.PatientNotesUpdate
@PatientID	int,
@Notes		text

AS

	UPDATE 	dbo.tblPatientOHD
	SET	Notes = @Notes
	WHERE 	PatientID = @PatientID
go

