

CREATE PROCEDURE dbo.ad_TrackingGroup_Insert
@User			char(10),
@TrackingGrp		int,
@Description		varchar(24),
@Status		int,
@Item1			int,
@Item2			int,
@Item3			int,
@Item4			int,
@Item5			int,
@Item6			int,
@Item7			int,
@Item8			int,
@Item9			int,
@Item10		int,
@Item11		int,
@Item12		int,
@Item13		int,
@Item14		int,
@Item15		int,
@Item16		int
AS
	INSERT INTO	tblTrackingOHD
			(TrackingGrp, Description, Status, Item1, Item2, Item3, Item4, Item5, Item6, Item7, Item8,
			 Item9, Item10, Item11, Item12, Item13, Item14, Item15, Item16)
	VALUES	(@TrackingGrp, @Description, @Status, @Item1, @Item2, @Item3, @Item4, @Item5, @Item6, @Item7, @Item8,
			 @Item9, @Item10, @Item11, @Item12, @Item13, @Item14, @Item15, @Item16)
go

