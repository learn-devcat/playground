

CREATE FUNCTION dbo.GetMiddleNameDisplay(@MiddleName char(15),
					@IsPOS bit = 1)
RETURNS varchar(35)
AS
BEGIN
DECLARE @MiddleNameDisplay as int,
		@MiddleNameString as varchar(20)

	IF (@IsPOS = 0) 
		SET @MiddleNameDisplay = dbo.GetOverheadItem('MiddleNameReportDisplay');
	ELSE
		SET @MiddleNameDisplay = dbo.GetOverheadItem('MiddleNamePOSDisplay');

	IF (@MiddleNameDisplay = 0) -- no display
		SET @MiddleNameString = ''
	ELSE IF (@MiddleNameDisplay = 1) -- full display
		SET @MiddleNameString = ' ' + RTRIM(@MiddleName)
	ELSE IF (@MiddleNameDisplay = 2) -- Middle Initial Only
		SET @MiddleNameString = ' ' + LEFT(RTRIM(@MiddleName) , 1)
	ELSE -- Unknown setting. No Display
		SET @MiddleNameString = ''
		

	DECLARE	@ReturnString	varchar(32)
	IF (RTRIM(@MiddleName)='') 
		SET @ReturnString = '' 
	ELSE 
		SET @ReturnString=@MiddleNameString
	
	RETURN @ReturnString
END
go

