

CREATE PROCEDURE dbo.EmployeeDelete
@LoggedOnUser	varchar(20),
@LoginUserID     		varchar(250)

AS
	SET NOCOUNT ON 
	
    DELETE  dbo.tblEmployees
	WHERE   LoginUserID = @LoginUserID
	
	RETURN
go

