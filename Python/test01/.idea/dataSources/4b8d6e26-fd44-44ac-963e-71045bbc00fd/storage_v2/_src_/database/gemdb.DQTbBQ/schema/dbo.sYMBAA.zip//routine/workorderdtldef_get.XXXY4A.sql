
CREATE    PROCEDURE dbo.WorkorderDTLDef_Get
@User			    char(10), 
@WorkOrderDTLDefID  int
AS
    SELECT  WorkOrderDTLDefID,
            LocationID,
            WorkOrderDTLClassID,
            EmployeeClassID,
            ShortDescription,
            Description,
            SkillLevel,
            Price,
            Cost,
            EstimatedHours,
            LeadTime,
            TransID,
	    LaborCenterID 	
    FROM    tblWorkOrderDTLDef
    WHERE   WorkOrderDTLDefID = @WorkorderDTLDefID
    RETURN
go

