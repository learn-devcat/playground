

CREATE PROCEDURE dbo.sp_AddressClass_List
@AccountNo	char(19)=''
AS
	IF (@AccountNo <> '')
		SELECT	AC.AddressID,
				AC.Description
		FROM		tblAddressClass AS AC
		WHERE	AC.AddressID NOT IN
				(SELECT AddressID 
				FROM	tblAccountAddress
				WHERE	AccountNo = @AccountNo)
		ORDER BY	AC.AddressID
	ELSE
		SELECT	AddressID,
				Description
		FROM		tblAddressClass
		ORDER BY	AddressID
go

