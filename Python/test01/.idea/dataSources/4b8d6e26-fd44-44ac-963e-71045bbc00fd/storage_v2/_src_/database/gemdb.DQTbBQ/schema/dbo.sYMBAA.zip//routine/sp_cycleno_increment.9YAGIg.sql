

CREATE PROCEDURE dbo.sp_CycleNo_Increment
@CoreID int = 1
as
DECLARE @CycleNo	 int
DECLARE @msg 		varchar(50)
	SELECT 	@CycleNo  = CycleNo 
	FROM	cfgCore
	WHERE	CoreID = @CoreID
	IF( @CycleNo is null )
	    BEGIN
		SET @msg = 'Failed to increment CycleNo for # ' + ltrim(str( @CoreID , 4 ))
	    END
	ELSE
	   BEGIN
		UPDATE 	cfgCore
		SET	CycleNo = CycleNo + 1
		WHERE	CoreID = @CoreID
	
		insert into  tblCycleLog  (CycleNo, CoreID) VALUES (@CycleNo+1,@CoreID )
		SET @msg = 'Increment Cycle Number for CORE ID #' + ltrim(str( @CoreID , 4 ))
	   END
	--[ UPDATE Log ]---------------------------------------
	EXEC dbo.sp_Logit 0 , @CoreID , 'SYSTEM' , @Msg
	-------------------------------------------------------[ UPDATE Log END ]------
	RETURN
go

