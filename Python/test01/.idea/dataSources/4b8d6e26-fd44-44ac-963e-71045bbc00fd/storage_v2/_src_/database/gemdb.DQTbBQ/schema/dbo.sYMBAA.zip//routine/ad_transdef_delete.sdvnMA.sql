CREATE PROCEDURE dbo.ad_TransDef_Delete
@User		char(10),
@TransID	int
AS 
	DELETE	tblTransDef
	WHERE	TransID = @TransID
go

