
CREATE PROCEDURE [dbo].[RoomGet]
@RoomID		int
AS
	SET NOCOUNT ON

	
	SELECT	R.RoomID,
			R.RoomNumber,
			R.RoomClassID,
			R.LocationClassID,
			R.PhoneNumber,
			R.IP,
			R.Privilege,
			R.Diet,
			R.Notes,
			L.Description AS LocationClass
	FROM dbo.tblRoomOHD AS R (NOLOCK)
	JOIN dbo.tblLocationClass AS L (NOLOCK) ON R.LocationClassID = L.LocationClassID
	WHERE R.RoomID = @RoomID

	RETURN
go

