
CREATE PROCEDURE [dbo].[GSI_MicrosMenuItemUpdate]
@ObjectNumber INT OUTPUT, @Name VARCHAR (16), @MajorGroupSeq INT, @FamilyGroupSeq INT, @MIGroupSeq INT, @MITypeSeq INT, @MLvlClassSeq INT, @PrnDefClassSeq INT, @CrossRef1 VARCHAR (16), @Cost DECIMAL (12, 2), @Price DECIMAL (12, 2), @CondimentAllowed INT=1, @CondimentGroup INT=1
AS
SET NOCOUNT ON
	
	DECLARE @SQL nvarchar(4000),
			@Mi_Seq int

	SET @SQL = 'DECLARE	@Overhead varchar(10),
		@TempObjectNumber	int,
		@NutrientId	int,
		@NutrientQty decimal(10,3)

	SELECT @NutrientId = CAST(Value AS int)
	FROM dbo.cfgOverhead
	WHERE KeyId = ''NutrientOnReceipt''

	IF (@NutrientId > 0)
		SELECT @NutrientQty = N.Qty
		FROM dbo.tblMenuItemNutrients AS N
		JOIN dbo.tblMenuItemOHD AS M ON N.MenuItemId = M.MenuItemId
		WHERE M.POSMenuItemSEQ = @MI_Seq1

	SET @NutrientQty = COALESCE(@NutrientQty, 0)

	SET @Overhead = dbo.GetOverheadValue(''CondimentAllowed'')
	IF (@Overhead <> '''') 
		SET @CondimentAllowed1 = CAST(@Overhead AS int)

	SET @Overhead = dbo.GetOverheadValue(''CondimentGroup'')
	IF (@Overhead <> '''') 
		SET @CondimentGroup1 = CAST(@Overhead AS int)

	IF EXISTS (SELECT obj_num FROM Micros..micros.mi_def WHERE obj_num = @ObjectNumber1)
	BEGIN
		SELECT @MI_Seq1 = mi_seq
		FROM	Micros..micros.mi_def
		WHERE	obj_num = @ObjectNumber1
		
		UPDATE	Micros..micros.mi_def
		SET	name_1 = @Name1,
			maj_grp_seq = @MajorGroupSeq1,
			fam_grp_seq = @FamilyGroupSeq1,
			mi_grp_seq = @MIGroupSeq1,
			mi_type_seq = @MITypeSeq1,
			mlvl_class_seq = @MLvlClassSeq1,
			prn_def_class_seq = @PRnDefClassSeq1,
			cross_ref1 = @CrossRef1_1,
			cond_allowed = COALESCE(cond_allowed, @CondimentAllowed1),
			cond_grp_mem_seq = COALESCE(cond_grp_mem_seq, @CondimentGroup1)
		FROM	Micros..micros.mi_def
		WHERE	mi_seq = @MI_Seq1
	END
	ELSE
	BEGIN
		IF (COALESCE(@ObjectNumber1,0) <=0)
		BEGIN
			SELECT @Overhead = dbo.GetOverheadValue(''POSMenuItemObjectNum'')
			SET @ObjectNumber1 = CAST(@Overhead as int)
		END

		INSERT INTO Micros..micros.mi_def (obj_num,name_1,maj_grp_seq,fam_grp_seq,
		        mi_grp_seq,mi_type_seq,mlvl_class_seq,prn_def_class_seq,cross_ref1,
			cond_allowed, cond_grp_mem_seq)
		VALUES(@ObjectNumber1, @Name1, @MajorGroupSeq1, @FamilyGroupSeq1,
			@MIGroupSeq1, @MITypeSeq1, @MLvlClassSeq1, @PrnDefClassSeq1, @CrossRef1_1,
			@CondimentAllowed1, @CondimentGroup1)

		SELECT @MI_Seq1 = mi_seq
		FROM	Micros..micros.mi_def
		WHERE	obj_num = @ObjectNumber1

		SET @TempObjectNumber = @ObjectNumber1 + 1
		UPDATE dbo.cfgOverhead SET Value = CAST(@TempObjectNumber as varchar(10)) WHERE KeyID = ''POSMenuItemObjectNum''
	END

	UPDATE	Micros..micros.mi_price_def
	SET	preset_amt_1 = @NutrientQty,
		preset_amt_2 = @NutrientQty,
		preset_amt_3 = @NutrientQty,
		preset_amt_4 = @NutrientQty,
		preset_amt_5 = @NutrientQty,
		preset_amt_6 = 0,
		preset_amt_7 = 0,
		preset_amt_8 = 0,
		preset_amt_9 = 0,
		preset_amt_10 = @Price1,
		cost_1 = @Cost1,
		cost_2 = @Cost1,
		cost_3 = @Cost1,
		cost_4 = @Cost1,
		cost_5 = @Cost1,
		cost_6 = @Cost1,
		cost_7 = @Cost1,
		cost_8 = @Cost1,
		cost_9 = @Cost1,
		cost_10 = @Cost1
	WHERE	mi_seq = @MI_Seq1'
	
	EXEC sp_executesql @SQL, N'@Mi_Seq1 int OUTPUT, @ObjectNumber1 int OUTPUT, @Name1 varchar(16), @MajorGroupSeq1 int, @MIGroupSeq1 int, @MITypeSeq1 int, @MLvlClassSeq1 int, @PrnDefClassSeq1 int, @CrossRef1_1 varchar(16), @Cost1 decimal(12,2), @Price1 decimal(12,2), @CondimentAllowed1 int, @CondimentGroup1 int, @FamilyGroupSeq1 int ',@Mi_Seq OUTPUT, @ObjectNumber,@Name, @MajorGroupSeq, @MIGroupSeq, @MITypeSeq, @MLvlClassSeq, @PrnDefClassSeq, @CrossRef1, @Cost, @Price, @CondimentAllowed, @CondimentGroup, @FamilyGroupSeq

	RETURN @Mi_Seq
go

