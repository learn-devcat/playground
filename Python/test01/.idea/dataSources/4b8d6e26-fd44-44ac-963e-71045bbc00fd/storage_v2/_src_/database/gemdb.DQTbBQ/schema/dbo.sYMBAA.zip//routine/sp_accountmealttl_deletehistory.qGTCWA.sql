

CREATE PROCEDURE [dbo].[sp_AccountMealTTL_DeleteHistory]
@AccountNo		char(19),
@MealPlanID		int
AS
		DELETE	tblAccountMealTTL
		WHERE	AccountNo = @AccountNo
				AND MealPlanID = @MealPlanID
				AND GETDATE() NOT BETWEEN ActiveDate AND ExpireDate
go

