CREATE PROCEDURE [dbo].[Micros_POSDietsFromGEM]
@LoginUserID		varchar(250)

AS

	DECLARE @iPOSDietID		int,
			@DietID			int,
			@AltDescription varchar(16),
			@POSMenuEditing int,
			@POSDietPrefix	int,
			@TotalDiets		int,
			@CurrentRow		int
		
	-- Check to see if the MICROS editing is allowed - default is not allowed (0)
	SET @POSMenuEditing = COALESCE(dbo.GetOverheadValueNull('POSMenuEditing'),'0')
	
	IF(@POSMenuEditing = '1')
	BEGIN	

		-- Get the number to be added to the DietId to create the POS Diet ID on the MICROS
		SET @POSDietPrefix = COALESCE(dbo.GetOverheadValueNull('POSDietPrefix'),'9000000')	
		
		DECLARE @TempDietOHD AS TABLE 
			(
					[ID] INT IDENTITY(1,1),
					[DietID]				int,
					[AltDescription]		varchar(50)
			)
	
		-- Insert Diets to be sent to the MICROS in a temp table
		INSERT INTO @TempDietOHD(DietID, AltDescription)
		SELECT DietID, AltDescription
		FROM dbo.tblDietOHD
		WHERE (DietID > 0) AND (NPO <> 1)
		
		-- Get Total Number of Diets
		SET @TotalDiets = @@ROWCOUNT
		
		-- Set up Loop
		SET @CurrentRow = 1
		
		-- Loop through Diets and send them to the MICROS
		WHILE (@CurrentRow <= @TotalDiets)
		BEGIN
			
			-- Get the current Diet
			SELECT	@DietID = DietID,
					@AltDescription = LEFT(AltDescription,16)
			FROM	@TempDietOHD
			WHERE	[ID] = @CurrentRow
			
			-- Set the POS Diet ID that will be used on the MICROS
			SET @iPOSDietID = @POSDietPrefix + @DietID
			
			-- Write the Diet Info to the Micros
			EXEC dbo.Micros_DietUpdate @LoginUserID, @iPOSDietID, @AltDescription
		 
			-- Increment the @CurrentRow variable
			SET @CurrentRow = @CurrentRow + 1
		END
		
	END
go

