


CREATE PROCEDURE dbo.PatientLogADD
(
    @EventClassID int,
    @LoginUserID       varchar(250),
    @PatientID    int,
    @PatientVisitID varchar(50),
    @RoomID       int,
    @Description  varchar(200),
    @LogDate      varchar(20) = ''
)
AS
	SET NOCOUNT ON
	
	INSERT INTO dbo.tblPatientLog 
	            (EventClassID, LoginUserID, PatientID, PatientVisitID, RoomID, Description, Date ) 
	   VALUES (@EventClassID, @LoginUserID, @PatientID, @PatientVisitID, @RoomID , @Description, dbo.HL7ConvertDateTime(@LogDate,getdate()))
	
	RETURN
go

