

CREATE PROCEDURE dbo.sp_GiftCard_Balance
@User			char(10),
@AccountNo		char(19)
AS
	SELECT	-(Balance) AS Balance
	FROM	tblAccountTTL
	WHERE	AccountNo = @AccountNo AND
			TransClassID = dbo.GetGCTransClass()
	
	DECLARE @cMsg  char(255),
			@CoreID	int
	SET @CoreID = dbo.GetCoreIDFromUser(@User)
	SET @cMsg = 'Retrieved account Balances for Account No <' + RTRIM(@AccountNo) + '>'
	EXEC dbo.sp_Logit 4 , @CoreID , @User , @cMsg
go

