

CREATE FUNCTION dbo.GetTSLocation(@Row as int, @Col as int)
RETURNS int
AS
BEGIN
	DECLARE @Return	int,
		@Temp	varchar(50)

	SELECT @Temp = KeyIn
	FROM	dbo.tblXlat
	WHERE	KeyOut = CAST(@Row AS varchar(10))
		AND [Description] = CAST(@Col AS varchar(10))
		AND xlatID = 'Touchscreen'

	RETURN CAST(ISNULL(@Temp,0) AS int)
END
go

