

CREATE PROCEDURE [dbo].[ad_AccountCategory_Update]
@User			char(10),
@Category		char(10),
@Description	varchar(24)
AS 
	SET NOCOUNT ON
	
	UPDATE	tblAccountCategory
	SET		Description = @Description
	WHERE	Category = @Category
	
	IF(@@ROWCOUNT = 0)
		SELECT 'Database failed to UPDATE category: [' + @Category + ']'
	ELSE
		SELECT ''
go

