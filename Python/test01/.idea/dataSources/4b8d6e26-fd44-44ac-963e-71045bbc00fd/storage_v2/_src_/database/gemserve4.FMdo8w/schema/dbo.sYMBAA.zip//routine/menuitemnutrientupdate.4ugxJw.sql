


CREATE PROCEDURE dbo.MenuItemNutrientUpdate
@LoginUserID			varchar(250),
@MenuItemID		int,
@NutrientID		int,
@Qty			decimal(10,3)

AS
	SET NOCOUNT ON

	UPDATE dbo.tblMenuItemNutrients
	SET 	Qty = @Qty
	WHERE MenuItemID = @MenuItemID
		AND NutrientID = @NutrientID

	IF (@@ROWCOUNT = 0)
		INSERT INTO dbo.tblMenuItemNutrients(MenuItemID, NutrientID, Qty)
		VALUES(@MenuItemID, @NutrientID, @Qty)

	
	RETURN
go

