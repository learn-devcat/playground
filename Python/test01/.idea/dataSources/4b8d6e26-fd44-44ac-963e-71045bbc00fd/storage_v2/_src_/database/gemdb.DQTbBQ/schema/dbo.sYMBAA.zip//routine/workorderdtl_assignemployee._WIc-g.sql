CREATE   PROCEDURE dbo.WorkorderDTL_AssignEmployee
@User               char(10),
@WorkOrderID        int,
@WorkOrderDTLID     int,
@AssigningEmployeeID int,
@AssignedEmployeeID int,
@AssignmentDate     datetime
AS
    SET @AssignmentDate = ISNULL( @AssignmentDate , getdate())      -- IF no date, SET to today.
    UPDATE  tblWorkOrderDTL
       SET  AssignedEmployeeID = @AssignedEmployeeID,
            AssigningEmployeeID = @AssigningEmployeeID,
            AssignmentDate      = @AssignmentDate
    WHERE   WorkOrderID = @WorkOrderID AND
            WorkOrderDTLID = @WorkOrderDTLID
    RETURN
go

