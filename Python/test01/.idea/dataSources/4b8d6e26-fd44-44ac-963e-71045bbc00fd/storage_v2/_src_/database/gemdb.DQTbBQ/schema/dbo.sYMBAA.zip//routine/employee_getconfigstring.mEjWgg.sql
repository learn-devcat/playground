



Create        PROCEDURE dbo.Employee_GetConfigString
@User			char(10),
@EmployeeID		int
AS
    	SELECT  C.ConfigString
	
        FROM	tblEmployeeOHD E
	    		LEFT JOIN 
		tblEmployeeClass C on C.EmployeeClassID = E.EmployeeClassID
	WHERE   E.EmployeeID = @EmployeeID
go

