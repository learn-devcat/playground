


CREATE PROCEDURE dbo.ad_Location_Insert
@User		char(10),
@LocationID	int,
@Description	varchar(50)
AS 
	INSERT INTO cfgLocations (LocationID, Description)
		VALUES (@LocationID, @Description)
go

