


CREATE FUNCTION dbo.InCurrentMealPeriod(@MealPlanID int,@TransDate datetime, @Today datetime)
RETURNS int
AS
BEGIN
	DECLARE @Return int
	SELECT 	@Return = 1
	FROM	tblPlanOHD AS M
		INNER JOIN
		tblPlanDTL AS PD
	ON	M.MealPlanID = PD.MealPlanID
	WHERE 	M.MealPlanID = @MealPlanID
		AND dbo.TimeOnly(@TransDate) BETWEEN PD.BegTime AND PD.EndTime
		AND dbo.TimeOnly(@Today) BETWEEN PD.BegTime AND PD.EndTime
		AND dbo.dDateOnly(@TransDate) = dbo.dDateOnly(@Today)
	RETURN ISNULL(@Return,0)
END
go

