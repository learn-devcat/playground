CREATE FUNCTION dbo.DelimitedStringFieldCount ( @String varchar(1900), @Delimiter char(1) )
RETURNS int 
AS
BEGIN
	/*
		This function returns the number of fields in a delimited string
	*/
	
	DECLARE @NoDelimString varchar(1900),
			@FieldCount int

	SET @NoDelimString = REPLACE(@String, @Delimiter, '')

	SET @FieldCount =	CASE @String
							WHEN '' THEN 0
							ELSE LEN(@String) - LEN(@NoDelimString) + 1
						END

	RETURN @FieldCount

END
go

