

CREATE PROCEDURE dbo.DietMealPeriodNutrientUpdate
@LoginUserID		varchar(250),
@DietID		int,
@NutrientID	int,
@MealPeriodID	int,
@Qty		decimal(10,3)
AS
	SET NOCOUNT ON

	IF(@Qty >= 9999)
		DELETE dbo.tblDietMealPeriodNutrients
		WHERE DietID = @DietID
			AND NutrientID = @NutrientID
			AND MealPeriodID = @MealPeriodID
	ELSE
	BEGIN
		UPDATE dbo.tblDietMealPeriodNutrients
		SET Qty = @Qty
		WHERE DietID = @DietID
			AND NutrientID = @NutrientID
			AND MealPeriodID = @MealPeriodID

		IF(@@ROWCOUNT = 0)
			INSERT INTO dbo.tblDietMealPeriodNutrients (DietID, NutrientID, MealPeriodID, Qty)
				VALUES (@DietID, @NutrientID, @MealPeriodID, @Qty)
	END
	RETURN
go

