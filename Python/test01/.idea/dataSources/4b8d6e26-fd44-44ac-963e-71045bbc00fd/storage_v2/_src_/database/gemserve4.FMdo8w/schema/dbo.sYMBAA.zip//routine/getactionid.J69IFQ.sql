
CREATE FUNCTION dbo.GetActionID(@ActionKEY varchar(50))
RETURNS int
AS

BEGIN
	DECLARE @Return int

	SELECT @Return = ActionID
	FROM 	tblActions
	WHERE	ActionKEY = @ActionKEY

	RETURN COALESCE(@Return,-1)
END
go

