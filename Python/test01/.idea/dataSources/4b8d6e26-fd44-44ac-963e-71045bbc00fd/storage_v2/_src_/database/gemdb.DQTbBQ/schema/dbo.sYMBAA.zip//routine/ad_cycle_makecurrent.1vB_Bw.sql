CREATE PROCEDURE [dbo].[ad_Cycle_MakeCurrent]
@User char(10),
@XlatID char(10),
@NewDate datetime

AS

	SET NOCOUNT ON
	
	DECLARE @ErrNum int,
		@FrequencyCode varchar(50),
		@BeginDate datetime,
		@Cnt int,
		@Message varchar(255),
		@Exists int,
		@LastCycleNoAdded int

	SET @ErrNum = 0

	SELECT @FrequencyCode = FrequencyCode,
	@BeginDate = BeginDate
	FROM tblCycleOHD
	WHERE XlatID = @XlatID
	
	IF @@ROWCOUNT < 1
	BEGIN
		-- no row exists for the xlatid entered
		SET @ErrNum = 10
		SET @Message = 'Updating cycle: [' + @XlatID + '] failed because no entry exists in the cycle OHD table'
		EXEC dbo.sp_Logit 9, 1, @User, @Message, 1010 
		--SELECT @ErrNum (wjs 22-Dec-10)
		RETURN @ErrNum
	END
	
	-- don't try to insert if frequency code is improper (dont bother checking if it starts with a number, it is assumed to be a pattern based cycle)
	IF ISNUMERIC(SUBSTRING(@FrequencyCode, 1, 1)) < 1
	BEGIN
		IF ( UPPER(LEFT(@FrequencyCode + 'Z', 1) )NOT IN ( 'D', 'W', 'Q','M', 'Y', 'A','B' ) ) 
			BEGIN
				SET @Message = 'Error creating cycles for cycle item [' + @XlatID + ']: frequency code ['+ @FrequencyCode + '] cannot be processed' 
				EXEC dbo.sp_Logit 9, 1, 'system', @Message, 1010 
				RETURN 11 -- wjs 22-Dec-10
			END 		
	END


	--don't try to insert if the begin date is in the future
	IF (CAST(dbo.DateOnly(@BeginDate) AS datetime) > CAST(dbo.DateOnly(GETDATE()) AS datetime)) 
		RETURN 12 -- wjs 22-Dec-10
			
	SET @Cnt = 9999 
	
	-- create new cycles until a cycle exists for the chosen date use @Cnt as a
	-- way out of an endless loop
	
	SELECT @Exists = COUNT(*)
	FROM tblCycleXlat 
	WHERE XlatID = @XlatID AND @NewDate BETWEEN BeginDate AND EndDate
	
	WHILE @Exists < 1
	BEGIN
		IF ISNUMERIC(SUBSTRING(@FrequencyCode, 1, 1)) = 1
		BEGIN
			--add a pattern based cycle because pattern based cycles BEGIN with a number
			IF NOT EXISTS (SELECT * FROM tblCycleXlat WHERE XlatID = @XlatID)
				EXEC dbo.sp_CycleXLATnew_Pattern 1, @XlatID, 1, @FrequencyCode, @BeginDate, 1 
			ELSE
				EXEC dbo.sp_CycleXLATnew_Pattern 1, @XlatID, 1, @FrequencyCode
		END
		ELSE
		BEGIN
			-- add a regular cycle
			IF NOT EXISTS (SELECT * FROM tblCycleXlat WHERE XlatID = @XlatID)
				EXEC dbo.sp_CycleXLATnew 1, @XlatID, @BeginDate, 1, @FrequencyCode
			ELSE
				EXEC dbo.sp_CycleXLATadd 1, @XlatID, 1, @FrequencyCode
		END
		
		SET @Cnt = @Cnt - 1
		
		IF @Cnt < 1
		BEGIN
			SET @ErrNum = 20
			SET @Message = 'An unknown error happened while updating the cycle table. Operation aborted'
			EXEC dbo.sp_Logit 9, 1, @User, @Message, 1010
			-- SELECT @ErrNum 
			RETURN @ErrNum -- wjs 22-Dec-10
		END
		
		SELECT @Exists = COUNT(*)
		FROM tblCycleXlat 
		WHERE XlatID = @XlatID AND @NewDate BETWEEN BeginDate AND EndDate

		--if this is the last add, let's update the lastrundate and nextrundate columns of the ohd table
		IF @Exists > 0
		BEGIN
			SELECT @LastCycleNoAdded = CycleNo
			FROM tblCycleXlat 
			WHERE XlatID = @XlatID AND @NewDate BETWEEN BeginDate AND EndDate			

			UPDATE tblCycleOHD
			SET LastRunDate = GETDATE(),
			NextRunDate = dbo.GetCycleEndDateByXREF(@LastCycleNoAdded, @XlatID)
			WHERE XlatID = @XlatID
		END
	END
	
	Return @ErrNum
go

