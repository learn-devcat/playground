

CREATE PROCEDURE dbo.ad_AccountClass_Get
@User			char(10),
@AccountClassID	int
AS
	SELECT	AccountClassID,
			Name,
			Status,
			Category,
			Flags,
			AccountType,
			ExpireDays,
			TrackingGrp,
			DailyLimit,
			DailyQtyLimit,
			Limit,
			Xref,
			CycleXrefID,
			SubType,
			IncludeAtTerm,
			Department
			--LocationID
	FROM		tblAccountClass
	WHERE	AccountClassID = @AccountClassID
go

