

CREATE PROCEDURE dbo.MenuItemKioskPriceGet
@MenuItemKioskID	int
AS
	SET NOCOUNT ON

	SELECT	MenuItemKioskPriceID,
		MenuItemKioskID,
		PriceLevel,
		Price,
		PriceBreakQuantity,
		PriceBreakDiscount
	FROM	dbo.tblMenuItemKioskPrice
	WHERE	MenuItemKioskID = @MenuItemKioskID

	RETURN
go

