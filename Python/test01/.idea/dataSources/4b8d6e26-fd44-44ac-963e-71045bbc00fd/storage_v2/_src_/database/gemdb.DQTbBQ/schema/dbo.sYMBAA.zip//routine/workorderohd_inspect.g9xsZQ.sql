
CREATE  PROCEDURE dbo.WorkorderOHD_Inspect
@User                   char(10),
@WorkorderID            int,
@EmployeeID             int,
@IDate                  varchar(20)
AS
DECLARE @InspectedDate    datetime
    SET @InspectedDate = ISNULL( @IDate , getdate())
    -- Condtion also includes Inspected, so IF already Inspected @@rowcount will = 0.
    UPDATE  tblWorkOrderOHD
        SET Inspected = 1,
            InspectingEmployeeID = @EmployeeID,
            InspectedDate       = @InspectedDate
      WHERE WorkOrderID = @WorkOrderID AND
            Inspected   = 0
    -- TODO: Record the UPDATE failure here ... could be because reccount = 0  or 
    --       @@Error is SET --
    RETURN
go

