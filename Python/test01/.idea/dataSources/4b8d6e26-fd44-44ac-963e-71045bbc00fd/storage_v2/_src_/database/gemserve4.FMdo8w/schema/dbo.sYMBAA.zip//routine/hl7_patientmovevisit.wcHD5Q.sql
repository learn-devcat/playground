CREATE PROCEDURE dbo.HL7_PatientMoveVisit
@MedicalRecordID	varchar(30),
@OldMedicalRecordID	varchar(30),
@PatientVisitID		varchar(30),
@LastName		varchar(30),
@FirstName		varchar(30),
@MiddleInitial		varchar(50),
@EntryDate		varchar(25),
@Source             	varchar(50),
@BirthDate		varchar(25),
@Gender			varchar(10),
@PatientClass		varchar(32)

AS
	SET NOCOUNT ON
	DECLARE @PatientID	int,
		@OldPatientID	int,
		@Msg		varchar(100),
		@PatientClassID	int

	BEGIN TRANSACTION
		-- Existing patient ID
		SELECT @OldPatientID = PatientID
		FROM dbo.tblPatientVisit
		WHERE PatientVisitID = @PatientVisitID

		IF (@OldPatientID IS NULL)
		BEGIN
			SET @Msg = 'Error processing Patient Move Visit for PatientVisitID [' + @PatientVisitID + ']. Patient Visit does not exist.'
			GOTO TransError
		END
	
		-- If new MRN record does not exist yet, then add it
		IF NOT EXISTS (SELECT 1 FROM dbo.tblPatientOHD WHERE MedicalRecordID = @MedicalRecordID)
		BEGIN
			SELECT @PatientClassID = dbo.PatientClassLookup(@PatientClass)
	
			INSERT INTO dbo.tblPatientOHD (Active, MedicalRecordID, LastName, FirstName, 
				    MiddleInitial, BirthDate, Gender, EnteredBy, PatientClassID)
			    VALUES (1, @MedicalRecordID, @LastName, @FirstName, 
				    @MiddleInitial, @BirthDate, @Gender, @Source, @PatientClassID)
	
			-- New patient ID
			SET @PatientID = SCOPE_IDENTITY()
		END
		ELSE
			-- New patient ID
			SELECT @PatientID = PatientID
			FROM dbo.tblPatientOHD
			WHERE MedicalRecordID = @MedicalRecordID
	
		-- Move the patient visit to the new Patient ID
		UPDATE dbo.tblPatientVisit
		SET PatientID = @PatientID
		WHERE PatientVisitID = @PatientVisitID
	
		-- Update patient allergens
		UPDATE dbo.tblPatientAllergens
		SET PatientID = @PatientID
		WHERE PatientID = @OldPatientID
	
		-- Update Patient Daily Nutrient Overrides
		UPDATE dbo.tblPatientDailyNutrientOverride
		SET PatientID = @PatientID
		WHERE PatientID = @OldPatientID
	
		-- Update Patient Log
		UPDATE dbo.tblPatientLog
		SET PatientID = @PatientID
		WHERE PatientID = @OldPatientID
	
		-- Update Patient Meal Period Nutrient Overrides
		UPDATE dbo.tblPatientMealPeriodNutrientOverride
		SET PatientID = @PatientID
		WHERE PatientID = @OldPatientID
	
		-- Update Patient Nutrient Count
		UPDATE dbo.tblPatientNutrientCount
		SET PatientID = @PatientID
		WHERE PatientID = @OldPatientID
	
		-- Update Orders
		UPDATE dbo.tblOrderOHD
		SET PatientID = @PatientID
		WHERE PatientID = @OldPatientID

	COMMIT TRANSACTION

	SET @Msg = 'Moved patient visit from patient MRN [' + @OldMedicalRecordID + '] to MRN [' + @MedicalRecordID + '].'
	EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, '', 0, @Msg
	EXEC dbo.ProcessLogInsert @Source

	RETURN

TransError:
	ROLLBACK TRANSACTION

	IF (@Msg IS NULL)
		SET @Msg = 'Error processing Patient Move Visit for PatientVisitID [' + @PatientVisitID + '].'

	EXEC dbo.Logit 1, @Msg, 'system'

	RETURN
go

