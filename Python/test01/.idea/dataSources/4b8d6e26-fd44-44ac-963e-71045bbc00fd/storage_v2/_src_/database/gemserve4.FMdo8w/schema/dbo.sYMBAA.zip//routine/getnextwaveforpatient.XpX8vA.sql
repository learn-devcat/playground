
CREATE FUNCTION dbo.GetNextWaveForPatient(@WaveID int,@PatientID int)
RETURNS int
AS

BEGIN
	DECLARE @Return int,
		@EndTime varchar(5),
		@MealPeriodID	int

	SELECT @EndTime = EndTime,
		@MealPeriodID = MealPeriodID
	FROM dbo.tblWave
	WHERE WaveID = @WaveID

	SELECT TOP 1 @Return = W.WaveID
	FROM dbo.tblWave AS W
		JOIN dbo.tblDietWave AS DW ON W.WaveID = DW.WaveID AND DW.Active = 1
		JOIN dbo.tblPatientOHD AS P ON P.PatientID = @PatientID
		JOIN dbo.tblPatientVisit AS PV ON P.PatientID = PV.PatientID
		JOIN dbo.tblPatientDiet AS PD (NOLOCK) ON PV.PatientVisitID = PD.PatientVisitID AND PD.DietID = DW.DietID
	WHERE W.EndTime > @EndTime
		AND W.MealPeriodID <> @MealPeriodID
	ORDER BY W.EndTime

	RETURN ISNULL(@Return,-1)
END
go

