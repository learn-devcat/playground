CREATE PROCEDURE dbo.PatientAllergiesUpdate
@User		varchar(200),
@PatientID	int,
@Allergies	varchar(6000)

AS
	DECLARE @MedicalRecordID	varchar(50)

	SELECT @MedicalRecordID = MedicalRecordID
	FROM dbo.tblPatientOHD
	WHERE PatientID = @PatientID

	EXEC dbo.PatientAllergiesUpdateEX @User, @MedicalRecordID, @Allergies

	RETURN
go

