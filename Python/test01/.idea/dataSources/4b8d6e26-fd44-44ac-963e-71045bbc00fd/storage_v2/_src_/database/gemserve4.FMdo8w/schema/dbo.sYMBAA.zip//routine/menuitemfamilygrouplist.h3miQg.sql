

CREATE PROCEDURE dbo.MenuItemFamilyGroupList

AS
	SET NOCOUNT ON

	SELECT 	MenuItemFamilyGroupID,
		FAM_GRP_SEQ,
		OBJ_NUM,
		[NAME]
	FROM	dbo.tblMenuItemFamilyGroup
	WHERE   [NAME] IS NOT NULL

	RETURN
go

