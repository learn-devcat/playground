
CREATE FUNCTION dbo.GetNextDateForWave(@WaveID int, @Today datetime)
RETURNS datetime
AS
BEGIN
	DECLARE @Return 	datetime,
		@Temp		int,
		@BeginTime	char(5),
		@PrepTime	varchar(10)

	SELECT @PrepTime = dbo.GetOverheadValue('MinimumPrepTime')
	IF(@PrepTime = '')
		SET @PrepTime = '30'

	SELECT TOP 1 @Temp = WaveID,
		@BeginTime = BeginTime
	FROM tblWave
	WHERE WaveID = @WaveID
		AND EndTime >= dbo.TimeString(DATEADD(mi,CAST(@PrepTime AS integer),@Today))
	ORDER BY EndTime

	IF(@Temp IS NULL)
		SELECT @Return = dbo.dDatePlusNewTime(@Today + 1,BeginTime)
			FROM tblWave WHERE WaveID = @WaveID
	ELSE
		SET @Return = dbo.dDatePlusNewTime(@Today,@BeginTime)
		

	RETURN @Return
END
go

