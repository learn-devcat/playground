CREATE PROCEDURE [dbo].[sp_Dashboard_UpdatePosition]
	@User			char(10),
	@DashboardID    int,
	@NewTop			int,
	@NewLeft		int
AS

	DECLARE @ExistingID int,
			@ExistingName varchar(50)

	Select @ExistingName = Name 
	FROM tblDashboardPages
	WHERE ID = @DashboardID

	Select @ExistingID = ID
	FROM tblDashboardPages
	WHERE UserID = @User 
	AND Name = @ExistingName

	IF (@ExistingID IS NULL)
	BEGIN
	   INSERT INTO tblDashboardPages(Name, UserID, SerializedRequestData, PageURL, UserHidden, SortPosition, PrivilegeActionID,GoToURL,AllowInteraction,AbsoluteTop,AbsoluteLeft)
	   	SELECT Top 1 Name,@User,SerializedRequestData, PageURL ,0,99,PrivilegeActionID,GoToURL,AllowInteraction,@NewTop,@NewLeft
		FROM tblDashboardPages
		WHERE ID = @DashboardID
	END
	ELSE
	BEGIN
		Update tblDashboardPages
		Set AbsoluteTop = @NewTop,
		AbsoluteLeft = @NewLeft
		WHERE UserID = @User
		AND Name = @ExistingName
	END
go

