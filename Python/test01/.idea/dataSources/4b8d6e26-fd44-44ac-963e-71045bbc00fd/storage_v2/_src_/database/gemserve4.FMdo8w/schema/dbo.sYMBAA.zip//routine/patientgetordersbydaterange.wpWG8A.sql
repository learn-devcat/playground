CREATE PROCEDURE [dbo].[PatientGetOrdersByDateRange]
@PatientID INT, @BeginDate DATETIME, @EndDate DATETIME
AS
SET NOCOUNT ON

	DECLARE @Delivered	int,
			@Today	datetime

	SET @Today = getdate()

	SELECT @Delivered = ActionID
	FROM dbo.tblActions
	WHERE ActionKey = 'Delivered'

	SELECT	O.OrderID,
		CASE WHEN O.OrderType = 2 THEN 'guest'
			WHEN O.OrderType = 4 THEN 'parent'
			WHEN O.OrderType = 6 THEN 'Dr.'
			WHEN O.OrderType = 7 THEN 'stork'
		ELSE 'self'
		END AS OrderedFor,
		O.OrderDate,
		O.SentDate,
		O.Cancelled,
		O.CancelDate,
		O.CheckNo,
		W.Description AS Wave,
		OL.[Date] AS DeliveryTime,
		OL.LoginUserID AS DeliveredBy,
 		CASE WHEN ISNULL(O.Cancelled,0) = 1 THEN 'Cancelled'
 			ELSE dbo.GetActionDescription(dbo.GetOrderStatus(O.OrderID))
 		END AS OrderStatus,
		dbo.GetOrderStatus(O.OrderID) AS Status,
		dbo.DateStringFormat(O.OrderDate,-1,@Today) + ' ' + dbo.GetMealPeriodNameForOrder(O.OrderID) AS MealPeriod,
		K.Description AS Kitchen
	FROM dbo.tblOrderOHD AS O (NOLOCK)
	LEFT JOIN dbo.tblKitchens AS K (NOLOCK) ON O.SentToKitchenId = K.KitchenId
	LEFT JOIN dbo.tblOrderLog AS OL (NOLOCK) ON O.OrderID = OL.OrderID AND OL.ActionID = @Delivered
	LEFT JOIN dbo.tblWave AS W (NOLOCK) ON O.WaveID = W.WaveID
	WHERE O.PatientID = @PatientID
		AND O.OrderDate BETWEEN @BeginDate AND @EndDate
	ORDER BY O.OrderDate, O.PostDate

	RETURN
go

