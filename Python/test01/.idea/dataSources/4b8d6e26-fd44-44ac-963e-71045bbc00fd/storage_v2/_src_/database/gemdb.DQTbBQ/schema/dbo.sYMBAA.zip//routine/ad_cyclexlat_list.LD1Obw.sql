

CREATE PROCEDURE dbo.ad_CycleXlat_List
AS
    SELECT  XlatID,
            FrequencyCode,
            LastChangeDate,
            BeginDate
    FROM    dbo.tblCycleOHD
go

