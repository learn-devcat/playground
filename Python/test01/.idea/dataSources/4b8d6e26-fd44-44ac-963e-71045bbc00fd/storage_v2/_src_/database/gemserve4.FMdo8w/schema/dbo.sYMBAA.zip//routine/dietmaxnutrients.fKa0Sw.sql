
CREATE FUNCTION [dbo].[DietMaxNutrients](@PatientDietID int, @FieldSeparator char(1))
RETURNS varchar(255)
BEGIN
	DECLARE @Return 	varchar(255),
		@NutrientID	int,
		@DefaultQty	decimal(10,3),
		@DietQty	decimal(10,3),
		@Qty		decimal(10,3),
		@DietID		int

	SET @Return = ''
	SELECT @DietID = DietID
	FROM dbo.tblPatientDiet
	WHERE [ID] = @PatientDietID

	IF (@DietID IS NULL)
		RETURN ''

	-- Cursor to retrieve all nutrients and dailymax for the diet
	DECLARE Nutrients cursor FOR
		SELECT  NutrientID, DefaultQty
		FROM 	cfgNutrients (NOLOCK)
		ORDER BY NutrientID

	OPEN Nutrients
	FETCH NEXT FROM Nutrients INTO @NutrientID, @DefaultQty

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @Qty = NULL
		SET @DietQty = NULL

		-- Get the patient nutrient override if it exists
		SELECT @Qty = Qty FROM dbo.tblPatientDailyNutrientOverride
		WHERE PatientDietID = @PatientDietID 
			AND NutrientID = @NutrientID

		SELECT @DietQty = DailyMax
		FROM dbo.tblDietDailyNutrients
		WHERE DietID = @DietID
			AND NutrientID = @NutrientID

		-- If not patrient nutrient override, get the diet daily value if it exists
		SET @Qty = COALESCE(@Qty,@DietQty, @DefaultQty)

		-- If Qty is null, write the nutrient default for this diet
		SET @Return = @Return +@FieldSeparator + CAST(CAST(@Qty * 1000 AS int) AS varchar(10))
		
		FETCH NEXT FROM Nutrients INTO @NutrientID, @DefaultQty
	END

	CLOSE Nutrients
	DEALLOCATE Nutrients

	IF (LEN(@Return) > 0)
		SET @Return = RIGHT(@Return,LEN(@Return)-1)

	RETURN @Return	
END
go

