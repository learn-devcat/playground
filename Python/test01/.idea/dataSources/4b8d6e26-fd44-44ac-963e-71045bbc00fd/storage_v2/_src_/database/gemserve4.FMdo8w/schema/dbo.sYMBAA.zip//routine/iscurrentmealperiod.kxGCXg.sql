

CREATE FUNCTION dbo.IsCurrentMealPeriod(@MealPeriodID int, @Today datetime)
RETURNS bit
AS
BEGIN
	DECLARE @Return bit,
		@MP int

	SELECT @MP = MealPeriodID FROM tblWave WHERE
		dbo.TimeString(BeginTime) < dbo.TimeString(@Today) 
		AND dbo.TimeString(EndTime) > dbo.TimeString(@Today)
		AND MealPeriodID = @MealPeriodID

	IF COALESCE(@MP,0) > 0
		SET @Return = 1
	ELSE
		SET @Return = 0

	RETURN @Return		
END
go

