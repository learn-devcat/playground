

CREATE FUNCTION dbo.TimeOnly (@WholeDate smalldatetime)
RETURNS char(5)
AS 
BEGIN 
	DECLARE @Hour char(2),
		 @Minute char(2)
	
	SET @Hour=CAST(DATEPART(hour,@WholeDate) AS varchar(2))
	IF LEN(RTRIM(@Hour))=1
		BEGIN
			SET @Hour='0' + @Hour
		END
	
	SET @Minute=CAST(DATEPART(minute,@WholeDate) AS varchar(2))
	IF LEN(RTRIM(@Minute))=1
		BEGIN
			SET @Minute='0' + @Minute
		END
	RETURN @Hour + ':' + @Minute
END
go

