
CREATE PROCEDURE dbo.GetRandomIDStringEX
AS
	DECLARE @Return	varchar(50),
		@NextID varchar(50)

	SELECT @NextID = dbo.GetOverheadValue('NextPatientVisitID')
	SELECT @Return = @NextID
	SET @NextID = CAST(CAST(@NextID as int) + 1 AS varchar(50))

	UPDATE dbo.cfgOverhead SET Value = @NextID WHERE KeyID = 'NextPatientVisitID'

	RETURN @Return
go

