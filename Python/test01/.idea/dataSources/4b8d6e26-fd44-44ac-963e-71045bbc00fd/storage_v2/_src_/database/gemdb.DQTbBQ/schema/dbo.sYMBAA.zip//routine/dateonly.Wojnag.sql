

CREATE FUNCTION dbo.DateOnly (@WholeDate datetime)
RETURNS char(10)
AS 
BEGIN 
	RETURN
	CAST(DATEPART(year,@WholeDate) AS varchar(4)) + '/' +
	CAST(DATEPART(month,@WholeDate) AS varchar(2)) + '/' + CAST(DATEPART(day,@WholeDate) AS varchar(2))
	 
END
go

