

CREATE       PROCEDURE [dbo].[sp_Recur_Update]
@User			char(10),
@RecurID		uniqueidentifier,
@AccountNo		char(19),
@ClassID		int,
@AcctClassID	int,
@TransID		int,
@Description	char(24),
@Amount			money,
@Percent		money,
@Minimum		bit,
@Balance		bit,
@PastDue		bit,
@TrackSlotNum	int,
@TrackIDNum		int,
@tax1			bit,
@tax2			bit,
@tax3			bit,
@tax4			bit,
@Active			bit,
@AllowNegAmt		bit,
@BatchID		char(10),
@ExpiredAccountsOnly	bit, 
@PostToAltAccount	bit, 
@AltAccountNo		varchar(19), 
@AltBadgeNo		varchar(19), 
@AltTransID		INT,
@Formula		VARCHAR(500)
		
AS 
		SET Nocount ON

		UPDATE 	tblRecurChg
		SET		AccountNo = @AccountNo,
				ClassID = @ClassID,
				AcctClassID = @AcctClassID,
				TransID = @TransID,
				Description = @Description,
				Amount = @Amount,
				[Percent] = @Percent,
				Minimum = @Minimum,
				Balance = @Balance,
				PastDue = @PastDue,
				TrackSlotNum = @TrackSlotNum,
				TrackIDNum = @TrackIDNum,
				Tax1 = @tax1,
				Tax2 = @tax2,
				Tax3 = @tax3,
				Tax4 = @tax4,
				Active = @Active,
				AllowNegAmt = @AllowNegAmt,
				BatchID = @BatchID,
				ExpiredAccountsOnly = @ExpiredAccountsOnly,
				PostToAltAccount = @PostToAltAccount,
				AltAccountNo = @AltAccountNo, 
				AltBadgeNo = @AltBadgeNo, 
				AltTransID = @AltTransID,
				Formula = @Formula

		WHERE	RecurID = @RecurID

		SELECT @@Error
go

