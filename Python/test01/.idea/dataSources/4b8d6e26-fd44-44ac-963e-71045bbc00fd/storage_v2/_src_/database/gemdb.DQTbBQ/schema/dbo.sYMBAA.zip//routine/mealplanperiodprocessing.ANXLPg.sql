CREATE PROCEDURE dbo.MealPlanPeriodProcessing
    @User VARCHAR(15) = 'System'
AS 
    SET NOCOUNT ON
	

    DECLARE @AccountNO VARCHAR(20)
    DECLARE @MealPlanID INT
    DECLARE @PeriodsRemain INT
    DECLARE @Freq VARCHAR(10)
    DECLARE @ReloadQty INT
    DECLARE @ReloadBalance MONEY
    DECLARE @ActiveDate DATETIME
    DECLARE @ExpireDate DATETIME
    DECLARE @Count INT
    DECLARE @Msg VARCHAR(250)

    DECLARE Plans CURSOR
		--notice right JOIN
        FOR SELECT  M.AccountNo,
                    M.MealPlanID,
                    PeriodsRemain,
                    Freq,
                    ReloadQty,
                    ReloadBalance
            FROM    tblAccountMeal M
                    INNER JOIN tblPlanOHD P ON M.MealPlanID = P.MealPlanID
            WHERE   m.AccountNo NOT IN (
                    SELECT  accountNo
                    FROM    tblAccountMealTTL
                    WHERE   dbo.ddateonly(GETDATE()) BETWEEN dbo.dDateOnly(ActiveDate)
                                                     AND     dbo.dDateOnly(ExpireDate) )
                    AND ( M.PeriodsRemain > 0 )
                    AND ( M.Active > 0 )

    OPEN Plans

    SET @Count = 0
		
    FETCH NEXT FROM Plans INTO @AccountNO, @MealPlanID, @PeriodsRemain, @Freq,
        @ReloadQty, @ReloadBalance

	-- Now loop through all plans requiring a new ttl.
    WHILE ( @@FETCH_STATUS = 0 ) 
        BEGIN
            SELECT  @ActiveDate = ActiveDate,
                    @ExpireDate = ExpireDate
            FROM    tblAccountMealTTL
            WHERE   AccountNO = @AccountNO
                    AND MealPlanID = @MealPlanID
            ORDER BY ExpireDate 
		
            SET @ActiveDate = @ExpireDate + 1
            SET @ExpireDate = dbo.NextDateByFrequency(@ExpireDate, @Freq, 0) -- Expire Date
			
            SET @Count = @Count + 1

            INSERT  INTO tblAccountMealTTL
                    (
                      AccountNo,
                      MealPlanID,
                      ActiveDate,
                      ExpireDate,
                      CurrentCount,
                      CurrentBalance 
                    )
            VALUES  (
                      @AccountNo,
                      @MealPlanID,
                      @ActiveDate,
                      @ExpireDate,
                      @ReloadQty,
                      @ReloadBalance 
                    )

            UPDATE  tblAccountMeal
            SET     PeriodsRemain = PeriodsRemain - 1
            WHERE   AccountNo = @AccountNO
                    AND MealPlanID = @MealPlanID

            FETCH NEXT FROM Plans INTO @AccountNO, @MealPlanID, @PeriodsRemain,
                @Freq, @ReloadQty, @ReloadBalance
        END

	-- Do our housekeeping.
    CLOSE Plans
    DEALLOCATE Plans


    SET @Msg = 'Meal Plan Processing:  Processed '
        + CAST(@Count AS VARCHAR(15)) + ' TTL(s)'		
    EXEC dbo.sp_logit 0, 1, @User, @Msg

	
    RETURN
go

