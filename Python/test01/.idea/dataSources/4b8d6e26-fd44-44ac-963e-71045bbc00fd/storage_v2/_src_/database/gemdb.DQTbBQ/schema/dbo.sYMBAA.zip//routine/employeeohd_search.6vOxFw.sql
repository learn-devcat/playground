CREATE        PROCEDURE [dbo].[EmployeeOHD_Search]
@User			char(10),
@LocationID     	int,
@Condition      	varchar(128) = null,
@ClassID		int = 0,
@LaborCenterID		int = 0
AS
    SET @Condition = ISNULL( @Condition , '' )
    /*
        Procedure: EmployeeOHD_Search
           Author: Wolf Scott
             Date: 25-May-05
        Revisions:  - Added search by labor center 7-21-2005 (RBeverly)
		    - Added where location IN locations for user
    */
    
    -- I've made this two different statements for ease of creation at the moment,
    -- however, this could be changed to a single SELECT.  Be sure to change
    -- both selects IF you are making a change ... :)
    IF (@Condition = '' AND @ClassID = 0 AND @LaborCenterID = 0)
      BEGIN
	    SELECT  	E.EmployeeID,
			E.EmployeeClassID,
			C.EmployeeClassName,
			C.Description,
			RTRIM(LastName) + ', ' + RTRIM(FirstName) AS FullName,
			FirstName,
			LastName,
			PhoneNumber,
			CellNumber,
			PagerNumber,
			eMail,
			SkillLevel,
			LocationID,
            LogonHours,
            CanCreateWorkOrder,
            CanDeleteWorkOrder,
            CanCloseWorkOrder,
            CanPrintWorkOrder,
            CanCompleteWorkOrderDTL,
            CanAddWorkOrderDTL,
            CanDeleteWorkOrderDTL		
	    FROM	tblEmployeeOHD E
	    			LEFT JOIN 
			tblEmployeeClass C ON C.EmployeeClassID = E.EmployeeClassID
	    WHERE   LocationID IN (SELECT LocationID FROM cfgUserLocations WHERE UserID = @User) AND E.EmployeeID <> 1
	    ORDER BY	LastName, FirstName
      END
    ELSE IF (@ClassID > 0)
      BEGIN
	    SELECT  	E.EmployeeID,
			E.EmployeeClassID,
			C.EmployeeClassName,
			C.Description,
			RTRIM(LastName) + ', ' + RTRIM(FirstName) AS FullName,
			FirstName,
			LastName,
			PhoneNumber,
			CellNumber,
			PagerNumber,
			eMail,
			SkillLevel,
			LocationID,
	                LogonHours,
	                CanCreateWorkOrder,
	                CanDeleteWorkOrder,
	                CanCloseWorkOrder,
	                CanPrintWorkOrder,
	                CanCompleteWorkOrderDTL,
	                CanAddWorkOrderDTL,
	                CanDeleteWorkOrderDTL	
	  
	    FROM    	tblEmployeeOHD E
	    			LEFT JOIN 
			tblEmployeeClass C ON C.EmployeeClassID = E.EmployeeClassID
	    WHERE   LocationID IN (SELECT LocationID FROM cfgUserLocations WHERE UserID = @User) 
		    AND E.EmployeeClassID = @ClassID AND E.EmployeeID <> 1
	    ORDER BY LastName, FirstName
      END
   ELSE IF @LaborCenterID <> 0
      BEGIN
	    SELECT  	E.EmployeeID,
			E.EmployeeClassID,
			C.EmployeeClassName,
			C.Description,
			RTRIM(LastName) + ', ' + RTRIM(FirstName) AS FullName,
			FirstName,
			LastName,
			PhoneNumber,
			CellNumber,
			PagerNumber,
			eMail,
			SkillLevel,
			LocationID,
	                LogonHours,
	                CanCreateWorkOrder,
	                CanDeleteWorkOrder,
	                CanCloseWorkOrder,
	                CanPrintWorkOrder,
	                CanCompleteWorkOrderDTL,
	                CanAddWorkOrderDTL,
	                CanDeleteWorkOrderDTL	
	  
	    FROM    	tblEmployeeOHD E
	    			LEFT JOIN 
			tblEmployeeClass C on C.EmployeeClassID = E.EmployeeClassID
	    WHERE   LocationID IN (SELECT LocationID FROM cfgUserLocations WHERE UserID = @User) AND
		    LaborCenterID = @LaborCenterID AND E.EmployeeID <> 1
	    ORDER BY LastName, FirstName
      END	
   ELSE
      BEGIN
	    SELECT  	E.EmployeeID,
			E.EmployeeClassID,
			C.EmployeeClassName,
			C.Description,
			RTRIM(LastName) + ', ' + RTRIM(FirstName) as FullName,
			FirstName,
			LastName,
			PhoneNumber,
			CellNumber,
			PagerNumber,
			eMail,
			SkillLevel,
			LocationID,
	                LogonHours,
	                CanCreateWorkOrder,
	                CanDeleteWorkOrder,
	                CanCloseWorkOrder,
	                CanPrintWorkOrder,
	                CanCompleteWorkOrderDTL,
	                CanAddWorkOrderDTL,
	                CanDeleteWorkOrderDTL	
	  
	    FROM    	tblEmployeeOHD E
	    			LEFT JOIN 
			tblEmployeeClass C on C.EmployeeClassID = E.EmployeeClassID
	    WHERE   LocationID IN (SELECT LocationID FROM cfgUserLocations WHERE UserID = @User) AND
	             (Lastname like @Condition OR
	             Firstname like @Condition) AND E.EmployeeID <> 1
	    ORDER BY LastName, FirstName
      END
go

