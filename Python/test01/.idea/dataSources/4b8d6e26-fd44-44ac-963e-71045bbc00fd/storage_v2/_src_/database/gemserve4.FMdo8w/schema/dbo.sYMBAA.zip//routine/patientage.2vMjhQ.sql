CREATE FUNCTION [dbo].[PatientAge](@DateOfBirth as datetime, @Today as datetime)
RETURNS int
AS
BEGIN
	DECLARE @Return int

		-- roll back 100 years if the birthdate has not occured yet to fix 2 digit year from being incorrect
		IF (@DateOfBirth > getdate())
			SET @DateOfBirth =DATEADD(year,-100,@DateOfBirth)

        SET @Return = DATEDIFF(yy,@DateOfBirth, @Today)

        -- deduct one from the year if the month has not occurred yet
        IF (MONTH(@DateOfBirth) > MONTH(@Today))
                SET @Return = @Return - 1
        
        -- deduct one from the year if the month is the same, but the day has not occurred yet
        IF ((MONTH(@DateOfBirth) = MONTH(@Today)) AND (DAY(@DateOfBirth) > DAY(@Today)))
                SET @Return = @Return - 1
        
        RETURN @Return
END
go

