CREATE FUNCTION dbo.PatientAllergens(@PatientID int)
RETURNS varchar(500)
BEGIN
	DECLARE @Return varchar(255),
		@Allergen varchar(50),
		@ORMSeparator varchar(10)

	SELECT @ORMSeparator = COALESCE(dbo.GetOverheadValueNull('ORMSeparator'),'|')

	SET @Return = ''

	DECLARE Allergens cursor FOR
		SELECT A.Description
		FROM	tblPatientAllergens AS P (NOLOCK)
			JOIN cfgAllergens AS A (NOLOCK) ON P.AllergenID = A.AllergenID
		WHERE	P.PatientID = @PatientID
		ORDER BY A.AllergenID

	OPEN Allergens

	FETCH NEXT FROM Allergens INTO @Allergen

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @Return = @Return + @ORMSeparator + @Allergen
		
		FETCH NEXT FROM Allergens INTO @Allergen
	END

	CLOSE Allergens
	DEALLOCATE Allergens

	IF (LEN(@Return) > 0)
		SET @Return = RIGHT(@Return,LEN(@Return)-1)

	RETURN @Return	
END
go

