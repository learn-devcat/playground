

CREATE PROCEDURE dbo.DietGet
	(
		@DietID int
	)
AS
    SELECT  DietID,
            Description,
            AltDescription,
            POSDietID,
            POSDescription,
            Notes
    FROM    dbo.tblDietOHD
    WHERE   DietID = @DietID

	RETURN
go

