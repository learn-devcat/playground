CREATE PROCEDURE dbo.GetDelimitedStringFromTableColumn
	@TableName varchar(50), 
	@ColumnName	varchar(50), 
	@WhereClause varchar(800), 
	@Delimiter char(1),
	@Rtn varchar(2000) OUTPUT
AS
	DECLARE @RowNum		int,
			@Field		varchar(500),
			@BuildUp	varchar(2000)

	/*
		This Procedure returns a delimited string containing teh result of a rowset of a single column 
		from the specified table. The specified column must be castable as a varchar(500).
		An empty string for the @WhereClause parameter will return all rows.
		The OUTPUT key MUST be used in the @Rtn parameter to get the return data.

		Should be called in the following manner:
 
			EXEC dbo.GetDelimitedStringFromQuery	'MyTabe', 
										'MyColumn', 
										'MyColumn = MyValue', 
										',',
										 @MyReturnVariable OUTPUT
	*/

	SET @RowNum = 1

	CREATE TABLE #MyTable (Field varchar(500), Processed bit)
	DECLARE @sql nvarchar(2000)

	IF @WhereClause <> '' AND CHARINDEX('WHERE', @WhereClause) = 0
		SET @WhereClause = ' WHERE ' + @WhereClause
	
	SET @sql = N'INSERT INTO #MyTable 
					SELECT CAST(' + @ColumnName + ' AS varchar(500)), 0
					FROM ' + @TableName + @WhereClause

	EXECUTE sp_executesql @sql	

	SET @BuildUp = ''	
	
	WHILE 1 = 1 
	BEGIN
		SELECT	TOP 1 @Field = Field
		FROM	#MyTable
		WHERE	Processed = 0

		IF @@ROWCOUNT < 1
			BREAK
		SET @BuildUp = @BuildUp + ',' +  @Field
		
		UPDATE	#MyTable
		SET		Processed = 1
		WHERE	Field = @Field
	END

	DROP TABLE #MyTable

	SET @Rtn = RIGHT(@BuildUp, LEN(@BuildUp) - 1)
go

