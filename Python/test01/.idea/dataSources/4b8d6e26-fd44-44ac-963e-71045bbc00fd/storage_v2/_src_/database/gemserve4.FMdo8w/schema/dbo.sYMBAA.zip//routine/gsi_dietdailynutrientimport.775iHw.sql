
CREATE PROCEDURE [dbo].[GSI_DietDailyNutrientImport]
@LoginUserID		varchar(250),
@DietID	int,
@NutrientName	varchar(50),
@DailyMax	decimal(10,3)
AS
	SET NOCOUNT ON

	DECLARE @NutrientID int,
			@Return int
	
	SET @Return =-1

	SELECT 	@NutrientID = NutrientID
	FROM	dbo.cfgNutrients
	WHERE	[Description] = @NutrientName

	-- Return -1 if Nutrient doesn't exist
	IF (@@RowCount = 0)
	BEGIN
		SET @Return = -1
		GOTO Finished
	END

	IF NOT EXISTS (SELECT 1 FROM dbo.tblDietDailyNutrients WHERE (DietID = @DietID) AND (NutrientID = @NutrientID) AND (DailyMax = @DailyMax))
	BEGIN
		INSERT INTO dbo.tblDietDailyNutrients (DietID, NutrientID, DailyMax)
			VALUES (@DietID, @NutrientID, @DailyMax)

		SELECT @Return = SCOPE_IDENTITY()
	END
	ELSE
	BEGIN
		-- Entry already exists in tblDietDailyNutrients table
		SET @Return = -3		
	END

Finished:
	-- Return -1 if Nutrient doesn't exist, -3 if rblDietDailyNutrient entry already exists,  otherwise return id
	SELECT @Return AS ErrorMessage
	RETURN
go

