

CREATE PROCEDURE dbo.GEM_SecurityLinkInsert
@LoggedInUser  varchar(250),
@RoleID        int,
@ActionID      int

AS

	INSERT INTO dbo.tblSecurityRoleActions (RoleID, ActionID)
                VALUES (@RoleID, @ActionID)

        RETURN
go

