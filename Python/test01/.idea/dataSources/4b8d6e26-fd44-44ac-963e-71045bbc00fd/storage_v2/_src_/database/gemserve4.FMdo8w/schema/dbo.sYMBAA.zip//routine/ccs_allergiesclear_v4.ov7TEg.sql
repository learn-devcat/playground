CREATE PROCEDURE [dbo].[CCS_AllergiesClear_v4]
@PatientVisitID	varchar(50),
@MedicalRecordID varchar(50),
@Source			varchar(50),
@ConnectionName	varchar(50)=''

AS
	SET NOCOUNT ON

	DECLARE @PatientID	int,
			@Msg		varchar(300)

	-- Get PatientID from either MedicalRecordID or PatientVisitID
	IF (@PatientVisitID = '')
		SELECT @PatientID = PatientID
		FROM dbo.tblPatientOHD
		WHERE MedicalRecordID = @MedicalRecordID
	ELSE
		SELECT @PatientID = PatientID
		FROM dbo.tblPatientVisit
		WHERE PatientVisitID = @PatientVisitID

	-- PatientID not found so log it
	IF (@PatientID IS NULL)
	BEGIN
		IF (@PatientVisitID <> '')
			SET @Msg = 'Unable to clear patient allergens for PatientVisitID [' + @PatientVisitID + ']. Patient not found.' 
		ELSE
			SET @Msg = 'Unable to clear patient allergens for MedicalRecordID [' + @MedicalRecordID + ']. Patient not found.'
		EXEC dbo.Logit 1, @Msg, 'system'		

		GOTO Finish
	END

	-- Delete all patient allergens
	DELETE dbo.tblPatientAllergens
	WHERE PatientID = @PatientID

Finish:
	SET @ConnectionName = 'Idt' + @ConnectionName
	EXEC dbo.WorkstationUpdateByID @ConnectionName

	RETURN


go

