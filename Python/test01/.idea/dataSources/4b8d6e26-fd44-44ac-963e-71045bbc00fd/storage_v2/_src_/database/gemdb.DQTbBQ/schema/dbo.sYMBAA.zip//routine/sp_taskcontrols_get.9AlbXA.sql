CREATE PROCEDURE [dbo].[sp_TaskControls_Get]
	@TaskId int
AS

	SELECT * 
	FROM dbo.TaskControls	
	WHERE TaskId = @TaskId
	ORDER BY Sequence
go

