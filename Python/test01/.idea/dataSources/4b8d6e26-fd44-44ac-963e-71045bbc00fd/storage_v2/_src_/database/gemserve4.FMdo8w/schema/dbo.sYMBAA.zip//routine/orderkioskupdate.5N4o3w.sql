

CREATE PROCEDURE dbo.OrderKioskUpdate
    @OrderID  int output,
    @PatientID int,
    @WaveID int,
    @OrderDetail varchar(2000),
    @LocationID int,
    @OrderName varchar(100),
    @DeliveryDate datetime,
    @DeliveryDirections varchar(300),
    @Comments varchar(500),	
    @WorkstationID int = 0,
    @OutletNo int = 0,
    @OrderEmployee int = 0,
    @OrderEmployeeName varchar(30),
    @OrderDate datetime = NULL,           -- if this is null, the database defaults to now.
    @SubLevel int = 0,
    @StandingOrder bit = 0,
    @CheckNo varchar(20) = '',
    @Subtotal money = 0,
    @DeliveryCharge Money = 0,
    @Tip money = 0
AS
	SET NOCOUNT ON

	IF( @OrderDate IS NULL )            -- ensure we have a valid order date.
	    SET @OrderDate = getdate()

BEGIN TRANSACTION
		    
	IF(@OrderID > 0)
	BEGIN
		UPDATE dbo.tblOrderOHD
			SET LocationID = @LocationID,
			WorkstationID = @WorkstationID,
			OutletNo = @OutletNo,
			WaveID = @WaveID,
			OrderEmployee = @OrderEmployee,
			OrderEmployeeName = @OrderEmployeeName,
			OrderDate = @OrderDate,
			CheckNo = @CheckNo,
			PatientID = @PatientID,
			SubLevel = @SubLevel
		WHERE OrderID = @OrderID
	
		IF (@@Error <> 0)
			GOTO ErrorHandler
		
		UPDATE dbo.tblOrderEX
			SET OrderName = @OrderName,
			DeliveryDate = @DeliveryDate,
			DeliveryDirections = @DeliveryDirections,
			Comments = @Comments
		WHERE	OrderID = @OrderID

		IF (@@Error <> 0)
			GOTO ErrorHandler


		UPDATE dbo.tblOrderDTL 
			SET OrderDetail = @OrderDetail
		WHERE	OrderID = @OrderID

		IF (@@Error <> 0)
			GOTO ErrorHandler

	END
	ELSE	
	BEGIN
		INSERT INTO dbo.tblOrderOHD (LocationID, WorkstationID, OutletNo, WaveID, OrderEmployee, 
				OrderEmployeeName, OrderDate, CheckNo, PatientID, SubLevel, 
				Subtotal, DeliveryCharge, Tip, StandingOrder) 
	                VALUES  (@LocationID,@WorkstationID,@OutletNo,@WaveID,@OrderEmployee,
				@OrderEmployeeName,@OrderDate,@CheckNo,@PatientID,@SubLevel,
				@SubTotal,@DeliveryCharge,@Tip, @StandingOrder)

		IF (@@Error <> 0)
			GOTO ErrorHandler

		-- Send the new orderID back to the caller.
       		SET @OrderID = SCOPE_IDENTITY()

		INSERT INTO dbo.tblOrderEX (OrderID, OrderName, DeliveryDate, DeliveryDirections, Comments)
			VALUES (@OrderID, @OrderName, @DeliveryDate, @DeliveryDirections, @Comments)
		IF (@@Error <> 0)
			GOTO ErrorHandler

       		INSERT INTO dbo.tblOrderDTL ( OrderID ,  OrderDetail ) 
               		VALUES (@OrderID , @OrderDetail )
		IF (@@Error <> 0)
			GOTO ErrorHandler
	END

	EXEC dbo.UpdateOrderLog @OrderEmployeeName, @OrderID , 'ADDORDER'
  
ErrorHandler:
	IF( @@ERROR <> 0 )                      -- could get a bit fancier here but
		ROLLBACK TRANSACTION                -- for now, any error aborts...
	ELSE                    
		COMMIT TRANSACTION
        
	RETURN
go

