

CREATE PROCEDURE dbo.sp_Overhead_GetKeys
@SearchKey	varchar(32)=NULL,
@SearchKey2	varchar(32)=NULL,
@SearchKey3	varchar(32)=NULL,
@SearchKey4	varchar(32)=NULL,
@SearchKey5	varchar(32)=NULL
AS
	SELECT	sValue
	FROM		cfgOverhead
	WHERE	oKey=@SearchKey OR oKey=@SearchKey2 OR oKey=@SearchKey3 OR oKey=@SearchKey4 OR oKey=@SearchKey5
	ORDER BY	Sequence
go

