CREATE   PROCEDURE dbo.WorkorderDTL_SetScheduleDate
@User               char(10),
@WorkOrderID        int,
@WorkOrderDTLID     int,
@ScheduledStartDate datetime
AS
    SET @ScheduledStartDate = ISNULL( @ScheduledStartDate , getdate())      -- IF no date, SET to today.
    UPDATE  tblWorkOrderDTL
       SET  ScheduledStartDate  = @ScheduledStartDate
    WHERE   WorkOrderID = @WorkOrderID AND
            WorkOrderDTLID = @WorkOrderDTLID
    RETURN
go

