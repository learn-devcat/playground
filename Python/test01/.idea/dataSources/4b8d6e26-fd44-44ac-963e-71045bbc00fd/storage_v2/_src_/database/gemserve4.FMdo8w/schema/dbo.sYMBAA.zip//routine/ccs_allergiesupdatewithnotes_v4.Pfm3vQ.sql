
CREATE PROCEDURE [dbo].[CCS_AllergiesUpdateWithNotes_v4]
@MedicalRecordID	varchar(50),
@PatientVisitID		varchar(50),
@Allergies			varchar(4000),
@Source				varchar(100),
@ConnectionName		varchar(50)=''

AS
	SET NOCOUNT ON

	DECLARE @PatientID	int,
		@AllergenID		int,
		@CurrentAllergy	varchar(200),
		@Notes			varchar(4000),
		@Msg			varchar(500),
		@ORMSeparator	varchar(10),
		@EndLoop		int
		
	SELECT @ORMSeparator = COALESCE(dbo.GetOverheadValueNull('ORMSeparator'),'|')

	DECLARE @Process TABLE (AllergenID int)

	-- Get PatientID from either MedicalRecordID or PatientVisitID
	IF (@PatientVisitID = '')
		SELECT @PatientID = PatientID
		FROM dbo.tblPatientOHD
		WHERE MedicalRecordID = @MedicalRecordID
	ELSE
		SELECT @PatientID = PatientID
		FROM dbo.tblPatientVisit
		WHERE PatientVisitID = @PatientVisitID

	-- PatientID not found so log it
	IF (@PatientID IS NULL)
	BEGIN
		IF (@PatientVisitID <> '')
			SET @Msg = 'Unable to update patient allergens for PatientVisitID [' + @PatientVisitID + ']. Patient not found.' 
		ELSE
			SET @Msg = 'Unable to update patient allergens for MedicalRecordID [' + @MedicalRecordID + ']. Patient not found.'
		EXEC dbo.Logit 1, @Msg, 'system'		

		GOTO Finish
	END

	SET @EndLoop = 0

	WHILE (@EndLoop = 0)	
	BEGIN
		IF (CHARINDEX(@ORMSeparator,@Allergies) > 0)
		BEGIN
			SET @CurrentAllergy = SUBSTRING(@Allergies,1,CHARINDEX(@ORMSeparator,@Allergies)-1)
			SET @Allergies = SUBSTRING(@Allergies, CHARINDEX(@ORMSeparator,@Allergies) + 1,LEN(@Allergies) - LEN(@CurrentAllergy))
		END
		ELSE
		BEGIN
			-- Process the last item
			SET @CurrentAllergy = @Allergies
			SET @EndLoop = 1
		END

		-- Null AllergenID
		IF (@CurrentAllergy <> '') 
		BEGIN
			-- Put all Allergens that need to be set by this item into a temporary table
			DELETE @Process

			INSERT INTO @Process 
			SELECT CAST(KeyOut AS int)
			FROM dbo.tblXlat
			WHERE KeyIn = @CurrentAllergy
				AND xlatID = 'ModifierAllergenID'
			
			INSERT INTO @Process
			SELECT AllergenID
			FROM dbo.cfgAllergens
			WHERE [Description] = @CurrentAllergy
				AND AllergenID NOT IN (SELECT AllergenID FROM @Process)

			-- Null AllergenID
			IF NOT EXISTS (SELECT 1 FROM @Process)
			BEGIN
			-- Check to see if allergen note need to be translated in the XLAT table
				IF EXISTS (SELECT 1 FROM dbo.tblXLAT WHERE xlatID = 'AllergenNote' AND KeyIn = @CurrentAllergy) 
				BEGIN
					-- Set the translation note to the current note and get the note type from the XLAT table
					SELECT 	@CurrentAllergy = [Description]
					FROM 	dbo.tblXLAT
					WHERE	(xlatID = 'AllergenNote') 
						AND (KeyIn = @CurrentAllergy) 		
				END
				
				--  Check to see if the current allergy is blank
				IF (@CurrentAllergy <> '')
				BEGIN
					-- Write the text to the Patient Notes.
					SELECT @Notes = Notes
					FROM	dbo.tblPatientOHD
					WHERE 	PatientID  = @PatientID

					IF (@Notes IS NULL)
						SET @Notes = ''

					IF (CHARINDEX(@CurrentAllergy, @Notes) = 0)
					BEGIN
						IF (@Notes = '')
							SET @Notes = @CurrentAllergy
						ELSE
							SET @Notes = @Notes + @ORMSeparator + @CurrentAllergy

						UPDATE dbo.tblPatientOHD
						SET Notes = @Notes
						WHERE PatientID = @PatientID
					END
				END
			END
			ELSE
			BEGIN
				SELECT TOP 1 @AllergenID = AllergenID
				FROM @Process

				WHILE (1=1)
				BEGIN
					IF (@AllergenID IS NULL)
						BREAK

					IF NOT EXISTS (SELECT AllergenID FROM dbo.tblPatientAllergens (NOLOCK)
					WHERE PatientID = @PatientID
					AND AllergenID = @AllergenID)
					BEGIN
						INSERT INTO dbo.tblPatientAllergens(PatientID, AllergenID)
							VALUES (@PatientID, @AllergenID)

						SELECT @Msg = 'Allergen added: ' + UPPER([Description])
							FROM cfgAllergens WHERE AllergenID = @AllergenID
	
						EXEC dbo.PatientLOGAdd 1000, 'HL7', @PatientID, '', NULL, @Msg
					END

					DELETE @Process
					WHERE AllergenID = @AllergenID

					SET @AllergenID = NULL
					SELECT TOP 1 @AllergenID = AllergenID
					FROM @Process
				END
			END
		END
	END

Finish:
	SET @ConnectionName = 'Idt' + @ConnectionName
	EXEC dbo.WorkstationUpdateByID @ConnectionName

	RETURN


go

