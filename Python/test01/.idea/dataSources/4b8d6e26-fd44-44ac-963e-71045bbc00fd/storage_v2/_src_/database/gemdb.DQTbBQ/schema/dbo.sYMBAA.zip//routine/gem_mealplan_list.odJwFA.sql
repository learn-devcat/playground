

CREATE PROCEDURE dbo.gem_MealPlan_List
@CoreID		int,
@User		varchar(50),
@MealPlanID	int = 0
AS
	IF (@MealPlanID = 0)
		SELECT	MealPlanID,
			Name,
			Status,
			SubType,
			Freq,
			InitialNumPeriods,
			FirstDayOfWeek,
			ReloadQty,
			ReloadBalance
		FROM	tblPlanOHD
		ORDER BY MealPlanID
	ELSE
		SELECT	MealPlanID,
			Name,
			Status,
			SubType,
			Freq,
			InitialNumPeriods,
			FirstDayOfWeek,
			ReloadQty,
			ReloadBalance
		FROM	tblPlanOHD
		WHERE 	MealPlanID = @MealPlanID
		ORDER BY MealPlanID
go

