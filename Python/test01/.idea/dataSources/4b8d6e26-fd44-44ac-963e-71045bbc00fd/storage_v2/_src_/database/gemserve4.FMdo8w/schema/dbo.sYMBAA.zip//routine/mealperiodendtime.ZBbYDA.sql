
CREATE FUNCTION dbo.MealPeriodEndTime(@Today datetime, @MealPeriodID int)
RETURNS datetime
AS
BEGIN
	DECLARE @Return datetime

	SELECT TOP 1 @Return = dbo.dDatePlusNewTime(@Today,EndTime)
	FROM dbo.tblWave 
	WHERE MealPeriodID = @MealPeriodID
	ORDER BY EndTime DESC

	RETURN @Return
END
go

