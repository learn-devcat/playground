

CREATE PROCEDURE dbo.sp_DateClass_List
AS
	SELECT	DateID,
			Description
	FROM		tblDateClass
	ORDER BY	Description
go

