
CREATE PROCEDURE dbo.gem_AllowedOutlets
@AccountNo	char(19)
AS
	SELECT 	A.AccountNo,
		O.OutletName,
		CASE O.SubType & AC.SubType
		
		--CASE dbo.IsAllowed(O.OutletNo, AC.AccountClassID, -1)
			WHEN 0 THEN 'Not Allowed'
			ELSE 'Allowed'
		END AS Status,
		O.SubType,
		AC.SubType
	FROM	tblOutletOHD AS O
		LEFT JOIN tblAccountOHD AS A ON A.AccountNo = @AccountNo
		LEFT JOIN tblAccountClass AS AC ON A.AccountClassID = AC.AccountClassID
go

