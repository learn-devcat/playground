CREATE PROCEDURE [dbo].[PatientStatusFlagsList]
@PatientID int=0
AS
SET NOCOUNT ON

	SELECT	SF.StatusFlagID,
			SF.[Description],
			CASE WHEN PS.StatusFlagID  IS NULL THEN 0
				ELSE 1
			END AS Checked
	FROM dbo.tblStatusFlags AS SF
	LEFT JOIN dbo.tblPatientStatusFlags AS PS ON SF.StatusFlagID = PS.StatusFlagID AND PS.PatientID = @PatientID
	ORDER BY SF.[Description]

	RETURN
go

