CREATE PROCEDURE [dbo].[PatientOrderItemConsumptionUpdate]
@LoginUserId	varchar(250),
@OrderItemId	int,
@Consumption	decimal(5,2)
AS
	SET NOCOUNT ON

	DECLARE @Msg varchar(250),
		@OrderId int,
		@PatientID int,
		@Description varchar(50)

	SELECT @Description = M.[Description],
		@OrderId = O.OrderId,
		@PatientID = R.PatientID
	FROM dbo.tblOrderItems AS O (NOLOCK)
	JOIN dbo.tblMenuItemOHD AS M (NOLOCK) ON O.POSMenuItemID = M.POSMenuItemID
	JOIN dbo.tblOrderOHD AS R (NOLOCK) ON O.OrderID = R.OrderID
	WHERE O.OrderItemId = @OrderItemId

	UPDATE dbo.tblOrderItems 
	SET Consumption = @Consumption
	WHERE OrderItemId = @OrderItemID

	-- Recalculate patient nutrient numbers
	EXEC dbo.PatientUpdateNutrientCountEX @PatientID, @OrderID

	SET @Msg = 'Consumption updated for OrderID [' + CAST(@OrderId AS varchar(50)) + '] - Menu Item [' + @Description + '] set to [' + 
		CAST(@Consumption AS varchar(10)) + '%]'
	EXEC dbo.Logit 1, @Msg, 'system'

	RETURN
go

