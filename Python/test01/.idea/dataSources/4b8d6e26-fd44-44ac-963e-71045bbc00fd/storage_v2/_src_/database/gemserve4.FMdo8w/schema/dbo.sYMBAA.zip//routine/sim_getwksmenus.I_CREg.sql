


/*
    sim_GetWKSMenus            03-May-05   w.j.scott
    
    This proc is called from the WKS and sparks the transaction which will read the menu items from
   GEMServe and create the touchscreen templates in the MICROS based on the wksid and the
    patient ID... The ID helps us filter menu items which may have alergens attached.
    

*/
CREATE PROCEDURE dbo.sim_GetWKSMenus
(
    @CoreID int,
    @LoginUserID		varchar(250),
    @WSID int,
    @PatientID int
)
AS
	SET NOCOUNT ON
	

	-- return a valid gem error message to indiate that this call failed...	
	select 'OK' as ReturnMessage


	RETURN
go

