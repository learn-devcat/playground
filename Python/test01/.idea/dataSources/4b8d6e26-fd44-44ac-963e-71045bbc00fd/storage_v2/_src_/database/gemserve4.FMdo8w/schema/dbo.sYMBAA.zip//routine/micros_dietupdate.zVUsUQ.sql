CREATE PROCEDURE [dbo].[Micros_DietUpdate]
@UserID		char(10),
@ObjectNumber	int,
@Description	varchar(16)
AS
	SET NOCOUNT ON

	DECLARE @Msg varchar(500),
			@Temp varchar(10),
			@MajorGroupSeq int,
			@FamilyGroupSeq int,
			@MIGroupSeq int,
			@MITypeSeq int,
			@MLvlClassSeq int,
			@PrnDefClassSeq int,
			@POSDietPrefix int,
			@DietID int,
			@MicrosServerName varchar(50),
			@SQL nvarchar(4000),
			@IsValid bit,
			@ReturnError int
			
	/* Initialize Return Error Code
			0 = No Error
			1 = Invalid Object Number
			2 = Diet Name is blank
			3 = Invalid Major Group Sequence Number
			4 = Invalid Family Group Sequence Number
			5 = Invalid Menu Item Group Sequence Number
			6 = Invalid Menu Item Type Sequence Number
			7 = Invalid Menu Level Class Sequence Number
			8 = Invalid Printer Definition Class Sequence Number	
	*/	
	
	SET @ReturnError = 0
			
	SET @POSDietPrefix = COALESCE(dbo.GetOverheadValueNull('POSDietPrefix'),'9000000')
	SET @DietID = @ObjectNumber - @POSDietPrefix
	SET @MicrosServerName = COALESCE(dbo.GetOverheadValueNull('MicrosServerName'), 'Micros')
	SET @MajorGroupSeq = COALESCE(dbo.GetOverheadValueNull('DietMajorGroupSeq'),'-1')
	SET @FamilyGroupSeq = COALESCE(dbo.GetOverheadValueNull('DietFamilyGroupSeq'), '-1')
	SET @MIGroupSeq = COALESCE(dbo.GetOverheadValueNull('DietMenuItemGroupSeq'),'-1')
	SET @MITypeSeq = COALESCE(dbo.GetOverheadValueNull('DietMenuItemTypeSeq'),'-1')
	SET @MLvlClassSeq = COALESCE(dbo.GetOverheadValueNull('DietMenuLevelClassSeq'),'-1')
	SET @PrnDefClassSeq = COALESCE(dbo.GetOverheadValueNull('DietPrinterDefClassSeq'),'-1')
	
	--Check to see if object number is a valid diet object number
	IF (@ObjectNumber < @POSDietPrefix)
	BEGIN
		--Object number is not in the correct range for a MICROS POS DietID so log the error
		SET @Msg = 'Object Number [' + CAST(@ObjectNumber AS varchar(10)) + '] is not a valid object number for MICROS diets. Diet not added to MICROS.'
		SET @ReturnError = 1
		GOTO TransError 
	END
	
	-- Verify that the Diet Name is not blank
	IF (@Description = '')
	BEGIN
		SET @Msg = 'The Diet Name for DietID [' + CAST(@DietID AS varchar(10)) + '] is blank.  Diet not added to MICROS.'
		SET @ReturnError = 2
		GOTO TransError
	END
	
	-- Verify that the Major Group Sequence Number is not blank and exists on the MICROS
	IF NOT EXISTS (SELECT 1 FROM MicrosMajorGroupDef WHERE MAJ_GRP_SEQ = @MajorGroupSeq)
	BEGIN
		SET @Msg = 'The Major Group Sequence Number for Diet [' + @Description + '] either does not exist in the cfgOverhead table or on the MICROS.  Diet not added to MICROS.'
		SET @ReturnError = 3
		GOTO TransError
	END

	-- Verify that the Family Group Sequence Number is not blank and exists on the MICROS
	IF NOT EXISTS (SELECT 1 FROM MicrosFamilyGroupDef WHERE FAM_GRP_SEQ = @FamilyGroupSeq)
	BEGIN
		SET @Msg = 'The Family Group Sequence Number for Diet [' + @Description + '] either does not exist in the cfgOverhead table or on the MICROS.  Diet not added to MICROS.'
		SET @ReturnError = 4
		GOTO TransError
	END

	-- Verify that the Menu Item Group Sequence Number is not blank and exists on the MICROS	
	IF NOT EXISTS (SELECT 1 FROM MicrosMenuItemGroupDef WHERE MI_GRP_SEQ = @MIGroupSeq)
	BEGIN
		SET @Msg = 'The Menu Item Group Sequence Number for Diet [' + @Description + '] either does not exist in the cfgOverhead table or on the MICROS.  Diet not added to MICROS.'
		SET @ReturnError = 5
		GOTO TransError
	END

	-- Verify that the Menu Item Type Class Number is not blank and exists on the MICROS
	SET @IsValid = 0
	SET @SQL = 'SELECT @IsValid1=IsValid FROM OPENQUERY(['+ @MicrosServerName + '],''SELECT 1 AS IsValid
		FROM micros.MI_TYPE_CLASS_DEF 
		WHERE MI_TYPE_SEQ = ' + CAST(@MITypeSeq AS varchar(10)) + ''')'

	EXEC sp_executesql @SQL, N'@IsValid1 int out', @IsValid out
	
	IF (@IsValid = 0)
	BEGIN
		SET @Msg = 'The Menu Item Type Class for Diet [' + @Description + '] either does not exist in the cfgOverhead table or on the MICROS.  Diet not added to MICROS.'
		SET @ReturnError = 6
		GOTO TransError
	END	

	-- Verify that the Menu Level Sequence Number is not blank and exists on the MICROS	
	IF NOT EXISTS (SELECT 1 FROM MicrosMenuLevel WHERE MLVL_CLASS_SEQ = @MLvlClassSeq)
	BEGIN
		SET @Msg = 'The Menu Level Sequence Number for Diet [' + @Description + '] either does not exist in the cfgOverhead table or on the MICROS.  Diet not added to MICROS.'
		SET @ReturnError = 7
		GOTO TransError
	END

	-- Verify that the Printer Class is not blank and exists on the MICROS	
	IF NOT EXISTS (SELECT 1 FROM MicrosPrinterClass WHERE PRN_DEF_CLASS_SEQ = @PrnDefClassSeq)
	BEGIN
		SET @Msg = 'The Printer Class for Diet [' + @Description + '] either does not exist in the cfgOverhead table or on the MICROS.  Diet not added to MICROS.'
		SET @ReturnError = 8
		GOTO TransError
	END
	
	--Check to see if diet needs to be updated or added
	IF EXISTS (SELECT 1 FROM MicrosMenuItems WHERE obj_num = @ObjectNumber)
	BEGIN
	
		-- Update Diet on MICROS
		UPDATE MicrosMenuItems
		SET name_1 = @Description,
			maj_grp_seq = @MajorGroupSeq,
			fam_grp_seq = @FamilyGroupSeq,
			mi_grp_seq = @MIGroupSeq,
			mi_type_seq = @MITypeSeq,
			mlvl_class_seq = @MLvlClassSeq,
			prn_def_class_seq = @PrnDefClassSeq
		WHERE obj_num = @ObjectNumber	
		
		SET @Msg = 'Diet [' + @Description + '] was updated on the MICROS.'
	END
	ELSE
	BEGIN
		-- Add Diet to MICROS
		INSERT INTO MicrosMenuItems(obj_num, name_1, maj_grp_seq, fam_grp_seq, mi_grp_seq, mi_type_seq, mlvl_class_seq, prn_def_class_seq)
		VALUES(@ObjectNumber,@Description,@MajorGroupSeq,@FamilyGroupSeq,@MIGroupSeq,@MITypeSeq,@MLvlClassSeq,@PrnDefClassSeq)
		
		SET @Msg = 'A new diet [' + @Description + '] has been added to the MICROS.'
	END

Finished:
	IF (@Msg IS NULL)
		SET @Msg = 'Diet [' + @Description + '] has been added/updated.'
	
	EXEC dbo.Logit 1, @Msg, 'system'
	
	RETURN @ReturnError
	
TransError:		
		IF (@Msg IS NULL)
			SET @Msg = 'Cannot insert/update diet on the MICROS for Object Number [' + @ObjectNumber + '].'
       
		EXEC dbo.Logit 1, @Msg, 'system'
		
		RETURN @ReturnError
go

