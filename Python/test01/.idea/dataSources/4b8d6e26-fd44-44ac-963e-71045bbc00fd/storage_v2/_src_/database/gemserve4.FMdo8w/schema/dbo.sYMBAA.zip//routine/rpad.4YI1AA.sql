
CREATE FUNCTION dbo.RPad (@sString	 varchar(50),@iLen int, @sPadString char(1)) 
RETURNS varchar(100)
AS 
BEGIN 
	DECLARE @ReturnString	varchar(100)
	IF (LEN(@sString) < @iLen)
		SET @ReturnString = @sString + REPLICATE(@sPadString,@iLen-LEN(@sString))
	ELSE
		SET @ReturnString = @sString
	RETURN @ReturnString
END
go

