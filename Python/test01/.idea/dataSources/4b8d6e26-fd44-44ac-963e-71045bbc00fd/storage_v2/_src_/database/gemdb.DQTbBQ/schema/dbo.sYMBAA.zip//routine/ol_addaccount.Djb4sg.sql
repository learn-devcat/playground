

CREATE PROCEDURE dbo.ol_AddAccount
@CoreID			int,
@User			char(10),
@AccountNo 		char(19),
@Description 	char(30),
@Status			int,
@Title			char(10),
@FirstName		char(15),
@LastName		char(20),
@Phone 			char(15),
@Fax 			char(15),
@email			varchar(64),
@AccountClassID int,
@PIN			char(10),
@ActiveDate		datetime,
@ExpireDate		datetime,
@Inactive		bit,
@NoStatements	bit,
@NoAging		bit,
@NoFinanceChg	bit,
@NoVerify		bit,
@NoDetail		bit,
@Bump200		bit,
@AutoOverpost	bit,
@BadgeNo		char(19),
@StatusB		int,
@PrimaryBadge	bit,
@BadgeClass		smallint,
@Limit			money,
@DailyLimit		money,
@ImagePath		varchar(255),
@Lost			bit,
@Stolen			bit,    
@TransClassID	int,
@AddressID		char(10),
@Address1		varchar(40),
@Address2		varchar(40),
@Address3		varchar(40),
@Address4		varchar(40),
@Address5		varchar(40)
AS 
 	DECLARE	@ReturnCode	int
	SET NOCOUNT ON
	
	BEGIN TRANSACTION
	
		--Insert AND UPDATE a new account
		EXEC @ReturnCode = dbo.sp_Account_Insert @User, @AccountNo, @AccountClassID
		IF (@ReturnCode <> 0)
			GOTO AddFailed
		
		EXEC @ReturnCode = dbo.sp_Account_Update @User, @AccountNo, @Description, @Status, @Title,
											@FirstName, @LastName, @Phone, @Fax, @email,
											@AccountClassID, @PIN, @ActiveDate, @ExpireDate,
											@Inactive, @NoStatements, @NoAging, @NoFinanceChg,
											@NoVerify, @NoDetail, @Bump200, @AutoOverpost
		IF (@ReturnCode <> 0)
			GOTO AddFailed
											
		--Insert AND UPDATE a new badge
		EXEC @ReturnCode = dbo.sp_Badge_Insert @User, @BadgeNo, @AccountNo
		IF (@ReturnCode <> 0)
			GOTO AddFailed
		
		EXEC @ReturnCode = dbo.sp_Badge_Update @User, @BadgeNo, @BadgeNo, @AccountNo, @StatusB,
											@PrimaryBadge, @ActiveDate, @ExpireDate, @BadgeClass,
											@Title, @FirstName, @LastName, @Limit, @DailyLimit,
											@ImagePath, @Inactive, @Lost, @Stolen
		IF (@ReturnCode <> 0)
			GOTO AddFailed
		
		--Insert account TTL     
		EXEC @ReturnCode = dbo.sp_AccountTTL_Insert @User, @AccountNo, @TransClassID
		IF (@ReturnCode <> 0)
			GOTO AddFailed
		
		--Insert AND UPDATE account address
		EXEC @ReturnCode = dbo.sp_Address_Insert @User, @AddressID, @AccountNo
		IF (@ReturnCode <> 0)
			GOTO AddFailed
		
		EXEC @ReturnCode = dbo.sp_Address_Update @User, @AddressID, @AddressID, @AccountNo,
											@Address1, @Address2, @Address3, @Address4, @Address5
		IF (@ReturnCode <> 0)
			GOTO AddFailed
		
		--Add succeeded, so commit AND RETURN
		COMMIT TRANSACTION
		RETURN 0
	
AddFailed:
		
		--Add failed, so RETURN failure message		
		ROLLBACK TRANSACTION
		SELECT 'Add account failed'
go

