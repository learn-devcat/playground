CREATE PROCEDURE dbo.PatientDietNotesUpdate
@LoginUserID		varchar(250),
@PatientDietID		int,
@Notes			varchar(500)

AS

	SET NOCOUNT ON

	UPDATE dbo.tblPatientDiet
	SET Notes = @Notes
	WHERE [ID] = @PatientDietID

	RETURN
go

