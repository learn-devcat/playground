CREATE PROCEDURE [dbo].[StatusFlagUpdate]
@LoginUserID	varchar(250),
@StatusFlagID	int,
@Description	varchar(50),
@OnDashboard	bit

AS
	SET @Description = REPLACE(LTRIM(RTRIM(@Description)),',','')

	IF (@StatusFlagID < 1)
	BEGIN
		INSERT INTO dbo.tblStatusFlags ([Description],OnDashboard,EnteredBy)
			VALUES (@Description, @OnDashboard, @LoginUserID)

		SET @StatusFlagID = SCOPE_IDENTITY()
	END
	ELSE
		UPDATE dbo.tblStatusFlags
		SET [Description] = @Description,
			OnDashboard = @OnDashboard,
			LastUpdateBy = @LoginUserID
		WHERE StatusFlagID = @StatusFlagID


	SELECT @StatusFlagID AS StatusFlagID
go

