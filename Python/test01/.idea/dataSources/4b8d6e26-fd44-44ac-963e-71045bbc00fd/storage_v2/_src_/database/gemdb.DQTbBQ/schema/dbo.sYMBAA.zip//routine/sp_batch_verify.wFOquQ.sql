CREATE PROCEDURE [dbo].[sp_Batch_Verify]
@BatchID	char(10)
AS 
 	DECLARE @CoreID 	int,
			@AccountNo 	char(19),
			@BadgeNo 	char(19),
			@TransDate	datetime,
			@CycleNo	int,
			@OutletNo	int,
			@TransID	int,
			@RefNum		char(6),
			@TransTotal	money,
			@Sales1		money,
			@Sales2		money,
			@Sales3		money,
			@Sales4		money,
			@Sales5		money,
			@Sales6		money,
			@Sales7		money,
			@Sales8		money,
			@Sales9		money,
			@Sales10	money,
			@Sales11	money,
			@Sales12	money,
			@Sales13	money,
			@Sales14	money,
			@Sales15	money,
			@Sales16	money,
			@tax1		money,
			@tax2		money,
			@tax3		money,
			@tax4		money,
			@Total		money
	--SET up cursor
	DECLARE Temp cursor FOR
		SELECT	CoreID,
				AccountNo,
				BadgeNo,
				TransDate,
				CycleNo,
				OutletNo,
				TransID,
				RefNum,
				TransTotal,
				Sales1,
				Sales2,
				Sales3,
				Sales4,
				Sales5,
				Sales6,
				Sales7,
				Sales8,
				Sales9,
				Sales10,
				Sales11,
				Sales12,
				Sales13,
				Sales14,
				Sales15,
				Sales16,
				tax1,
				tax2,
				tax3,
				tax4
		FROM	tblBatch
		WHERE	BatchID = @BatchID
			AND Posted NOT IN ('P','I')
	--Open cursor AND get first item in the cursor
	OPEN Temp
	FETCH NEXT FROM Temp INTO @CoreID, @AccountNo, @BadgeNo, @TransDate, @CycleNo,
							@OutletNo, @TransID, @RefNum, @TransTotal, @Sales1,
							@Sales2, @Sales3, @Sales4, @Sales5, @Sales6, @Sales7, @Sales8,
							@Sales9, @Sales10, @Sales11, @Sales12, @Sales13, @Sales14, @Sales15,
							@Sales16, @tax1, @tax2, @tax3, @tax4
	--Loop until no more items in the cursor
	WHILE (@@FETCH_STATUS=0)
	BEGIN
		--Check required items that cannot be resolved
		IF (@CoreID <= 0 OR (@AccountNo = '' AND @BadgeNo = ''))
			UPDATE	tblBatch
			SET		BatchID = 'EXCEPTION',
					LastUpdateDate = GETDATE()
			WHERE CURRENT OF Temp
		ELSE
		BEGIN
			--IF Account No is empty, get it FROM the Badge No
			IF (ISNULL(@AccountNo,'') = '')
				SET @AccountNo = dbo.GetFirstAccount(@BadgeNo)
			
			--IF Badge No is empty, get it FROM the Account No
			IF (ISNULL(@BadgeNo,'') = '')
				SET @BadgeNo = dbo.GetFirstBadge(@AccountNo)
			--IF the TransDate is empty, SET it to today's date
        	IF (ISNULL(@TransDate,'') = '')
        		SET @TransDate = getdate()
        	
			--IF the Cycle No is null, SET it to a 0, which translates to the current cycle
			IF (ISNULL(@CycleNo,0) = 0)
				SET @CycleNo = 0
			
			--IF the Outlet No is 0, get it FROM the TransID
			IF (ISNULL(@OutletNo,0) = 0)
				SET @OutletNo = dbo.GetFirstOutlet(@TransID)
			ELSE 
				--IF the Outlet No is not 0, make sure the TransID is not a 0. IF so, get it FROM the Outlet No
				BEGIN
					IF (ISNULL(@TransID,0) = 0)
						SET @TransID = dbo.GetFirstTransID(@OutletNo)
				END
			--IF the RefNum is empty, create one using the TransDate seconds + month + year
			IF (ISNULL(@RefNum,'') = '')
				SET @RefNum = DATEPART(ss,@TransDate) + DATEPART(mm,@TransDate) + DATEPART(hh,@TransDate)
			
			--IF the Sales bucket totals do not match the TransTotal, SET Sales1 value
			SET @Total = @Sales1 + @Sales2 + @Sales3 + @Sales4 + @Sales5 + @Sales6 + @Sales7 + @Sales8 +
						@Sales9 + @Sales10 + @Sales11 + @Sales12 + @Sales13 + @Sales14 + @Sales15 + @Sales16
			IF (@TransTotal > @Total)
				SET @Sales1 = @TransTotal - @Total			
			--UPDATE the tblBatch with the VALUES through the cursor record
			UPDATE	tblBatch
			SET		AccountNo = @AccountNo,
					BadgeNo = @BadgeNo,
					TransDate = @TransDate,
					CycleNo = @CycleNo,
					OutletNo = @OutletNo,
					TransID = @TransID,
					RefNum = @RefNum,
					Sales1 = @Sales1,
					LastUpdateDate = GETDATE()
			WHERE CURRENT OF Temp
		
		END
		
		--Get next item in the cursor
	FETCH NEXT FROM Temp INTO @CoreID, @AccountNo, @BadgeNo, @TransDate, @CycleNo,
							@OutletNo, @TransID, @RefNum, @TransTotal, @Sales1,
							@Sales2, @Sales3, @Sales4, @Sales5, @Sales6, @Sales7, @Sales8,
							@Sales9, @Sales10, @Sales11, @Sales12, @Sales13, @Sales14, @Sales15,
							@Sales16, @tax1, @tax2, @tax3, @tax4
	END
	--Release resources AND clean up	   	
	CLOSE Temp
	DEALLOCATE Temp
go

