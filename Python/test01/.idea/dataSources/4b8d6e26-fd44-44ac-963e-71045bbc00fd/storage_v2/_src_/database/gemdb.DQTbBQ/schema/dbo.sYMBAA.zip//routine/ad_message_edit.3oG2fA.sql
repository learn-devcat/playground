


CREATE  PROCEDURE [dbo].[ad_Message_Edit]
@User		char(10),
@GlobalID	int,
@MessageID	varchar(50),
@Message	varchar(255),
@Language	int,
@PageID		varchar(50),
@DELETE		bit = 0

AS 
	DECLARE @LogMsg varchar(255)

	IF @DELETE = 1
		GOTO DODELETE

	IF (@GlobalID = -1)
	  BEGIN
		INSERT dbo.tblMessages([ID],Message,Language,PageID)		 
		VALUES(@MessageID,
			@Message,
			@Language,
			@PageID)

			SELECT @LogMsg = 	'New Message Item Added: (' + @PageID + ':' + @MessageID + ':) ' +  @Message
					
	  END
	ELSE
	  BEGIN

		UPDATE	dbo.tblMessages
		SET	[ID] = @MessageID,
			Message = @Message,
			Language = @Language,
			PageID = @PageID
		WHERE	GlobalID = @GlobalID

		SELECT @LogMsg = 	('Edit of ID (' + @PageID + ':' + @MessageID + ') to ' + @Message + ' : ' + 
					CASE WHEN (SELECT [ID] FROM dbo.tblMessages WHERE GlobalID = @GlobalID) IS NULL
					     THEN 'FAILED'
					     ELSE 'SUCCEDED'
					     END)
	  END

	EXEC dbo.sp_Logit 9, 1, @User, @LogMsg, 1010	
	SELECT @LogMsg AS 'Rtn'

	RETURN

	DODELETE:
	DELETE	dbo.tblMessages
	WHERE	GlobalID = @GlobalID

	IF EXISTS (SELECT * FROM dbo.tblMessages WHERE GlobalID = @GlobalID)
		SELECT @LogMsg = 'DELETE Message ID (' + @PageID + ':' + @MessageID + ') Failed'
	ELSE
		SELECT @LogMsg = 'DELETE Message ID (' + @PageID + ':' + @MessageID + ') Succeded'

	EXEC dbo.sp_Logit 9, 1, @User, @LogMsg, 1010	
	SELECT @LogMsg AS 'Rtn'
go

