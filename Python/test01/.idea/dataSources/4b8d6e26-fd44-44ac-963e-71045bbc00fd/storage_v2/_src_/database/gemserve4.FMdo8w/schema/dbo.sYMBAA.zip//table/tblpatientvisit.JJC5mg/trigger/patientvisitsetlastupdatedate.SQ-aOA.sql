CREATE TRIGGER PatientVisitSetLastUpdateDate ON dbo.tblPatientVisit FOR INSERT,
                          UPDATE    AS
                                                      UPDATE    dbo.tblPatientVisit
                                                       SET              LastUpdateDate = getdate()
                                                       FROM         Inserted AS I JOIN
                                                                              dbo.tblPatientVisit AS P ON I.PatientVisitID = P.PatientVisitID
go

