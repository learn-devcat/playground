

CREATE PROCEDURE dbo.ad_AddressClass_Update
@User		char(10),
@AddressID	int,
@Description	char(10)
AS
	UPDATE	tblAddressClass
	SET		Description = @Description
	WHERE	AddressID = @AddressID
go

