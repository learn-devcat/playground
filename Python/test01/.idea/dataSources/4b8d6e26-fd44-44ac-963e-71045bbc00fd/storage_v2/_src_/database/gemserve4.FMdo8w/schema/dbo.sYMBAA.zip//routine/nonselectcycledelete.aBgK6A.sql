CREATE PROCEDURE [dbo].[NonSelectCycleDelete]
@LoginUserID	varchar(250),
@CycleID	int
AS
	SET NOCOUNT ON

	DELETE dbo.cfgNonSelectCycles
	WHERE CycleID = @CycleID

	RETURN
go

