CREATE PROCEDURE dbo.PatientOrder_UpdateTest
AS
	DECLARE @OrderDate datetime,
			@Days int

	SELECT @OrderDate = OrderDate 
	FROM dbo.tblOrderOHD
	WHERE OrderID = 204

	SET @Days = DATEDIFF(d, @OrderDate, getdate())
	SET @Days = @Days - 1

	UPDATE dbo.tblOrderOHD SET OrderDate = DATEADD(d,@Days, OrderDate)

	RETURN
go

