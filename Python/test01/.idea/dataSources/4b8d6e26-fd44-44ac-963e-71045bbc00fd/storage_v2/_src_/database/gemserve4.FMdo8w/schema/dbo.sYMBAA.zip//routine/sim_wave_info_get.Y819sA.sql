
CREATE PROCEDURE [dbo].[sim_Wave_Info_Get]
@CoreID 		int,
@LoginUserID	varchar(250),
@WaveID			int
AS
	SET NOCOUNT ON
	
	DECLARE @WaveOnPOS	varchar(5),
			@WaveName	varchar(50)
	
	SELECT @WaveOnPOS = COALESCE(dbo.GetOverheadValueNull('WaveOnPOS'),'0')

	IF (@WaveOnPOS = '1')
		SELECT @WaveName = 'Wave=[' + Description + '] '
		FROM dbo.tblWave
		WHERE WaveID = @WaveID
	ELSE
		SET @WaveName = ''

	-- Return the string				
	SELECT @WaveName AS ReturnString

	RETURN
go

