CREATE PROCEDURE dbo.tt5_Inquire
@CoreID	int,
@User		char(10),
@BadgeNo	char(19),
@Outlet		int,
@TransID	int,
@TerminalID	int,
@ChkNum	char(10),
@CashierID	int,
@Taxable	money,
@Tax		money,
@Dsc		money,
@Svc		money,
@xTotal	money
AS
DECLARE @Today 	datetime,
	@ID           	int,
	@PostReturn	int,
	@ReturnCode  	int,
	@SP_Return	int,
	@DeclBalMode	bit,
	@AccountNo  	char(19),
	@Desc          	char(16),
	@Description	char(32),
	@FirstName	char(15),
	@LastName	char(20),
	@message	varchar(255),
	@ReturnName	varchar(24),
	@Balance	money,	
	@Total         	money,
	@OutletSubType  int

	SET NOCOUNT ON
 	
	-- Removes badge swipe character if it exists in @BadgeNo
	SET @BadgeNo = dbo.RemoveBadgeSwipePrefix(@BadgeNo);

	SET @ReturnCode = 0
 	SET @Today = getdate()
	
	IF( ISNULL(@BadgeNo,'') = '' )				--  Need one of these dudes to continue ...
	    BEGIN
		SELECT '/Badge # Required' as ReturnMsg
		RETURN
	    END	
	IF (LEFT(@BadgeNo,1) = '~')				-- The TT5 may need some configuration.
		SET @BadgeNo = RIGHT(@BadgeNo , LEN(@BadgeNo) - 1)
	-- 
	-- Get the outlet subtype so we can restrict any pending Account classes later.
	-- 
	SELECT 	@OutletSubType = SubType 
	FROM	tblOutletOHD
	WHERE	OutletNo = @Outlet
	IF (@@RowCount = 0)
	    BEGIN
		SELECT '/Outlet ' + CAST(@Outlet as varchar(6)) + ' Not Defined' as ReturnMsg
		RETURN
	    END
		
	--
	-- Now, we have the outlet AND know that it exists, let's see IF we get a hit for this badge
	-- in the accout file.  We will need to attach the Account table just so we can 
	-- link in the AccountClass table (for the subtype).
	--
	SELECT @AccountNo = ISNULL(b.AccountNo ,'')
	FROM 	 tblBadgesOHD b
	LEFT JOIN tblAccountOHD A on A.AccountNo = b.AccountNo AND ( A.ActiveDate <= @Today ) AND (A.ExpireDate >= @Today) AND ( A.Inactive = 0 )
	RIGHT JOIN  tblAccountClass AC on AC.AccountClassID = A.AccountClassID AND (dbo.IsAllowed(@Outlet, AC.AccountClassID, -1 ) <> 0 )
	--RIGHT JOIN  tblAccountClass AC on AC.AccountClassID = A.AccountClassID AND (( AC.SubType & @OutletSubType ) <> 0 )
	WHERE  badgeNo = @BadgeNo
	           AND B.ActiveDate <= @Today
	          AND B.ExpireDate >= @Today
	          AND b.inactive = 0
 	IF (@@RowCount = 0)
	    BEGIN
 		SELECT '/Not On File' AS ReturnMsg
		RETURN
 	    END
	--
	-- We now have a properly "masked" badge AND account number -- so let's get to business.
	-- 
 	BEGIN
		SELECT @FirstName = ISNULL(A.FirstName,''),
			@LastName = ISNULL(A.LastName,''),
			@Description = ISNULL(A.Description,'')
		FROM	tblAccountOHD AS A
		WHERE A.AccountNo = @AccountNo
		IF (@FirstName <> '' OR @LastName <> '')
			SET @ReturnName = RTRIM(@LastName) + ', ' + RTRIM(@FirstName)
		ELSE
			SET @ReturnName = @Description
 		SET @message = ISNULL(@ReturnName,'') + char(28)
		DECLARE TTL_Cursor  CURSOR FOR 
		SELECT 	t.TransClassID,t.Balance, D.Description, D.DeclBalMode 			-- Retrieve the Account TTL's
		FROM	tblAccountTTL as  t
			 JOIN 	tblTransClass as d ON t.TransClassID=d.TransClassID
		WHERE  	t.AccountNo=@AccountNo 					
				AND t.expiredate >= @Today
		ORDER BY 	t.TransClassID
	
		OPEN TTL_Cursor
	
		FETCH NEXT FROM ttl_cursor
			INTO @ID,@Total, @Desc, @DeclBalMode
	
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF (ISNULL(@DeclBalMode,0) = 0)
				SET @message = @message + CAST(ISNULL(@Desc,'') as char(5)) +  CAST(ISNULL(@Total,0) as char(7) ) 	-- format at 16 bytes per record.
			ELSE
				SET @message = @message + CAST(ISNULL(@Desc,'') as char(5)) +  CAST(-ISNULL(@Total,0) as char(7) ) 	-- format at 16 bytes per record.
	
			IF @@RowCount > 1 
			    SET @message = @message + ' '
			FETCH NEXT FROM TTL_Cursor	-- Get next row IF one exists.
			INTO @ID,@Total, @Desc, @DeclBalMode
	
		END
	
		CLOSE TTL_Cursor
		DEALLOCATE TTL_Cursor
	
		IF LEN( @message ) < 16								-- IF no TTL Records, display that on the POS.
			SET @message = @message + char(28) +  'NO ACTIVE TTLS'  
	
	
 		SELECT  @message as ReturnMsg
 	END
go

