

CREATE TRIGGER trgInsertXref ON [dbo].[tblAccountClass]
FOR INSERT
AS
	DECLARE	@Xref varchar(10)
	SELECT @Xref = XRef
	FROM	inserted
	IF (@Xref = '')
		UPDATE	tblAccountClass
		SET		Xref = A.AccountClassID
		FROM		tblAccountClass AS A
				INNER JOIN
				inserted AS I
		ON		A.AccountClassID = I.AccountClassID
go

