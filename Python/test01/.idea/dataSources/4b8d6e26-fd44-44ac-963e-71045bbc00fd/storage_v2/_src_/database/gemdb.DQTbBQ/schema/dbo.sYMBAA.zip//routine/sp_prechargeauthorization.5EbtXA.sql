CREATE PROCEDURE dbo.sp_PreChargeAuthorization
@AccountNo	char(19),
@BadgeNo	char(19),
@TransTotal	money,
@TransID	int,
@OutletNo	int
AS

	-- 11-9-16 - Updated the code to get the daily badge balance to look it up correctly using with the badgeNo and AccountNo 

	DECLARE	@AvailableCredit	money,
			@AvailableQty		int,
			@DailyBadgeBal	money,
			@DailyAccountBal	money,
			@BadgeTransLimit	money,
			@TransLimit		money,
			
			@ActiveAccount	char(19),
			@Active		int,
			@ActiveBadge		char(19),
			@Today		datetime,
			@AccountSubType 	int,
			@OutletSubType	int,
			@AccountClassID int,
			@GlobalTransOverride money

	-- Removes badge swipe character if it exists in @BadgeNo
	SET @BadgeNo = dbo.RemoveBadgeSwipePrefix(@BadgeNo);
	
	SET @Today = getdate()
	SELECT 	@OutletSubType = SubType
	FROM		tblOutletOHD
	WHERE	OutletNo = @OutletNo
	IF( @@RowCount = 0 )							-- Outlet not defined.
		RETURN '11'
	
	-- Check Account
	IF (@AccountNo = '')
		-- IF account is blank, then look it up FROM the badge
		SELECT 	TOP 1 @AccountNo = B.AccountNo
		FROM		tblBadgesOHD B
		LEFT JOIN tblAccountOHD A on A.AccountNo = B.AccountNo
		LEFT JOIN tblAccountClass AC on A.AccountClassID = AC.AccountClassID
		WHERE	B.BadgeNo = @BadgeNo
				AND B.Inactive = 0
				AND B.ActiveDate <= @Today
				AND B.ExpireDate >= @Today
			AND dbo.IsAllowed(@OutletNo,@AccountClassID,-1 ) > 0 
		Order By B.PrimaryBadge Desc
	IF (ISNULL(@AccountNo,'') = '')
		RETURN '3'	
	ELSE
	BEGIN
		-- Make sure the account is active AND check active/expire dates.
		SELECT 	@ActiveAccount = A.AccountNo, 
				@Active = A.Inactive,
				@AccountSubType = AC.SubType,
				@AccountClassID = A.AccountClassID
		FROM		tblAccountOHD A
		LEFT JOIN		tblAccountClass AC on A.AccountClassID = AC.AccountClassID
		WHERE	AccountNo = @AccountNo
				AND Inactive = 0    
				AND ActiveDate <= @Today
				AND ExpireDate >= @Today
		IF (ISNULL(@ActiveAccount,'') = '')
			-- No valid account
			RETURN '8'
	END
	
	-- Check Badge
	IF (@BadgeNo = '')
		-- IF badge is blank, then look it up FROM the account (TOP 1)
		SELECT	TOP 1 @BadgeNo = BadgeNo
		FROM		tblBadgesOHD
		WHERE	AccountNo = @AccountNo
				AND Inactive = 0
				AND ActiveDate <= @Today
				AND ExpireDate >= @Today
		ORDER BY 	PrimaryBadge Desc
		
	IF (ISNULL(@BadgeNo,'') = '')
		-- No valid badge
		RETURN '4'
	
	-- Make sure the Badge is active AND check active/expire dates | DailyLimit | DailyQtyLimit | TransLimit                      
	SELECT	@ActiveBadge = BadgeNo,
			@DailyBadgeBal = (DailyLimit - dbo.IsDailyMoney(DailyBalance,LastChgDate,@Today)) - @TransTotal,
			@BadgeTransLimit = TransLimit
	FROM		tblBadgesOHD
	WHERE	BadgeNo = @BadgeNo
			AND Inactive = 0
			AND ActiveDate <= @Today
			AND ExpireDate >= @Today
			AND AccountNo = @AccountNo
			
	IF (ISNULL(@ActiveBadge,'') = '')
		-- No valid badge
		RETURN '4'
	ELSE                                                                      
	BEGIN
		-- Got this far with a valid account AND badge, so check the Badge AND TTL daily limits
		IF (@TransTotal > @BadgeTransLimit)
		BEGIN
			SELECT @TransTotal, @BadgeTransLimit
			RETURN '6'
		END

		SELECT 	@DailyAccountBal = (TT.DailyLimit - dbo.IsDailyMoney(TT.DailyBalance,TT.LastChgDate,@Today)) - @TransTotal
		FROM	tblAccountTTL AS TT
				JOIN 	tblTransDef AS TD ON TT.TransClassID = TD.TransClassID
		WHERE	TD.TransID = @TransID
				AND TT.AccountNo = @AccountNo
				
    	SELECT @AvailableCredit = dbo.fnMin(@DailyBadgeBal,@DailyAccountBal)
		
		IF (@AvailableCredit < 0)  -- Over daily limit for the badge or the TTL
			RETURN '2'
		ELSE
		BEGIN
			IF EXISTS (SELECT 1 FROM dbo.tblAccountOHD WHERE AccountNo = @AccountNo AND TransOverride = 1)
				SELECT @GlobalTransOverride = TransOverrideAmt
				FROM dbo.tblAccountOHD WHERE AccountNo = @AccountNo AND TransOverride = 1

			-- Account TTL -- expire date | Limit | DailyLimit | DailyQtyLimit 
			-- Make sure the charge is does not go over the TTL limit (charge account)
			-- or the available credit (debit account such as gift card, etc.)
			SELECT	@AvailableCredit = CASE WHEN @GlobalTransOverride IS NOT NULL THEN ISNULL(@GlobalTransOverride - (TT.Balance + @TransTotal), 0)
					ELSE ISNULL((dbo.fnMin(TT.Limit,AC.Limit) - (TT.Balance + @TransTotal)),0) 
				END,
					@AvailableQty = ISNULL(TT.DailyQtyLimit - (dbo.IsDailyQty(TT.DailyQty,TT.LastChgDate,getdate()) + 1),0)
			FROM	tblAccountTTL AS TT
					JOIN
				tblTransDef AS TD ON TT.TransClassID = TD.TransClassID
					JOIN    
				tblAccountOHD A on A.AccountNo = TT.AccountNo
					JOIN 	
				tblAccountClass AC on AC.AccountClassID = A.AccountClassID
			WHERE	TD.TransID = @TransID
					AND TT.AccountNo = @AccountNo
					AND TT.ExpireDate >= @Today
		
			IF (@AvailableCredit < 0)
				-- Over credit limit
				RETURN '1'
			ELSE IF (@AvailableQty < 0)
			BEGIN
			
				-- Over daily quantity
				RETURN '5'
			END

		END	
	END			
	
	-- TransID  -- TransLimit
	SELECT	@TransLimit = CASE WHEN @GlobalTransOverride IS NOT NULL THEN @GlobalTransOverride 
		ELSE TransLimit END
	FROM	tblTransDef
	WHERE	TransID = @TransID	
	
	IF (@TransTotal > @TransLimit)
		-- Over transaction limit
		RETURN '7'               
		
	ELSE       
		-- Got this far, so success. Charge is authorized
		RETURN '0'
go

