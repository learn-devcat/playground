


CREATE PROCEDURE dbo.pos_Account_Insert2
@CoreID		int,
@User			char(10),
@AccountNo 		char(19),
@TransID		int = 1,
@OutletNo		int = 1,
@TransTotal		money = 0,
@RefNum		char(6) = '',
@CheckNum		char(6) = '',
@FirstName		char(15) = '',
@LastName		char(20) = 'Valued Customer' ,
@Phone 		char(15) = '',
@Address1		varchar(40) = '',
@Address2		varchar(40) = '',
@Address3		varchar(40) = '',
@Address4		varchar(40) = '',
@Address5		varchar(40) = '',
@Comment		varchar(40) = '',
@Category 		char(10) = 'GIFTCARD',
@PaymentNo		int = 1,
@ServeEmpl		int = 0
AS 
 	DECLARE	@ReturnCode	int
	DECLARE	@ActiveDate	datetime 
	DECLARE @ExpireDate	datetime 
	DECLARE @TransDate	datetime 
	
	SET NOCOUNT ON
	
	SET @LastName = left( @Lastname , 20 )		-- So we don't overflow our buffer.
	BEGIN TRANSACTION
	
		--Insert AND UPDATE a new account
		EXEC @ReturnCode = dbo.sp_Account_Insert @User, @AccountNo, 3000
		IF (@ReturnCode <> 0)
			GOTO AddFailed
		
		SET @ActiveDate = getdate()
		SET @ExpireDate = getdate() + 365
		EXEC @ReturnCode = dbo.sp_Account_Update @User, @AccountNo, '', 0, '',
											@FirstName, @LastName, @Phone, '', '',
											3000, '', @ActiveDate, @ExpireDate,
											0, 0, 0, 0,	0, 0, 0, 0
		IF (@ReturnCode <> 0)
			GOTO AddFailed
											
		--Insert AND UPDATE a new badge
		EXEC @ReturnCode = dbo.sp_Badge_Insert @User, @AccountNo, @AccountNo
		IF (@ReturnCode <> 0)
			GOTO AddFailed
		
		EXEC @ReturnCode = dbo.sp_Badge_Update @User, @AccountNo, @AccountNo, @AccountNo, 0,
											1, @ActiveDate, @ExpireDate, 3000,
											'', @FirstName, @LastName
		IF (@ReturnCode <> 0)
			GOTO AddFailed
		
		--Insert account TTL     
		EXEC @ReturnCode = dbo.sp_AccountTTL_Insert @User, @AccountNo, 3000
		IF (@ReturnCode <> 0)
			GOTO AddFailed
		
		--Insert AND UPDATE account address
		EXEC @ReturnCode = dbo.sp_Address_Insert @User, 10, @AccountNo
		IF (@ReturnCode <> 0)
			GOTO AddFailed
		
		EXEC @ReturnCode = dbo.sp_Address_Update @User, 10, 10, @AccountNo,
											@Address1, @Address2, @Address3, @Address4, @Address5
		IF (@ReturnCode <> 0)
			GOTO AddFailed
		
		--Insert the transaction
		SET @TransDate = getdate()
		EXEC @ReturnCode = dbo.sp_Trans_Post @CoreID, @User, @AccountNo, @AccountNo, @TransDate, @OutletNo, 
						@RefNum, @CheckNum, @TransTotal, @TransTotal, @Comment, 0, @TransID,
						@Category, @PaymentNo, @ServeEmpl         
						
		IF (@ReturnCode <> 0)
			GOTO AddFailed
		
		--Add succeeded, so commit AND RETURN
		COMMIT TRANSACTION
		SELECT 'Account Activated'
		RETURN
	
AddFailed:
		
		--Add failed, so RETURN failure message		
		ROLLBACK TRANSACTION
		IF (@ReturnCode = 2627)
			SELECT '/Card Already Active'
		ELSE
			SELECT '/Account Activation Failed'
go

