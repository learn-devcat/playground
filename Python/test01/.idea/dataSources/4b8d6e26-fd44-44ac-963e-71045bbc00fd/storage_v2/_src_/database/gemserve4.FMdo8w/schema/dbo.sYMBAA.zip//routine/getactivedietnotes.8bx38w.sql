
CREATE FUNCTION [dbo].[GetActiveDietNotes]
(@PatientVisitID varchar(50), @Today datetime)

RETURNS varchar(500)

AS
	BEGIN
		DECLARE @Return	varchar(500)

		SELECT TOP 1 @Return = Notes
		FROM dbo.tblPatientDiet
		WHERE PatientVisitID = @PatientVisitID
			AND ActiveDate <= @Today
			AND COALESCE(Cancelled,0) = 0
		ORDER BY ActiveDate DESC, PostDate DESC

		RETURN ISNULL( @Return, '' )
	END
go

