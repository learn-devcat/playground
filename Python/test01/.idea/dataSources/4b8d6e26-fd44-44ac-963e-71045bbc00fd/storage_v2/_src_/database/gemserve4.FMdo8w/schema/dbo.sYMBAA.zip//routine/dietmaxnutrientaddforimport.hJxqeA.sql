
CREATE PROCEDURE dbo.DietMaxNutrientAddForImport
@LoginUserID		varchar(250),
@DietID	int,
@NutrientName	varchar(50),
@DailyMax	decimal(10,3)
AS
	SET NOCOUNT ON

	DECLARE @NutrientID int

	SELECT 	@NutrientID = NutrientID
	FROM	dbo.cfgNutrients
	WHERE	[Description] = @NutrientName

	IF (@NutrientID IS NOT NULL)
	BEGIN
		INSERT INTO dbo.tblDietDailyNutrients (DietID, NutrientID, DailyMax)
			VALUES (@DietID, @NutrientID, @DailyMax)
	END

	RETURN
go

