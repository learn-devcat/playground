
CREATE FUNCTION [dbo].[MealCountForMonth](@WhatMonth as int, @WhatYear as int, @DietID as int, @KitchenId as int=NULL)
RETURNS int
BEGIN
	DECLARE @Return int

	IF (@KitchenId = 0)
	   	SET @KitchenId = NULL

	SELECT @Return = COUNT(OL.[Date])
	FROM dbo.tblOrderLOG AS OL (NOLOCK)
	LEFT JOIN tblOrderOHD AS O (NOLOCK) ON OL.OrderID = O.OrderID
	LEFT JOIN tblRoomOHD AS R (NOLOCK) ON O.RoomID = R.RoomID
	LEFT JOIN tblLocationClass AS L (NOLOCK) ON R.LocationClassID  = L.LocationClassID
	LEFT JOIN tblKitchens AS K (NOLOCK) ON L.KitchenId = K.KitchenId
	WHERE MONTH(OL.[Date]) = @WhatMonth
		AND YEAR(OL.[Date]) = @WhatYear
		AND COALESCE(OL.DietID, -1) = @DietID
		AND dbo.GetActionID('RECEIVED') = ActionID
		AND K.KitchenId = ISNULL(@KitchenId,K.KitchenId)
		
	SELECT @Return = @Return + COUNT(AOL.[Date])
	FROM dbo.tblArchive_OrderLOG AS AOL (NOLOCK)
	LEFT JOIN tblOrderOHD AS O (NOLOCK) ON AOL.OrderID = O.OrderID
	LEFT JOIN tblRoomOHD AS R (NOLOCK) ON O.RoomID = R.RoomID
	LEFT JOIN tblLocationClass AS L (NOLOCK) ON R.LocationClassID  = L.LocationClassID
	LEFT JOIN tblKitchens AS K (NOLOCK) ON L.KitchenId = K.KitchenId
	WHERE MONTH(AOL.[Date]) = @WhatMonth
		AND YEAR(AOL.[Date]) = @WhatYear
		AND COALESCE(AOL.DietID, -1) = @DietID
		AND dbo.GetActionID('RECEIVED') = ActionID
		AND K.KitchenId = ISNULL(@KitchenId,K.KitchenId)

	RETURN COALESCE(@Return, 0)
END
go

