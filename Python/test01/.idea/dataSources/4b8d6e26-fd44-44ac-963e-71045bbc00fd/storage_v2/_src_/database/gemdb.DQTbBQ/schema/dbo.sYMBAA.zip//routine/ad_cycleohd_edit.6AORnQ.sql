



CREATE     PROCEDURE [dbo].[ad_CycleOHD_Edit]
@User			char(10),
@ExistingXlatID		char(10),
@XlatID			char(10),
@FrequencyCode		varchar(50),
@BeginDate		datetime,
@Active			bit,
@Description	varchar(500),
@DELETE			bit = 0


AS 
	DECLARE @Message varchar(255)

	IF @DELETE = 1
		GOTO DODELETE

	IF NOT EXISTS(SELECT * 	FROM dbo.tblCycleOHD
		      WHERE	XlatID = @XlatID)   	
	BEGIN
		INSERT dbo.tblCycleOHD (XlatID, FrequencyCode, BeginDate, LastChangeDate, LastChangedby, Active, [Description])
		VALUES(@XlatID, @FrequencyCode, @BeginDate, getdate(), @User, @Active, @Description)
		IF @@ERROR <> 0
			SET  @Message = 'Error creating Cycle OHD Item [' + @XlatID + '] Err#: ' + Cast(@@ERROR AS varchar(25))
		SET  @Message = 'New CycleOHD Item Added: ' + @XlatID + ' - Frequency Code: (' + @FrequencyCode +  ')'
	END
	ELSE
	BEGIN

		UPDATE	dbo.tblCycleOHD
		SET	XlatID = @XlatID,
			FrequencyCode = @FrequencyCode,
			LastChangeDate = getdate(),
			BeginDate = @BeginDate,
			LastChangedBy = @User,
			Active = @Active,
			[Description] = @Description
	      	WHERE  	XlatID = @ExistingXlatID

		SET  @Message = 'CycleOHD item edited: '  + @XlatID + ' - Frequency Code: (' + @FrequencyCode +  ')'
	END
	
	EXEC dbo.sp_Logit 9, 1, @User, @Message, 1010	
	SELECT @Message AS 'Rtn'

	RETURN

	DODELETE:
 	DELETE	dbo.tblCycleOHD
       	WHERE  	xlatID = @ExistingXlatID
       	
    DELETE dbo.tblCycleXlat
		WHERE xlatID = @ExistingXlatID

	SET  @Message = 'CycleOHD Item [' + @ExistingXlatID + '] Deleted'

	EXEC dbo.sp_Logit 9, 1, @User, @Message, 1010	
	SELECT @Message AS 'Rtn'
go

