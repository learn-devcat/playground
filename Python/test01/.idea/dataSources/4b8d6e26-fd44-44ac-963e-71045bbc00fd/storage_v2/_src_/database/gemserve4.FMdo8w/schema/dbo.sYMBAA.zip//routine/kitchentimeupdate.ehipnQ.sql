CREATE PROCEDURE [dbo].[KitchenTimeUpdate]
	@LoginUserId		VARCHAR(250),
	@KitchenTimeId		INT,
	@KitchenId			INT,
	@Day				INT,
	@StartTime			CHAR(5),
	@EndTime			CHAR(5)
AS
	
	SET NOCOUNT ON
	
	IF (@KitchenTimeId > 0)
	BEGIN
		UPDATE dbo.tblKitchenTimes	
			SET KitchenId = @KitchenId,
			[Day] = @Day,
			StartTime = @StartTime,
			EndTime = @EndTime
		WHERE KitchenTimeId = @KitchenTimeId
	END
	ELSE
	BEGIN
		INSERT INTO dbo.tblKitchenTimes (KitchenId, [Day], StartTime, EndTime)
			VALUES(@KitchenId, @Day, @StartTime, @EndTime)
			
		SELECT @KitchenTimeID = SCOPE_IDENTITY()
	END

	SELECT @KitchenTimeID AS KitchenTimeID
		
	RETURN
go

