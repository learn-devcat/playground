

CREATE PROCEDURE dbo.sp_Report_AccountSummary_Date
@StartAccount			char(19),
@EndAccount			char(19),
@BeginAccountClass		int,
@EndAccountClass		int,
@dBeginDate			datetime,
@dEndDate			datetime,
@IgnorePrintFlag		int=0
AS
	SELECT	A.AccountNo,
			dbo.NameLookup(A.AccountNo, '') AS Name,
			dbo.dDateOnly(D.TransDate) AS TransDate,
			D.TransTotal,
			D.OutletNo,
			D.TransID,RTRIM(O.OutletName) AS OutletName,
			TD.Payment
	FROM	tblAccountOHD AS A 
			LEFT JOIN tblDetail AS D
	ON		A.AccountNo=D.AccountNo
			LEFT JOIN tblOutletOHD AS O
	ON 		D.OutletNo=O.OutletNo
			LEFT JOIN tblTransDef AS TD
	ON		D.TransID=TD.TransID
			LEFT JOIN tblAccountClass AS C
	ON		A.AccountClassID = C.AccountClassID
	WHERE	(A.AccountNo BETWEEN @StartAccount AND @EndAccount
			AND D.TransDate BETWEEN @dBeginDate AND @dEndDate
			AND A.AccountClassID BETWEEN @BeginAccountClass AND @EndAccountClass
			AND (ISNULL(C.Status,0) & 1) = 0) OR
    		(A.AccountNo BETWEEN @StartAccount AND @EndAccount
			AND D.TransDate BETWEEN @dBeginDate AND @dEndDate
			AND A.AccountClassID BETWEEN @BeginAccountClass AND @EndAccountClass
			AND ((ISNULL(C.Status,0) & 1) = @IgnorePrintFlag))
	ORDER BY 	D.AccountNo,D.TransDate,D.OutletNo,D.TransID
go

