
CREATE      PROCEDURE dbo.WorkorderDTL_ListOpen
@User           char(10),
@LocationID     int,
@EmployeeID     int
AS
    SELECT  O.AccountNo,
            O.LocationID,
	    O.WorkorderNumber,
            O.PO,
            O.OpenDate,
            DEF.TransID as DetailTransID,   -- TRANSID for THIS detail item.
            A.FirstName,
            A.LastName,
	    RTRIM(A.LastName) + ', ' + RTRIM(A.FirstName) as AccountFullName,
            A.Description as AltName,
            A.Phone,
            DEF.ShortDescription as DetailShortDescription,
            DEF.Description as DetailDescription,
            DEF.SkillLevel,
            DEF.LeadTime,
            DTL.ID,                         -- This is the "UNIQUE" ID for each record in the DTL table.
            DTL.WorkorderID,                -- This links back to the WorkOrderOHD
            DTL.WorkOrderDTLID,             -- Unique ID for this DETAIL record within THIS WorkOrder OHD.
            DTL.WorkOrderDTLDefID,          -- This points to the default overhead ...
            DTL.AssigningEmployeeID,
            DTL.AssignedEmployeeID,
            DTL.AssignmentDate,
            DTL.CompletingEmployeeID,
            DTL.Completed,           
            DTL.Price,
            DTL.Cost,
            DTL.ActualHours,
            DTL.ScheduledStartDate,
            DTL.ActualStartDate,
            DTL.CompletionDate, 
            DTL.Notes
    FROM    tblWorkOrderDTL DTL
    LEFT JOIN tblWorkOrderOHD O      on DTL.WorkOrderID = O.WorkOrderID
    LEFT JOIN tblAccountOHD A        on O.AccountNo = A.AccountNo
    LEFT JOIN tblWorkOrderDTLDEF DEF on DTL.WorkOrderDTLDEFID = DEF.WorkOrderDTLDEFID
    WHERE   O.LocationID IN (SELECT LocationID FROM cfgUserLocations WHERE UserID = @User) AND
            O.Completed = 0 AND
            DTL.Completed = 0 AND
            DTL.AssignedEmployeeID = @EmployeeID
    ORDER BY O.WorkOrderNumber, DTL.WorkOrderDTLID
go

