

CREATE PROCEDURE dbo.RolePrivileges
@Roles		varchar(2000),
@Application	int=0

AS
	SET NOCOUNT ON

	EXEC GEMdb..gem_GetRolePrivileges @Roles,@Application

	RETURN
go

