CREATE PROCEDURE dbo.gem_CheckUserPrivilegeByKey
	@UserID varchar(20),
	@ActionKey varchar(25),
	@Application int = 1
AS
BEGIN

    DECLARE @ActionID as int

	-- =============================================
	-- Author:		wscott
	-- Create date: 26-Nov-07
	-- Description:	Check a specific user ID for a privilege key and return 
	--              the action ID if it's allowed, or 0 if not.
	-- =============================================
	
	-- SET NOCOUNT ON added to prevent extra result sets FROM
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
    SELECT DISTINCT	@ActionID = ISNULL( A.ActionID , 0 )
    FROM    tblPrivilegeClassMembers AS M
       JOIN tblPrivilegeLinks AS PL ON M.PrivilegeClassID = PL.PrivilegeClassID
       JOIN tblPrivilegeActions AS A ON PL.ActionID = A.ActionID
	WHERE     M.UserID = @UserID
		  AND A.ActionKey = @ActionKey
          AND PL.Application = @Application

	SELECT ISNULL( @ActionID , 0 ) as ActionID

END
go

