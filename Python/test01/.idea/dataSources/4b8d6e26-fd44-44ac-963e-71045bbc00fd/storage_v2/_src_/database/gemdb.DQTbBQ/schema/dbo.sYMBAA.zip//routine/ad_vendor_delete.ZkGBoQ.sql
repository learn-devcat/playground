
CREATE PROCEDURE [dbo].[ad_Vendor_Delete] @ID int
AS 
    DELETE  dbo.tblVendors
    WHERE   ID = @ID
go

