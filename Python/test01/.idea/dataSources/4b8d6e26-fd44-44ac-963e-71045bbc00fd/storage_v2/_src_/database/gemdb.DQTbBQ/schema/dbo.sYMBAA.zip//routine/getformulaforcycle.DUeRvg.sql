
CREATE FUNCTION [dbo].[GetFormulaForCycle]
(
    @BeginDate datetime,
	@EndDate datetime
)
RETURNS char(3)
AS
BEGIN
	DECLARE @cnt int

	-- if the end date is before the begin date, just leave, the cycle is wrong to begin with
	IF(@BeginDate >= @EndDate)
		RETURN ''

    --are we greater than, or equal to a year?
	IF(@EndDate >= DATEADD(year, 1, @BeginDate))
	BEGIN
		SET @cnt = 1

		--test for years
		WHILE @cnt < 100
		BEGIN
			IF(DATEADD(YEAR, @cnt, @BeginDate) = @EndDate)
				RETURN 'y' + dbo.LPad( @cnt, 2, '0')
			ELSE
				SET @cnt = @cnt + 1
		END
	END

	--are we greater than, or equal to a quarter?
	IF(@EndDate >= DATEADD(QUARTER, 1, @BeginDate))
	BEGIN
		SET @cnt = 1

		--test for quarters
		WHILE @cnt < 100
		BEGIN
			IF(DATEADD(QUARTER, @cnt, @BeginDate) = @EndDate)
				RETURN 'q' + dbo.LPad( @cnt, 2, '0')
			ELSE
				SET @cnt = @cnt + 1
		END
	END


	--are we greater than, or equal to a month?
	IF(@EndDate >= DATEADD(MONTH, 1, @BeginDate))
	BEGIN
		SET @cnt = 1

		--test for months
		WHILE @cnt < 100
		BEGIN
			IF(DATEADD(MONTH, @cnt, @BeginDate) = @EndDate)
				RETURN 'm' + dbo.LPad( @cnt, 2, '0')
			ELSE
				SET @cnt = @cnt + 1
		END
	END

	--are we greater than, or equal to a week?
	IF(@EndDate >= DATEADD(WEEK, 1, @BeginDate))
	BEGIN
		SET @cnt = 1

		--test for weeks
		WHILE @cnt < 100
		BEGIN
			IF(DATEADD(WEEK, @cnt, @BeginDate) = @EndDate)
				RETURN 'w' + dbo.LPad( @cnt, 2, '0')
			ELSE
				SET @cnt = @cnt + 1
		END
	END

	-- try bimonthly (15 days)
	IF(@EndDate = DATEADD(DAY, 15, @BeginDate))
		RETURN 'b' + dbo.LPad( DAY(@BeginDate), 2, '0')


	--OK, we're dealing with days now
	SET @cnt = 1
	WHILE @cnt < 100
	BEGIN
		IF(DATEADD(DAY, @cnt, @BeginDate) = @EndDate)
			RETURN 'd' + dbo.LPad( @cnt, 2, '0')
		ELSE
			SET @cnt = @cnt + 1
	END

	--if we got here, nothing matched, so return an empty string
	RETURN ''
END
go

