CREATE PROCEDURE [dbo].[ie_AccountImport_v3]
@Module		varchar(100)
AS
	DECLARE	@AccountTTL		varchar(100),
		@AddBadge		int,
		@ImportAccountClass	int,
		@ImportBadgeClass	int,
		@DefaultCreditLimit	money,
		@PrimaryAddressID	int,
		@InactivateNotInFile	int,
		@InactivateNewAccts	int,
		@InactivateInFile	int,
		@InactivateOldBadges	int,
		@StripZeros		int,
		@UpdateGEMDesktop	int,
		@TempAccountClass	varchar(100),
		@TempAccountClassID	int,
		@Msg			varchar(255),
		@PreProc		varchar(255),
		@PostProc		varchar(255),
		@ClassCount		int,
		@cnt					int,
		@DefaultLocation INT,
		@LocationID int,
		@BadgeLocationID int,
		@IgnoreManuallyEditedAccounts int,
		@SetInactive int,
		@ReactivateInFile varchar(200)

	-- Don't try to run IF nothing in import table
	IF NOT EXISTS (SELECT TOP 1 * FROM tblAccountImport)
		RETURN
	/*
		Changes since v1_80:
		RBeverly 4/17/2008
			* Added code to create OutletClassTTLs 
			* Refactored all code that processes delimited multiple VALUES to use new functions AND procs
				that process or create delimited strings
			* Added quick read headers to all major processes
		RBeverly 10/7/2009
			* Added LocationID import for account
		RBeverly 3/24/2010
			* Added locationID to imported badges (has new module key for badge location)
			* Added module key to allow NOT ignoring manually edited accounts
	*/

	--****************************************************************
	--				Run any Pre-procedures
	--****************************************************************
	DECLARE Prerun cursor FOR 
		SELECT sValue FROM cfgScriptParams
		WHERE sModule = @Module 
		AND KeyName LIKE 'preproc%'
		AND sValue <> ''
	OPEN Prerun
	FETCH NEXT FROM Prerun INTO @PreProc
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC ('EXEC ' + @PreProc)
		FETCH NEXT FROM Prerun INTO @PreProc
	END
	CLOSE Prerun
	DEALLOCATE Prerun	


	--****************************************************************
	--				Get module data
	--****************************************************************
	SET @AccountTTL = dbo.GetScriptParamEX('AccountTTL',@Module,'')
	IF ( @AccountTTL = '' )
	BEGIN
		-- Fatal error - log AND exit
		SET @Msg = 'Import - No Account TTL found in Module ' + @Module
		EXEC sp_Logit 0, 1, 'system', @Msg, 1000
		RAISERROR (@Msg, 16, 1)
		RETURN
	END
	SET @TempAccountClass = dbo.GetScriptParamEX('ImportAcctClass',@Module,'')
	IF ( @TempAccountClass = '' )
	BEGIN
		-- Fatal error - log AND exit
		SET @Msg = 'Import - No Import Account Class found in Module ' + @Module
		EXEC sp_Logit 0, 1, 'system', @Msg, 1000
		RAISERROR (@Msg, 16, 1)
		RETURN
	END
	SET @ImportBadgeClass = dbo.GetScriptParamEX('ImportBadgeClass',@Module,'0')
	IF ( @ImportBadgeClass = '0' )
	BEGIN
		-- Fatal error - log AND exit
		SET @Msg = 'Import - No Import Badge Class found in Module ' + @Module
		EXEC sp_Logit 0, 1, 'system', @Msg, 1000
		RAISERROR (@Msg, 16, 1)
		RETURN
	END
	
	SELECT TOP 1 @DefaultLocation = LocationID FROM dbo.cfgLocations ORDER BY LocationID
	
	SET @PrimaryAddressID = CAST(dbo.GetScriptParamEX('PrimaryAddressID',@Module,'100') as int)
	SET @AddBadge = CAST(dbo.GetScriptParamEX('AddBadgeOnImport',@Module,'0') as int)
	SET @StripZeros = CAST(dbo.GetScriptParamEX('StripBadgeZeros',@Module,'0') as int)
	SET @InactivateNotInFile = CAST(dbo.GetScriptParamEX('InactivateNotInFile',@Module,'1') as int)
	SET @InactivateInFile = CAST(dbo.GetScriptParamEX('InactivateInFile',@Module,'0') as int)
	SET @InactivateNewAccts = CAST(dbo.GetScriptParamEX('InactivateNewAccts',@Module,'0') as int)
	SET @DefaultCreditLimit = CAST(dbo.GetScriptParamEX('DefaultCreditLimit',@Module,'999999') as money)
	SET @UpdateGEMDesktop = CAST(dbo.GetScriptParamEX('UpdateGEMDesktop',@Module,'0') as int)
	SET @InactivateOldBadges = CAST(dbo.GetScriptParamEX('InactivateOldBadges',@Module,'1') as int)
	SET @LocationID = CAST(dbo.GetScriptParamEX('LocationID',@Module, @DefaultLocation) as int)
	SET @BadgeLocationID = CAST(dbo.GetScriptParamEX('BadgeLocationID',@Module, @LocationID) as int)
	SET @IgnoreManuallyEditedAccounts = CAST(dbo.GetScriptParamEX('IgnoreManuallyEditedAccounts',@Module, '1') as int)
	SET @ReactivateInFile = dbo.GetScriptParamEX('ReActivateInFile',@Module, NULL)
	
	--this item is being reversed to be semantically correct. IF 1, it should be a 0, otherwise null
	SET @SetInactive = CAST(CASE WHEN @ReactivateInFile = '1' THEN 0 ELSE NULL END AS int)
	

	--****************************************************************
	--				Inactivate Accounts IF specified
	--****************************************************************
	-- IF the InactivateInFile flag is SET, then everyone in the file will be SET to inactive.
	-- No other processing matters, so SET them AND get out.
	IF ( @InactivateInFile = 1 )
	BEGIN
		UPDATE 	tblAccountOHD
		SET 	Inactive = 1,
				LastUpdateDate = GETDATE()
		WHERE	AccountNo IN (SELECT AccountNo FROM tblAccountImport)
		RETURN
	END

	--****************************************************************
	--				Prepare existing accounts for updates
	--****************************************************************

	-- Count fields in delimited string of affected account classes
	SET @ClassCount = dbo.DelimitedStringFieldCount ( @TempAccountClass, ',' )

	-- IF existing account is in one of the affected account classes AND NOT manually added or edited,
	-- SET it's ImpExpFlag to 'X' signifying that it should be updated
	WHILE @ClassCount > 0
	BEGIN
		--get class ids FROM "ImportAcctClass" key. The last class id in comma delimited list (IF more thatn one class specified)
		--will be used as the account class id IF one is not found in the import table. This will be the FIRST one in the list, because
		--this routine starts FROM the END AND moves to the front.
		SET @ImportAccountClass = CAST(dbo.GetDelimitedStringField( @TempAccountClass, ',', @ClassCount) AS int)
			
		UPDATE	tblAccountOHD
		SET 	ImpExpFlag = 'X',
				LastUpdateDate = GETDATE()
		WHERE	AccountClassID = @ImportAccountClass
				AND (SELECT CASE WHEN @IgnoreManuallyEditedAccounts = 1 THEN CASE WHEN ImpExpFlag = 'M' THEN 'no' ELSE 'yes' END ELSE 'yes' END) = 'yes'
		
		SET @ClassCount = @ClassCount - 1
	END

	--****************************************************************
	--				UPDATE existing accounts
	--**************************************************************** 
	--SET the ImpExpFlag in the import table to 'N' to prepare for importing
	UPDATE 	tblAccountImport
	SET	ImpExpFlag = 'X'
	--UPDATE existing records in the tblAccountOHD table
	UPDATE	tblAccountOHD
	SET	Description = ISNULL(I.Description, A.Description),
		AccessID = ISNULL(I.AccessID, A.AccessID),
		Status = ISNULL(I.Status, A.Status),
		Title = ISNULL(I.Title, A.Title),
		FirstName = ISNULL(I.FirstName, A.FirstName),
		LastName = ISNULL(I.LastName, A.LastName),
		Phone = ISNULL(I.Phone, A.Phone),
		Fax = ISNULL(I.Fax, A.Fax),
		email = ISNULL(I.email, A.email),
		AccountClassID = ISNULL(dbo.AccountClassLU(I.AccountClassID), A.AccountClassID),
		PIN = ISNULL(I.PIN, A.PIN),
		ActiveDate = ISNULL(I.ActiveDate, A.ActiveDate),
		ExpireDate = ISNULL(I.ExpireDate, A.ExpireDate),
		Process = ISNULL(I.Process, A.Process),
		Reference = ISNULL(I.Reference, A.Reference),
		ImpExpFlag = 'Y',
		Inactive = COALESCE(I.Inactive, @SetInactive, A.Inactive),
		NoStatements = ISNULL(I.NoStatements, A.NoStatements),
		NoAging = ISNULL(I.NoAging, A.NoAging),
		NoFinanceChg = ISNULL(I.NoFinanceChg, A.NoFinanceChg),
		NoVerify = ISNULL(I.NoVerify, A.NoVerify),
		NoDetail = ISNULL(I.NoDetail, A.NoDetail),
		Bump200 = ISNULL(I.Bump200, A.Bump200),
		AutoOverpost = ISNULL(I.AutoOverpost, A.AutoOverpost),
		PublicID = ISNULL(I.PublicID, A.PublicID),
		User1 = ISNULL(I.User1, A.User1),
		User2 = ISNULL(I.User2, A.User2),
		User3 = ISNULL(I.User3, A.User3),
		User4 = ISNULL(I.User4, A.User4),
		LocationID = ISNULL(I.LocationID,ISNULL(A.LocationID, @LocationID)),
		LastUpdateDate = GETDATE()
	FROM	tblAccountOHD AS A
		JOIN tblAccountImport AS I ON A.AccountNo = I.AccountNo
	WHERE A.ImpExpFlag = 'X'	
	--SET the flags in the import table for import records that have been updated in the tblAccountOHD table
	UPDATE 	tblAccountImport
	SET	ImpExpFlag = 'E'
	FROM	tblAccountImport AS I
		JOIN tblAccountOHD AS A ON I.AccountNo = A.AccountNo

	--****************************************************************
	--				Create new accounts
	--****************************************************************
	--Insert remaining (new) items in the import table into the tblAccountOHD table 
	--Use distinct AND only import the account numbers in case a file has a duplicate
	--account number.
	INSERT INTO 	tblAccountOHD (AccountNo, AccountClassID, ImpExpFlag)
	SELECT DISTINCT I.AccountNo, ISNULL(dbo.AccountClassLU(I.AccountClassID),@ImportAccountClass), 'Y'
	FROM	tblAccountImport AS I
	WHERE	I.AccountNo IS NOT NULL AND
			ISNULL(I.ImpExpFlag,'') <> 'E'
			AND I.AccountNo <> '' --<------------ No empty account numbers

	--UPDATE the new accounts that were just added with the other information FROM the import table
	UPDATE	tblAccountOHD
	SET	Description = ISNULL(I.Description, A.Description),
		AccessID = ISNULL(I.AccessID, A.AccessID),
		Status = ISNULL(I.Status, A.Status),
		Title = ISNULL(I.Title, A.Title),
		FirstName = ISNULL(I.FirstName, A.FirstName),
		LastName = ISNULL(I.LastName, A.LastName),
		Phone = ISNULL(I.Phone, A.Phone),
		Fax = ISNULL(I.Fax, A.Fax),
		email = ISNULL(I.email, A.email),
		PIN = ISNULL(I.PIN, A.PIN),
		ActiveDate = ISNULL(I.ActiveDate, A.ActiveDate),
		ExpireDate = ISNULL(I.ExpireDate, A.ExpireDate),
		Process = ISNULL(I.Process, A.Process),
		Reference = ISNULL(I.Reference, A.Reference),
		Inactive = ISNULL(I.Inactive, @InactivateNewAccts),
		NoStatements = ISNULL(I.NoStatements, A.NoStatements),
		NoAging = ISNULL(I.NoAging, A.NoAging),
		NoFinanceChg = ISNULL(I.NoFinanceChg, A.NoFinanceChg),
		NoVerify = ISNULL(I.NoVerify, A.NoVerify),
		NoDetail = ISNULL(I.NoDetail, A.NoDetail),
		Bump200 = ISNULL(I.Bump200, A.Bump200),
		AutoOverpost = ISNULL(I.AutoOverpost, A.AutoOverpost),
		PublicID = ISNULL(I.PublicID, A.PublicID),
		User1 = ISNULL(I.User1, A.User1),
		User2 = ISNULL(I.User2, A.User2),
		User3 = ISNULL(I.User3, A.User3),
		User4 = ISNULL(I.User4, A.User4),
		LocationID = ISNULL(I.LocationID,ISNULL(A.LocationID, @LocationID)),
		LastUpdateDate = GETDATE()	
	FROM	tblAccountOHD AS A
		JOIN tblAccountImport AS I ON A.AccountNo = I.AccountNo
	WHERE	ISNULL(I.ImpExpFlag,'') <> 'E'

	--****************************************************************
	--		Add Account TTLs (New accounts ONLY)
	--****************************************************************
	SET @ClassCount = dbo.DelimitedStringFieldCount ( @AccountTTL, ',' )

	WHILE @ClassCount > 0
	BEGIN
		INSERT INTO	tblAccountTTL (AccountNo, TransClassID)
		SELECT  DISTINCT I.AccountNo, CAST(dbo.GetDelimitedStringField( @AccountTTL, ',', @ClassCount) AS int)
		FROM	tblAccountImport AS I
		WHERE	I.ImpExpFlag <> 'E'

		SET @ClassCount = @ClassCount - 1
	END
	

	--****************************************************************
	--		Add Outlet Class TTLs
	--****************************************************************
	-- Add an OutletClassTTL for each TransClass\OutletClass combo in the system 
	-- for each new acccount AND missing TTLs for ALL existing accounts that are ACTIVE. This way,
	-- new TransClass\OutletClass combos that surface will be added to all active accounts in the system

	DECLARE	@TempAcct	varchar(19)

	-- get all active accounts in the system
	DECLARE OutletClassAccounts cursor FOR 
		SELECT	AccountNo 
		FROM	tblAccountOHD
		WHERE	Inactive = 0

	OPEN OutletClassAccounts
	FETCH NEXT FROM OutletClassAccounts INTO @TempAcct
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC dbo.sp_Account_InsertNewOutletClassTTLs 'system', @TempAcct
		
		FETCH NEXT FROM OutletClassAccounts INTO @TempAcct
	END
	CLOSE OutletClassAccounts
	DEALLOCATE OutletClassAccounts

	--****************************************************************
	--				Add\UPDATE Badges
	--****************************************************************
	-- Strip leading zeros for NEW badges
	IF ( @StripZeros = 1 )
	BEGIN
		UPDATE  tblAccountImport
		SET	BadgeNo = CASE
				WHEN LEFT(BadgeNo,1) = '0' THEN dbo.StripLeadingZeros(BadgeNo)
				ELSE BadgeNo
			END
	END

	--Create Badges for ones that don't exist AND UPDATE existing badges
	IF (@AddBadge <> 0)
	BEGIN 
		--UPDATE existing badges
		UPDATE	tblBadgesOHD
		SET	FirstName = ISNULL(I.FirstName,''),
			LastName = ISNULL(I.LastName,''),
			Limit = ISNULL(I.CreditLimit,B.Limit),
			Inactive = ISNULL(I.Inactive, 0),
			LocationID = ISNULL(B.LocationID, @BadgeLocationID) 
		FROM	tblBadgesOHD AS B
			LEFT JOIN tblAccountImport AS I ON B.AccountNo = I.AccountNo
			AND B.BadgeNo = I.BadgeNo
		WHERE	I.ImpExpFlag = 'E' 

		--Inactivate existing badges that WHERE not imported for accounts that were imported
		IF (@InactivateOldBadges = 1)
			UPDATE	tblBadgesOHD
			SET	Inactive = 1
			FROM	tblBadgesOHD AS B, tblAccountImport AS I
			WHERE	I.ImpExpFlag = 'E' AND 
					(B.AccountNo IN (SELECT AccountNo FROM tblAccountImport) 
					AND B.BadgeNo NOT IN 
					(SELECT X.BadgeNo FROM tblBadgesOHD AS X
						JOIN tblAccountImport AS IM ON X.AccountNo = IM.AccountNo
						 AND X.BadgeNo = IM.BadgeNo))
									
		--Insert new badges into the tblBadgesOHD table for new accounts
		INSERT INTO tblBadgesOHD (AccountNo, BadgeNo, FirstName, LastName, BadgeClassID,Limit, Inactive, LocationID)
		SELECT	I.AccountNo AS Acct, 
			I.BadgeNo AS Badge, 
			ISNULL(I.FirstName,''), 
			ISNULL(I.LastName,''),
			@ImportBadgeClass,
			ISNULL(I.CreditLimit,@DefaultCreditLimit),
			0,
			@BadgeLocationID
		FROM	tblAccountImport AS I
		WHERE	ISNULL(I.ImpExpFlag,'Z') <> 'E' 

		--Insert new badges into the tblBadgesOHD table for existing accounts
		INSERT INTO	tblBadgesOHD (AccountNo, BadgeNo, FirstName, LastName, BadgeClassID,Limit, Inactive, LocationID)
		SELECT	I.AccountNo AS Acct, 
			I.BadgeNo AS Badge, 
			ISNULL(I.FirstName,''), 
			ISNULL(I.LastName,''),
			@ImportBadgeClass,
			ISNULL(I.CreditLimit,@DefaultCreditLimit),
			0,
			@BadgeLocationID
		FROM	tblAccountImport AS I
		WHERE	ISNULL(I.ImpExpFlag,'Z') = 'E' 
			AND I.BadgeNo NOT IN (SELECT BadgeNo FROM tblBadgesOHD WHERE AccountNo = I.AccountNo)
	END

	--Flag account records in import table that have been updated
	UPDATE 	tblAccountImport
	SET		ImpExpFlag = 'A'
	FROM	tblAccountImport AS I
				JOIN 
			tblAccountOHD AS A ON I.AccountNo = A.AccountNo


	--****************************************************************
	--				Add\UPDATE addresses
	--****************************************************************
	--UPDATE existing records in the tblAccountAddress table
	UPDATE 	tblAccountAddress
	SET	Address1 = ISNULL(I.Address1,AD.Address1),
		Address2 = ISNULL(I.Address2,AD.Address2),
		Address3 = ISNULL(I.Address3,AD.Address3),
		Address4 = ISNULL(I.Address4,AD.Address4),
		Address5 = ISNULL(I.Address5,AD.Address5)
	FROM	tblAccountAddress AS AD
		JOIN tblAccountImport AS I ON AD.AccountNo = I.AccountNo AND
			UPPER(AD.AddressID) = @PrimaryAddressID
	
	--SET the flags in the import table for import records that have been updated in the tblAccountAddress table
	UPDATE 	tblAccountImport
	SET	ImpExpFlag = 'U'
	FROM	tblAccountImport AS I
		JOIN tblAccountAddress AS A ON I.AccountNo = A.AccountNo 
			AND A.AddressID = @PrimaryAddressID
	--Insert the remaining (new) items into the tblAccountAddress table (non-NULL items only)
	INSERT INTO	tblAccountAddress (AccountNo, AddressID, Address1, Address2, Address3,
						Address4, Address5)
	SELECT	AccountNo,
		@PrimaryAddressID,
		ISNULL(Address1,''),
		ISNULL(Address2,''),
		ISNULL(Address3,''),
		ISNULL(Address4,''),
		ISNULL(Address5,'')
	FROM	tblAccountImport
	WHERE	ImpExpFlag <> 'U'
	
	--********************************************************************************
	--				Inactivate accounts in affected classes AND NOT in file
	--********************************************************************************

	IF ( @InactivateNotInFile = 1 )
	BEGIN
		EXECUTE ('UPDATE tblAccountOHD SET Inactive = 1 WHERE AccountClassID IN (' + @TempAccountClass + ') AND ImpExpFlag = ''X''')
	END

	-- final flag change for all updated\added accounts, SET to normal
	UPDATE tblAccountOHD 
	SET ImpExpFlag = 'N',
		LastUpdateDate = GETDATE()
	WHERE ImpExpFlag = 'X'

	--************************************************************
	--				UPDATE GEMdesktop
	--************************************************************
	IF ( @UpdateGEMDesktop = 1 )
	BEGIN
		EXEC pub_CreateLoginsFromAccounts
	END


	--************************************************************
	--				Run any Post-procedures
	--************************************************************
	DECLARE PostRun cursor FOR 
		SELECT sValue FROM cfgScriptParams
		WHERE sModule = @Module 
		AND KeyName LIKE 'postproc%'
		AND sValue <> ''
	OPEN PostRun
	FETCH NEXT FROM PostRun INTO @PostProc
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC ('EXEC ' + @PostProc)
		FETCH NEXT FROM PostRun INTO @PostProc
	END
	CLOSE PostRun
	DEALLOCATE PostRun	

	--************************************************************
	--			DELETE all records in the tblAccountImport table
	--************************************************************

	DELETE	tblAccountImport
go

