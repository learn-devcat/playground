

CREATE PROCEDURE dbo.sp_Audit_Update
@User		char(10),
@DetailID	uniqueidentifier
AS 
	UPDATE	tblDetail
	SET		AuditDate = getdate(),
			AuditUser = @User
	WHERE	DetailID = @DetailID
go

