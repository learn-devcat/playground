

CREATE PROCEDURE dbo.DietWaveUpdate
@LoginUserID		varchar(250),
@DietID	int,
@WaveID	int,
@Active	int

AS
	SET NOCOUNT ON

	UPDATE	dbo.tblDietWave
	SET	Active = @Active
	WHERE	DietID = @DietID
		AND WaveID = @WaveID

	IF ( @@ROWCOUNT = 0 )
		INSERT INTO dbo.tblDietWave (DietID, WaveID, Active)
			VALUES (@DietID, @WaveID, @Active)

	RETURN
go

