

CREATE FUNCTION dbo.GetLastOrderByPatient(@PatientID int, @AdmitDate datetime, @Now datetime)
RETURNS datetime
BEGIN
	DECLARE @OrderDate datetime
	
	SELECT TOP 1 @OrderDate = OrderDate
	FROM dbo.tblOrderOHD
	WHERE PatientID = @PatientID
		AND OrderDate < @Now
	ORDER BY OrderDate DESC
	
	RETURN ISNULL(@OrderDate, @AdmitDate)
END
go

