

CREATE PROCEDURE dbo.sp_Recur_GetFunctionsList
@User		char(10)
AS
	SELECT	R.ClassID,
			R.RecurFuncID,
			R.Description,
			R.NumParms,
			R.CMD,
			R.LastRunDate,
			R.FilterID,
			R.Module,
			R.Sequence,
			R.Active,
			R.Parm1,
			R.ParmType1,
			R.Parm2,
			R.ParmType2,
			R.Parm3,
			R.ParmType3,
			R.Parm4,
			R.ParmType4,
			R.Parm5,
			R.ParmType5,
			R.Parm6,
			R.ParmType6,
			R.Parm7,
			R.ParmType7,
			R.Parm8,
			R.ParmType8,
			R.Parm9,
			R.ParmType9
	FROM		tblRecurFunctions AS R
	ORDER BY	Sequence,R.ClassID, R.Description
go

