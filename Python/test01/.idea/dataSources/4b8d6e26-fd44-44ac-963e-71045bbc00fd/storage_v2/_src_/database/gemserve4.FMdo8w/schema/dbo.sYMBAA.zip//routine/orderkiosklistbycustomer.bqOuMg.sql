

CREATE PROCEDURE dbo.OrderKioskListByCustomer
@OrderName	varchar(100)
AS
	SET NOCOUNT ON
	
	SELECT	O.OrderID,
			O.OrderDate,
			O.SubTotal,
			O.DeliveryCharge,
			O.Tip,
			E.OrderName,
			E.DeliveryDate,
			E.DeliveryDirections,
			E.Comments
	FROM		dbo.tblOrderOHD AS O (NOLOCK)
			JOIN dbo.tblOrderEX AS E (NOLOCK) ON O.OrderID = E.OrderID
	WHERE	E.OrderName = @OrderName

	RETURN
go

