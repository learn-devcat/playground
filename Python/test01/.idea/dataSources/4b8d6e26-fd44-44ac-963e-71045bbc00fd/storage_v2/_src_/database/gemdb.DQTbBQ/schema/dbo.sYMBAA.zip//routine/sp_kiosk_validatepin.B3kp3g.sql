

CREATE PROCEDURE dbo.sp_Kiosk_ValidatePIN
@User		char(10),
@AccountNo	char(19),
@PIN		char(10)
AS 
 	DECLARE	@ValidPin	char(10)
 	
 	SELECT 	@ValidPin = PIN
 	FROM	tblAccountOHD
 	WHERE	AccountNo = @AccountNo AND
 			PIN = @PIN
 			
 	IF (@ValidPin = null)
 		SELECT -99 AS Validate
 	ELSE
 		SELECT 0 AS Validate
go

