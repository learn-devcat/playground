CREATE PROCEDURE [dbo].[Micros_RemoveLinkedServer]
@ServerName	varchar(100) = 'Micros'

AS

	DECLARE	@SQL nvarchar(1000),
			@TotalSynonyms	 int,
			@CurrentRow	int,
			@SynonymName varchar(50)

	--Drop the linked Micros server
	IF EXISTS (SELECT 1 FROM sys.servers WHERE [name] = @ServerName)
	BEGIN	
		EXEC sp_droplinkedsrvlogin @ServerName, 'gemuser'
		EXEC sp_dropserver @ServerName
	END
	
	-- Put synonyms to drop in a temp table
	DECLARE @TempSynonyms AS TABLE 
	(
			[ID] INT IDENTITY(1,1),
			[SynonymName]			varchar(50)
	)

	INSERT INTO @TempSynonyms (SynonymName)
	SELECT 'MicrosMenuItems'
	UNION ALL
	SELECT 'MicrosMenuItemType'
	UNION ALL
	SELECT 'MicrosMenuLevel'
	UNION ALL
	SELECT 'MicrosPrinterClass'
	UNION ALL
	SELECT 'MicrosTouchScreenDef'
	UNION ALL
	SELECT 'MicrosTouchScreenKeyDef'
	UNION ALL
	SELECT 'MicrosMajorGroupDef'
	UNION ALL
	SELECT 'MicrosMenuItemGroupDef'
	UNION ALL
	SELECT 'MicrosFamilyGroupDef'
	UNION ALL
	SELECT 'MicrosCheckDetail'
	UNION ALL
	SELECT 'MicrosTransactionDetail'
	UNION ALL
	SELECT 'MicrosKdsDetail'
	UNION ALL
	SELECT 'MicrosOrderDeviceDef'
	UNION ALL
	SELECT 'MicrosRevenueCenterDef'

	SET @TotalSynonyms = @@ROWCOUNT
	
	-- Set up loop
	SET @CurrentRow = 1
	
	-- Drop the synonyms
	WHILE (@CurrentRow <= @TotalSynonyms)
	BEGIN
		SELECT	@SynonymName = SynonymName
		FROM	@TempSynonyms
		WHERE	[ID] = @CurrentRow
		
		IF EXISTS (SELECT 1 FROM sys.synonyms WHERE name = @SynonymName)
		BEGIN
			SET @SQL = 'DROP SYNONYM ' + @SynonymName
			EXEC(@SQL)
		END
		
		SET @CurrentRow = @CurrentRow + 1
	END	

	--Remove the Overhead Key	
	IF EXISTS (SELECT 1 FROM dbo.cfgOverhead WHERE KeyID = 'MicrosServerName')
		DELETE FROM dbo.cfgOverhead
		WHERE KeyID = 'MicrosServerName'

	RETURN
go

