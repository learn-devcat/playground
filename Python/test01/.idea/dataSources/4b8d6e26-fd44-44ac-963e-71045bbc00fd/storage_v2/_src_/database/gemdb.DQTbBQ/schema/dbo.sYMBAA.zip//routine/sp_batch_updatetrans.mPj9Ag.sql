CREATE PROCEDURE [dbo].[sp_Batch_UpdateTrans]
@User		char(10),
@DetailID	uniqueidentifier,
@BatchID	char(10),
@AccountNo	char(19),
@BadgeNo	char(19),
@TransDate	datetime,
@Category	char(10),
@OutletNo	int,
@TransID	int,
@RefNum	char(6),
@ChkNum	char(6),
@PaymentNo	int,
@ServeEmpl	int,
@PostEmpl	int,
@Covers	smallint,
@RevCntr	int,
@TransTotal	money,
@Sales1	money,
@Sales2	money,
@Sales3	money,
@Sales4	money,
@Sales5	money,
@Sales6	money,
@Sales7	money,
@Sales8	money,
@Sales9	money,
@Sales10	money,
@Sales11	money,
@Sales12	money,
@Sales13	money,
@Sales14	money,
@Sales15	money,
@Sales16	money,
@Tax1		money,
@Tax2		money,
@Tax3		money,
@Tax4		money,
@Dsc		money,
@Svc		money,
@Comment	varchar(40)
AS
	UPDATE	tblBatch
	SET		BatchID=@BatchID,AccountNo=@AccountNo, BadgeNo=@BadgeNo,
			TransDate=@TransDate,Category=@Category,OutletNo=@OutletNo,TransID=@TransID,
			RefNum=@RefNum,ChkNum=@ChkNum,PaymentNo=@PaymentNo,ServeEmpl=@ServeEmpl,
			PostEmpl=@PostEmpl,Covers=@Covers,RevCntr=@RevCntr,TransTotal=@TransTotal,
			Sales1=@Sales1,Sales2=@Sales2,Sales3=@Sales3,Sales4=@Sales4,Sales5=@Sales5,
			Sales6=@Sales6,Sales7=@Sales7,Sales8=@Sales8,Sales9=@Sales9,Sales10=@Sales10,
			Sales11=@Sales11,Sales12=@Sales12,Sales13=@Sales13,Sales14=@Sales14,
			Sales15=@Sales15,Sales16=@Sales16,Tax1=@Tax1,Tax2=@Tax2,Tax3=@Tax3,
			Tax4=@Tax4,Dsc=@Dsc,Svc=@Svc,Comment=@Comment,LastUpdateDate=GETDATE()
	WHERE	DetailID=@DetailID
	
	DECLARE 	@cMsg char(255),
				@CoreID	int
	SET @CoreID = dbo.GetCoreIDFromUser(@User)
	SET @cMsg = 'Updated batch transaction Detail ID <' + CAST(@DetailID as varchar(32)) + '> for Batch ID <' + @BatchID + '>'
	EXEC dbo.sp_Logit 1 , @CoreID , @User , @cMsg
go

