
CREATE   PROCEDURE dbo.WorkorderDTLClass_List
@User   char(10)
AS
	SELECT      WorkOrderDTLClassID,
                Description
	FROM        tblWorkorderDTLClass
	ORDER BY    WorkOrderDTLClassID
go

