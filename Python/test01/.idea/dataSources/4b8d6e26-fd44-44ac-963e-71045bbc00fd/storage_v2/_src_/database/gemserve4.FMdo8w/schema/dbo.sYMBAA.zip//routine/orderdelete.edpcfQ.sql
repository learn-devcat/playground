


----------------------------------------------------------------------------------
--
--  OrderDelete                  15-Aug-03 w.j.scott
--
--  Remove an order from the database.  The detail entries, if any, are
--  also removed.
--
--
-----------------------------------------------------------------------------------
CREATE PROCEDURE dbo.OrderDelete 
@OrderID as int
AS
	
	DELETE dbo.tblOrderOHD
	WHERE  OrderID = @OrderID
		
	RETURN
go

