

CREATE PROCEDURE dbo.ad_AccountCategory_Insert
@User			char(10),
@Category		char(10),
@Description	varchar(24)	
AS 
	INSERT INTO tblAccountCategory(Category, Description)
				VALUES(@Category, @Description)
go

