CREATE PROCEDURE [dbo].[DietGetEX]
@SearchString	varchar(200),
@DietID 	int

AS
	SET NOCOUNT ON

	IF ( @SearchString <> '' )
	BEGIN
		DECLARE	@SQL	nvarchar(4000)

 		SET @SQL = 'SELECT DietID, Description, ISNULL(AltDescription,'''') AS AltDescription, ISNULL(POSDietID,0) AS POSDietID, ISNULL(POSDescription,'''') AS POSDescription, ISNULL(Notes,'''') AS Notes, Active, ISNULL(NPO,''0'') AS NPO, ISNULL(MenuLevel,''0'') AS MenuLevel FROM dbo.tblDietOHD AS D WHERE ' + @SearchString +
 		' SELECT DISTINCT W.WaveID, W.Description AS WaveName, ISNULL(DW.Active, 0) AS Active, W.EndTime FROM dbo.tblWave AS W LEFT JOIN dbo.tblDietOHD AS D ON ' + @SearchString + ' LEFT JOIN dbo.tblDietWave AS DW ON DW.WaveID = W.WaveID AND DW.DietID = D.DietID WHERE W.ShowOnMap <> 0 ORDER BY W.EndTime'

		EXEC sys.sp_executesql @SQL
	END
	ELSE
	BEGIN
		SELECT  D.DietID,
			D.Description,
			ISNULL(D.AltDescription,'') AS AltDescription,
			ISNULL(D.POSDietID,0) AS POSDietID,
			ISNULL(D.POSDescription,'') AS POSDescription,
			ISNULL(D.Notes,'') AS Notes,
			D.Active,
			ISNULL(D.NPO,'0') AS NPO,
			ISNULL(D.MenuLevel, '0') AS MenuLevel
		FROM    dbo.tblDietOHD AS D
		WHERE   D.DietID = @DietID

		SELECT	DISTINCT W.WaveID,
			W.Description AS WaveName,
			ISNULL(DW.Active, 0) AS Active,
                        W.EndTime
		FROM	dbo.tblWave AS W
			LEFT JOIN dbo.tblDietWave AS DW ON DW.WaveID = W.WaveID AND DW.DietID = @DietID
		 WHERE W.ShowOnMap <> 0
		ORDER BY W.EndTime
	END

	RETURN
go

