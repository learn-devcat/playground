

CREATE PROCEDURE dbo.sp_Overhead_Insert
@oKey		varchar(32),
@sValue	varchar(255),
@iType		smallint,
@iSequence	smallint
AS
	INSERT INTO	cfgOverhead (oKey,sValue,dType,Sequence)
	VALUES	(@oKey,@sValue,@iType,@iSequence)
go

