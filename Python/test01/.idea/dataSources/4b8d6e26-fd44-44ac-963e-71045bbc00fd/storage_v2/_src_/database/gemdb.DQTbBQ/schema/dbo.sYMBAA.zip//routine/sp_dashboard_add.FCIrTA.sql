CREATE PROCEDURE [dbo].[sp_Dashboard_Add]
	@User			char(10),
	@Url    varchar(500),
	@Name			varchar(50)
AS

	DECLARE @ExistingID int

	Select @ExistingID = ID
	FROM tblDashboardPages
	WHERE (UserID = @User)
	AND PageURL = @Url

	IF (@ExistingID IS NULL)
	BEGIN
	   INSERT INTO tblDashboardPages(Name, UserID, GoToURL,PageURL)
		VALUES(@Name,@User,@Url,@Url)
	END
	ELSE
	BEGIN

		INSERT INTO tblDashboardPages(Name, UserID, SerializedRequestData, PageURL, UserHidden, SortPosition, PrivilegeActionID,GoToURL,AllowInteraction)
	   	SELECT Top 1 Name,@User,SerializedRequestData, PageURL ,0,SortPosition,PrivilegeActionID,GoToURL,AllowInteraction
		FROM tblDashboardPages
		WHERE UserID = @User
		AND PageURL = @Url

		DELETE Top(1) tblDashboardPages
		WHERE ID IN(
		SELECT Top 1 ID
		FROM tblDashboardPages
		WHERE UserID = @User
		AND PageURL = @Url
		ORDER BY ID ASC)
	END
go

