

CREATE FUNCTION dbo.ColumnAlreadyExists(@TableName nvarchar(128),@ColumnName nvarchar(128)) 
RETURNS INT
AS
BEGIN 
	--Returns 0 IF column does not exist. Returns 1 IF column exists.
	--See IF the Table already contains the column.
	IF EXISTS (SELECT * FROM SysObjects O 
			INNER JOIN SysColumns C ON O.ID=C.ID
			WHERE ObjectProperty(O.ID,'IsUserTable') = 1 
				AND O.Name=@TableName
				AND C.Name=@ColumnName) 
		RETURN 1
	--Table does not contain the column.
	RETURN 0
END
go

