


CREATE  PROCEDURE dbo.ie_OfflineImport
AS
	DECLARE	@StripZeros	int
	SELECT @StripZeros = dbo.GetOverheadItem('StripBadgeZeros')
	IF (@StripZeros = 1)
	BEGIN
		UPDATE tblOfflineImport SET BadgeNo = dbo.StripLeadingZeros(BadgeNo) WHERE LEFT(BadgeNo,1) = '0'
		UPDATE tblOfflineImport SET AccountNo = dbo.GetFirstAccount(BadgeNo)
	END
	INSERT INTO 	tblBatch (CoreID,BatchID, AccountNo,BadgeNo,TransDate,OutletNo,RefNum,ChkNum,TransTotal,Sales1,Comment,CycleNo,TransID) 
	SELECT 	CoreID,BatchID,ISNULL(AccountNo,BadgeNo),BadgeNo,TransDate,OutletNo,ISNULL(RefNum,''),ChkNum,TransTotal,Sales1,Comment,CycleNo,TransID
	FROM 		tblOfflineImport
go

