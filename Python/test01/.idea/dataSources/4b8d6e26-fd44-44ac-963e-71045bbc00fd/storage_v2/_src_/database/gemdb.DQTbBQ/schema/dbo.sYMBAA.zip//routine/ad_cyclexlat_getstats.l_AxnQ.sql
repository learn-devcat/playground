





CREATE    PROCEDURE dbo.ad_CycleXlat_GetStats
@XlatID	char(10) = ''
AS 

	IF @XlatID = ''
	BEGIN

		SELECT	XlatID,
			(SELECT Max(CycleNo) FROM tblCycleXlat WHERE xlatID = C.xlatID) AS 'LastCycle',
			dbo.GetCycleByXREF( -1 , getdate() , XlatID) AS 'CurrentCycleNo',
			(SELECT Max(EndDate) FROM tblCycleXlat WHERE xlatID = C.xlatID) AS 'LastDate'
		FROM	dbo.tblCycleXlat AS C
		GROUP BY XlatID
	END
	ELSE
	BEGIN
		SELECT	XlatID,
			(SELECT Max(CycleNo) FROM tblCycleXlat WHERE xlatID = @xlatID) AS 'LastCycle',
			dbo.GetCycleByXREF( -1 , getdate() , XlatID) AS 'CurrentCycleNo',
			(SELECT Max(EndDate) FROM tblCycleXlat WHERE xlatID = @xlatID) AS 'LastDate'
		FROM	dbo.tblCycleXlat
		WHERE	xlatID = @xlatID
		GROUP BY XlatID
	END
go

