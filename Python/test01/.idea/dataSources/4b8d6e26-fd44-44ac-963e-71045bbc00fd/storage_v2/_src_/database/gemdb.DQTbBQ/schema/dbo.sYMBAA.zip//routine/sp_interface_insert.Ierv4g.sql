

CREATE PROCEDURE dbo.sp_Interface_Insert
@InterfaceID 	int, 
@CoreID 	int, 
@sDesc 	varchar(32)
AS
	INSERT INTO	cfgInterface (InterfaceID,CoreID,Active,Description)
	VALUES	(@InterfaceID,@CoreID,'1',@sDesc)
go

