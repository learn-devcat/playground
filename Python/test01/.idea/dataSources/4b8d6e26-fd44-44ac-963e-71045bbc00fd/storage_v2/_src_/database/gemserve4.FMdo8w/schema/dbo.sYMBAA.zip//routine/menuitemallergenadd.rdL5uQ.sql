

CREATE PROCEDURE dbo.MenuItemAllergenAdd
@LoginUserID		varchar(250),
@MenuItemID		int,
@AllergenID		int,
@MenuItemAllergenID	int OUTPUT

AS
	SET NOCOUNT ON
	
	INSERT INTO dbo.tblMenuItemAllergens(MenuItemID, AllergenID)
		VALUES(@MenuItemID, @AllergenID)

	SELECT @MenuItemAllergenID = SCOPE_IDENTITY()		

	RETURN
go

