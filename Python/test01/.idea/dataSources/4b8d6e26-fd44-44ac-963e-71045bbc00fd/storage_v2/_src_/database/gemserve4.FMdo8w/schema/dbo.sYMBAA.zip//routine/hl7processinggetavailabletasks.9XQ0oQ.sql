CREATE PROCEDURE dbo.HL7ProcessingGetAvailableTasks
@MessageType	varchar(32)
AS
	SET NOCOUNT ON

	SELECT CommandID,
		MessageType,
		[Name],
		[Description],
		ControlType,
		CommandType,
		Command,
		ReturnColumn,
		[Sequence],
		Active
	FROM dbo.tblHL7Processing
	WHERE MessageType = @MessageType
		AND Active = 0
	ORDER BY [Name]

	RETURN
go

