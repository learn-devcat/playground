

CREATE PROCEDURE [dbo].[gem2go_1_GetSyncUsers_OLD]
    @CoreID int ,
    @User char(10) ,
    @EffectiveDate as varchar(100),
    @AccountClassList varchar(max),
    @BadgeClassList varchar(max),
	@SyncMultipleAccountsPerBadge bit,
	@SyncWithoutEmail bit
AS
    SET NOCOUNT ON 

   declare @CutoffDate as datetime

   -- let's see if we can get a date cutoff out of this --
   if( len( isNull( @EffectiveDate , '' )) = 0 )
      set @CutoffDate = dbo.GetDateLocalTime() 
   else
      begin try
          set @CutoffDate = cast( @EffectiveDate as datetime)        -- Check for valid date format to continue. 
      end try 
      begin catch
         set @CutoffDate = dbo.GetDateLocalTime() -- if we don't have a valid date then use todays date. 
      end catch

		-- We are limiting accounts by Account Class and if none passed in, we're taking all classes.
		DECLARE @AccountClassIds AS TABLE(
			AccountClassId	varchar(38),
			Id				int
		)

		--Separate Account Class Ids into separate rows
		INSERT INTO @AccountClassIds 
		SELECT * FROM dbo.GetTableFromDelimitedString(@AccountClassList, ',')
		if @@ROWCOUNT <= 0 
		begin
		INSERT INTO @AccountClassIds (AccountClassId, Id)
		SELECT DISTINCT AccountClassID, ROW_NUMBER()OVER(PARTITION BY AccountClassId Order By AccountClassId) as id
		FROM tblAccountOHD
		end

		-- We are limiting by badge class too, so if no list passed in, take all...   
		DECLARE @BadgeClassIds AS TABLE(
			BadgeClassId	varchar(38),
			Id				int
		)

		--Separate Badge ClassIds into separate rows
		INSERT INTO @BadgeClassIds 
		SELECT * FROM dbo.GetTableFromDelimitedString(@BadgeClassList, ',')
		if @@ROWCOUNT <= 0
		begin
		INSERT INTO @BadgeClassIds (BadgeClassId, Id)
		SELECT DISTINCT BadgeClassID, ROW_NUMBER()OVER(PARTITION BY BadgeClassId Order By BadgeClassId) as id
		FROM tblBadgesOHD
		end  
     	   

      -- We are returning ACTIVE (based on the InActive field) but the WHERE clause ONLY get's active, non-expired accounts
      -- so this is a little redundant.  BUT, the sync call to G2G required an "Active" Field so here ya go...
      -- Also doing just a little sanity check on the email address -- not great, but better than nothing ...

      select 
		--master account info
         case len(rtrim(b.firstname)+rtrim(b.lastname)) 
            when 0 then dbo.description_FullName( A.Description , A.FirstName , A.Lastname ) 
                   else rtrim(rtrim( b.Firstname ) + ' ' + B.Lastname) 
         end as Name, 
         rtrim(A.email) as Email, 
		 B.FirstName as BadgeFirstName,
		 B.LastName as BadgeLastName,
		 A.FirstName as AccountFirstName,
		 A.LastName as AccountLastName,
		 A.User1,
		 A.User2,
		 A.User3,
		 A.User4,
		 a.AccountClassID as MasterAccountClass,
		 b.BadgeClassID as MasterBadgeClass,
		 rtrim(B.AccountNo) as MasterAccountNo, 
         rtrim(B.BadgeNo) as MasterBadgeNo,
		 case when A.ImportSource IS NULL OR A.PreventChangesDuringImport = 1 then 0 else 1
		 end as CanBeActivatedWithCashlessAgreements,
		 case 
             --when B.inactive = 1           then 0 
            -- when B.ExpireDate < dbo.GetDateLocalTime() then 0
             when A.ExpireDate < dbo.GetDateLocalTime() then 0
			 when A.inactive = 1		   then 0
                                           else 1 
          end as MasterActive,  

		 --linked account info
         dbo.description_FullName( A2.Description , A2.FirstName , A2.Lastname ) as LinkedFriendlyName , 
		 rtrim(B2.AccountNo) as GEMAccountNo, 
         rtrim(B2.BadgeNo) as GEMBadgeNo,
		  case len(rtrim(B2.firstname)+rtrim(b2.lastname)) 
            when 0 then dbo.description_FullName( A2.Description , A2.FirstName , A2.Lastname ) 
                   else rtrim(rtrim( b2.Firstname ) + ' ' + B2.Lastname) 
         end as LinkedAccountName,
		 a2.AccountClassID as LinkedAccountClass,
		 b2.BadgeClassID as LinkedBadgeClass,
		    case 
             when B.inactive = 1           then 0 
             when B.ExpireDate < dbo.GetDateLocalTime() then 0
             when A.ExpireDate < dbo.GetDateLocalTime() then 0
			 when A.inactive = 1		   then 0
			 when B2.inactive = 1           then 0 
             when B2.ExpireDate < dbo.GetDateLocalTime() then 0
             when A2.ExpireDate < dbo.GetDateLocalTime() then 0
			 when A2.inactive = 1		   then 0
                                           else 1 
         end as LinkedActive,
		 T.TransClassID

      from 
	  tblAccountOHD A  -- this is our primary account which is created 1 to 1 with a GEM2go account.
	  left join  tblBadgesOHD B on A.AccountNo = B.AccountNo -- This is all the badges on the account. 
	  left join tblBadgesOHD B2 on B.BadgeNo = B2.BadgeNo
	   AND (@SyncMultipleAccountsPerBadge = 1 OR B2.AccountNo = A.AccountNo )  -- this gets us all the other accounts attached to all the badges on the account.
      left join tblAccountOHD A2 on B2.AccountNo = A2.AccountNo
	   AND (@SyncMultipleAccountsPerBadge = 1 OR A2.AccountNo = A.AccountNo )  -- this gets all the accounts including linked account info (aka department accounts)
	  left join tblAccountTTL T on A2.AccountNo = T.AccountNo   -- gets all the buckets (trans profiles/transclasses)
      where   --  B.Inactive = 0
            --and A.Inactive = 0
            --and
			(B.ActiveDate >= @CutoffDate-13
            or B.ExpireDate <= @CutoffDate+13
            or A.ActiveDate >= @CutoffDate-13
            or A.ExpireDate <= @CutoffDate+13
			or A.LastUpdateDate >= @CutoffDate-13
			or B.LastUpdateDate >= @CutoffDate-13)
            and (@SyncWithoutEmail = 1 OR A.email LIKE '%_@_%_._%')
			and A.AccountClassID in (select AccountClassId from @AccountClassIds)
			and B.BadgeClassId in (select BadgeClassId from @BadgeClassIds)
		Order By B.PrimaryBadge, B.inactive, B2.PrimaryBadge, B2.inactive, B.BadgeNo, B2.BadgeNo 
         
         

    return
go

