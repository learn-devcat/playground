

CREATE PROCEDURE dbo.ie_AccountImport_Insert
@AccountNo	char(19),
@BadgeNo	char(19),
@Description	char(30),
@AccessID	int,
@Status		int,
@Title		char(10),
@FirstName	char(15),
@LastName	char(20),
@Phone		char(15),
@Fax		char(15),
@email		varchar(64),
@AccountClassID	varchar(20),
@PIN		char(10),
@ActiveDate	datetime,
@ExpireDate	datetime,
@Process	bit,
@Reference	varchar(50),
@ImpExpFlag	char(1),
@Inactive	bit,
@NoStatements	bit,
@NoAging	bit,
@NoFinanceChg	bit,
@NoVerify	bit,
@NoDetail	bit,
@Bump200	bit,
@AutoOverPost	bit,
@AddressID	char(10),
@Address1	varchar(50),
@Address2	varchar(50),
@Address3	varchar(50),
@Address4	varchar(50),
@Address5	varchar(50),
@CreditLimit	money,
@BadgeEmail	varchar(64),
@ReloadActive	int,
@ReloadTransID	int,
@ReloadThreshold	money,
@ReloadAmount	money,
@Identity	int OUTPUT
AS
	INSERT INTO tblAccountImport (AccountNo,BadgeNo,Description,AccessID,Status,Title,FirstName,LastName,Phone,Fax,email,
			AccountClassID,PIN,ActiveDate,ExpireDate,Process,Reference,ImpExpFlag,Inactive,NoStatements,NoAging,
			NoFinanceChg,NoVerify,NoDetail,Bump200,AutoOverPost,AddressID,Address1,Address2,Address3,Address4,Address5,CreditLimit,
			BadgeEmail,ReloadActive,ReloadTransID,ReloadThreshold,ReloadAmount)
		VALUES (@AccountNo,@BadgeNo,@Description,@AccessID,@Status,@Title,@FirstName,@LastName,@Phone,@Fax,@email,
			@AccountClassID,@PIN,@ActiveDate,@ExpireDate,@Process,@Reference,@ImpExpFlag,@Inactive,@NoStatements,@NoAging,
			@NoFinanceChg,@NoVerify,@NoDetail,@Bump200,@AutoOverPost,@AddressID,@Address1,@Address2,@Address3,@Address4,@Address5,@CreditLimit,
			@BadgeEmail,@ReloadActive,@ReloadTransID,@ReloadThreshold,@ReloadAmount)
	SELECT @Identity = SCOPE_IDENTITY()
go

