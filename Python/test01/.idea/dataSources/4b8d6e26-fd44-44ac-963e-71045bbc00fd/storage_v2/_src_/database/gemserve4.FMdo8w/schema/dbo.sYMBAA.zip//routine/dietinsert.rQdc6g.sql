CREATE PROCEDURE dbo.DietInsert
	(
		@DietID             int,
		@Description        varchar(50),
		@AltDescription     varchar(50),
		@POSDietID          int,
		@POSDescription     varchar(50),
		@Notes              text,
		@RestrictedCalorie  bit = 0
	)

AS
	INSERT INTO dbo.tblDietOHD(DietID, Description, AltDescription, POSDietID,
	                POSDescription, Notes)
        VALUES(@DietID, @Description, @AltDescription, @POSDietID,
	                @POSDescription, @Notes)
	
	
	RETURN
go

