

CREATE PROCEDURE [dbo].[ScheduledReportGet]
@ScheduledReportID	int

AS
	SET NOCOUNT ON

	IF (@ScheduledReportID <= 0)
		SELECT ScheduledReportID,
			DefName,
			ReportTitle,
			ReportFile,
			ReportSQL,
			DefXML,
			PrinterName,
			NextDate,
			Frequency
		FROM dbo.tblScheduledReports
		ORDER BY ReportTitle, PrinterName
	ELSE
		SELECT ScheduledReportID,
			DefName,
			ReportTitle,
			ReportFile,
			ReportSQL,
			DefXML,
			PrinterName,
			NextDate,
			Frequency
		FROM dbo.tblScheduledReports
		WHERE ScheduledReportID = @ScheduledReportID

	RETURN
go

