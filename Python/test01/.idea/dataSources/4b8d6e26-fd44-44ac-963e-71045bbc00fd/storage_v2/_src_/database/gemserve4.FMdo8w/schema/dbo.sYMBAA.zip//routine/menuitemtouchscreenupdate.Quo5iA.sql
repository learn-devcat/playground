

CREATE PROCEDURE dbo.MenuItemTouchScreenUpdate
@LoginUserID		varchar(250),
@MenuItemID	int,
@DietID		int,
@MenuCategoryID	int,
@Location	int,
@Legend		varchar(16),
@NextScreen	int=null,

@Height		int=3,
@Width		int=4,
@Font		int=5,
@Color		int=23,
@IconPlacement	char(1)='C',
@IconID		int=1

AS
	SET NOCOUNT ON
	DECLARE 	@RowStart	int,
			@ColStart	int

	SET @RowStart = dbo.GetTSRow(@Location)
	SET @ColStart = dbo.GetTSCol(@Location)

	IF (@NextScreen = 0)
		SET @NextScreen = null

	IF EXISTS(SELECT MenuItemID FROM dbo.tblMenuItem_TouchScreen (NOLOCK)
			WHERE MenuItemID = @MenuItemID
				AND DietID = @DietID
				AND MenuCategoryID = @MenuCategoryID)

		UPDATE	dbo.tblMenuItem_TouchScreen
			SET Active = 1,
			RowStart = @RowStart,
			ColStart = @ColStart,
			Height = @Height,
			Width = @Width,	
			Font = @Font,
			Color = @Color,
			IconPlacement = @IconPlacement,
			Legend = @Legend,
			KeyType = 3,
			Modified = 1,
			NextScreen = @NextScreen
		WHERE	MenuItemID = @MenuItemID
			AND DietID = @DietID
			AND MenuCategoryID = @MenuCategoryID		
	ELSE
		INSERT INTO dbo.tblMenuItem_TouchScreen (MenuItemID, DietID, MenuCategoryID, Active,
				RowStart, ColStart, Height, Width, Font, Color, IconPlacement,
				IconID, Legend, KeyType, Modified, NextScreen)
			VALUES (@MenuItemID, @DietID, @MenuCategoryID, 1,
				@RowStart, @ColStart, @Height, @Width, @Font, @Color, @IconPlacement,
				@IconID, @Legend, 3, 1, @NextScreen)

	-- General cleanup in case we have orphaned touchscreen entries for diets or categories that no longer exist
	DELETE dbo.tblMenuItem_Touchscreen
	FROM dbo.tblMenuItem_Touchscreen AS T (NOLOCK)
	LEFT JOIN dbo.tblDietOHD AS D (NOLOCK) ON T.DietID = D.POSDietID
	WHERE D.DietID IS NULL
		OR T.MenuCategoryID IS NULL

	RETURN
go

