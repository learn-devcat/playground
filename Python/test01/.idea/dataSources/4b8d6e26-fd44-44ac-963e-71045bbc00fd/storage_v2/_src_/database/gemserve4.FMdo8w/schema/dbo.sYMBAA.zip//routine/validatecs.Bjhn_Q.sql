CREATE FUNCTION dbo.ValidateCS(@KitchenId as int, @Description as varchar(50), @LicenseKey as varchar(50))
RETURNS int
AS
BEGIN
	RETURN CHECKSUM(@KitchenId, @Description, @LicenseKey)
END
go

