CREATE PROCEDURE [dbo].[PurgeData]

AS

	DECLARE	@DataRetentionDays		int,
			@DataRetentionDate		datetime,
			@MaxPurgeRowsAllowed	int,
			@MaxPatientVisitPurge	int,
			@Msg					varchar(500)

		--Determine the number of days to keep data in the datbase (-1 = Keep All Data)
		SELECT @DataRetentionDays = COALESCE(dbo.GetOverheadValueNull('DataRetentionDays'),'-1')

		--Get the maximum number of rows allowed to be deleted at one time
		SELECT @MaxPurgeRowsAllowed = COALESCE(dbo.GetOverheadValueNull('MaxPurgeRowsAllowed'),'500000')

		--Determine the maximum number of patient visits that are allowed to be deleted at one time (Minimum 1000)
		SET @MaxPatientVisitPurge = CASE WHEN (@MaxPurgeRowsAllowed/10 > 1000) THEN (@MaxPurgeRowsAllowed /10)
										ELSE 1000 END

		--For safety reasons, keep at least a minimum of 3 months of data
		IF (@DataRetentionDays > 89)
		BEGIN

			--Set the Data Retention Date
			SET @DataRetentionDate = dbo.dDateOnly(getDate()) - @DataRetentionDays
		
			--Log that the purge process has begun
			SET @Msg = 'PURGEDATA: Begin data purge for GEMserve records prior to ' + CONVERT(varchar(10), @DataRetentionDate, 120) + '.'
			EXEC dbo.Logit 1, @Msg, 'system'

			--GENERAL MAINTENANCE -------------------------------------
			--Remove old System Log information
			;WITH D
				AS (SELECT TOP (@MaxPurgeRowsAllowed) *
				FROM dbo.tblSysLog
				WHERE EventDate < @DataRetentionDate
				ORDER BY EventDate)
			DELETE FROM D

			--Remove old Process Log information 
			;WITH D
				AS (SELECT TOP (@MaxPurgeRowsAllowed) *
				FROM dbo.tblProcessLog
				WHERE LastProcessTime < @DataRetentionDate
				ORDER BY LastProcessTime)
			DELETE FROM D

			--Remove old Workstation Log information
			;WITH D
				AS (SELECT TOP (@MaxPurgeRowsAllowed) *
				FROM dbo.tblWorkstation
				WHERE LastIdleEvent < @DataRetentionDate
				ORDER BY LastIdleEvent)
			DELETE FROM D
		
			--PATIENT VISIT MAINTENANCE --------------------------------
			--Get a list of PatientVisits older than the data retention days - use the Entry date if the discharge date is null
			--Also make sure that it is not a reserved patient that we use for doctor or stork orders, etc.
			DECLARE @PatientVisitDelete TABLE
			(
				ID				int IDENTITY(1,1),
				PatientVisitID	varchar(50),
				PatientID		int
			)

			;WITH I
				AS (SELECT TOP (@MaxPatientVisitPurge) PatientVisitID, PatientID
				FROM dbo.tblPatientVisit
				WHERE	COALESCE(DischargeDate, EntryDate) < @DataRetentionDate
					AND PatientVisitID NOT IN (SELECT KeyIn FROM dbo.tblXLAT WHERE xlatID = 'ExcludePatientPurge')
				ORDER BY COALESCE(DischargeDate, EntryDate))
			INSERT INTO @PatientVisitDelete
			SELECT PatientVisitID, PatientID FROM I

			--Remove old Patient Log information by PatientVisitID and any log information less than the DataRetentionDate
			DELETE	PL
			FROM	dbo.tblPatientLog AS PL
			JOIN	@PatientVisitDelete AS PV ON PL.PatientVisitID = PV.PatientVisitID

			;WITH D
				AS (SELECT TOP (@MaxPurgeRowsAllowed) *
				FROM dbo.tblPatientLog
				WHERE [Date] < @DataRetentionDate
				ORDER BY [Date])
			DELETE FROM D

			--Remove old Patient Notes information prior to the Data Retention Date
			;WITH D
				AS (SELECT TOP (@MaxPurgeRowsAllowed) *
				FROM dbo.tblPatientNotes
				WHERE PostDate < @DataRetentionDate
				ORDER BY PostDate)
			DELETE FROM D

			--Remove old Meal Orders for patient visits
			DELETE	O
			FROM	dbo.tblOrderOHD AS O
			JOIN	@PatientVisitDelete AS PV ON O.PatientVisitID = PV.PatientVisitID

			--Remove old Meal Orders prior to the Data Retention Date
			;WITH D
				AS (SELECT TOP (@MaxPurgeRowsAllowed) *
				FROM dbo.tblOrderOHD
				WHERE PostDate < @DataRetentionDate
				ORDER BY PostDate)
			DELETE FROM D

			--Remove old Patient Diets
			;WITH D
				AS (SELECT TOP (@MaxPurgeRowsAllowed) *
				FROM dbo.tblPatientDiet
				WHERE PostDate < @DataRetentionDate
				ORDER BY PostDate)
			DELETE FROM D

			--Remove the Patient visits
			DELETE PV
			FROM	dbo.tblPatientVisit AS PV
			JOIN	@PatientVisitDelete AS PVD ON PV.PatientVisitID = PVD.PatientVisitID

			--PATIENT MAINTENANCE -------------------------------------
			--Get a list of PatientIDs that don't exist in the patient visit table and can be deleted
			DECLARE @PatientOHDDelete TABLE
			(
				ID			int IDENTITY(1,1),
				PatientID	int
			)
			INSERT INTO @PatientOHDDelete
			SELECT DISTINCT PatientID
			FROM @PatientVisitDelete AS PVD
			WHERE PVD.PatientID NOT IN (SELECT PatientID FROM dbo.tblPatientVisit WHERE PatientID = PVD.PatientID)

			--Delete the Patients from tblPatientOHD 
			DELETE	P
			FROM	dbo.tblPatientOHD AS P
			JOIN	@PatientOHDDelete AS PD ON P.PatientID = PD.PatientID

			SET @Msg = 'PURGEDATA: Data purge for GEMserve records prior to ' + CONVERT(varchar(10), @DataRetentionDate, 120) + ' complete!'
			EXEC dbo.Logit 1, @Msg, 'system'
	
		END
go

