CREATE PROCEDURE [dbo].[sp_Logit]
@LoggingLevel	smallint = 0,
@CoreID		int = 1,
@User	 	varchar(10),
@Cmsg 		varchar(255),
@EventID	int = 0
AS
	IF( @logginglevel <= dbo.currentlogginglevel() )
		BEGIN
			INSERT INTO	tbllog (UserID,CoreID,Description, EventID)
				VALUES	(@User,@CoreID,@Cmsg, @EventID)
		END
		/*
			this is being disabled for now. We should consider loging an accounting of unlogged messages, but the overhead is probably not the best place
		ELSE
		BEGIN
			--for debugging purposes, IF log level prevents msg FROM being inserted, increment a bucket
			DECLARE @NumberOfUnloggedMessages varchar(255)
			DECLARE @NumMsgs int
			SELECT	@NumberOfUnloggedMessages = ISNULL(sValue,'NaN')
			FROM	cfgOverhead
			WHERE	oKey = 'NumberOfUnloggedMessages'

			SET @NumMsgs =	CASE 
								WHEN ISNUMERIC(@NumberOfUnloggedMessages) > 0 
								THEN Cast(@NumberOfUnloggedMessages AS int) + 1
								ELSE 1
							END

			-- Don't hose logging just because the newer proc doesn't exist, do, however, log that it is missing
			IF EXISTS (SELECT name FROM sysobjects WHERE name = 'Overhead_UpdateOrInsertKey')
				EXEC dbo.Overhead_UpdateOrInsertKey 'NumberOfUnloggedMessages', @NumMsgs
			ELSE
				INSERT INTO	tbllog (UserID,CoreID,Description, EventID)
				VALUES	('system',@CoreID,'Expected procedure "dbo.Overhead_UpdateOrInsertKey" not found in database.', 1020)
		END
		*/
go

