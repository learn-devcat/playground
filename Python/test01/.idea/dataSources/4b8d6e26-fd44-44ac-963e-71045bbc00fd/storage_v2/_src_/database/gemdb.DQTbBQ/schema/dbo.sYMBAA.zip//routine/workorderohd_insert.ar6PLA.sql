
CREATE          PROCEDURE dbo.WorkorderOHD_Insert
@User			    char(10),
@LocationID	        int,
@WorkOrderNumber	varchar(25),	
@WorkorderClassID	int,
@ShortDescription	varchar(50),
@Description	   	varchar(250),
@OpenDate	        datetime,	
@OpeningEmployeeID	int,	
@EstimatedHours     	money	= 0
AS
SET NOCOUNT ON
DECLARE @ident	int
DECLARE @Err	int
    -- IF no open date defined, use now ...
    SET @OpenDate = ISNULL( @OpenDate, getdate())
--Insert only enough fields to create a record AND RETURN the identity field.
    INSERT tblWorkOrderOHD
          ( WorkOrderNumber,LocationID,	WorkorderClassID,ShortDescription, Description, OpenDate, OpeningEmployeeID,EstimatedHours )
   VALUES( @WorkOrderNumber,@LocationID,@WorkorderClassID,@ShortDescription, @Description,@OpenDate,@OpeningEmployeeID,@EstimatedHours )     
    IF @@Error <> 0 
      BEGIN
	SET @Err = @@Error
	SELECT 'Error: ' + Cast(@Err as VarChar(20))
        -- TODO: Log the error here AND exit.
        RETURN
      END
    SET @ident = @@IDENTITY --as WorkOrderID
	SELECT @ident
    RETURN
go

