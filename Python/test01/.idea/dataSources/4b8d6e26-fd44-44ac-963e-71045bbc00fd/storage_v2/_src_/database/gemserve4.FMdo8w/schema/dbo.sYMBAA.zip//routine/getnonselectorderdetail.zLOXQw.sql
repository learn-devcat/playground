CREATE FUNCTION [dbo].[GetNonSelectOrderDetail](@NonSelectOrderID int)
RETURNS varchar(4000)
AS
BEGIN
	DECLARE	@Return		varchar(4000),
		@POSMenuItemID	int,
		@ItemType	int

	SET @Return = ''

	DECLARE Detail CURSOR FOR 
		SELECT 	MenuItemID,
			ItemType
		FROM	dbo.tblNonSelectDetail (NOLOCK)
		WHERE 	NonSelectOrderID = @NonSelectOrderID
		ORDER BY COALESCE(IsDiet,0) DESC, MenuItemID 

	OPEN Detail

	FETCH NEXT FROM Detail INTO @POSMenuItemID, @ItemType

	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @Return = @Return + 
				CASE WHEN @ItemType > 2000 THEN '259'
				ELSE CAST(@ItemType AS varchar(20)) END + 
				','   + 
				CAST(@POSMenuItemID AS varchar(20)) +
				 ','

		FETCH NEXT FROM Detail INTO @POSMenuItemID, @ItemType
	END

	CLOSE Detail
	DEALLOCATE Detail

	IF (LEN(@Return) > 0)
		SET @Return = LEFT(@Return, LEN(@Return) - 1)

	RETURN @Return
END
go

