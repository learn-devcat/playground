CREATE  PROCEDURE [dbo].[ol_Inquire]
    @CoreID smallint = 1 ,
    @User char(10) ,
    @BadgeNo char(19)
AS 
    SET nocount ON			-- Required so we can pass back a string.
    DECLARE @UserName char(16)
    DECLARE @AccountNo char(19)
    DECLARE @ID int
    DECLARE @Desc char(16)
    DECLARE @Badge char(19)
    DECLARE @Total money
    DECLARE @message varchar(200)
    DECLARE @Active bit
    DECLARE @DeclBal bit ,
        @Stolen bit ,
        @Lost bit ,
        @Count int ,
        @Value varchar(50) ,
        @totalStr varchar(50) ,
        @descLen int

	SET @BadgeNo = dbo.RemoveBadgeSwipePrefix(@BadgeNo);
	
	/* IF we are doing a name search, handle it here... */
    IF ( SUBSTRING(@BadgeNo, 1, 1) = '?' ) 
    BEGIN
        SET @BadgeNo = UPPER(RTRIM(SUBSTRING(@BadgeNo, 2, 18))) + '%'
        SET @message = ''
        DECLARE TTL_Cursor CURSOR
        FOR SELECT TOP 8
        RTRIM(SUBSTRING(b.LastName, 1, 6)) + ','
        + SUBSTRING(b.FirstName, 1, 1) AS AcctName,
        b.BadgeNo	-- Retrieve the Account TTL's
        FROM    dbo.tblBadgesOHD AS b
        WHERE   UPPER(b.LastName) LIKE RTRIM(@BadgeNo)
        ORDER BY b.LastName
	
        OPEN TTL_Cursor
        FETCH NEXT FROM ttl_cursor INTO @Desc, @Badge
        WHILE @@FETCH_STATUS = 0
            AND LEN(@message) < 129 
            BEGIN
                SET @message = @message + CAST(@Desc AS char(8)) + ' '
                    + CAST(@Badge AS char(7)) 	-- format at 16 bytes per record.
                FETCH NEXT FROM TTL_Cursor -- Get next row IF one exists.
                    INTO @Desc, @Badge
            END
        CLOSE TTL_Cursor
        DEALLOCATE TTL_Cursor
        IF LEN(@message) < 8 								-- IF no TTL Records, display that on the POS.
            SET @message = CAST('No Matches ' AS char(16))
		
        SELECT  @message AS ReturnMsg
        RETURN
    END

    SELECT  @UserName = LTRIM(dbo.Description_FullNameWithMiddle(a.Description,
                                                       LTRIM(dbo.Description_FullNameWithMiddle(a.LastName,
                                                              tblBadgesOHD.FirstName,
                                                              tblBadgesOHD.LastName,
															  tblBadgesOHD.MiddleName,
															  1)),
                                                       a.FirstName,
													   a.MiddleName,
													   1)) ,
            @Lost = Lost ,
            @Stolen = Stolen ,
            @AccountNo = tblBadgesOHD.AccountNo
    FROM    dbo.tblBadgesOHD ,
            dbo.tblAccountOHD AS a
    WHERE   tblBadgesOHD.BadgeNo = @BadgeNo
            AND tblBadgesOHD.AccountNo = a.AccountNo
            AND tblBadgesOHD.inactive = 0
            AND dbo.dDateOnly(tblBadgesOHD.expiredate) >= dbo.dDateOnly(GETDATE())
            AND dbo.dDateOnly(tblBadgesOHD.activeDate) <= dbo.dDateOnly(GETDATE())
    SET @Count = @@ROWCOUNT
    IF ( @Lost = 1 ) 
        BEGIN
            SELECT  'Lost Badge' AS ReturnMsg
            RETURN
        END
	
    IF ( @Stolen = 1 ) 
        BEGIN
            SELECT  'Stolen Badge' AS ReturnMsg
            RETURN
        END
    IF @Count = 0 		-- Not found.
        BEGIN
            SELECT  -3 AS ReturnMsg	-- Must use the SELECT to create a recordset 
            RETURN 
        END
    SET @message = CAST(@BadgeNo AS char(16)) + CAST(@UserName AS char(16)) 	-- Format 16 chars per line.
	
	/* Check for TTL's */
    DECLARE TTL_Cursor CURSOR
    FOR SELECT  t.TransClassID,
    t.Balance,
    D.Description,
    d.DeclBalMode			-- Retrieve the Account TTL's
    FROM    dbo.tblAccountTTL AS t
    JOIN dbo.tblTransClass AS d ON t.TransClassID = d.TransClassID
    WHERE   t.AccountNo = @AccountNo
    AND t.expiredate >= GETDATE()
    ORDER BY t.TransClassID
    OPEN TTL_Cursor
    FETCH NEXT FROM ttl_cursor INTO @ID, @Total, @Desc, @DeclBal
    IF ( @DeclBal > 0 ) 
        SET @Total = -@Total
    WHILE @@FETCH_STATUS = 0
        AND LEN(@message) < 129			-- Don't overflow our output buffer ...
        BEGIN
            SET @Value = CAST(@Total AS varchar(50)) 
            SET @message = @message + CAST(@Desc AS char(8)) + ' '
                + CASE WHEN LEN(@Value) > 7 THEN 'E' + RIGHT(@Value, 6)
                       ELSE CAST(@Value AS char(7))
                  END 	-- format at 16 bytes per record.
            FETCH NEXT FROM TTL_Cursor INTO @ID, @Total, @Desc, @DeclBal
        END
    CLOSE TTL_Cursor
    DEALLOCATE TTL_Cursor
	
    IF LEN(@message) < 33 								-- IF no TTL Records, display that on the POS.
        SET @message = @message + CAST('NO ACTIVE TTLS' AS char(16))
	-- Get the RANGE PLAN this account is on...
    IF ( dbo.GetOverheadItem('CFCLB') = '1' ) 
        BEGIN
            DECLARE @IsRange char(16)
		
            SELECT  @IsRange = TD.Description
            FROM    dbo.tblDetail AS D
                    LEFT JOIN tblTransDef AS TD ON D.TransID = TD.TransID
            WHERE   D.TransID = 115
                    AND D.AccountNo = @AccountNo
                    AND YEAR(D.TransDate) = YEAR(GETDATE())
				--AND (getdate() - D.TransDate) < 365
            IF ( ISNULL(@IsRange, '0    ') = '0    ' ) 
                SELECT  @IsRange = TD.Description
                FROM    dbo.tblDetail AS D
                        LEFT JOIN tblTransDef AS TD ON D.TransID = TD.TransID
                WHERE   D.TransID = 116
                        AND D.AccountNo = @AccountNo
                        AND YEAR(D.TransDate) = YEAR(GETDATE())
					--AND (getdate() - D.TransDate) < 365
			
	
            IF ( ISNULL(@IsRange, '0    ') = '0    ' ) 
                SET @IsRange = 'NO RANGE PLAN '
            ELSE 
                SET @IsRange = SUBSTRING(@IsRange, 1, 13) + ')'
	
            SET @Message = @Message + @IsRange
        END
    SELECT  @message AS ReturnMsg
go

