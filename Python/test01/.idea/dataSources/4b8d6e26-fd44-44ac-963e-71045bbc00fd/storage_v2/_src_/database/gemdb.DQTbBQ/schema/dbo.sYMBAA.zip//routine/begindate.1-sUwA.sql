

CREATE FUNCTION dbo.BeginDate (@Selection int, @CurrentDate datetime)  
RETURNS datetime
AS
BEGIN 
	DECLARE @Return datetime
	
	SELECT @Return = CASE @Selection
			WHEN 0 THEN			--Today
				dbo.dDateOnly(@CurrentDate)
			WHEN 1 THEN			--Yesterday
				dbo.dDateOnly(@CurrentDate-1)
			WHEN 2 THEN			--This week
				dbo.dDateOnly(@CurrentDate - ((DATEPART(dw,@CurrentDate)) - 1))
			WHEN 3 THEN			--Last week
				dbo.dDateOnly(@CurrentDate - ((DATEPART(dw,@CurrentDate)) - 1 + 7))
			WHEN 4 THEN			--This month
				dbo.dDateOnly(@CurrentDate - ((DATEPART(d,@CurrentDate)) - 1))
			WHEN 5 THEN			--Last month
				DATEADD(m, -1,dbo.dDateOnly(@CurrentDate - ((DATEPART(d,@CurrentDate)) - 1)))
			WHEN 6 THEN			--This year
				dbo.dDateOnly(@CurrentDate - ((DATEPART(y,@CurrentDate)) - 1))
			WHEN 7 THEN			--Last year
				DATEADD(yy, -1,dbo.dDateOnly(@CurrentDate - ((DATEPART(y,@CurrentDate)) - 1)))
	END
	RETURN @Return
END
go

