CREATE PROCEDURE [dbo].[ad_Vending_Insert]
    @Description varchar(50) ,
    @VendorID int ,
    @MachineTAG varchar(16) ,
    @AccountClassID int ,
    @BadgeClassID int ,
    @OutletNo int ,
    @TransID int ,
    @LocationID int ,
    @InActive bit ,
    @RefundAllowed bit ,
    @MaxItemPrice money ,
    @Comment varchar(255)
AS 
    INSERT  dbo.tblVendingDTL
            ( [Description] ,
              VendorID ,
              MachineTAG ,
              AccountClassID ,
              BadgeClassID ,
              OutletNo ,
              TransID ,
              LocationID ,
              InActive ,
              RefundAllowed ,
              MaxItemPrice ,
              Comment
            )
    VALUES  ( @Description ,
              @VendorID ,
              @MachineTAG ,
              @AccountClassID ,
              @BadgeClassID ,
              @OutletNo ,
              @TransID ,
              @LocationID ,
              @InActive ,
              @RefundAllowed ,
              @MaxItemPrice ,
              @Comment
            )
go

