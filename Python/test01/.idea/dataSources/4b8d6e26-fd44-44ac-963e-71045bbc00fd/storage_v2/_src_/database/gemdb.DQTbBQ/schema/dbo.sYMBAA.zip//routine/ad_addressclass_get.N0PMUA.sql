

CREATE PROCEDURE dbo.ad_AddressClass_Get
@User			char(10),
@AddressID		int
AS
	SELECT	AddressID,
			Description
	FROM		tblAddressClass
	WHERE	AddressID = @AddressID
go

