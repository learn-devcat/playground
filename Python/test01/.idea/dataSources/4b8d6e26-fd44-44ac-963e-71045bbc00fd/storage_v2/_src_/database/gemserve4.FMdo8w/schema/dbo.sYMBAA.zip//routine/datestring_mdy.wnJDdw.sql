

Create  FUNCTION dbo.DateString_MDY (@WholeDate as datetime)
RETURNS varchar(10)
AS 
BEGIN 
	RETURN 	cast(DatePart(m,@WholeDate) as varchar(2)) + '/' + 
		cast(DatePart(d,@WholeDate) as varchar(2)) + '/' + 
		cast(DatePart(yyyy,@WholeDate) as varchar(4))
END
go

