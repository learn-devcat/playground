
CREATE PROCEDURE [dbo].[PatientNotesGet]
@PatientVisitID		varchar(50)
AS
	SET NOCOUNT ON

	SELECT	NoteID,
		PatientVisitID,
		NoteType,
		ActiveDate,
		PostDate,
		Source,
		Notes,
		Cancelled,
		CancelDate,
		TransactionIdentifier
	FROM dbo.tblPatientNotes (NOLOCK)
	WHERE PatientVisitID = @PatientVisitID
	ORDER BY ActiveDate DESC, PostDate DESC

	RETURN
go

