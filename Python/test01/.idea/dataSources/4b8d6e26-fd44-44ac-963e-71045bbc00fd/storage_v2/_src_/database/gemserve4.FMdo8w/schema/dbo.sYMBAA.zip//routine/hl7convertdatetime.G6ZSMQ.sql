CREATE FUNCTION [dbo].[HL7ConvertDateTime](@Input  varchar(20),@Today  datetime)
RETURNS datetime
AS
BEGIN
	DECLARE	@MyDate datetime,
			@TempDate varchar(30)

	SET @Input = REPLACE(@Input,'\','/')
	
	IF (LEN(@Input) < 7 AND ISDATE(@Input) = 0)
		SET @MyDate = @Today
	ELSE
	BEGIN
		IF (ISDATE(@Input) = 1)
			SET @TempDate = @Input
		ELSE
		BEGIN
			IF (CHARINDEX('-' , @Input) = 0 AND CHARINDEX('/' , @Input) = 0)
			BEGIN
				SET @TempDate = LEFT(@Input,4) + '/' +
				SUBSTRING(@Input,5,2) + '/' + SUBSTRING(@Input,7,2)    
			END

			IF (CHARINDEX(':', @Input) = 0) AND (LEN(@Input) > 8 AND ISDATE(@Input) = 0)
				SET @TempDate = @TempDate  + ' ' + SUBSTRING(@Input,9,2) + ':' + SUBSTRING(@Input,11,2)
		END

		SET @MyDate = CAST(@TempDate as datetime)		
	END		

	RETURN @MyDate
END
go

