


CREATE  FUNCTION dbo.VM_ValidateMealPlan
(@accountno char(19),@transid int,@outletno int, @Today datetime, @GetMealPlanID int)
RETURNS money                 
AS 
BEGIN
	DECLARE	@currenttime 	varchar(5),
            @currentdate	datetime,
	        @outletsubtype  int,    		-- to see WHERE we're allowed to use this.
            @slot           int,
            @Return	        money
    SELECT  @slot = slotno 
    FROM    tblTransDef 
    WHERE   TransID = @transid
	SET @currentdate = dbo.ddateonly(@Today)
	SET @currenttime = dbo.timeonly(@Today)
    /*
    NOTE: This function can return two different types of data, but MUST BE CALLED twice to get both.
	    1. To retrieve amount of money remaining for the current meal period, pass a 0 in the @GetMealPlanID variable. This option will return 0 as the available balance if we are over the numOfPasses, etc.
	    2. To retrieve the MealPlanID for the current meal period (if any are active for the account), pass a 1 in the @GetMealPlanID. This option returns the MealPlanID
    */
	
	-- get the subtype to mask against the meal plans -- this allows us
	-- to restrict certain meal plans to certain outlets... we are going
	-- to "AND()" the two VALUES, a non-zero results in a "go"
    SELECT  @outletsubtype = subtype 
    FROM    tbloutletohd
    WHERE   outletno = @outletno                          
    -- IF we are asking for the meal plan id, do it here.                        
	IF (@GetMealPlanID = 1)
		SELECT TOP 1 @Return = CAST(a.MealPlanID as money)      -- CAST as money cuz that's our RETURN type.
		FROM		tblaccountmeal as a
		LEFT JOIN 	tblaccountmealttl as att	on	a.accountno = att.accountno
				AND a.mealplanid = att.mealplanid
				AND @currentdate between dbo.ddateonly(att.activedate) AND dbo.ddateonly(att.expiredate)
		LEFT JOIN  tblplanohd as p  on a.mealplanid = p.mealplanid
		LEFT JOIN tblplandtl  as pd on a.mealplanid = pd.mealplanid
			AND (@currenttime between pd.begtime AND pd.endtime)
		WHERE	a.accountno = @accountno
			AND a.slot = @slot
			AND a.active = 1
			AND (@currenttime between pd.begtime AND pd.endtime)  
			AND ( p.subtype & @outletsubtype ) <> 0
		order by case when (pd.description is null or att.currentcount is null) then '1'
				ELSE '0'	
			END, pd.begtime
	ELSE        -- We are asking for the balance, so let's get busy.
		SELECT TOP 1 @Return = CAST(CASE
				WHEN pd.passesallowed - dbo.currentpasses(a.accountno,a.mealplanid,dbo.ddateplusnewtime(@currentdate,pd.begtime),dbo.ddateplusnewtime(@currentdate,pd.endtime)) < 1 THEN 0
				WHEN pd.translimit - dbo.currentperiodbalance(a.accountno,a.mealplanid,dbo.ddateplusnewtime(@currentdate,pd.begtime),dbo.ddateplusnewtime(@currentdate,pd.endtime)) <= 0 THEN 0
				ELSE pd.translimit - dbo.currentperiodbalance(a.accountno,a.mealplanid,dbo.ddateplusnewtime(@currentdate,pd.begtime),dbo.ddateplusnewtime(@currentdate,pd.endtime))
		        END AS money)
		FROM		tblaccountmeal as a
		LEFT JOIN 	tblaccountmealttl as att on a.accountno = att.accountno
				AND a.mealplanid = att.mealplanid
				AND @currentdate between dbo.ddateonly(att.activedate) AND dbo.ddateonly(att.expiredate)
		LEFT JOIN  tblplanohd as p  on a.mealplanid = p.mealplanid
		LEFT JOIN tblplandtl  as pd on a.mealplanid = pd.mealplanid
			AND (@currenttime between pd.begtime AND pd.endtime)
		WHERE	a.accountno = @accountno
			AND a.slot = @slot
			AND a.active = 1
			AND (@currenttime between pd.begtime AND pd.endtime)  
			AND ( p.subtype & @outletsubtype ) <> 0
		order by case when (pd.description is null or att.currentcount is null) then '1'
				ELSE '0'	
			END, pd.begtime
	-- IF null, then RETURN 999999 so that we do not deny a charge IF the user has
	RETURN @Return
END
go

