CREATE        PROCEDURE [dbo].[sp_Trans_RollbackDuplicates]
    @User char(10) ,
    @BeginDate datetime ,
    @EndDate datetime
AS 
    DECLARE @DtlID uniqueidentifier ,
        @Filter varchar(2000) ,
        @cnt int

	-- Just in case
    IF EXISTS ( SELECT  *
                FROM    dbo.sysobjects
                WHERE   id = OBJECT_ID(N'[temptableDupes]')
                        AND OBJECTPROPERTY(id, N'IsUserTable') = 1 ) 
        DROP TABLE [temptableDupes]

	-- We must create an actual table, because temp tables cannot be referenced in a function and because table variables
	-- cannot be passed to a function. We will create the table and drop it when finished.
    CREATE TABLE dbo.temptableDupes
        (
          DetailID uniqueidentifier ,
          AccountNo varchar(19) ,
          BadgeNo varchar(19) ,
          TransDate datetime ,
          PostDate datetime ,
          OutletNo int ,
          TransID int ,
          RefNum varchar(6) ,
          ChkNum varchar(6) ,
          TransTotal money
        )

    INSERT  dbo.temptableDupes
            SELECT  *
            FROM    dbo.GetDupeTransInDateRange(@User, @BeginDate, @EndDate, 0)
	
	--This variable will be used to prevent an endless loop if there is a failure when removing records
    SELECT  @cnt = COUNT(*)
    FROM    dbo.temptableDupes
	
    WHILE @cnt > 1 
        BEGIN
		-- find first dupe in the temp table
            SELECT TOP 1
                    @DtlID = DetailID
            FROM    dbo.GetDupeTransInDateRange(@User, @BeginDate, @EndDate, 1)

            IF @@ROWCOUNT < 1 
                BREAK
	
            SET @Filter = 'WHERE DetailID = ' + CHAR(39)
                + CAST(@DtlID AS varchar(50)) + CHAR(39)
	
            EXEC dbo.sp_Trans_RollBack @User, @Filter

            DELETE  dbo.temptableDupes
            WHERE   DetailID = @DtlID
		
            SET @cnt = @cnt - 1
        END

	-- we don't need it anymore, so drop it
    IF EXISTS ( SELECT  *
                FROM    dbo.sysobjects
                WHERE   id = OBJECT_ID(N'[temptableDupes]')
                        AND OBJECTPROPERTY(id, N'IsUserTable') = 1 ) 
        DROP TABLE [temptableDupes]
go

