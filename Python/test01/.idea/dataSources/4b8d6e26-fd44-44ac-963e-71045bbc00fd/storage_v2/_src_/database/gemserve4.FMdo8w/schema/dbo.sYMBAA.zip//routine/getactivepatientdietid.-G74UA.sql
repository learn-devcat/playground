CREATE FUNCTION [dbo].[GetActivePatientDietID]
(@PatientVisitID varchar(50), @Today datetime)

RETURNS int
AS
	BEGIN
 		DECLARE @Return	int,
				@LookForwardDiet varchar(10)

		SELECT @PatientVisitID = COALESCE(MergedTo, PatientVisitID)
		FROM dbo.tblPatientVisit
		WHERE PatientVisitID = @PatientVisitID
		
		SELECT TOP 1 @Return = PD.[ID]
		FROM dbo.tblPatientDiet AS PD
		JOIN dbo.tblDietOHD AS D ON PD.DietID = D.DietID
		WHERE PD.PatientVisitID = @PatientVisitID
			AND PD.ActiveDate <= @Today
			AND dbo.GetDietCancelStatus(PD.CancelDate, @Today) = 0
		ORDER BY PD.ActiveDate DESC, PD.PostDate DESC

		-- If no active diet, then choose the next diet becoming active if it exists and the LookForwardDiet overhead key is enabled (1)
		IF (@Return IS NULL)
		BEGIN
			SELECT @LookForwardDiet = COALESCE(dbo.GetOverheadValueNull('LookForwardDiet'),'0')

			IF (@LookForwardDiet = '1')	
				SELECT TOP 1 @Return = PD.[ID]
				FROM dbo.tblPatientDiet AS PD
				JOIN dbo.tblDietOHD AS D ON PD.DietID = D.DietID
				WHERE PD.PatientVisitID = @PatientVisitID
					AND dbo.GetDietCancelStatus(PD.CancelDate, @Today) = 0
				ORDER BY PD.ActiveDate, PD.PostDate
		END

		RETURN ISNULL( @Return, -1 )
	END
go

