
CREATE FUNCTION [dbo].[DateStringMMDDYYYY] (@WholeDate as varchar(100))
RETURNS varchar(15)
AS 
BEGIN 
	DECLARE @Return varchar(15),
		@Temp varchar(100)

	SET @WholeDate = REPLACE(@WholeDate,'\','/')

	IF (ISDATE(@WholeDate) = 1 AND (CHARINDEX('/',@WholeDate) > 0 OR CHARINDEX('-',@WholeDate) > 0))
		SET @Return = LEFT(@WholeDate,10)
	ELSE
	BEGIN
		IF (@WholeDate IS NULL OR @WholeDate='')
			SET @Return =  ''
		ELSE
		BEGIN
			IF (LEN(@WholeDate) = 8)
			BEGIN
				SET @Temp = LEFT(@WholeDate,4) + '/' + SUBSTRING(@WholeDate,5,2) + '/' + RIGHT(@WholeDate,2)
			END
			ELSE
			BEGIN
				IF (LEN(@WholeDate) = 6)
					SET @Temp = LEFT(@WholeDate,2) + '/' + SUBSTRING(@WholeDate,3,2) + '/' + RIGHT(@WholeDate,2)
			END
	
			IF (ISDATE(@Temp) = 1)
			BEGIN
				SET @Return = RIGHT('0' + CAST(DATEPART(MONTH,@Temp) AS varchar(2)),2) + 
				       '/' + RIGHT('0' + CAST(DATEPART(DAY,@Temp) AS varchar(2)) , 2) +
				       '/' + CAST(DATEPART(YEAR,@Temp) AS varchar(4))
			END
			ELSE
				SET @Return = @WholeDate
	
		END
	END

	RETURN @Return
END
go

