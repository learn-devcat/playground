
CREATE      PROCEDURE [dbo].[sp_Recur_Get]
@User			char(10),
@RecurID		uniqueidentifier
AS 
	SELECT 	R.AcctClassID,
			R.AccountNo,
			R.ClassID,
			R.RecurID,
			R.TransID,
			R.OutletNo,
			R.Description AS Description,
			R.Amount,
			R.[Percent],
			R.Minimum,
			R.Balance,
			R.PastDue,
			R.TrackSlotNum,
			R.TrackIDNum,
			R.Tax1,
			R.Tax2,
			R.Tax3,
			R.Tax4,
			R.Active,
			C.NextDate,
			C.Frequency,
			C.Dtl_ChkNum,
			C.Dtl_RefNum,
			C.Dtl_Comment,
			T.Description AS TransDescription,
			T.Preset,
			A.Name,
			R.AllowNegAmt,
			R.BatchID,
			R.ExpiredAccountsOnly,
			R.PostToAltAccount,
			R.AltAccountNo,
			R.AltBadgeNo,
			R.AltTransID,
			R.AltOutletNo,
			R.UseOutletClassBal,
			R.Formula,
			R.BalanceMax
	FROM	tblRecurChg AS R LEFT JOIN
			tblRecurChgClass AS C 
	ON		R.ClassID = C.ClassID LEFT JOIN
			tblTransDef AS T
	ON		T.TransID = R.TransID LEFT JOIN
			tblAccountClass AS A
	ON		A.AccountClassID = R.AcctClassID
	WHERE	R.RecurID = @RecurID
	ORDER BY C.NextDate, R.ClassID
go

