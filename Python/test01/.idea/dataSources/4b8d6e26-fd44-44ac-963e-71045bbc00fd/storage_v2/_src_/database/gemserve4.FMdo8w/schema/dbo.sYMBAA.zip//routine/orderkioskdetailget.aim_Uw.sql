

CREATE PROCEDURE dbo.OrderKioskDetailGet
@OrderID AS int
AS
	SET NOCOUNT ON
	
	SELECT	OrderID,
		OrderDetail
	FROM	dbo.tblOrderDTL
	WHERE 	OrderID = @OrderID
	
	RETURN
go

