



CREATE PROCEDURE dbo.UserPrivileges
@User		char(10),
@Application	int=10

AS
	SET NOCOUNT ON

	EXEC GEMdb..gem_GetUserPrivileges @User,@Application

	RETURN
go

