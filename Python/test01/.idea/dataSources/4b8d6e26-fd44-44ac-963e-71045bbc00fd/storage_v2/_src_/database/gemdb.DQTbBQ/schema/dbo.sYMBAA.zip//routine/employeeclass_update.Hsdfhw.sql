







CREATE       PROCEDURE dbo.EmployeeClass_Update
@User				char(10),
@EmployeeClassID		int, 
@EmployeeClassName		char(50), 
@Description			char(50),
@LogonHours			char(24),
@CanCreateWorkOrder		bit,
@CanDeleteWorkorder		bit,
@CanCloseWorkOrder		bit,
@CanPrintWorkOrder		bit,
@CanAddWorkOrderDTL		bit,
@CanCompleteWorkOrderDTL	bit,
@CanDeleteWorkOrderDTL		bit,
@ViewAllWorkorders		bit,
@ViewWorkordersInClass		bit,
@AdjustWorkorderCharge		bit,
@ConfigString			varchar(32)
AS
	UPDATE	tblEmployeeClass
	SET	EmployeeClassName 	= @EmployeeClassName,
		Description 		= @Description,
		LogonHours 		= @LogonHours,
		CanCreateWorkOrder 	= @CanCreateWorkOrder,
		CanDeleteWorkorder 	= @CanDeleteWorkorder,
		CanCloseWorkOrder 	= @CanCloseWorkOrder,
		CanPrintWorkOrder 	= @CanPrintWorkOrder,
		CanAddWorkOrderDTL 	= @CanAddWorkOrderDTL,
		CanCompleteWorkOrderDTL = @CanCompleteWorkOrderDTL,
		CanDeleteWorkOrderDTL 	= @CanDeleteWorkOrderDTL,
		ViewAllWorkorders 	= @ViewAllWorkorders,
		ViewWorkordersInClass 	= @ViewWorkordersInClass,
		AdjustWorkorderCharge 	= @AdjustWorkorderCharge,
		ConfigString		= @ConfigString	
	WHERE	EmployeeClassID = @EmployeeClassID
go

