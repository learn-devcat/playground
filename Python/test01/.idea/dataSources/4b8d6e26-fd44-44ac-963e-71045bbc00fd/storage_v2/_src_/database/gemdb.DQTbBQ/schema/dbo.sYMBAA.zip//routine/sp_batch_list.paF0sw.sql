CREATE PROCEDURE [dbo].[sp_Batch_List]
AS
	DECLARE @BatchPostRetentionDays int,
			@GEM2goRetentionDays int
	
	-- Get the number of days to show the posted batches
	SET @BatchPostRetentionDays = COALESCE(dbo.GetOverheadItem('BatchPostRetentionDays'),0)
	
	-- Get the number of days to show the GEM2go batches
	SET @GEM2goRetentionDays = COALESCE(dbo.GetOverheadItem('GEM2goRetentionDays'),0)
	
	-- NOTE: the '-' in the WHERE clause is used to filter out recurring batches that have the '-' in the BatchID
	-- Get the unposted batches as well as the batches within the Batch Retention Days
	-- Also exclude any inprocess (I) transactions from GEM2go
	SELECT DISTINCT	B.BatchID 			AS BatchID,
				C.TT 					AS TotalTrans,
				MD.MTRANS 				AS FirstDate,
				ISNULL(TC.TransTotal,0)	AS TransCharges,
				ISNULL(TP.TransTotal,0)	AS TransPayments,
				ISNULL(U.Unresolved,0) 	AS Unresolved,
				ISNULL(D.Duplicate,0) 	AS Duplicates,
				ISNULL(E.Exception,0) 	AS Exceptions,
				0 AS Posted
	FROM		tblBatch AS B
				LEFT JOIN
				(
					SELECT		MIN(TransDate) AS MTRANS,BatchID
					FROM 		tblBatch
					WHERE 		ISNULL(Posted,'') NOT IN ('P','I')
					GROUP BY 	BatchID
				) AS MD
				ON 	B.BatchID = MD.BatchID
				LEFT JOIN
				(
					SELECT		SUM(TransTotal) AS TransTotal,BatchID
					FROM		tblBatch AS BA LEFT JOIN
								tblTransDef BB
					ON			BA.TransID = BB.TransID			
					WHERE		ISNULL(Posted,'') NOT IN ('P','I') AND
								BB.Payment = 0
					GROUP BY	BatchID
				) AS TC
				ON	B.BatchID = TC.BatchID    
				
				LEFT JOIN
				(
					SELECT		SUM(TransTotal) AS TransTotal,BatchID
					FROM		tblBatch AS BA LEFT JOIN
								tblTransDef BB
					ON			BA.TransID = BB.TransID			
					WHERE		ISNULL(Posted,'') NOT IN ('P','I') AND
								BB.Payment = 1
					GROUP BY	BatchID
				) AS TP
				ON	B.BatchID = TP.BatchID
				LEFT JOIN
				(
					SELECT		COUNT(BatchID) AS TT,BatchID
					FROM		tblBatch
					WHERE		ISNULL(Posted,'') NOT IN ('P','I')
					GROUP BY	BatchID
				) AS C
				ON	B.BatchID = C.BatchID
				
				LEFT JOIN
				(
					SELECT		COUNT(Posted) AS Unresolved,BatchID
					FROM		tblBatch
					WHERE		ISNULL(Posted,'')='U'
					GROUP BY	BatchID
				) AS U
				ON	B.BatchID = U.BatchID
				
				LEFT JOIN
				(
					SELECT		COUNT(Posted) AS Duplicate,BatchID
					FROM		tblBatch
					WHERE		ISNULL(Posted,'')='D'
					GROUP BY	BatchID
				) AS D
				ON B.BatchID = D.BatchID
				
				LEFT JOIN
				(
					SELECT		COUNT(Posted) AS Exception,BatchID
					FROM		tblBatch
					WHERE		ISNULL(Posted,'')='E'
					GROUP BY	BatchID
				) AS E
				ON B.BatchID = E.BatchID
					
	WHERE		ISNULL(Posted,'') NOT IN ('P','I')
		AND LEFT(B.BatchID,1) <> '-'
	UNION ALL
	SELECT DISTINCT	B.BatchID 			AS BatchID,
				C.TT 					AS TotalTrans,
				MD.MTRANS 				AS FirstDate,
				ISNULL(TC.TransTotal,0)	AS TransCharges,
				ISNULL(TP.TransTotal,0)	AS TransPayments,
				0 AS Unresolved,
				0 AS Duplicates,
				0 AS Exceptions,
				1 AS Posted
	FROM		tblBatch AS B
				LEFT JOIN
				(
					SELECT		MIN(TransDate) AS MTRANS,BatchID
					FROM 		tblBatch
					WHERE 		ISNULL(Posted,'') IN ('P','I')
						AND ((@BatchPostRetentionDays <> '0' AND BatchID <> 'GEM2GO'
								AND dbo.dDateOnly(LastUpdateDate) >= (dbo.dDateOnly(GETDATE())-@BatchPostRetentionDays))
							OR  (@GEM2goRetentionDays <> '0' AND BatchID = 'GEM2GO'
								AND dbo.dDateOnly(LastUpdateDate) >= (dbo.dDateOnly(GETDATE())-@GEM2goRetentionDays)))
					GROUP BY 	BatchID
				) AS MD
				ON 	B.BatchID = MD.BatchID
				LEFT JOIN
				(
					SELECT		SUM(TransTotal) AS TransTotal,BatchID
					FROM		tblBatch AS BA LEFT JOIN
								tblTransDef BB
					ON			BA.TransID = BB.TransID			
					WHERE		ISNULL(Posted,'')IN ('P','I') AND
								BB.Payment = 0
								AND ((@BatchPostRetentionDays <> '0' AND BA.BatchID <> 'GEM2GO'
										AND dbo.dDateOnly(LastUpdateDate) >= (dbo.dDateOnly(GETDATE())-@BatchPostRetentionDays))
									OR  (@GEM2goRetentionDays <> '0' AND BA.BatchID = 'GEM2GO'
										AND dbo.dDateOnly(LastUpdateDate) >= (dbo.dDateOnly(GETDATE())-@GEM2goRetentionDays)))
					GROUP BY	BatchID
				) AS TC
				ON	B.BatchID = TC.BatchID    
				
				LEFT JOIN
				(
					SELECT		SUM(TransTotal) AS TransTotal,BatchID
					FROM		tblBatch AS BA LEFT JOIN
								tblTransDef BB
					ON			BA.TransID = BB.TransID			
					WHERE		ISNULL(Posted,'')IN ('P','I') AND
								BB.Payment = 1
								AND ((@BatchPostRetentionDays <> '0' AND BA.BatchID <> 'GEM2GO'
										AND dbo.dDateOnly(LastUpdateDate) >= (dbo.dDateOnly(GETDATE())-@BatchPostRetentionDays))
									OR  (@GEM2goRetentionDays <> '0' AND BA.BatchID = 'GEM2GO'
										AND dbo.dDateOnly(LastUpdateDate) >= (dbo.dDateOnly(GETDATE())-@GEM2goRetentionDays)))
					GROUP BY	BatchID
				) AS TP
				ON	B.BatchID = TP.BatchID
				LEFT JOIN
				(
					SELECT		COUNT(BatchID) AS TT,BatchID
					FROM		tblBatch
					WHERE		ISNULL(Posted,'')IN ('P','I')
						AND ((@BatchPostRetentionDays <> '0' AND BatchID <> 'GEM2GO'
								AND dbo.dDateOnly(LastUpdateDate) >= (dbo.dDateOnly(GETDATE())-@BatchPostRetentionDays))
							OR  (@GEM2goRetentionDays <> '0' AND BatchID = 'GEM2GO'
								AND dbo.dDateOnly(LastUpdateDate) >= (dbo.dDateOnly(GETDATE())-@GEM2goRetentionDays)))
					GROUP BY	BatchID
				) AS C
				ON	B.BatchID = C.BatchID
					
	WHERE		ISNULL(Posted,'')IN ('P','I')
		AND LEFT(B.BatchID,1) <> '-'
		AND ((@BatchPostRetentionDays <> '0' AND B.BatchID <> 'GEM2GO'
				AND dbo.dDateOnly(LastUpdateDate) >= (dbo.dDateOnly(GETDATE())-@BatchPostRetentionDays))
			OR  (@GEM2goRetentionDays <> '0' AND B.BatchID = 'GEM2GO'
				AND dbo.dDateOnly(LastUpdateDate) >= (dbo.dDateOnly(GETDATE())-@GEM2goRetentionDays)))
	ORDER BY	Posted,FirstDate,BatchID
go

