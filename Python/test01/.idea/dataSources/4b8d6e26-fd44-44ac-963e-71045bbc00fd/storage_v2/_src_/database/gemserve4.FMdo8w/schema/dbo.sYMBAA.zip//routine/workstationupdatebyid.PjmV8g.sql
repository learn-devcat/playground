

CREATE PROCEDURE [dbo].[WorkstationUpdateByID]
@WorkstationID 	varchar(50),
@LastIdleEvent		datetime=null
AS
	SET NOCOUNT ON

	DECLARE @Date varchar(10)

	SET @LastIdleEvent = ISNULL(@LastIdleEvent,getdate())
	SET @Date = dbo.DateString(getdate())

	UPDATE dbo.tblWorkstation
		SET LastIdleEvent = @LastIdleEvent
	WHERE WorkstationID = @WorkstationID
		AND [Date] = @Date

	IF (@@ROWCOUNT = 0)
		INSERT INTO dbo.tblWorkstation (WorkstationID, [Date], LastIdleEvent)
			VALUES(@WorkstationID, @Date, @LastIdleEvent)
go

