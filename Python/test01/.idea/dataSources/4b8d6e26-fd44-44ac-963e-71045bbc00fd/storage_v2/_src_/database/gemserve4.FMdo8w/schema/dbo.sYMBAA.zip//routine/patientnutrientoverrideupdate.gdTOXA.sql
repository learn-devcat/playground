
CREATE PROCEDURE [dbo].[PatientNutrientOverrideUpdate]
@LoginUserID	varchar(250),
@PatientID      int,
@NutrientID		int,
@Qty			decimal(10,3),
@PatientDietID	int,
@MealPeriodName	varchar(50)=''

AS
	SET NOCOUNT ON

	DECLARE	@MealPeriodID	int,
		@NutrientName	varchar(50),
		@Msg		varchar(200),
		@RoomID		int,
		@OldValue	int

	SELECT 	@NutrientName = [Description]
	FROM	dbo.cfgNutrients
	WHERE	NutrientID = @NutrientID

	SELECT @MealPeriodID = MealPeriodID FROM dbo.tblMealPeriods WHERE [Description] = @MealPeriodName
	SET @MealPeriodID = ISNULL(@MealPeriodID, -1)


	IF(@MealPeriodID > -1)
	BEGIN
		-- Get the previous value
		SELECT 	@OldValue = Qty
		FROM	dbo.tblPatientMealPeriodNutrientOverride
		WHERE PatientDietID = @PatientDietID
			AND NutrientID = @NutrientID
			AND MealPeriodID = @MealPeriodID

		UPDATE dbo.tblPatientMealPeriodNutrientOverride
		SET Qty = @Qty
		WHERE PatientDietID = @PatientDietID
			AND NutrientID = @NutrientID
			AND MealPeriodID = @MealPeriodID

		IF(@@ROWCOUNT = 0)
		BEGIN
			INSERT INTO dbo.tblPatientMealPeriodNutrientOverride(PatientDietID, PatientID, NutrientID, MealPeriodID, Qty)
				VALUES(@PatientDietID, @PatientID, @NutrientID, @MealPeriodID, @Qty)

			SET @Msg = 'Meal Period nutrient override added: [' + @NutrientName + ' = ' + CAST(@Qty AS varchar(10)) + ']'
		END
		ELSE
			SET @Msg = 'Meal Period  override update: [' + @NutrientName + ' :: Previous value = ' + 
				CAST(@OldValue AS varchar(10)) + ' :: New Value = ' + CAST(@Qty AS varchar(10)) + ']'
	
		-- Add a log entry
		EXEC dbo.PatientLOGAdd 1000, @LoginUserID, @PatientID, '', Null, @Msg
	END
	ELSE
	BEGIN
		-- Get the previous value
		SELECT 	@OldValue = Qty
		FROM	dbo.tblPatientDailyNutrientOverride
		WHERE PatientDietID = @PatientDietID
			AND NutrientID = @NutrientID

		UPDATE dbo.tblPatientDailyNutrientOverride
		SET Qty = @Qty
		WHERE PatientDietID = @PatientDietID
			AND NutrientID = @NutrientID

		IF(@@ROWCOUNT = 0)
		BEGIN
			INSERT INTO dbo.tblPatientDailyNutrientOverride(PatientDietID, PatientID, NutrientID, DietID, Qty)
				VALUES(@PatientDietID, @PatientID, @NutrientID, 0, @Qty)

			SET @Msg = 'Daily nutrient override added: [' + @NutrientName + ' = ' + CAST(@Qty AS varchar(10)) + ']'
		END
		ELSE
			SET @Msg = 'Daily nutrient override updated: [' + @NutrientName + ' :: Previous value = ' + 
				CAST(@OldValue AS varchar(10)) + ' :: New Value = ' + CAST(@Qty AS varchar(10)) + ']'

		-- Add a log entry
		EXEC dbo.PatientLOGAdd 1000, @LoginUserID, @PatientID, '', Null, @Msg
	END		

	RETURN
go

