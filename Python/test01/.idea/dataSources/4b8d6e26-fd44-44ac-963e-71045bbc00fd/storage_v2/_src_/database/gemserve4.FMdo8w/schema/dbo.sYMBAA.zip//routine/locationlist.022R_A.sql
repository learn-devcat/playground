
CREATE PROCEDURE dbo.LocationList

AS
	SET NOCOUNT ON

    SELECT  LocationClassID,
            LC.Description,
            LC.DeliveryPriority,
            LC.Active,
            LC.KitchenId,
            K.Description AS 'Kitchen',
            LC.ExcludeFromDashboard
    FROM    dbo.tblLocationClass LC ( NOLOCK )
            LEFT JOIN dbo.tblKitchens K ON LC.KitchenId = K.KitchenId
    ORDER BY LC.Description

	RETURN
go

