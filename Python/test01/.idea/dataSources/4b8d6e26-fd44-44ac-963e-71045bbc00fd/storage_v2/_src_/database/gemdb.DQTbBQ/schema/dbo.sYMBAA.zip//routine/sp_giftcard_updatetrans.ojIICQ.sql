

CREATE PROCEDURE dbo.sp_GiftCard_UpdateTrans
@User		char(10),
@DetailID	uniqueidentifier,
@AccountNo	char(19),
@TransDate	datetime,
@OutletNo	int,
@TransID	int,
@RefNum		char(6),
@ChkNum		char(6),
@TransTotal	money,
@Comment	varchar(40)
AS
	DECLARE @CycleNo	int,
			@ReturnCode	int,
			@CoreID		int,
			@cMsg		varchar(255)
	
BEGIN TRANSACTION
	SET @CoreID = dbo.GetCoreIDFromUser(@User)
	EXEC @ReturnCode = dbo.sp_Trans_RemovePost @User,@DetailID
	IF (@ReturnCode <> 0)
		GOTO ERR_PROC
  EXEC @ReturnCode = dbo.sp_Trans_Post @CoreID,@User,@AccountNo,@AccountNo,@TransDate,@OutletNo,@RefNum,@ChkNum,
						@TransTotal,@TransTotal,@Comment,0,@TransID,'',0,0,
						0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
	IF (@ReturnCode<>0)
		GOTO ERR_PROC
	-- Log table entry
	INSERT INTO tblLog (UserID,CoreID,Description) VALUES(@User,'1','Updated transaction for Gift Card No <' + RTRIM(@AccountNo) + '>' +
		' RefNo <' + @RefNum +'>')
COMMIT TRANSACTION
   	--[ UPDATE Log ]---------------------------------------
	SET @cMsg = 'Updated transaction for Gift Card No <' + RTRIM(@AccountNo) + '> RefNo <' + @RefNum + '>'
	EXEC dbo.sp_Logit 2 , @CoreID , @User , @cMsg
	-------------------------------------------------------[ UPDATE Log END ]------
RETURN
ERR_PROC:
	ROLLBACK TRANSACTION
	
	   	--[ UPDATE Log ]---------------------------------------
	SET @cMsg = 'sp_Trans_Update FAILED'
	EXEC dbo.sp_Logit 2 , @CoreID , @User , @cMsg
	-------------------------------------------------------[ UPDATE Log END ]------
	
	RETURN @ReturnCode
go

