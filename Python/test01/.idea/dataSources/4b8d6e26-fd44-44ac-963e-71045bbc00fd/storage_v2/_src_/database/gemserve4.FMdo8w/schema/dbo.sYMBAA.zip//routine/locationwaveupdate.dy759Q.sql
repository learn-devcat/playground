

CREATE PROCEDURE dbo.LocationWaveUpdate
@LoginUserID		varchar(250),
@WaveID			int,
@LocationClassID	int,
@Active			bit

AS
	SET NOCOUNT ON 

	UPDATE dbo.tblLocationWave
	SET Active = @Active
	WHERE	WaveID = @WaveID
		AND LocationClassID = @LocationClassID

	IF (@@ROWCOUNT = 0)
		INSERT INTO dbo.tblLocationWave (WaveID, LocationClassID, Active)
			VALUES (@WaveID, @LocationClassID, @Active)	

	RETURN
go

