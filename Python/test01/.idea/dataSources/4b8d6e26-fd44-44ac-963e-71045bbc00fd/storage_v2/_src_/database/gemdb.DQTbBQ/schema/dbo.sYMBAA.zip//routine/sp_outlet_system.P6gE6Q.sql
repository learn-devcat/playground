

CREATE PROCEDURE dbo.sp_Outlet_System
AS
	DECLARE	@OutletNo	int
	SELECT	@OutletNo = ISNULL(dbo.GetOverheadItem('SystemOutlet'),1000)
	SELECT	OutletName, @OutletNo as OutletNo
	FROM		tblOutletOHD 
	WHERE 	OutletNo = @OutletNo
go

