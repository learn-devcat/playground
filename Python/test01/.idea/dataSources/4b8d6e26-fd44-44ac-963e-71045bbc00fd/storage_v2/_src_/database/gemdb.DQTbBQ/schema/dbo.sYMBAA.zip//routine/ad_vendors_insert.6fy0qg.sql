CREATE PROCEDURE [dbo].[ad_Vendors_Insert]
    @ID int,
    @Description varchar(50),
    @Notes varchar(200)
AS 
    INSERT  dbo.tblVendors
            (
              ID,
              [Description],
              Notes 
            )
    VALUES  (
              @ID,
              @Description,
              @Notes
	          
            )
go

