/*
	1. Delete all standing orders for this patient that are in the future
	2. Loop through all items in the tblMealPeriodDiet table and get the ones that match the DietID. 
		This will give us a listing of Meal Periods that need a standing order
	3. For each Meal Period retrieved, look up the OrderDetail from tblStandingOrderOHD. Insert an order in
		tblOrderOHD for each Meal Period using the OrderDetail retrieved. 
		The WaveID from tblStandingOrderOHD will be the delivery wave/time.
		If a MealPeriod is in the future, insert the meal for today.
		If a MealPeriod is in progress, insert the meal for the next available Wave in the MealPeriod.
		  If we are in the last wave for the MealPeriod, insert the meal for the current Wave.
		If a MealPeriod has already passed, insert the meal for today + 1 day.
*/

/*
	1. Delete all standing orders for this patient that are in the future
	2. Loop through all items in the tblMealPeriodDiet table and get the ones that match the DietID. 
		This will give us a listing of Meal Periods that need a standing order
	3. For each Meal Period retrieved, look up the OrderDetail from tblStandingOrderOHD. Insert an order in
		tblOrderOHD for each Meal Period using the OrderDetail retrieved. 
		The WaveID from tblStandingOrderOHD will be the delivery wave/time.
		If a MealPeriod is in the future, insert the meal for today.
		If a MealPeriod is in progress, insert the meal for the next available Wave in the MealPeriod.
		  If we are in the last wave for the MealPeriod, insert the meal for the current Wave.
		If a MealPeriod has already passed, insert the meal for today + 1 day.
*/
CREATE PROCEDURE [dbo].[NonSelectOrderAdd]
@PatientID	int,
@PatientVisitID varchar(50),
@DietID		int

AS
	SET NOCOUNT ON

	DECLARE @MealPeriodID		int,
		@PreviousMealPeriodID	int,
		@WaveID			int,
		@BeginTime		char(5),
		@NextWave		int,
		@NextWaveDate		datetime,
		@OrderID		int,
		@OrderDetail		varchar(2000)

	SET @PreviousMealPeriodID = -1

	-- Delete all future standing orders for this patient, 
	-- since we are about to re-add them.
	DELETE dbo.tblOrderOHD WHERE PatientID = @PatientID 
		AND NonSelectOrder = 1 
		AND dbo.dDateOnly(OrderDate) >= dbo.dDateOnly(getdate())
		AND Sent = 0
	
	-- Select all meal periods for this diet
	DECLARE MealPeriods cursor FOR
		SELECT W.MealPeriodID, W.BeginTime
		FROM dbo.tblWave AS W (NOLOCK)
			JOIN dbo.tblDietWave AS DW (NOLOCK) ON W.WaveID = DW.WaveID AND DW.DietID = @DietID
		WHERE W.MealPeriodID IS NOT NULL
		ORDER BY W.MealPeriodID, W.WaveID

	OPEN MealPeriods
	FETCH NEXT FROM MealPeriods INTO @MealPeriodID, @BeginTime

	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		-- Make sure we only process a meal period one time
		IF(@MealPeriodID <> @PreviousMealPeriodID)
		BEGIN
			SET @PreviousMealPeriodID = @MealPeriodID

			-- reset variables
			SET @WaveID = null
			SET @OrderDetail = null

			-- Get the wave and order detail information for the standing order
			SELECT @WaveID = WaveID
				FROM dbo.tblNonSelectOHD 
				WHERE DietID = @DietID
					AND MealPeriodID = @PreviousMealPeriodID

			-- Get the WaveID and Next Date for the wave
			SET @NextWave = COALESCE(@WaveID,dbo.GetNextWaveForMealPeriod(@MealPeriodID, getdate()))
			SET @NextWaveDate = dbo.GetNextDateForWave(@NextWave, getdate())

			-- Insert the order
			INSERT INTO dbo.tblOrderOHD (WaveID, SubLevel, OrderDate, PostDate, PatientID, PatientVisitID, NonSelectOrder, EnteredBy)
				VALUES(@NextWave, DATEPART(dw,@NextWaveDate), @NextWaveDate, getdate(), @PatientID, @PatientVisitID, 1, 'NonSelectOrderAdd')

			-- Get the OrderID for the new order
			SET @OrderID = SCOPE_IDENTITY()

			-- Insert the Order detail
			INSERT INTO dbo.tblOrderItems(OrderID, POSMenuItemID, ItemType, IsDiet, Consumption)
			SELECT @OrderID, D.MenuItemID, D.ItemType, D.IsDiet, 100
			FROM dbo.tblNonSelectDetail AS D
				JOIN dbo.tblNonSelectOHD AS O ON D.NonSelectOrderID = O.NonSelectOrderID
			WHERE O.DietID = @DietID
				AND O.MealPeriodID = @PreviousMealPeriodID
		END

		FETCH NEXT FROM MealPeriods INTO @MealPeriodID, @BeginTime
	END

	CLOSE MealPeriods
	DEALLOCATE MealPeriods

	RETURN
go

