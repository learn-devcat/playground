CREATE PROCEDURE dbo.MenuItemTouchscreenDuplicate
@DietToCopy	int,
@NewPOSDietID	int
AS
	SET NOCOUNT ON

	INSERT INTO dbo.tblMenuItem_TouchScreen (MenuItemID, DietID, MenuCategoryID, Active,
		RowStart, ColStart, Height, Width, Font, Color, IconPlacement,
		IconID, Legend, KeyType, Modified, NextScreen)
	SELECT MenuItemID, @NewPOSDietID, MenuCategoryID, Active,
		RowStart, ColStart, Height, Width, Font, Color, IconPlacement,
		IconID, Legend, KeyType, 1, NextScreen
	FROM dbo.tblMenuItem_TouchScreen
	WHERE DietID = @DietToCopy

	RETURN
go

