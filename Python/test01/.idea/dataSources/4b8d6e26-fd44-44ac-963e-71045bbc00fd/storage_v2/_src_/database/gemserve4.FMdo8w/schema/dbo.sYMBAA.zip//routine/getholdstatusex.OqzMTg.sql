CREATE FUNCTION dbo.GetHoldStatusEX
(@PatientId INT, @Now DATETIME)
RETURNS BIT
AS
BEGIN
	DECLARE @Return	bit,
			@HoldActiveTime datetime,
			@HoldReleaseTime datetime

	SELECT @HoldActiveTime = COALESCE(HoldActiveTime, '1/1/2050'),
			@HoldReleaseTime = COALESCE(HoldReleaseTime, '1/1/2050')
	FROM dbo.tblPatientOHD
	WHERE PatientId = @PatientId

	IF (@Now BETWEEN @HoldActiveTime AND @HoldReleaseTime)
		SET @Return = 1
	ELSE
		SET @Return = 0

	RETURN @Return
END
go

