


create     PROCEDURE dbo.ad_AddGemMenus_old
@AddGC	int = 0
AS
IF (dbo.CheckMenu(100) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(100, 0, 'Home', '', 1, 0, 1000)
IF (dbo.CheckMenu(105) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(105, 100, 'GEM Home', 'parent.MainView.document.location=''GemInstruct.asp''', 9, 9, 1005)
IF (dbo.CheckMenu(110) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(110, 100, 'CCENTS Home', 'window.open(''http://www.ccents.com'')', 2, 0, 1010)
IF (dbo.CheckMenu(115) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(115, 100, 'Change User/Logoff', 'parent.TOP.document.location=''Logon.htm''', 2, 0, 1015)
IF (dbo.CheckMenu(120) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(120, 100, 'User Options', 'parent.MainView.document.location=''Users/UserOptions.asp''', 4, 0, 1020)
/*
	Management Menus
*/
IF (dbo.CheckMenu(300) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(300, 0, 'Management', '', 1, 0, 1100)
IF (dbo.CheckMenu(305) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(305, 300, 'Account Management', 'parent.MainView.document.location=''Accounts/AccountRetrieve.asp''', 4, 0, 1105)
IF (dbo.CheckMenu(310) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(310, 300, 'Badge Management', 'parent.MainView.document.location=''Badges/BadgeRetrieve.asp''', 9, 0, 1110)
IF (dbo.CheckMenu(315) = 0) AND @AddGC <> 0
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(315, 300, 'Gift Card Management', 'parent.MainView.document.location=''GiftCards/GCRetrieve.asp''', 4, 0, 1115)
IF (dbo.CheckMenu(320) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(320, 300, 'Batch Management', 'parent.MainView.document.location=''Trans/BatchRetrieve.asp''', 6, 0, 1120)
IF (dbo.CheckMenu(372) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(372,300, 'Recurring Charges', 'parent.MainView.document.location=''Trans/RecurringChargesList_Class.asp''', 1, 0, 1125)
/* 
	Gift Card Assignment
*/
IF (dbo.CheckMenu(500) = 0) AND @AddGC <> 0
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(500, 0, 'Assign Gift Cards', '', 1, 0, 1200)
IF (dbo.CheckMenu(510) = 0) AND @AddGC <> 0
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(510, 500, 'Add [GCValue1] Gift Card', 'parent.MainView.document.location=''GiftCards/GCAdd.asp?CardValue=[GCValue1]''', 4, 0, 1205)
IF (dbo.CheckMenu(520) = 0) AND @AddGC <> 0
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(520, 500, 'Add [GCValue2] Gift Card', 'parent.MainView.document.location=''GiftCards/GCAdd.asp?CardValue=[GCValue2]''', 4, 0, 1215)
IF (dbo.CheckMenu(530) = 0) AND @AddGC <> 0
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(530, 500, 'Add [GCValue3] Gift Card', 'parent.MainView.document.location=''GiftCards/GCAdd.asp?CardValue=[GCValue3]''', 4, 0, 1220)
/*
	Report Menus
*/
IF (dbo.CheckMenu(600) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(600, 0, 'Reports', 'parent.MainView.document.location=''Reports/ProcessReports.asp''', 1, 0, 1300)
--IF (dbo.CheckMenu(602) = 0)
--	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
--	VALUES(602, 600, 'Available Reports', 'parent.MainView.document.location=''Reports/ProcessReports.asp''', 1, 0)
--IF (dbo.CheckMenu(650) = 0)
--	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
--	VALUES(650, 600, 'Edit Report Messages', 'parent.MainView.document.location=''Administrative/ReportMessagesEdit.asp''',7,0)
--IF (dbo.CheckMenu(652) = 0)
--	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
--	VALUES(652, 600, 'SET Report Messages', 'parent.MainView.document.location=''Administrative/ReportMessagesSet.asp''',7,0)
/*
	Admin Menus
*/
IF (dbo.CheckMenu(800) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(800, 0, 'Admin', '', 1, 0, 1305)
IF (dbo.CheckMenu(802) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(802, 800, 'Cores', 'parent.MainView.document.location=''Administrative/CoreRetrieve.asp''', 9, 0, 1310)
IF (dbo.CheckMenu(804) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(804, 800, 'Interfaces', 'parent.MainView.document.location=''Administrative/InterfaceRetrieve.asp''', 9, 0, 1315)
IF (dbo.CheckMenu(806) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(806, 800, 'Connections', 'parent.MainView.document.location=''Administrative/ConnectionRetrieve.asp''', 9, 0, 1320)
IF (dbo.CheckMenu(808) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(808, 800, 'Account Profiles', 'parent.MainView.document.location=''Administrative/AccountProfileRetrieve.asp''', 9, 9, 1325)
IF (dbo.CheckMenu(809) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(809, 800, 'Account Categories', 'parent.MainView.document.location=''Administrative/AccountCategoryRetrieve.asp''', 9, 9, 1330)
IF (dbo.CheckMenu(810) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(810, 800, 'Address Profiles', 'parent.MainView.document.location=''Administrative/AddressProfileRetrieve.asp''', 9, 9, 1335)
IF (dbo.CheckMenu(812) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(812, 800, 'Badge Profiles', 'parent.MainView.document.location=''Administrative/BadgeProfileRetrieve.asp''', 9, 9, 1340)
IF (dbo.CheckMenu(814) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(814, 800, 'Outlet Profiles', 'parent.MainView.document.location=''Administrative/OutletProfileRetrieve.asp''', 9, 9, 1345)
IF (dbo.CheckMenu(816) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(816, 800, 'Recur. Chg. Profiles', 'parent.MainView.document.location=''Administrative/RecurChgProfileRetrieve.asp''', 9, 9, 1350)
IF (dbo.CheckMenu(818) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(818, 800, 'Transaction Profiles', 'parent.MainView.document.location=''Administrative/TransProfileRetrieve.asp''', 9, 9, 1355)
IF (dbo.CheckMenu(820) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(820, 800, 'Meal Plans', 'parent.MainView.document.location=''Meals/PlanOHD.asp''', 9, 9, 1365)
IF (dbo.CheckMenu(825) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(825, 800, 'Manage Locations', 'parent.MainView.document.location=''Administrative/LocationRetrieve.asp''', 9, 9, 1500)
IF (dbo.CheckMenu(830) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(830, 800, 'Outlets', 'parent.MainView.document.location=''Administrative/OutletRetrieve.asp''', 9, 9, 1370)
--IF (dbo.CheckMenu(834) = 0)
--	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
--	VALUES(834, 800, 'Schedules', 'parent.MainView.document.location=''Schedules/SchedulesRetrieve.asp''', 9, 9, 1375)
IF (dbo.CheckMenu(836) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(836, 800, 'Tracking Groups', 'parent.MainView.document.location=''Administrative/TrackingGroupRetrieve.asp''', 9, 9, 1380)
IF (dbo.CheckMenu(838) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(838, 800, 'Transaction IDs', 'parent.MainView.document.location=''Administrative/TransDefRetrieve.asp''', 9, 9, 1385)
IF (dbo.CheckMenu(840) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(840, 800, 'Transaction Rollback', 'parent.MainView.document.location=''Trans/Rollback.asp''', 9, 9, 1390)
IF (dbo.CheckMenu(845) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(845, 800, 'Transaction Archive', 'parent.MainView.document.location=''Administrative/Archive.asp''', 9, 9, 1390)
IF (dbo.CheckMenu(850) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(850, 800, 'Edit Report Messages', 'parent.MainView.document.location=''Administrative/ReportMessagesEdit.asp''',1,0, 1395)
IF (dbo.CheckMenu(852) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(852, 800, 'SET Report Messages', 'parent.MainView.document.location=''Administrative/ReportMessagesSet.asp''',1,0, 1400)
IF (dbo.CheckMenu(860) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(860, 800, 'Overhead Values', 'parent.MainView.document.location=''Administrative/Overhead.asp''', 9, 9, 1405)
--IF (dbo.CheckMenu(870) = 0)
--	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
--	VALUES(870, 800, 'Menu Management', 'parent.MainView.document.location=''Administrative/MenuManagement.asp''', 9, 9, 1410)
IF (dbo.CheckMenu(872) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(872, 800, 'SET Debug Mode', 'parent.MainView.document.location=''Administrative/SetDebug.asp''', 1, 0, 1415)
IF (dbo.CheckMenu(880) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(880,800, 'GEMpay Status', 'parent.MainView.document.location=''Administrative/MasterAdmin.asp''', 9, 9, 1420)
IF (dbo.CheckMenu(884) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(884,800, 'Online Status', 'parent.MainView.document.location=''Administrative/SOnline.asp''', 9, 9, 1425)
IF (dbo.CheckMenu(886) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(886,800, 'Manage Script Params', 'parent.MainView.document.location=''Administrative/ScriptParams.asp''', 9, 9, 1430)
/*
	User Menus
*/
IF (dbo.CheckMenu(900) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(900, 0, 'Users', '', 1, 9, 1500)
IF (dbo.CheckMenu(910) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(910, 900, 'Manage Users', 'parent.MainView.document.location=''Users/UserEdit.asp''', 9, 9, 1505)
IF (dbo.CheckMenu(920) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(920, 900, 'Manage User Privileges', 'parent.MainView.document.location=''Users/UserSecurity.asp''', 9, 9, 1510)
IF (dbo.CheckMenu(930) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(930, 900, 'Manage Privilege Profiles', 'parent.MainView.document.location=''Users/PrivilegeClassRetrieve.asp''', 9, 9, 1515)
IF (dbo.CheckMenu(940) = 0)
	INSERT INTO cfgMenus (MenuID, SubMenuID, Description, URL, SecurityLevel, MenuGroup, ActionID)
	VALUES(940, 900, 'Manage Privilege Actions', 'parent.MainView.document.location=''Users/PrivilegeActionRetrieve.asp''', 9, 9, 1520)
DELETE cfgOverhead
WHERE UPPER(oKey) = 'STARTUPMSG'
INSERT INTO cfgOverhead (oKey, sValue, dType)
		VALUES('StartupMsg', 'Welcome to GEMpay! <BR><BR>  Choose any menu item on the left to BEGIN.', '1')
IF (@AddGC <> 0)
	UPDATE	cfgOverhead
	SET		sValue = 3
	WHERE	oKey = 'Menus'
ELSE
	UPDATE	cfgOverhead
	SET		sValue = 1
	WHERE	oKey = 'Menus'
go

