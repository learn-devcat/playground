

CREATE PROCEDURE dbo.sp_ColumnInfo
@TableName	varchar(50)
AS
	EXEC sp_columns @TableName
go

