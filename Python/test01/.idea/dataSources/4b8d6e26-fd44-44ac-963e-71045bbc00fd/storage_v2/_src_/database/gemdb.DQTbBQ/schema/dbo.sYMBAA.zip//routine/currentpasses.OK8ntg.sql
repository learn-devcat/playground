


CREATE FUNCTION dbo.CurrentPasses(@AccountNo char(19),@MealPlanID int, @BeginTime datetime, @EndTime datetime)
RETURNS int
AS
BEGIN
	DECLARE @Return int
	SELECT 	@Return = COUNT(TransID)
	FROM	tblDetail
	WHERE	AccountNo = @AccountNo
		AND MealPlanID = @MealPlanID
		AND TransDate >= @BeginTime
		AND TransDate <= @EndTime
	RETURN ISNULL(@Return,0)
END
go

