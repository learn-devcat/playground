CREATE PROCEDURE [dbo].[Micros_DietConsistencyList]
AS
	SET NOCOUNT ON

	DECLARE @RoomServiceObjNum int
	
	-- Check the overhead table and get the object number for Room Service in the Revenue Center Def
	SET @RoomServiceObjNum = COALESCE(dbo.GetOverheadValueNull('RoomServiceObjNum'),'-1')

	IF (@RoomServiceObjNum <> -1)
	BEGIN
		-- Get the Main Menu Levels used for Diet Consistency (Levels 1-6) 
		SELECT REPLACE(REPLACE(Main_Mlvl_Seq, 'main_mlvl_',''),'_name','') AS Main_Mlvl_Seq, Consistency
		FROM
			(SELECT main_mlvl_1_name, main_mlvl_2_name, main_mlvl_3_name, main_mlvl_4_name, main_mlvl_5_name, main_mlvl_6_name
				FROM MicrosRevenueCenterDef WHERE obj_num = @RoomServiceObjNum) AS MRCD
		UNPIVOT
			(Consistency FOR Main_Mlvl_Seq IN
				(main_mlvl_1_name, main_mlvl_2_name, main_mlvl_3_name, main_mlvl_4_name, main_mlvl_5_name, main_mlvl_6_name)
			) AS unpvt
		WHERE Consistency NOT IN ('1','2','3','4','5','6','')
	END

	RETURN
go

