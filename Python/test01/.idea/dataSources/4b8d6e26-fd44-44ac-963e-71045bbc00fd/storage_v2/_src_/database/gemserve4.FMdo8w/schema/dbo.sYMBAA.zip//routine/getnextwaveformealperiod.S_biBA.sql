
CREATE FUNCTION dbo.GetNextWaveForMealPeriod(@MealPeriodID int, @Today datetime)
RETURNS int
AS
BEGIN
	DECLARE @Return 	int,
		@WaveID		int,
		@PrepTime	varchar(10)

	SELECT @PrepTime = dbo.GetOverheadValue('MinimumPrepTime')
	IF(@PrepTime = '')
		SET @PrepTime = '30'

	SELECT TOP 1 @Return = WaveID
	FROM tblWave
	WHERE MealPeriodID = @MealPeriodID
		AND EndTime >= dbo.TimeString(DATEADD(mi,CAST(@PrepTime AS integer),@Today))
	ORDER BY EndTime

	IF(@Return IS NULL)
		-- None for today, so return the first wave available for tomorrow
		SELECT TOP 1 @Return = WaveID
		FROM tblWave
		WHERE MealPeriodID = @MealPeriodID
		ORDER BY BeginTime

	RETURN ISNULL(@Return,-1)
END
go

