




CREATE PROCEDURE dbo.PatientUpdateNutrientCount
@PatientID	int,
@OrderID	int,
@WaveDate	datetime,
@Nutrients	varchar(500)

AS
	SET NOCOUNT ON

	DECLARE @NutrientID	int,
 		     @Qty	decimal(10,3)

		DECLARE Nutrients cursor FOR
		SELECT NutrientID
		FROM 	cfgNutrients
		ORDER BY NutrientID

	OPEN Nutrients
	FETCH NEXT FROM Nutrients INTO @NutrientID

	WHILE (@@FETCH_STATUS=0)
	BEGIN
		IF (CHARINDEX(',', @Nutrients) <> 0)
		BEGIN
			SET @Qty = CAST(LEFT(@Nutrients, CHARINDEX(',', @Nutrients) - 1) AS decimal(10,3)) / 1000
			SET @Nutrients = RIGHT(@Nutrients, LEN(@Nutrients) - (CHARINDEX(',', @Nutrients)))
		END
		ELSE
			IF (LEN(@Nutrients) > 0)
			BEGIN
				-- The last item in the list
				SET @Qty = CAST(@Nutrients AS decimal(10,3)) / 1000
				SET @Nutrients = ''
			END
			ELSE	
				-- No more values to set, so get out
				BREAK

		INSERT INTO dbo.tblPatientNutrientCount (PatientID, NutrientID, [Date], OrderID, Qty)
			VALUES (@PatientID, @NutrientID, @WaveDate, @OrderID, @Qty)

		FETCH NEXT FROM Nutrients INTO @NutrientID
	END

	CLOSE Nutrients
	DEALLOCATE Nutrients

	RETURN
go

