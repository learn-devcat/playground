

CREATE PROCEDURE [dbo].[gem_ClassPrivilege_Delete]
@User			char(10),
@PrivilegeClassID	int
AS
	IF (@PrivilegeClassID = -1)
	BEGIN
		DELETE tblPrivilegeLinks
	END
	ELSE
	BEGIN
		DELETE tblPrivilegeLinks WHERE PrivilegeClassID = @PrivilegeClassID
	END
go

