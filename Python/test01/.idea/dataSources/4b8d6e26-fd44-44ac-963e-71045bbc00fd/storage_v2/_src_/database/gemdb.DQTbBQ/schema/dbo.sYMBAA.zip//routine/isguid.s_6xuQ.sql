CREATE FUNCTION [dbo].[IsGuid] (@testString varchar(38)) 
	RETURNS uniqueidentifier 
	AS 
	BEGIN 
		DECLARE @Return uniqueidentifier 

		SELECT @testString = REPLACE(REPLACE(@testString, '{', ''), '}', '') 

		SELECT @Return = CASE WHEN @testString like 
		(REPLICATE('[0-9A-Fa-f]',8) + '-' + 
		REPLICATE('[0-9A-Fa-f]',4) + '-' + 
		REPLICATE('[0-9A-Fa-f]',4) + '-' + 
		REPLICATE('[0-9A-Fa-f]',4) + '-' + 
		REPLICATE('[0-9A-Fa-f]',12)) THEN CAST(@testString AS uniqueidentifier) ELSE NULL END 

		RETURN @Return
	END
go

