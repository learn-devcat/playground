
Create    PROCEDURE dbo.WorkOrderOHD_CountIncompleteItems
@User			char(10),
@WorkorderID     	int
AS
	
	SELECT  Count(*)
	FROM    tblWorkOrderDTL
	WHERE	WorkorderID = @WorkorderID
		AND Completed = 0
    RETURN
go

