

CREATE FUNCTION dbo.GetLastOrderIDForPatient(@PatientID int, @Now datetime)
RETURNS int
BEGIN
	DECLARE @Return int
	
	SELECT TOP 1 @Return = OrderID
	FROM dbo.tblOrderOHD
	WHERE PatientID = @PatientID
		AND OrderDate <= @Now
	ORDER BY OrderDate DESC
	
	RETURN ISNULL(@Return, -1)
END
go

