CREATE PROCEDURE [dbo].[DietMenuItemsGet]
@DietID INT
AS
SET NOCOUNT ON

	SELECT	DM.DietMenuItemID, 
			DM.DietID,
			D.[Description] AS DietName,
			DM.POSMenuItemID,
			MI.[Description] AS MenuItemName
	FROM	dbo.tblDietMenuItems AS DM (NOLOCK)
	JOIN	dbo.tblDietOHD AS D (NOLOCK) ON D.DietID = DM.DietID
	LEFT JOIN dbo.tblMenuItemOHD AS MI (NOLOCK) ON DM.POSMenuItemID = MI.POSMenuItemID
	WHERE DM.DietID = @DietID
	ORDER BY MI.[Description]

	RETURN
go

