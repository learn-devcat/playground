CREATE PROCEDURE [dbo].[KitchenTimeGet]
    @KitchenTimeId int ,
    @KitchenId int
AS 
    SET NOCOUNT ON
	
	IF (@KitchenTimeId > 0)
		SELECT	KitchenTimeId,
				KitchenId,
				[Day],
				CAST(StartTime AS datetime) AS 'StartTime',
				CAST(EndTime AS datetime) AS 'EndTime'
		FROM dbo.tblKitchenTimes
		WHERE KitchenTimeId = @KitchenTimeId
	ELSE
		SELECT	KitchenTimeId,
				KitchenId,
				[Day],
				CAST(StartTime AS datetime) AS 'StartTime',
				CAST(EndTime AS datetime) AS 'EndTime'
		FROM dbo.tblKitchenTimes
		WHERE KitchenId = @KitchenId
		ORDER BY [Day] ASC, CAST(StartTime AS datetime) ASC
    RETURN
go

