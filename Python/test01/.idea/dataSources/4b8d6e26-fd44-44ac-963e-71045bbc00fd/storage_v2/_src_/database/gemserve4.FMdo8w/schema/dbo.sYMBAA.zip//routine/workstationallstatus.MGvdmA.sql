

CREATE PROCEDURE dbo.WorkstationAllStatus

AS
	SET NOCOUNT ON

	DECLARE @IdleIntervalCaution	varchar(20),
		@IdleIntervalWarning	varchar(20),
		@LastIdleEvent		datetime,
		@Now			datetime,
		@CautionMinutes		int,
		@WarningMinutes		int,
		@Return			int

	SET @Now = getdate()
	SET @IdleIntervalCaution = dbo.GetOverheadValue('IdleIntervalCaution')
	SET @IdleIntervalWarning = dbo.GetOverheadValue('IdleIntervalWarning')

	IF (ISNULL(@IdleIntervalCaution,'0') = '0')
		SET @CautionMinutes = '5'

	IF (ISNULL(@IdleIntervalWarning,'0') = '0')
		SET @WarningMinutes = '10'

	SET @CautionMinutes = CAST(@IdleIntervalCaution AS int)
	SET @WarningMinutes = CAST(@IdleIntervalWarning AS int)


	SELECT TOP 1 @LastIdleEvent = LastIdleEvent
	FROM dbo.tblWorkstation
	WHERE WorkStationID LIKE 'wrk%'
	ORDER BY LastIdleEvent DESC

	IF (@LastIdleEvent IS NULL)
		SET @LastIdleEvent = '1/1/1980'

	IF (DATEDIFF(mi, @LastIdleEvent, @Now) > @WarningMinutes)
	BEGIN
		SET @Return = 2
		GOTO ReturnStatus
	END			

	IF (DATEDIFF(mi, @LastIdleEvent, @Now) > @CautionMinutes)
	BEGIN
		SET @Return = 1
		GOTO ReturnStatus
	END			

	SET @Return = 0

ReturnStatus:
	SELECT @Return AS Status
go

