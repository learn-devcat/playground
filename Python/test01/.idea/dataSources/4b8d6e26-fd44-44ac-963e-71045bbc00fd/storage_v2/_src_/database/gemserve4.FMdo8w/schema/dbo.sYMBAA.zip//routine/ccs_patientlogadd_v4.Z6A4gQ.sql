CREATE PROCEDURE [dbo].[CCS_PatientLogAdd_v4]
@PatientID	varchar(50),
@PatientDietID	varchar(50),
@Notes		varchar(1000),
@Source		varchar(100)

AS
	SET NOCOUNT ON
	
	-- Since this procedure can be called from either ADT or ORM processing,
	-- we need to parameters for the respective ID's.
	-- Because one of them will always be missing, we use a varchar data type to allow 
	-- an empty string and CAST the ID received to an integer.
	DECLARE @iPatientID	int,
		@iPatientDietID	int,
		@PatientVisitID	varchar(50),
		@RoomID		int

	-- Check to see if there are any notes that need to be added to the patient log
	IF (@Notes = '')
		GOTO Finished

	IF (COALESCE(@PatientID,0) > 0)
	BEGIN
		SET @iPatientID = CAST(@PatientID AS int)
		SET @PatientVisitID = ''
	END
	ELSE
	BEGIN
		SET @iPatientDietID = CAST(@PatientDietID AS int)

		SELECT @PatientVisitID = PV.PatientVisitID,
			@iPatientID = PV.PatientID,
			@RoomID = RoomID
		FROM dbo.tblPatientDiet AS PD (NOLOCK)
		JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON PD.PatientVisitID = PV.PatientVisitID
		WHERE PD.[ID] = @iPatientDietID
	END				

	EXEC dbo.PatientLOGAdd 7000, 'HL7', @iPatientID, @PatientVisitID, @RoomID, @Notes

Finished:
	RETURN


go

