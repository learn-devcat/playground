CREATE PROCEDURE [dbo].[KitchenDelete]
	@LoginUserId		VARCHAR(150),
	@KitchenId			INT
AS
	SET NOCOUNT ON
	
	DECLARE @Msg VARCHAR(100)
	
	DELETE dbo.tblKitchens
	WHERE KitchenId = @KitchenId
	
	SET @Msg = 'Deleted kitchen id [' + CAST(@KitchenId AS VARCHAR(10)) + ']'
	EXEC dbo.Logit 2, @Msg, @LoginUserID
	
	RETURN 0
go

