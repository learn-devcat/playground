



CREATE PROCEDURE dbo.pub_RedeemGiftCard
@AccountNo	char(19),
@TransTotal	money,
@TransID	int,
@OutletNo	int,
@CoreID	int = 1
AS
	DECLARE	@TransDate	datetime,
			@Return	int
	SELECT	@TransDate = getdate()
	EXEC @Return = dbo.sp_Trans_Post @CoreID, 'GEMpos', @AccountNo, @AccountNo, @TransDate, @OutletNo, 'GEMpos', 'GEMpos', @TransTotal, @TransTotal, '', 0, @TransID
	
	SELECT @Return AS Field1
go

