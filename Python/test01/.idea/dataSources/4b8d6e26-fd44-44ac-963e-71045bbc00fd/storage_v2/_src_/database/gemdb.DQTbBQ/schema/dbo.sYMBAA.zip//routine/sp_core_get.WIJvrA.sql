

CREATE PROCEDURE dbo.sp_Core_Get
AS
	SELECT	CoreID, Active, Description, Category, SWKEY, SWPIN, MyIP, ExceptionIP,SysOptions
	FROM		cfgCore
go

