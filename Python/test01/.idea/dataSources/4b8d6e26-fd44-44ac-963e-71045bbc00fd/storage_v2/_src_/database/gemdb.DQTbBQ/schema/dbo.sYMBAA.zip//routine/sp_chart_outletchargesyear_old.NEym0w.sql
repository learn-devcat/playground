CREATE PROCEDURE [dbo].[sp_Chart_OutletChargesYear_OLD]
AS

DECLARE @Today datetime;

SET @Today = getdate();
	
SELECT 
ThisYear.OutletName,
ThisYear.OutletNO,
ThisYear.NumberofCharges AS ThisYearNumberOfCharges, 
ThisYear.SumOfCharges AS ThisYearSumOfCharges, 
ThisYear.NumberofPayments AS ThisYearNumberOfPayments,
ThisYear.SumOfPayments AS ThisYearSumOfPayments,
ThisYear.[Year] AS ThisYearValue,
LastYear.NumberofCharges AS LastYearNumberOfCharges, 
LastYear.SumOfCharges AS LastYearSumOfCharges, 
LastYear.NumberofPayments AS LastYearNumberOfPayments,
LastYear.SumOfPayments AS LastYearSumOfPayments,
LastYear.[Year] AS LastYearValue
FROM(
	SELECT ISNULL(O.OutletName,'[Outlet not found]') AS OutletName, T.OutletNo, SUM(T.ChgQty) AS NumberofCharges, 
		SUM(T.ChgTotal) AS SumOfCharges, SUM(T.PayQty) AS NumberofPayments, SUM(T.PayTotal) AS SumOfPayments, DATEPART(YEAR,C.BeginDate) AS Year
        FROM dbo.tblOutletTTL AS T 
        LEFT JOIN dbo.tblOutletOHD AS O ON T.OutletNo = O.OutletNo 
        LEFT JOIN dbo.tblCycleXlat AS C ON T.CycleNo = C.CycleNo AND C.xlatID = 'MTH'
		WHERE DATEPART(YEAR,C.BeginDate) = DATEPART(YEAR,@Today)
			AND T.OutletNO IN (
			SELECT  T2.OutletNo
			FROM dbo.tblOutletTTL AS T2 
			LEFT JOIN dbo.tblOutletOHD AS O2 ON T2.OutletNo = O2.OutletNo 
			LEFT JOIN dbo.tblCycleXlat AS C2 ON T2.CycleNo = C2.CycleNo AND C2.xlatID = 'MTH'
			WHERE DATEPART(YEAR,C2.BeginDate) = DATEPART(YEAR,@Today))
		GROUP BY ISNULL(O.OutletName,'[Outlet not found]'), T.OutletNo , DATEPART(YEAR,C.BeginDate)) AS ThisYear
		JOIN (
			SELECT ISNULL(O.OutletName,'[Outlet not found]') AS OutletName, T.OutletNo, SUM(T.ChgQty) AS NumberofCharges, 
			SUM(T.ChgTotal) AS SumOfCharges, SUM(T.PayQty) AS NumberofPayments, SUM(T.PayTotal) AS SumOfPayments, DATEPART(YEAR,C.BeginDate) AS Year
			FROM dbo.tblOutletTTL AS T 
			LEFT JOIN dbo.tblOutletOHD AS O ON T.OutletNo = O.OutletNo 
			LEFT JOIN dbo.tblCycleXlat AS C ON T.CycleNo = C.CycleNo AND C.xlatID = 'MTH'
			WHERE DATEPART(YEAR,C.BeginDate) = DATEPART(YEAR, DATEADD(YEAR, -1, @Today))
			AND T.OutletNO IN (
			SELECT  T2.OutletNo
			FROM dbo.tblOutletTTL AS T2 
			LEFT JOIN dbo.tblOutletOHD AS O2 ON T2.OutletNo = O2.OutletNo 
			LEFT JOIN dbo.tblCycleXlat AS C2 ON T2.CycleNo = C2.CycleNo AND C2.xlatID = 'MTH'
			WHERE DATEPART(YEAR,C2.BeginDate) = DATEPART(YEAR,@Today)
		)
		GROUP BY ISNULL(O.OutletName,'[Outlet not found]'), T.OutletNo , DATEPART(YEAR,C.BeginDate)) AS LastYear ON ThisYear.OutletNO = LastYear.OutletNO

		
RETURN 0
go

