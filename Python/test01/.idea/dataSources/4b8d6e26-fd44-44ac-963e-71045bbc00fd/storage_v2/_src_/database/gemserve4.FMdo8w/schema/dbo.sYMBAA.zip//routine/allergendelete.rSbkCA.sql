

CREATE PROCEDURE [dbo].[AllergenDelete]
@LoginUserId varchar(250),
@AllergenID	int

AS
	DELETE dbo.cfgAllergens
	WHERE AllergenID = @AllergenID
go

