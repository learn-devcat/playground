

CREATE PROCEDURE dbo.sp_Messages_Get
@User	char(10)
AS
	SELECT	ID,Message
	FROM		tblMessages
	WHERE	dbo.GetUserLanguage(@User) = Language
go

