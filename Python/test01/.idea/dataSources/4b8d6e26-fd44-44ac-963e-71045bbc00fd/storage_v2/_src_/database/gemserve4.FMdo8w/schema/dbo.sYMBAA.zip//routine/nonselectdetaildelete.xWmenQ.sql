CREATE PROCEDURE [dbo].[NonSelectDetailDelete]
@LoginUserID		varchar(250),
@NonSelectItemID	int,
@NonSelectOrderID	int=0

AS

	SET NOCOUNT ON

	IF (@NonSelectItemID > 0)
		DELETE dbo.tblNonSelectDetail
		WHERE NonSelectItemID = @NonSelectItemID
	ELSE
		DELETE dbo.tblNonSelectDetail
		WHERE NonSelectOrderID = @NonSelectOrderID

	RETURN
go

