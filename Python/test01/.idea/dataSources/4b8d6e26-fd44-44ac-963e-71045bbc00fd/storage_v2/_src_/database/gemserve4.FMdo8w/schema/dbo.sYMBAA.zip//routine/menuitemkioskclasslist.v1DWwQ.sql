


CREATE PROCEDURE dbo.MenuItemKioskClassList
AS
	SET NOCOUNT ON

	SELECT	MenuItemKioskClassID,
		[Description],
		ImageUrl
	FROM	dbo.tblMenuItemKioskClass
	ORDER BY [Sequence]

	RETURN
go

