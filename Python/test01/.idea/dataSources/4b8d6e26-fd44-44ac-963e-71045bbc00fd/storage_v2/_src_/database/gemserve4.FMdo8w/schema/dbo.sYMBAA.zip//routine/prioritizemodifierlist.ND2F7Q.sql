
CREATE FUNCTION [dbo].[PrioritizeModifierList]
(@ModifierList VARCHAR (4000))
RETURNS VARCHAR (4000)
AS
BEGIN
	DECLARE @Start		int,
		@Item		varchar(200),
		@ItemPriority	int,
		@Return		varchar(4000),
		@Done 		int,
		@Count		int,
		@ORMSeparator	varchar(10),
		@TempID		int

	SELECT @ORMSeparator = COALESCE(dbo.GetOverheadValueNull('ORMSeparator'),'|')
	SET @Done = 0
	SET @Count = 1

	IF (CHARINDEX(@ORMSeparator, @ModifierList) = 0)
	BEGIN
		SET @Return = @ModifierList
		GOTO Finish
	END
	ELSE
	BEGIN
		DECLARE @Modifiers TABLE (ModifierID int IDENTITY(1,1),ModifierName varchar(200), ModifierPriority int)

		SET @Start = 1

		WHILE (@Done = 0)
		BEGIN
			IF (CHARINDEX(@ORMSeparator, @ModifierList, @Start) > 0)
			BEGIN
				SELECT @Item = SUBSTRING(@ModifierList, @Start, CHARINDEX(@ORMSeparator, @ModifierList, @Start) - @Start)
				SET @Start = @Start + LEN(@Item) + 1
			END
			ELSE
			BEGIN
				SET @Item = SUBSTRING(@ModifierList, @Start, LEN(@ModifierList) - @Start + 1)
				SET @Done = 1
			END
	
			IF EXISTS (SELECT 1 FROM dbo.tblXlat WHERE xlatid = 'ModifierPriority' AND KeyIn = @Item)
			BEGIN
				-- Item is in the Modifier Priority listing, so process
				INSERT INTO @Modifiers (ModifierName, ModifierPriority)
				SELECT DISTINCT @Item, KeyOut
				FROM dbo.tblXlat 
				WHERE xlatid = 'ModifierPriority'
					AND KeyIn = @Item
			END	
			ELSE
			BEGIN
				IF @Item <> ''
				BEGIN
					INSERT INTO @Modifiers(ModifierName, ModifierPriority)
					SELECT @Item, 100000
				END
			END

			SET @Count = @Count + 1
					
		END

		-- Wrap the string back up
		IF EXISTS (SELECT 1 FROM @Modifiers)
		BEGIN
			SET @Return = ''
			
			SELECT @Return = COALESCE(@Return + @ORMSeparator, '') + 
				CAST(ModifierName AS varchar(200))
			FROM @Modifiers
			ORDER BY ModifierPriority DESC, ModifierID ASC
		END
		ELSE
			SET @Return = @ModifierList
	END

Finish:
	IF (RIGHT(@Return, 1) = @ORMSeparator)
		SET @Return = LEFT(@Return,LEN(@Return)-1)
	
	IF (LEFT(@Return, 1) = @ORMSeparator)
		SET @Return = RIGHT(@Return,LEN(@Return)-1)

	RETURN @Return
END

go

