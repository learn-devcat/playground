CREATE PROCEDURE [dbo].[sp_Task_ClearPreventImportChangesOnAccounts]

AS

	SET NOCOUNT ON

	DECLARE	@Msg	varchar(255)

	SET @Msg = 'The Prevent Changes During Import checkbox has been cleared for all accounts'

	UPDATE dbo.tblAccountOHD
	SET PreventChangesDuringImport = 0
	WHERE COALESCE(PreventChangesDuringImport,1) = 1

	SELECT @Msg AS [Msg]
go

