
CREATE FUNCTION dbo.FoodCostByLocation(@BeginDate datetime, @EndDate datetime, @LocationID as int)
RETURNS decimal
BEGIN
	DECLARE @Return decimal

	SELECT @Return = SUM(M.Cost)
	FROM dbo.tblOrderOHD AS O (NOLOCK)
                JOIN dbo.tblOrderLog AS OL (NOLOCK) ON O.OrderID = OL.OrderID
                JOIN dbo.tblOrderItems AS I (NOLOCK) ON O.OrderID = I.OrderID 
                JOIN dbo.tblMenuItemOHD AS M (NOLOCK) ON I.POSMenuItemID = M.POSMenuItemID
                        AND I.IsDiet <> 1
	WHERE O.OrderDate BETWEEN @BeginDate AND @EndDate
		AND COALESCE(O.RoomID, -1) IN (SELECT RoomID FROM dbo.tblRoomOHD WHERE LocationClassID = @LocationID)
		AND dbo.GetActionID('RECEIVED') = OL.ActionID

	RETURN COALESCE(@Return, 0)
END
go

