

CREATE PROCEDURE dbo.gem_ClassPrivilege_Insert
@User			char(10),
@PrivilegeClassID	int,
@ActionID		int,
@Application		int=1
AS
	INSERT INTO	tblPrivilegeLinks (PrivilegeClassID, ActionID, Application)
		VALUES (@PrivilegeClassID, @ActionID, @Application)
go

