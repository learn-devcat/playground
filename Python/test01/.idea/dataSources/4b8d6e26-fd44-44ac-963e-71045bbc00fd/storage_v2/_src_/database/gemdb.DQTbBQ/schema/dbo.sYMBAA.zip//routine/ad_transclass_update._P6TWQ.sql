

CREATE PROCEDURE dbo.ad_TransClass_Update
@User				char(10),
@TransClassID		int,
@Description		varchar(25),
@Status				int,
@DisablePOSPosting	bit,
@DeclBalMode		bit,
@AddToBadgeBalance	int,
@SubType		int
AS 
	UPDATE	tblTransClass
	SET		Description = @Description,
			Status = @Status,
			DisablePOSPosting = @DisablePOSPosting,
			DeclBalMode = @DeclBalMode,
			AddToBadgeBalance = @AddToBadgeBalance,
			SubType = @SubType
	WHERE	TransClassID = @TransClassID
go

