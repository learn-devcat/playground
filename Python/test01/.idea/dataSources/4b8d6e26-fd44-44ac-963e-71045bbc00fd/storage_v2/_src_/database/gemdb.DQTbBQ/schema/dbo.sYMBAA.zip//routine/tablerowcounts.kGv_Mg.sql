
CREATE PROCEDURE dbo.TableRowCounts
AS
	DECLARE @TblName	VarChar(128),
		@Qry		VarChar(128)
	
	CREATE TABLE #UserTables (
		TableName  	varchar(128),
		NumRows		int	DEFAULT -1
		)
	
	Insert into #UserTables (TableName)
		SELECT	name		
		FROM	sysobjects 
		WHERE xtype = 'U'
	
	
	While 1 = 1
	BEGIN
		SELECT TOP 1 @TblName = TableName FROM #UserTables WHERE NumRows < 0 Order By TableName
		
		IF (@@ROWCOUNT = 0)
			BREAK
		SET @Qry = ('UPDATE #UserTables SET NumRows = (SELECT count(*) FROM ' + @TblName  + ') WHERE TableName = ' + char(39) + @TblName + char(39))
	
		EXEC ( @Qry )
	
	END
	
	
	SELECT * FROM #UserTables Order By TableName
	
	Drop Table #UserTables
go

