

CREATE FUNCTION dbo.CPDate(@WholeDate smalldatetime)
RETURNS char(10)
AS 
BEGIN 
	DECLARE	@Return	as char(10)
	DECLARE	@Day	as int,
			@Month	as int
			
	
	SELECT @Day = Day(@WholeDate),@Month = Month(@WholeDate)
	
	IF (@Day < 10) 
		BEGIN
			IF (@Month < 10)
				SET @Return = '0' + CAST(@Month AS char(1)) + '-0' + CAST(@Day AS char(1)) + '-' + CAST(Year(@WholeDate) AS char(4))
			ELSE
				SET @Return = CAST(@Month AS char(2)) + '-0' + CAST(@Day AS char(1)) + '-' + CAST(Year(@WholeDate) AS char(4))
		END
	ELSE
		BEGIN
			IF (@Month < 10)
				SET @Return = '0' + CAST(@Month AS char(1)) + '-' + CAST(@Day AS char(2)) + '-' + CAST(Year(@WholeDate) AS char(4))
			ELSE
				SET @Return = CAST(@Month AS char(2)) + '-' + CAST(@Day AS char(2)) + '-' + CAST(Year(@WholeDate) AS char(41))
		END
	
	RETURN @Return
END
go

