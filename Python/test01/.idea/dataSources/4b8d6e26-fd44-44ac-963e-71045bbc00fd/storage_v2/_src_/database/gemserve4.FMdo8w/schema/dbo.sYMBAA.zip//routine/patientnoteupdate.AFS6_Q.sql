
CREATE PROCEDURE [dbo].[PatientNoteUpdate]
@LoginUserID		varchar(250),
@NoteID			int,
@PatientVisitID		varchar(50),
@NoteType		int=null,
@ActiveDate		datetime=null,
@Source			varchar(50)=null,
@Notes			varchar(1000)=null,
@Cancelled		bit=null,
@TransactionIdentifier	varchar(50)=null,
@CancelDate		datetime=null
AS
	SET NOCOUNT ON

	DECLARE @Today datetime,
			@Msg varchar(250),
			@PatientID	int,
			@RoomID		int

	SELECT @PatientID = PatientID,
		@RoomID = RoomID
	FROM dbo.tblPatientVisit
	WHERE PatientVisitID = @PatientVisitID

	SET @Today = getdate()

	IF (@NoteID = -1)
	BEGIN
		INSERT INTO dbo.tblPatientNotes (PatientVisitID, NoteType, ActiveDate, Source, Notes,TransactionIdentifier, CancelDate, UpdateDate, UpdateID)
			VALUES (@PatientVisitID, @NoteType, @ActiveDate, @Source, @Notes,@TransactionIdentifier, @CancelDate, @Today, @LoginUserID)
	
		SET @Msg = 'Inserted new Patient Diet Note'
		EXEC dbo.PatientLOGAdd 7000, @LoginUserID, @PatientID, @PatientVisitID, @RoomID, @Msg
	END
	ELSE
	BEGIN
		UPDATE dbo.tblPatientNotes
			SET NoteType = COALESCE(@NoteType, NoteType),
			ActiveDate = COALESCE(@ActiveDate, ActiveDate),
			Source = COALESCE(@Source, Source),
			Notes = COALESCE(@Notes, Notes),
			CancelDate = @CancelDate,
			TransactionIdentifier = COALESCE(@TransactionIdentifier,TransactionIdentifier),
			UpdateDate = @Today,
			UpdateID = @LoginUserID
		WHERE NoteID = @NoteID

		SET @Msg = 'Updated Patient Diet Notes'
		EXEC dbo.PatientLOGAdd 7000, @LoginUserID, @PatientID, @PatientVisitID, @RoomID, @Msg
	END

	RETURN
go

