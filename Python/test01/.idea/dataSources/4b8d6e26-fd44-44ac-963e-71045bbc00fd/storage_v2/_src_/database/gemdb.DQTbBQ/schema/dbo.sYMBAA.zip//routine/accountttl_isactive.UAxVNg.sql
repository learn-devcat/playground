
		CREATE  FUNCTION dbo.AccountTTL_IsActive(@AccountNo varchar(50), @TransClassID int)
		RETURNS bit
		AS
		BEGIN
			/* Checks to see if a particular AccountTTL is active.
			   This can be used to check multiple conditions.
			   the first check is to see if CreditCard Settlement buckets have a credit card. 
			*/

			DECLARE @Return bit 
	
			--default this to active. 
			Set @Return = 1


			IF NOT Exists(Select 1 
				FROM tblAccountTTL AS TT
				JOIN tblTransClass as TC ON TT.TransClassID = TC.TransClassID
				WHERE TC.TransClassID = @TransClassID
				AND TT.AccountNo = @AccountNo
				AND (TC.CCSettlementType = 0 or TT.HasValidCreditCard = 1)
				)
				BEGIN
				 --This is a Credit Card Settlement Bucket without a valid credit card on account. Indicate it as inactive. 		
					SET @Return = 0
				END

			RETURN @Return
		END

    go

