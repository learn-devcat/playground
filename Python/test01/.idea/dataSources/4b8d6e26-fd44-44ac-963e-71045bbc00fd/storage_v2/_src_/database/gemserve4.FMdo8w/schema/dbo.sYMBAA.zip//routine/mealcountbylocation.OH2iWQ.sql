CREATE FUNCTION [dbo].[MealCountByLocation](@BeginDate datetime, @EndDate datetime, @LocationID as int, @IsSnackTotal as bit, @OrderType int)
RETURNS int
BEGIN
	DECLARE @Return int

	IF (@IsSnackTotal = 0)
	BEGIN
		-- Meals
		SELECT @Return = COUNT([Date])
		FROM dbo.tblOrderLOG AS L WITH (NOLOCK)
		JOIN dbo.tblOrderOHD AS O WITH (NOLOCK) ON L.OrderID = O.OrderID
		JOIN dbo.tblWave AS W WITH (NOLOCK) ON O.WaveID = W.WaveID
		WHERE L.[Date] BETWEEN @BeginDate AND @EndDate
			AND COALESCE(L.RoomID, -1) IN (SELECT RoomID FROM dbo.tblRoomOHD WHERE LocationClassID = @LocationID)
			AND dbo.GetActionID('RECEIVED') = L.ActionID
			AND W.MealPeriodID NOT IN (SELECT KeyOut FROM dbo.tblXlat WHERE xlatID = 'SnackMealPeriod')
			AND COALESCE(O.OrderType,1) = @OrderType
	
		SELECT @Return = @Return + COUNT(L.[Date])
		FROM dbo.tblArchive_OrderLOG AS L
		JOIN dbo.tblArchive_PatientOHD AS P ON P.PatientArchiveID = L.PatientArchiveID
		JOIN dbo.tblOrderOHD AS O WITH (NOLOCK) ON L.OrderID = O.OrderID
		JOIN dbo.tblWave AS W WITH (NOLOCK) ON O.WaveID = W.WaveID
		WHERE L.[Date] BETWEEN @BeginDate AND @EndDate
			AND COALESCE(P.RoomID, -1)  IN (SELECT RoomID FROM dbo.tblRoomOHD WHERE LocationClassID = @LocationID)
			AND dbo.GetActionID('RECEIVED') = L.ActionID
			AND W.MealPeriodID NOT IN (SELECT KeyOut FROM dbo.tblXlat WHERE xlatID = 'SnackMealPeriod')
			AND COALESCE(O.OrderType,1) = @OrderType
	END
	ELSE
	BEGIN
		-- Patient Snacks
		SELECT @Return = COUNT([Date])
		FROM dbo.tblOrderLOG AS L WITH (NOLOCK)
		JOIN dbo.tblOrderOHD AS O WITH (NOLOCK) ON L.OrderID = O.OrderID
		JOIN dbo.tblWave AS W WITH (NOLOCK) ON O.WaveID = W.WaveID
		WHERE L.[Date] BETWEEN @BeginDate AND @EndDate
			AND COALESCE(L.RoomID, -1) IN (SELECT RoomID FROM dbo.tblRoomOHD WHERE LocationClassID = @LocationID)
			AND dbo.GetActionID('RECEIVED') = L.ActionID
			AND W.MealPeriodID IN (SELECT KeyOut FROM dbo.tblXlat WHERE xlatID = 'SnackMealPeriod')
			AND COALESCE(O.OrderType,1) = 1
	
		SELECT @Return = @Return + COUNT(L.[Date])
		FROM dbo.tblArchive_OrderLOG AS L
		JOIN dbo.tblArchive_PatientOHD AS P ON P.PatientArchiveID = L.PatientArchiveID
		JOIN dbo.tblOrderOHD AS O WITH (NOLOCK) ON L.OrderID = O.OrderID
		JOIN dbo.tblWave AS W WITH (NOLOCK) ON O.WaveID = W.WaveID
		WHERE L.[Date] BETWEEN @BeginDate AND @EndDate
			AND COALESCE(P.RoomID, -1)  IN (SELECT RoomID FROM dbo.tblRoomOHD WHERE LocationClassID = @LocationID)
			AND dbo.GetActionID('RECEIVED') = L.ActionID
			AND W.MealPeriodID IN (SELECT KeyOut FROM dbo.tblXlat WHERE xlatID = 'SnackMealPeriod')
			AND COALESCE(O.OrderType,1) = 1
	END

	RETURN COALESCE(@Return, 0)
END
go

