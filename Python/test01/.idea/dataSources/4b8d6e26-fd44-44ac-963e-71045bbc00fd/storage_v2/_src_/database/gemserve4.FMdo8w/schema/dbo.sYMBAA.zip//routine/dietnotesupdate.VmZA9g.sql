

CREATE PROCEDURE dbo.DietNotesUpdate
@LoginUserID		varchar(250),
@DietID		int,
@Notes		text

AS
	SET NOCOUNT ON

	UPDATE	dbo.tblDietOHD
	SET	Notes = @Notes
	WHERE	DietID = @DietID

	RETURN
go

