CREATE PROCEDURE [dbo].[sim140_GetAccountMealPlan]
@CoreID		int,
@User		   varchar(10),
@AccountNo	char(19),
@Slot		   int,
@OutletNo	int
AS 
   DECLARE	@CurrentTime 	   varchar(10),
            @CurrentDate	   datetime,
            @Now              datetime,
            @IsActive		   char(1),
            @MealPlanID		   int,
            @MealPlan		   varchar(32),
            @MealPeriod		   varchar(32),
            @TransLimit		   money,
            @Equiv			   money,
            @PassesAllowed	   int,
            @CurrentPasses 	int,
            @CurrentPeriodBal	money,
            @CurrentCount	   int,
            @CurrentBalance	money,
            @OutletSubType    int,    		-- To see WHERE we're allowed to use this.
            @TotalRows		   int,
            @ExpireDate		   datetime,
            @LastOutlet		   int,
            @OutletName		   varchar(60),
            @ReturnString	   varchar(2000),
            @BegTime          varchar(10),
            @EndTime          varchar(10),
            @PlanStartDate    datetime,         -- when the MEAL PLAN begins and ends.
            @PlanEndDate      datetime
   
   SET @Now          = getdate()
   SET @CurrentDate  = dbo.dDateOnly(getdate())
   SET @CurrentTime  = dbo.TimeOnly(getdate())
   SET @ReturnString = ''

   -- Get the subtype to mask against the meal plans -- this allows us
   -- to restrict certain meal plans to certain outlets... we are going
   -- to AND() the two VALUES, a non-zero results
                                     
   SELECT 	@OutletSubType = SubType 
   FROM	   tblOutletOHD
   WHERE	   OutletNo = @OutletNo    
   
   IF( @@Rowcount = 0 )
      begin
         select '/Outlet ' + cast( @OutletNo as varchar(10)) + ' Not Found' as ReturnMessage
         return
      end

   DECLARE MealPlans cursor FOR
      SELECT	A.MealPlanID,
               CASE 
                  WHEN (PD.Description IS NULL OR TTL.CurrentCount IS NULL) THEN '0'
                  ELSE '1'	
               END AS IsActive,
               ISNULL(TTL.CurrentCount,0),
               ISNULL(TTL.CurrentBalance,0),
               ISNULL(P.Name,'') AS MealPlan,
               ISNULL(PD.Description,'') AS MealPeriod,
               ISNULL(PD.TransLimit,0),   
               ISNULL(PD.Equiv,0),
               CASE PD.CountAllPasses
                  WHEN 1 THEN dbo.fnMin(ISNULL(PD.PassesAllowed,0) , ISNULL(TTL.CurrentCount,0))
                  ELSE dbo.fnMin( 9 , ISNULL(TTL.CurrentCount,0))
               END AS PassesAllowed,
               dbo.CurrentPasses(A.AccountNo,A.MealPlanID,dbo.dDatePlusNewTime(@CurrentDate,PD.BegTime),dbo.dDatePlusNewTime(@CurrentDate,PD.EndTime)),
               dbo.CurrentPeriodBalance(A.AccountNo,A.MealPlanID,dbo.dDatePlusNewTime(@CurrentDate,PD.BegTime),dbo.dDatePlusNewTime(@CurrentDate,PD.EndTime)),
               ISNULL(TTL.ExpireDate,getdate()),
               dbo.GetLastMPOutlet(A.AccountNo,A.MealPlanID,dbo.dDatePlusNewTime(@CurrentDate,PD.BegTime),dbo.dDatePlusNewTime(@CurrentDate,PD.EndTime)),
               ISNULL(PD.BegTime , getdate()) as BegTime,
               ISNULL(PD.EndTime , getdate()) as EndTime
      FROM		tblAccountMeal AS A
      LEFT JOIN tblAccountMealTTL AS TTL	ON	A.AccountNo  = TTL.AccountNo 
                                         AND A.MealPlanID = TTL.MealPlanID 
                                         AND @CurrentDate BETWEEN dbo.DateOnly(TTL.ActiveDate) AND dbo.DateOnly(TTL.ExpireDate)
      LEFT JOIN tblPlanOHD        AS P  ON A.MealPlanID   = P.MealPlanID
      LEFT JOIN tblPlanDTL        AS PD ON A.MealPlanID   = PD.MealPlanID 
                                       AND (@CurrentTime BETWEEN PD.BegTime AND PD.EndTime)
      WHERE	    A.AccountNo = @AccountNo
            AND A.Slot      = @Slot
            AND A.Active    = 1
            AND (@CurrentTime BETWEEN PD.BegTime AND PD.EndTime)  
            AND ( P.SubType & @OutletSubType ) <> 0
      ORDER BY IsActive DESC
   
/* split Results[1] , "," , 
MealPlanID , 
IsActive  , 
AccountCurrentQty , 
AccountCurrentBalance , 
MealPlanName , 
MealPlanPname , 
TransLimit , 
Equivlancy , 
PassesAllowed , 
CurrentPasses, 
PeriodBalance, 
ExpireDate,
LastOutletNumber,
LastOutletName,
PeriodBeginTime,
PeriodEndTime

*/


   SET @TotalRows = 0            -- we add one for each row we loop...

   OPEN MealPlans
   FETCH NEXT FROM MealPlans INTO
      @MealPlanID,@IsActive,@CurrentCount,@CurrentBalance,@MealPlan,@MealPeriod,@TransLimit,
      @Equiv,@PassesAllowed, @CurrentPasses, @CurrentPeriodBal, @ExpireDate, @LastOutlet, @BegTime, @EndTime
   WHILE (@@FETCH_STATUS = 0)
     BEGIN
         SET @TotalRows = @TotalRows + 1
         -- Get outlet name
         IF ( @LastOutlet > 0 )
            SELECT @OutletName = dbo.GetOutletName(@LastOutlet)
         ELSE
            SET @OutletName = ' '
         -- Build up the RETURN string
         SET @ReturnString = @ReturnString + CHAR(28) + 
            CAST(@MealPlanID AS varchar(8)) + ',' +
            @IsActive + ',' + 
            CAST(@CurrentCount AS varchar(8)) + ',' +
   			CAST(@CurrentBalance AS varchar(16)) + ',' +
            @MealPlan   + ',' +
            @MealPeriod + ',' +
            CAST(@TransLimit AS varchar(16)) + ',' + 
            CAST(@Equiv AS varchar(16)) + ',' +
            CAST(@PassesAllowed AS varchar(8)) + ',' + 
            CAST(@CurrentPasses as varchar(8)) + ',' +
            CAST(@CurrentPeriodBal as varchar(10)) + ',' +
            CAST(dbo.DateFormat(@ExpireDate,'da-sm-yy') as varchar(25)) + ',' +
            CAST(@LastOutlet as varchar(10)) + ',' +
            @OutletName + ',' +
            @BegTime    + ',' + 
            @EndTime
      FETCH NEXT FROM MealPlans INTO
         @MealPlanID,@IsActive,@CurrentCount,@CurrentBalance,@MealPlan,@MealPeriod,@TransLimit,
         @Equiv,@PassesAllowed, @CurrentPasses, @CurrentPeriodBal, @ExpireDate, @LastOutlet, @BegTime, @EndTime
   END
   CLOSE MealPlans
   DEALLOCATE MealPlans

   -- Did we actually get any rows here, if not, send the error.
   IF (@TotalRows > 0)
      SET @ReturnString = 'Success' + CHAR(28) + CAST(@TotalRows AS varchar(8)) +  @ReturnString
   ELSE
      SET @ReturnString = '/No Valid Plans Found' + CHAR(28) + '0' + CHAR(28)
   
   SELECT @ReturnString
go

