


----------------------------------------------------------------------------------
--
--  OrderDTLGetAll                  13-Aug-03 w.j.scott
--
--  Get ALL the detail for a specific OrderID -- The overhead is NOT checked
--  and we do a simple select against the DTL table (tblOrderDTL) for anything
--  that matches OrderID.  
--
--      NOTE: The OrderID is 'system generated' when the order is inserted into
--            the table.
--
-----------------------------------------------------------------------------------

CREATE PROCEDURE dbo.OrderDTLGetAll
@OrderID as int
as
	SET NOCOUNT ON
	
	SELECT OrderID, DetailID, Description, OrderDetail
    FROM dbo.tblOrderDTL 
    WHERE OrderID  = @OrderID 
	
	RETURN
go

