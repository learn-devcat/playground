

CREATE PROCEDURE dbo.sp_Connection_GetData
@InterfaceID int
AS
	SELECT	ConnectionID, InterfaceID, Active, Description, Category, ComPort, Baud,
			DataBits, StopBits, Parity, ComInit, InterfaceType, ModemActive, PhoneNumber,
			ConnectionType, MyPort, RemoteIP, RemotePort, xlat,SysOptions,
			InquireProc,AuthorizationProc, PostingProc,
      			ModemSetup, WaitCarrier, ModemDialPrefix, ModemDownTime, ModemUpTime, LicenseKey
	FROM		cfgConnection
	WHERE	InterfaceID = @InterfaceID
go

