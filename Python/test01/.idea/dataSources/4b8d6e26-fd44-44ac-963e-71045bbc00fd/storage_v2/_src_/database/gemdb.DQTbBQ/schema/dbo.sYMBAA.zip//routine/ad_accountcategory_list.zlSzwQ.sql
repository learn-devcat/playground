

CREATE PROCEDURE dbo.ad_AccountCategory_List
@User			char(10)
AS 
	SELECT	Category,
			Description
	FROM	tblAccountCategory
	ORDER BY Category
go

