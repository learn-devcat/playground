

CREATE PROCEDURE dbo.sp_Company_Get
@User	char(10) 
AS 
 	SELECT	Description AS Company
 	FROM	cfgCore
 	WHERE	CoreID = dbo.GetCoreIDfromUser(@User)
go

