CREATE PROCEDURE [dbo].[PatientNutrientOverrideDelete]
@LoginUserID	varchar(250),
@PatientID		int,
@PatientDietID	int,
@NutrientID		int

AS
	SET NOCOUNT ON
	
	DECLARE	@MealPeriodID	int,
		@NutrientName	varchar(50),
		@Msg		varchar(200),
		@RoomID		int,
		@OldValue	int,
		@PatientWNutrientID int,
		@MealPeriodName	varchar(25)


	SELECT 	@NutrientName = [Description]
	FROM	dbo.cfgNutrients
	WHERE	NutrientID = @NutrientID

	IF EXISTS(SELECT PatientID
		FROM dbo.tblPatientDailyNutrientOverride
		WHERE PatientDietID = @PatientDietID)
	BEGIN
		SELECT @OldValue = Qty
		FROM dbo.tblPatientDailyNutrientOverride
		WHERE PatientDietID = @PatientDietID
			AND NutrientID = @NutrientID

		DELETE dbo.tblPatientDailyNutrientOverride
		WHERE PatientDietID = @PatientDietID
			AND NutrientID = @NutrientID

		-- Add a log entry
		SET @Msg = 'Daily nutrient override deleted: [' + @NutrientName + ' = ' + CAST(@OldValue AS varchar(10)) + ']'
		EXEC dbo.PatientLOGAdd 1000, @LoginUserID, @PatientID, '', @RoomID, @Msg
	END

	IF EXISTS(SELECT TOP 1 PatientID
		FROM dbo.tblPatientMealPeriodNutrientOverride
		WHERE PatientDietID = @PatientDietID)
	BEGIN
		DECLARE MealPeriod cursor FOR
			SELECT MealPeriodID, Qty
			FROM dbo.tblPatientMealPeriodNutrientOverride
			WHERE PatientDietID = @PatientDietID
				AND NutrientID = @NutrientID

		OPEN MealPeriod
		FETCH NEXT FROM MealPeriod INTO @MealPeriodID, @OldValue

		WHILE (@@FETCH_STATUS = 0)
		BEGIN 
			SELECT	@MealPeriodName = [Description]
			FROM 	dbo.tblMealPeriods
			WHERE 	MealPeriodID = @MealPeriodID

			SET @Msg = 'Nutrient override deleted for ' + @MealPeriodName + 
				': [' + @NutrientName + ' = ' + 
				CAST(@OldValue AS varchar(10)) + ']'
			EXEC dbo.PatientLOGAdd 1000, @LoginUserID, @PatientID, '', @RoomID, @Msg

			FETCH NEXT FROM MealPeriod INTO @MealPeriodID, @OldValue
		END

		CLOSE MealPeriod
		DEALLOCATE MealPeriod

		DELETE dbo.tblPatientMealPeriodNutrientOverride
		WHERE PatientDietID = @PatientDietID
			AND NutrientID = @NutrientID
	END

	RETURN
go

