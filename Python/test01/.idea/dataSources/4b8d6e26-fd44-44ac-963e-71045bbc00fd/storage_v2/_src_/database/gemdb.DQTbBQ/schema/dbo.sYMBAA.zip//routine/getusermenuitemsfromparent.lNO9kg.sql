CREATE FUNCTION GetUserMenuItemsFromParent
(	
	@UserID char(10),
	@ParentMenuID int
)
RETURNS @tempTable TABLE (MenuID int NULL,
							SubMenuID int NULL,
							Description varchar(50) NULL,
							URL varchar(250) NULL) 
AS
BEGIN
	INSERT @tempTable
	SELECT DISTINCT 
			M.MenuID, 
			M.SubMenuID,
			M.Description,  
			M.URL
	FROM	tblPrivilegeClassMembers AS P
			JOIN tblPrivilegeLinks AS PL ON P.PrivilegeClassID = PL.PrivilegeClassID
			JOIN tblPrivilegeActions AS A ON PL.ActionID = A.ActionID
			JOIN cfgMenus AS M ON PL.ActionID = M.ActionID			
	WHERE	P.UserID = @UserID AND M.SubMenuID = @ParentMenuID
	ORDER BY MenuID		

	RETURN
END
go

