CREATE PROCEDURE dbo.HL7ProcessingGetMessageTypes

AS
	SET NOCOUNT ON

	SELECT DISTINCT MessageType
	FROM dbo.tblHL7Processing
	ORDER BY MessageType


	RETURN
go

