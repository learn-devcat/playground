
CREATE FUNCTION dbo.PatientClassLookup(@PatientClass varchar(100))
RETURNS int
AS
BEGIN
	DECLARE @Return int

	IF (@PatientClass <> '')
		SELECT @Return = PatientClassID FROM dbo.tblPatientClass WHERE xref = @PatientClass

	IF (@Return IS NULL)
		SELECT @Return = CAST(KeyOut AS int) FROM dbo.tblXlat 
		WHERE KeyIn = @PatientClass AND xlatid = 'PatientClass'

	IF (@Return IS NULL)
		SELECT @Return = CAST(dbo.GetOverheadValue('DefaultPatientClass') AS int)	

	RETURN ISNULL(@Return,0)
END
go

