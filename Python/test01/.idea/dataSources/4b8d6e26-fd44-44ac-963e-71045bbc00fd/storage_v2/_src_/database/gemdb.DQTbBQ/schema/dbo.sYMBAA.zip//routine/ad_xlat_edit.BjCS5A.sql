


Create  PROCEDURE dbo.ad_Xlat_Edit
@User			char(10),
@ExistingIDString	varchar(112),
@XlatID			char(10),
@InChar			varchar(50),
@OutChar		varchar(50),
@DELETE			bit = 0
AS 
	DECLARE @Message varchar(255)

	IF @DELETE = 1
		GOTO DODELETE

	/* NOTE: @ExistingIDString is expected to be a concatenation of
	RTRIM(@XlatID) + ' ' + RTRIM(@InChar) + ' ' + RTRIM(@OutChar)
	*/

	IF NOT EXISTS(SELECT * FROM dbo.tblXLAT
		      WHERE  	( RTRIM(XlatID) + ' ' 
				+ RTRIM(InChar) + ' ' 
				+ RTRIM(OutChar)
				 ) = @ExistingIDString)
	BEGIN
		INSERT dbo.tblXLAT 
		VALUES(@XlatID, @InChar, @OutChar)

		SET  @Message = 'New System Xlat Item Added: ' + @XlatID 
				   + ': IN(' + @InChar + ') OUT(' + @OutChar + ')'
	END
	ELSE
	BEGIN

		UPDATE	dbo.tblXLAT
		SET	XlatID = @XlatID,
			InChar = @InChar,
			OutChar = @OutChar
	      	WHERE  	( RTRIM(XlatID) + ' ' 
			+ RTRIM(InChar) + ' ' 
			+ RTRIM(OutChar)
			 ) = @ExistingIDString

		SET  @Message = 'System Xlat Item Changed to: ' + @XlatID 
				   + ': IN(' + @InChar + ') OUT(' + @OutChar + ')'
	END

	EXEC dbo.sp_Logit 9, 1, @User, @Message, 1010	
	SELECT @Message AS 'Rtn'

	RETURN

	DODELETE:
	DELETE	dbo.tblXlat
      	WHERE  	( RTRIM(XlatID) + ' ' 
		+ RTRIM(InChar) + ' ' 
		+ RTRIM(OutChar)
		 ) = @ExistingIDString

	SET  @Message = 'System Xlat Item Deleted: ' + @XlatID 
			   + ': IN(' + @InChar + ') OUT(' + @OutChar + ')'

	EXEC dbo.sp_Logit 9, 1, @User, @Message, 1010	
	SELECT @Message AS 'Rtn'
go

