

CREATE PROCEDURE dbo.gem_UserAllowedLocations
@UserID		varchar(10)
AS
	SELECT L.LocationID, L.Description
	FROM	cfgLocations AS L
		JOIN cfgUserLocations AS U ON L.LocationID = U.LocationID
	WHERE	U.UserID = @UserID
go

