CREATE   PROCEDURE dbo.WorkorderDTL_Insert_Quick
@User                   char(10),
@WorkorderID            int, 
@WorkOrderDTLDefID      int = 0,
@Notes			varchar(250)
AS 
SET NOCOUNT ON
DECLARE @WorkOrderDTLID  int,
	@Ident		 int,
	@ErrorNum	 int,
	@Price		 money
	
	SET @WorkOrderDTLID = ISNULL((SELECT  TOP 1 WorkOrderDTLID
			          FROM    tblWorkOrderDTL
			          WHERE   WorkOrderID = @WorkorderID
			          order by WorkOrderDTLID desc),0)
	
	SET @WorkOrderDTLID = @WorkOrderDTLID + 1       -- The next one in line...
	SELECT 	@Price	= Price
	FROM	tblWorkorderDTLDef
	WHERE 	WorkOrderDTLDefID = @WorkOrderDTLDefID
	INSERT INTO tblWorkorderDTL
               (WorkorderID,  WorkOrderDTLID,  WorkOrderDTLDefID, AssigningEmployeeID, AssignmentDate, Notes, Price)
    	VALUES (@WorkorderID, @WorkOrderDTLID, @WorkOrderDTLDefID,0		     , getdate()     , @Notes, @Price)
	
    IF @@Error <> 0 
      BEGIN
	SET @ErrorNum = @@Error
	SELECT @ErrorNum
        RETURN
      END
   SET @Ident = Scope_Identity()
   SELECT @Ident
    RETURN
go

