CREATE PROCEDURE [dbo].[sim_RetrieveOrderCounts]
@CoreID as int,
@LoginUserID	varchar(250),
@PatientVisitID varchar(50),
@OrderID int,
@WaveDate  varchar(30)
AS
	SET NOCOUNT ON
			
	DECLARE @ReturnString varchar(500),
		@PatientID int,
		@MealPeriodID int,
		@OrderType int,
		@Today datetime,
		@Msg varchar(100)
		
	SET @Today = getdate()

	SELECT @PatientID = PV.PatientID
	FROM	dbo.tblPatientVisit AS PV (NOLOCK) 
	WHERE	PV.PatientVisitID = @PatientVisitID

	SELECT @MealPeriodID = W.MealPeriodID,
		   @OrderType = O.OrderType
	FROM dbo.tblOrderOHD AS O (NOLOCK)
		JOIN dbo.tblWave AS W (NOLOCK) ON O.WaveID = W.WaveID
	WHERE O.OrderID = @OrderID
		
	BEGIN TRANSACTION

	SET @ReturnString = @PatientVisitID

	IF (@OrderType = 1)
	BEGIN
		IF NOT EXISTS (SELECT OrderID FROM dbo.tblPatientNutrientCount (NOLOCK) WHERE OrderID = @OrderID) 
			GOTO Failed
	END
	
	-- Add theOrder Counts
	SET @ReturnString = @ReturnString + CHAR(28) + dbo.PatientOrderNutrientCount(@OrderID,  ',')  

--		DELETE tblOrderLog WHERE OrderID = @OrderID
--		IF (@@ERROR <> 0)
--			GOTO Failed

--		DELETE tblOrderDTL WHERE OrderID = @OrderID
--		IF (@@ERROR <> 0)
--			GOTO Failed

	-- Cancel the order
	SET @Msg = 'Order canceled due to order pick up. Order ID: ' + CAST(@OrderID AS varchar(30))
	EXEC dbo.OrderSETCancelled @LoginUserID, @OrderID, 1, @Today, @Msg, 800
	
	IF (@@ERROR <> 0)
		GOTO Failed

	-- Add the Patient Current Nutrient Count
	SET @ReturnString = @ReturnString + CHAR(28) + dbo.PatientDailyNutrientCount(@PatientID,@WaveDate,  ',')  	

	-- Add same meal period order counts
	SET @ReturnString = @ReturnString + CHAR(28) + dbo.PatientMealPeriodNutrientCount(@PatientID, @WaveDate, @MealPeriodID, ',')				

	--Add succeeded, so commit and return
	COMMIT TRANSACTION
	SELECT @ReturnString
	RETURN
	
Failed:
		
	--Add failed, so return failure message		
	ROLLBACK TRANSACTION

	-- Log failure
	EXEC Logit 1, 'Order retrieval failed', 'system'

	SELECT '/Order Retrieval Failed'
go

