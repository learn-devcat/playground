CREATE PROCEDURE dbo.HL7ProcessingTaskGet
@CommandID	int,
@MessageType	varchar(32)=''
AS
	SET NOCOUNT ON

	IF (@CommandID > 0)
		SELECT CommandID,
			MessageType,	
			[Name],
			[Description],
			ControlType,
			CommandType,
			Command,
			ReturnColumn,
			[Sequence]
		FROM dbo.tblHL7Processing
		WHERE CommandID = @CommandID
	ELSE
		SELECT CommandID,
			MessageType,	
			[Name],
			[Description],
			ControlType,
			CommandType,
			Command,
			ReturnColumn,
			[Sequence]
		FROM dbo.tblHL7Processing
		WHERE MessageType = @MessageType
		ORDER BY [Sequence]

	RETURN
go

