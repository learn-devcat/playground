

CREATE PROCEDURE dbo.DietAddForImport
@LoginUserID		varchar(250),
@DietID		int,
@Description	varchar(50),
@POSDietID	int,
@POSDescription	varchar(50)

AS
	SET NOCOUNT ON

	INSERT INTO dbo.tblDietOHD (DietID, Description, AltDescription, POSDietID, POSDescription, Active)
		VALUES (@DietID, @Description, @Description, @POSDietID, @POSDescription, 1)

	RETURN
go

