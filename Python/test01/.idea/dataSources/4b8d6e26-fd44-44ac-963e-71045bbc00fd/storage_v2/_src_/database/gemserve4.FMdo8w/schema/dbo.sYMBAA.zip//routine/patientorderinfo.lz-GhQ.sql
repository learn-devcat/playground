CREATE PROCEDURE [dbo].[PatientOrderInfo]
@RoomID		int,
@MealPeriodID  	int=0,
@DateOffset 	int=0

AS
	-- get the previous wave that this patient was allowed to have
	-- make sure the patient was admitted prior to that wave's time
	-- check to see if the patient ordered a meal during that wave
	-- if so, get the final status for that order and return it
	-- if not, return 000 for no meal ordered OR 100 for NPO

	SET NOCOUNT ON

	DECLARE	@SentOrderBuffer	int,
	@OrderDate				datetime,
	@BeginTime				datetime,
	@EndTime				datetime,
    @PreviousDay			datetime,
	@Today					datetime,
	@ShowNotes				int,
	@TempMealPeriodID		int,
	@ORMSeparator			varchar(10),
	@MealPeriodStartTime    datetime,
	@MealPeriodEndTime      datetime

	SET @Today = DATEADD(d,@DateOffset,getdate())           
	SET @ORMSeparator = COALESCE(dbo.GetOverheadValueNull('ORMSeparator'),'|')

	DECLARE @MyWaves TABLE (WaveID int,
				BeginTime char(5))

	DECLARE @Temp TABLE (
				PatientID		int,
				PatientVisitID		varchar(50),
				AdmitDate           datetime,
				RoomNumber 			varchar(10),
				Bed					varchar(15),
				MedicalRecordID		varchar(30),
				LastName			varchar(30),
				FirstName			varchar(60),
				CurrentDiet			varchar(50),
				CurrentMealPeriod	varchar(30),
				CurrentStatus 		varchar(50),
				PreviousMealPeriod	varchar(30),
				PreviousStatus		varchar(50),
				PreviousMealDate	datetime,
				ActionID			int,
				SentDate			datetime,
				CurrentOrderID		int,
				CurrentOrderDate	datetime,
				DeliveryTime		datetime,
				DeliveredBy			varchar(20),
				DisableAllergies	int,
				PatientNotes		varchar(4000),
				DateOfBirth			datetime,
				Age					int,
				ShowNotes			int)

	SET @SentOrderBuffer = dbo.GetOverheadValue('SentOrderBuffer')
	SET @ShowNotes = COALESCE(dbo.GetOverheadValueNull('ShowNotesOnDashboard'),0)

	IF ( @SentOrderBuffer IS NULL )
		SET @SentOrderBuffer = 30
	
	-- Get the current wave if none was sent in
	IF (@MealPeriodID = 0)
            SELECT @MealPeriodID = dbo.GetCurrentMealPeriodID(@Today)

        SET @BeginTime = dbo.MealPeriodStartTime(@Today, @MealPeriodID)

	INSERT INTO @MyWaves 
		SELECT WaveID, BeginTime FROM dbo.tblWave (NOLOCK) WHERE MealPeriodID = @MealPeriodID

	-- Get the information for the current wave/order status
	INSERT INTO @Temp (PatientID, PatientVisitID, AdmitDate, CurrentMealPeriod, CurrentStatus,RoomNumber, Bed, MedicalRecordID, LastName, FirstName, 
		CurrentDiet, ActionID, SentDate, CurrentOrderID, CurrentOrderDate, DeliveryTime, DeliveredBy, PatientNotes, DateOfBirth, Age, ShowNotes)
	SELECT	P.PatientID,
			PV.PatientVisitID,
            PV.EntryDate,
		dbo.GetMealPeriodShortName(@MealPeriodID),
		CASE
		    WHEN D.NPO = 1 THEN 'N/A'
		    WHEN PV.ROOMID IS NULL THEN 'Room Not Found'
		    WHEN O.Cancelled = 1 THEN dbo.GetActionDescription(105)
		    WHEN L.ActionID IS NULL THEN 
			CASE dbo.GetActionDescription(CAST(dbo.NoOrderStatus('-100',@Today, @DateOffset, O.WaveID, PV.DietID) AS int))
				WHEN 'Not Found' THEN 
                                        CASE
                                                WHEN PV.EntryDate > @BeginTime THEN 'New Admit'
                                                ELSE 'No Order' 
                                        END
				ELSE dbo.GetActionDescription(CAST(dbo.NoOrderStatus('-100',@Today, @DateOffset, O.WaveID, PV.DietID) AS int))
			END
		    WHEN (L.ACTIONID = 210 AND DATEDIFF(s,O.PostDate,@Today) < @SentOrderBuffer AND O.Received = 0) THEN dbo.GetActionDescription(205)
		    ELSE dbo.GetActionDescription(L.ACTIONID)
	    END AS CurrentStatus,
	    R.RoomNumber,
	    PV.Bed,
	    P.MedicalRecordID,
	    P.LastName,
	    P.FirstName + CASE WHEN P.MiddleInitial <> '' THEN ' ' + P.MiddleInitial 
			ELSE '' END AS FirstName,
	    D.Description,
	    CASE 
			WHEN NOT (L.ActionID IS NULL) THEN L.ActionID
			WHEN dbo.GetActionDescription(CAST(dbo.NoOrderStatus('-100',@Today, @DateOffset, O.WaveID, PV.DietID) AS int)) = 'WARNING' THEN 4000
			WHEN dbo.GetActionDescription(CAST(dbo.NoOrderStatus('-100',@Today, @DateOffset, O.WaveID, PV.DietID) AS int)) = 'CRITICAL' THEN 5000
			ELSE 0
	    END,
	    O.SentDate,
	    O.OrderID,
	    O.OrderDate,
	    OL.[Date] AS DeliveryTime,
	    OL.LoginUserID,
	    CAST(COALESCE(P.Notes,'') AS varchar(3500)) + @ORMSeparator + dbo.GetActiveDietNotesEX(PV.PatientVisitID, @Today, 0),
	    dbo.DateStringMMDDYYYY(P.BirthDate) AS BirthDate,
	    dbo.PatientAge(dbo.DateStringMMDDYYYY(P.BirthDate), @Today) AS Age,
	    @ShowNotes
    FROM dbo.tblPatientOHD AS P (NOLOCK)
		JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON P.PatientID = PV.PatientID AND PV.MergedTo IS NULL
		LEFT JOIN dbo.tblRoomOHD AS R (NOLOCK) ON R.RoomID = PV.RoomID
		LEFT JOIN dbo.tblDietOHD AS D (NOLOCK) ON PV.DietID = D.DietID
		LEFT JOIN dbo.tblOrderOHD AS O (NOLOCK) ON (O.PatientVisitID = PV.PatientVisitID OR O.PatientVisitID = PV.MergedTo) 
				AND O.WaveID IN (SELECT WaveID FROM @MyWaves)
    				AND dbo.dDateOnly(O.OrderDate) = dbo.dDateOnly(@Today)
				AND ISNULL(O.Cancelled,0) <> 1
		LEFT JOIN dbo.tblMealPeriods AS M (NOLOCK) ON M.MealPeriodID = @MealPeriodID
		--LEFT JOIN dbo.tblWave AS W (NOLOCK) ON W.WaveID = O.WaveID

		LEFT JOIN (SELECT ORDERID, MAX(ACTIONID) AS ACTIONID 
				FROM dbo.tblOrderLOG (NOLOCK)
				GROUP BY ORDERID) AS L ON O.OrderID = L.OrderID
                    AND dbo.dDateOnly(O.OrderDate) = dbo.dDateOnly(@Today)

	      LEFT JOIN dbo.tblOrderLog AS OL (NOLOCK) ON O.OrderID = OL.OrderID AND OL.ActionID = L.ActionID

	WHERE PV.RoomID = @RoomID
		AND PV.DischargeDate IS NULL

	-- Previous meal period
	SELECT @OrderDate = CurrentOrderDate FROM @Temp
	SET @TempMealPeriodID = @MealPeriodID
	SET @MealPeriodID = NULL
	SELECT @MealPeriodID = dbo.GetPreviousMealPeriodID(@TempMealPeriodID, @Today)

	IF (@MealPeriodID = -1)
	BEGIN
	        SET @MealPeriodID = dbo.GetLastMealPeriodID(@Today)
	        SET @PreviousDay = DATEADD(d,-1,@Today)
	END
	ELSE
	        SET @PreviousDay = @Today


	SET @BeginTime = dbo.MealPeriodStartTime(@PreviousDay, @MealPeriodID)
	SET @MealPeriodStartTime = dbo.MealPeriodStartTime(@PreviousDay, @MealPeriodID) 
    SET @MealPeriodEndTime = dbo.MealPeriodEndTime(@PreviousDay, @MealPeriodID)

        -- Clear the temporary wave table and add the waves that are valid for the previous meal period
        DELETE @MyWaves
	INSERT INTO @MyWaves 
		SELECT WaveID, BeginTime FROM dbo.tblWave (NOLOCK) WHERE MealPeriodID = @MealPeriodID

        UPDATE @Temp 
  		SET PreviousMealPeriod = dbo.GetMealPeriodShortName(@MealPeriodID),
  			PreviousStatus = CASE
  			    WHEN dbo.GetMealPeriod(O.OrderDate) = 0 THEN 
                                CASE
                                        WHEN PV.EntryDate > @BeginTime THEN 'New Admit'
                                        ELSE 'No Order' 
                                END
 			    WHEN D.NPO = 1 THEN 'N/A'
 			    WHEN PV.ROOMID IS NULL THEN 'Room Not Found'
 			    WHEN O.Cancelled = 1 THEN dbo.GetActionDescription(105)
 			    WHEN dbo.GetOrderStatus(O.OrderID) = 0 THEN 'No Order'
 			    WHEN (dbo.GetOrderStatus(O.OrderID) = 210 AND DATEDIFF(s,O.PostDate,@Today) < @SentOrderBuffer AND O.Received = 0) THEN dbo.GetActionDescription(205)
 			    ELSE dbo.GetActionDescription(dbo.GetOrderStatus(O.OrderID))
 			 END,
		PreviousMealDate =
			CASE WHEN dbo.dDateOnly(@OrderDate) = dbo.dDateOnly(O.OrderDate) THEN NULL
				ELSE O.OrderDate
			END
	FROM @Temp AS T 
		JOIN dbo.tblPatientOHD AS P (NOLOCK) ON T.PatientID = P.PatientID
                JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON P.PatientID = PV.PatientID AND PV.MergedTo IS NULL
		LEFT JOIN dbo.tblRoomOHD as R on R.RoomID = PV.RoomID
		LEFT JOIN dbo.tblDietOHD AS D ON PV.DietID = D.DietID
		LEFT JOIN dbo.tblOrderOHD as O ON O.OrderDate BETWEEN @MealPeriodStartTime AND @MealPeriodEndTime 
			AND O.PatientID = T.PatientID
	WHERE PV.PatientID = T.PatientID
		AND PV.RoomID = @RoomID

	UPDATE @Temp
		SET DisableAllergies = CASE WHEN AllergenID IS NULL THEN 1
			ELSE 0
			END
	FROM @Temp AS T
		LEFT JOIN dbo.tblPatientAllergens AS A (NOLOCK) ON T.PatientID = A.PatientID 

	SELECT 	PatientID,
		PatientVisitID,
        AdmitDate,
		RoomNumber,
		ISNULL(Bed,'') AS Bed,
		MedicalRecordID,
		LastName,
		FirstName,
		CurrentDiet,
		CurrentMealPeriod,
		CurrentStatus,
		PreviousMealPeriod,
		PreviousStatus,
		PreviousMealDate,
		ActionID,
		SentDate,
		CurrentOrderID,
		DeliveryTime,
		DeliveredBy,
		DisableAllergies,
		REPLACE(RTRIM(PatientNotes),',','|') AS PatientNotes,
		DateOfBirth,
		Age,
		ShowNotes
	FROM @Temp ORDER BY LastName, FirstName, ActionID DESC

	RETURN
go

