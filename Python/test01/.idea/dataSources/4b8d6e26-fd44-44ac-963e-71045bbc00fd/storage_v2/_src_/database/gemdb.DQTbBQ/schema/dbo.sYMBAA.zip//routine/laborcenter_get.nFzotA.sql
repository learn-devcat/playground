CREATE    PROCEDURE dbo.LaborCenter_Get
@User      	char(10),
@LaborCenterID	int
AS 
	SELECT	LocationID,
		Description,
		DeptAccountNo
	FROM	tblLaborCenter
	WHERE	LaborCenterID	= @LaborCenterID
go

