CREATE PROCEDURE [dbo].[sp_Dashboard_GetDropdown]
@User			char(10)
AS

SELECT d.* 
FROM tblDashboardPages as d 
WHERE ((d.UserID='GLOBAL' 
AND d.UserHidden=1
AND d.PageURL not in (SELECT PageURL FROM tblDashboardPages WHERE UserID =@User)) 
OR (d.UserID =@User AND d.UserHidden=1))
AND (PrivilegeActionID IS NULL or dbo.IsPermitted(@User,PrivilegeActionID) >0 ) 
Order By Name
go

