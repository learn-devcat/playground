


CREATE PROCEDURE dbo.UpdatePatientOrderStatus
@OrderID    int,
@Status		int

AS

	UPDATE	dbo.tblPatientOHD
	SET	    Status = @Status
	FROM    dbo.tblPatientOHD AS P
	        JOIN dbo.tblOrderOHD AS O ON P.PatientID = O.PatientID
	WHERE	O.OrderID = @OrderID
go

