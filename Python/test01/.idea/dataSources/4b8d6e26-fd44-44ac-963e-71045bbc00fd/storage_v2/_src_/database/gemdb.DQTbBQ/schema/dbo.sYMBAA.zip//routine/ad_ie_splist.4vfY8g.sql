

CREATE PROCEDURE dbo.ad_IE_SPList
AS
	SELECT	Name 
	FROM 		sysobjects
	WHERE 	xtype = 'P' 
			AND category <> 2 
			AND LEFT(Name,2) = 'ie'
	ORDER BY 	Name
go

