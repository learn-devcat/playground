


CREATE  PROCEDURE dbo.sp_User_Update2
@UserID		varchar(10),
@New		varchar(100),
@Options	varchar(50)
AS 
	DECLARE @Cmsg  char(255),
		@CoreID	int
	SET @CoreID = dbo.GetCoreIDFromUser(@UserID)
	-- Make sure a single asterisk (*) was not passed as the password.
	IF ( @New <> '3389dae361af79b04c9c8e7057f60cc6')		-- hash value for *
	BEGIN
		UPDATE	cfgUsers
		SET	UserOptions = @Options,
			PW = @new,
			LastPWChange = getdate()
		WHERE	UserID = @UserID
		SET @Cmsg = 'Password changed for user <' + @UserID + '>'
		EXEC dbo.sp_Logit 0, @CoreID, @UserID, @Cmsg, 102
	END
	ELSE
		UPDATE	cfgUsers
		SET	UserOptions = @Options
		WHERE	UserID = @UserID
go

