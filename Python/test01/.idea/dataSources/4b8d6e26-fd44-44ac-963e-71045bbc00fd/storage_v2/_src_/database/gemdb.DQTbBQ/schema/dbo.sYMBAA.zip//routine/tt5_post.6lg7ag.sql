CREATE PROCEDURE [dbo].[tt5_Post] 
@CoreID	integer,
@User		char(10),
@BadgeNo	char(19),
@Outlet	int,
@TransID	int,
@TerminalID	int,
@ChkNum	char(10),
@CashierID	int,
@Subtotal	money,
@Tax		money,
@Dsc		money,
@Svc		money,
@Total		money
AS
--
   -- 27-Sep-13 jlb
   --	 The TT5 is not sending the correct check number over so we are having to increment the check number by 1
   --
   -- 08-Oct-04 wjs 
   --    I changed the way the final results verified for correctness.  Previously, if we didn't explictily 
   --    capture an error, it would fall through as "success".   Now, I capture a 0 as success and if another
   --    code isn't present, we capture it as a "undefined error".
   --
   -- 2-14-2006 RBB
   --	Added code to use the "IsAllowed()" function instead of "Anding" the subtypes. The "IsAllowed()" function 
   --	now checks both methodologies for determining if an account can charge at a particular location	
   --
DECLARE @Today 	datetime,
		@ChargeWindow datetime,			-- The amount of time we'll consider for a duplicate charge
		@ReturnCode  int,
		@AccountNo   char(19),
		@SP_Return	int,
		@PostReturn	int,
		@FirstName	char(15),
		@LastName	char(20),
		@Description	char(32),
		@ReturnName	varchar(24),
		@Balance	money,
		@TransClassID	int,
		@OutletSubtype int,
        @isDuplicate int,
		@Swiped bit

	SET NOCOUNT ON

	-- Gets flag for badge swipe	
	SET @Swiped = dbo.BadgeSwiped(@BadgeNo);
	-- Removes badge swipe character if it exists in @BadgeNo
	SET @BadgeNo = dbo.RemoveBadgeSwipePrefix(@BadgeNo);

	IF (ISNULL(@BadgeNo,'') = '')				--  Need one of these dudes to continue ...
	BEGIN
		SELECT '/Badge # Required'  + char(28) + 'Press CLEAR To Continue' as ReturnMsg
		RETURN
	END

	IF (LEFT( @BadgeNo,1) = '~')				-- The TT5 may need some configuration.
		SET @BadgeNo = RIGHT(@BadgeNo , len(@BadgeNo) - 1) 

	SET @Today = getdate()					-- Define here cauz can't use it in an EXEC call ...
    SET @ChargeWindow = @Today - .05		-- How far back will we consider a duplicate charge.  (.05 is roughly an hour)
	SET @ReturnCode = 0
	
	SELECT TOP 1 @AccountNo = B.AccountNo
	FROM		dbo.tblBadgesOHD B
	LEFT JOIN dbo.tblAccountOHD A on A.AccountNo = B.AccountNo
	LEFT JOIN dbo.tblAccountClass AC on A.AccountClassID = AC.AccountClassID
	WHERE	B.BadgeNo = @BadgeNo
			AND B.Inactive = 0
			AND B.ActiveDate <= @Today
			AND B.ExpireDate >= @Today
			AND dbo.IsAllowed(@Outlet, A.AccountClassID, -1) <> 0

	SET @AccountNo = ISNULL(@AccountNo,@BadgeNo)		-- wjs 05-Sep-12  previously we blanked the account No, but this is the same thing and fixes the next part where we will NEED the account NO to valid.

	BEGIN TRY -- jlb 27-Sep-13  The TT5 is not sending the correct check number over so we are having to increment the check number by one
		SET @ChkNum = @ChkNum + 1  
	END TRY
	BEGIN CATCH
	END CATCH	

	-- Let's check for dup.  If we get a hit, we're dup.
	SELECT   @Description = AccountNo
	FROM    dbo.tblDetail
	WHERE   AccountNo = @AccountNo
			AND BadgeNo = @Badgeno
			AND OutletNo = @Outlet
			AND TransID = @TransID
			AND TransTotal = @Total
			AND ChkNum     = @ChkNum
			AND TransDate BETWEEN @ChargeWindow and @Today
    
    IF (@@ROWCOUNT = 0)
       SET @isDuplicate = 0
    ELSE
	BEGIN
		SET @isDuplicate = 1
		SET @SP_Return = 0
		SET @PostReturn = 0
	END
		
	if( @isDuplicate = 0 )	
		EXEC @SP_Return = dbo.sp_PreChargeAuthorization @AccountNo, @BadgeNo, @Total, @TransID, @Outlet
		
			
	IF (@SP_Return = 0)
	BEGIN

		EXEC @PostReturn = dbo.sp_Trans_Post @CoreID, @User,  @AccountNo, @BadgeNo , @Today , @Outlet , 'TT5', @ChkNum, @Total , 
			@Total, @Outlet, -1 , @TransID, @BadgeSwiped = @Swiped
		
		IF (@PostReturn = 0)
		BEGIN
			SELECT @FirstName = A.FirstName,
				@LastName = A.LastName,
				@Description = A.Description,
				@Balance = CASE TC.DeclBalMode
						WHEN 0 THEN TT.Balance 
						ELSE -TT.Balance
					END
			FROM	tblAccountOHD AS A
			LEFT JOIN tblAccountTTL AS TT ON	A.AccountNo = TT.AccountNo
			LEFT JOIN tblTransDef AS T ON	TT.TransClassID = T.TransClassID
			LEFT JOIN tblTransClass AS TC ON	T.TransClassID = TC.TransClassID
			WHERE A.AccountNo = @AccountNo
				   AND T.TransID = @TransID
				
			IF (@FirstName <> '' OR @LastName <> '')
				SET @ReturnName = RTRIM(@LastName) + ', ' + RTRIM(@FirstName)
			ELSE
				SET @ReturnName = @Description
				
		END
		
	END


	SELECT CASE @SP_Return
	      WHEN '0'  THEN
				CASE @PostReturn
					WHEN 0 THEN '@' + @ReturnName + Char(28) + 'Balance: ' + CAST(@Balance AS varchar(8)) + Char(28) + @ReturnName + char(13)+char(10) + 'Transaction: APPROVED ' + char(13)+char(10) +   'New Current Balance: ' + CAST(@Balance AS varchar(10)) + char(13) + char(10)  + '----------------------------------------' + char(13) + char(10) + '            ' + cast(  getdate() as varchar(30)) + char(13) + char(10)
					ELSE '/Error Code: ' + cast( @PostReturn as varchar(10))
				END
			WHEN '1' THEN '/Over Account Limit'
			WHEN '2' THEN '/Over Daily Limit'
			WHEN '3' THEN '/Badge Not On File'
			WHEN '4' THEN '/Badge Not Valid'
			WHEN '5' THEN '/Over Daily Qty'
			WHEN '6' THEN '/Over Badge Trans Limit'
			WHEN '7' THEN '/Over Account Trans Limit'
			WHEN '8' THEN '/Inactive Account'
			WHEN '9' THEN '/Over Badge Limit'
			WHEN '10' THEN '/Not Authorized Here'
			WHEN '11' THEN '/Outlet Not Defined'
			ELSE 
			   '/Undefined Error #:' +  cast( @SP_Return as varchar(10))
			   
		END AS ReturnMsg
go

