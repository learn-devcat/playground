


CREATE PROCEDURE dbo.NutrientGetNewID

AS
	SET NOCOUNT ON

	SELECT MAX(NutrientID) + 1 AS NutrientID FROM dbo.cfgNutrients

	RETURN
go

