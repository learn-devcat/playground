CREATE PROCEDURE [dbo].[tt5_Post2] 
@CoreID	integer,
@User		char(10),
@BadgeNo	char(19),
@Outlet	int,
@TransID	int,
@TerminalID	int,
@ChkNum	char(10),
@CashierID	int,
@Subtotal	money,
@Tax		money,
@Dsc		money,
@Svc		money,
@Total		money
AS
   /*
    27-Sep-13 jlb
		The TT5 is not sending the correct check number over so we are having to increment the check number by 1
   
    24-Aug-11 wjs
        Updated the receipt portions to center the output -- this makes the receipt move visually apealing.

    08-Oct-04 wjs 
        I changed the way the final results verified for correctness.  Previously, if we didn't explictily 
        capture an error, it would fall through as "success".   Now, I capture a 0 as success and if another
        code isn't present, we capture it as a "undefined error".
   
    2-14-2006 RBB
        Added code to use the "IsAllowed()" function instead of "Anding" the subtypes. The "IsAllowed()" function 
        now checks both methodologies for determining if an account can charge at a particular location	
   */

declare @Today 	datetime,
		@ChargeWindow datetime,			-- The amount of time we'll consider for a duplicate charge
		@ReturnCode  int,
		@AccountNo   char(19),
        @SP_Return	int,
        @PostReturn	int,
        @FirstName	char(15),
        @LastName	char(20),
        @Description	char(32),
        @ReturnName	varchar(24),
        @Balance	money,
        @TransClassID	int,
        @OutletSubtype int,
        @TransDescription varchar(35),
        @isDuplicate int

    SET NOCOUNT ON

	-- Removes badge swipe character if it exists in @BadgeNo
	SET @BadgeNo = dbo.RemoveBadgeSwipePrefix(@BadgeNo);

    if( ISNULL(@BadgeNo,'') = '' )				--  Need one of these dudes to continue ...
        begin
            select '/Badge # Required'  + char(28) + 'Press CLEAR To Continue' as ReturnMsg
            return
        end	

    if( left( @BadgeNo,1) = '~' )			-- The TT5 may need some configuration.
        set @BadgeNo = right( @BadgeNo , len( @BadgeNo  ) - 1 )

    set @Today = getdate()					-- Define here cauz can't use it in an EXEC call ...
    set @ChargeWindow = getdate() - .05			-- How far back will we consider a duplicate charge.  (.05 is roughly an hour)
    set @ReturnCode = 0
    
    SELECT 	top 1 @AccountNo = B.AccountNo
    FROM		tblBadgesOHD B
    left join	tblAccountOHD A on A.AccountNo = B.AccountNo
    left join	tblAccountClass AC on A.AccountClassID = AC.AccountClassID
    WHERE		B.BadgeNo = @BadgeNo
                AND B.Inactive = 0
				AND B.Lost = 0
				AND B.Stolen = 0
                AND B.ActiveDate <= @Today
                AND B.ExpireDate >= @Today
                AND dbo.IsAllowed(@Outlet, A.AccountClassID, -1) <> 0
	order by primaryBadge
	
    SET @AccountNo = ISNULL(@AccountNo,'')		-- wjs 05-Sep-12  previously we blanked the account No, but this is the same thing and fixes the next part where we will NEED the account NO to valid.

	 if( @@RowCount = 0 )
       begin
		 select '/Not Valid Here' + char(28) + '/Error Code' + char(28) + ' ' as ReturnMsg
	     return
       end
	   
	BEGIN TRY -- jlb 27-Sep-13  The TT5 is not sending the correct check number over so we are having to increment the check number by 1
		SET @ChkNum =@ChkNum + 1  
	END TRY
	BEGIN CATCH
		SET @ChkNum = @ChkNum
	END CATCH		   

	-- Let's check for dup.  If we get a hit, we're dup.
	select  @Description = AccountNo
	from    tblDetail
	where       AccountNo  = @AccountNo
			and BadgeNo    = @Badgeno
			and OutletNo   = @Outlet
			and TransID    = @TransID
			and TransTotal = @Total
			and ChkNum     = @ChkNum
			and TransDate between @ChargeWindow and @Today
    
    if( @@ROWCOUNT = 0 )
       SET @isDuplicate = 0
    else
		begin
			set @isDuplicate = 1
			set @SP_Return = 0
			set @PostReturn = 0
		end
		
	if( @isDuplicate = 0 )	
		EXEC @SP_Return = dbo.sp_PreChargeAuthorization @AccountNo, @BadgeNo, @Total, @TransID, @Outlet
 
    IF (@SP_Return = 0)
    BEGIN
		
		if( @isDuplicate = 0 )					-- not a dup -- good, so let's post
			EXEC @PostReturn = dbo.sp_Trans_Post  @CoreID, @User,  @AccountNo, @BadgeNo , @Today , @Outlet , 'TT5', @ChkNum, @Total , @Total, @Outlet, -1 , @TransID		
		
        IF (@PostReturn = 0)
        BEGIN
            SELECT	@FirstName = A.FirstName,
                    @LastName = A.LastName,
                    @Description = A.Description,
                    @TransDescription = T.Description,
                    @Balance = CASE TC.DeclBalMode
                                    WHEN 0 THEN TT.Balance 
                                    ELSE -TT.Balance
                                END
            FROM	tblAccountOHD AS A
            LEFT JOIN tblAccountTTL AS TT ON	A.AccountNo = TT.AccountNo
            LEFT JOIN tblTransDef AS T ON	TT.TransClassID = T.TransClassID
            LEFT JOIN tblTransClass AS TC ON	T.TransClassID = TC.TransClassID
            WHERE	A.AccountNo = @AccountNo
                    AND T.TransID = @TransID
                
            IF (@FirstName <> '' OR @LastName <> '')
                SET @ReturnName = RTRIM(@LastName) + ', ' + RTRIM(@FirstName)
            ELSE
                SET @ReturnName = @Description
                
        END
        
    END
       
    SELECT CASE @SP_Return
          WHEN '0'  THEN
                CASE @PostReturn
                    WHEN 0 THEN '@' + @ReturnName + Char(28) + 'Balance: ' + CAST(@Balance AS varchar(8)) + Char(28) + dbo.StringCenter( @ReturnName , 40) + char(13)+char(10) + dbo.StringCenter('Transaction: APPROVED ' , 40) + char(13)+char(10) + dbo.StringCenter( @TransDescription , 40 ) + char(10) + char(13) +  dbo.StringCenter( 'New Current Balance: ' + CAST(@Balance AS varchar(10)) , 40 ) + char(13) + char(10)  + '----------------------------------------' + char(13) + char(10) + '            ' + cast(  getdate() as varchar(30)) + char(13) + char(10)
                    ELSE '/Error Code: ' + cast( @PostReturn as varchar(10)) + char(28) + '/Invalid Location' + char(28) + ' '
                END
            WHEN '1' THEN '/Over Account Limit' + char(28) + '/Error Code' + char(28) + ' '
            WHEN '2' THEN '/Over Daily Limit' + char(28) + '/Error Code' + char(28) + ' '
            WHEN '3' THEN '/Badge Not On File' + char(28) + '/Error Code' + char(28) + ' '
            WHEN '4' THEN '/Badge Not Valid' + char(28) + '/Error Code' + char(28) + ' '
            WHEN '5' THEN '/Over Daily Qty' + char(28) + '/Error Code' + char(28) + ' '
            WHEN '6' THEN '/Over Badge Trans Limit' + char(28) + '/Error Code' + char(28) + ' '
            WHEN '7' THEN '/Over Account Trans Limit' + char(28) + '/Error Code' + char(28) + ' '
            WHEN '8' THEN '/Inactive Account' + char(28) + '/Error Code' + char(28) + ' '
            WHEN '9' THEN '/Over Badge Limit' + char(28) + '/Error Code' + char(28) + ' '
            WHEN '10' THEN '/Not Authorized Here' + char(28) + '/Error Code' + char(28) + ' '
            WHEN '11' THEN '/Outlet Not Defined' + char(28) + '/Error Code' + char(28) + ' '
            ELSE 
               '/Undefined Error #:' +  cast( @SP_Return as varchar(10)) + char(28) + '/Error Code' + char(28) + ' '      
               
        END AS ReturnMsg
go

