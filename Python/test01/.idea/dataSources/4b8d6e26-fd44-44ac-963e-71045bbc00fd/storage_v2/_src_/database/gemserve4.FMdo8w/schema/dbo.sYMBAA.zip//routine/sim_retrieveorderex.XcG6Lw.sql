CREATE   PROCEDURE dbo.sim_RetrieveOrderEX
@CoreID as int,
@LoginUserID 	varchar(250),
@WorkstationID int,
@PatientVisitID varchar(50),
@WaveID int,
@WaveDate  varchar(30)
AS
	SET NOCOUNT ON
			
	DECLARE @OrderID int,
		@RoomNumber as varchar(20),
		@SubLevel int,
		@PatientName varchar(50),
		@DietName varchar(50),
		@OrderWorkstationID int,
		@Sent int,
		@Received int,
		@Detail as varchar(4000),
		@Msg as varchar(2200),
		@PatientInfoOnOrder as char(1),
		@OrderDate datetime,
		@StandingOrder bit,
		@DietMenuLevel int,
		@ItemType int,
		@MenuItemID int,
		@POSMenuItemID int,
		@IsDiet bit,
		@Today datetime,
		@Msg2 varchar(1000)


	SELECT @PatientInfoOnOrder = dbo.GetOverheadValue('PatientInfoOnOrder')

	IF ( @PatientInfoOnOrder = '' )
		SET @PatientInfoOnOrder = '0'

	SET @Today = GETDATE()

        SELECT TOP 1 @OrderID = O.OrderID , 
		@RoomNumber = R.RoomNumber + ISNULL(PV.Bed,''),
	        @SubLevel = O.SubLevel,
	        @PatientName = P.FullName, 
		@OrderWorkstationID = O.WorkstationID,
		@Sent = O.Sent,
		@Received = O.Received,
		@DietName = DT.Description,
		@OrderDate = O.OrderDate,
		@StandingOrder = O.StandingOrder,
		@DietMenuLevel = COALESCE(DT.MenuLevel,1)
        FROM    dbo.tblOrderOHD O
                LEFT JOIN dbo.tblPatientOHD AS P (NOLOCK) ON O.PatientID = P.Patientid
        	LEFT JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON O.PatientVisitID = PV.PatientVisitID
			AND PV.MergedTo IS NULL
			AND PV.DischargeDate IS NULL
                LEFT JOIN dbo.tblDietOHD AS DT (NOLOCK) ON PV.DietID = DT.DietID
                LEFT JOIN dbo.tblRoomOHD AS R (NOLOCK) ON PV.RoomID = R.RoomID
        WHERE   dbo.dDateOnly(O.OrderDate) = dbo.dDateOnly(@WaveDate)
                AND O.PatientVisitID = @PatientVisitID
                AND O.WaveID = @WaveID
	AND COALESCE(O.Cancelled,0) = 0
                         
        IF( @@RowCount = 0 OR @OrderID IS NULL)
        BEGIN
            SELECT '/Order Not On File' AS rMsg
            RETURN
        END
        
        IF( @Received <> 0)
        BEGIN
            SELECT '/Order Already Sent' AS rMsg
            RETURN
        END
         
        -- Get Detail
        
        SELECT @Msg = 'RETRIEVE' + char(28) + cast(@OrderID as varchar(10)) + '^' + @RoomNumber + '^' + 
        CASE
        	WHEN @PatientInfoOnOrder = '1' THEN @PatientName 
        	ELSE ''
        END + '^' + CAST(@SubLevel as varchar(5)) + '^' +
        	@DietName + '^' + dbo.DateString(@OrderDate) + ' ' + dbo.TimeString(@OrderDate) + '^' 
        
        DECLARE Items cursor FOR
     	SELECT O.ItemType, O.POSMenuItemID
        	FROM dbo.tblOrderItems AS O
        	WHERE O.OrderID = @OrderID
		ORDER BY O.IsDiet DESC

	OPEN Items
	FETCH NEXT FROM Items INTO @ItemType,  @POSMenuItemID

	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @Msg = @Msg + CAST(@ItemType AS varchar(10)) + ',' + CAST(@POSMenuItemID AS varchar(10)) + ','

		FETCH NEXT FROM Items INTO @ItemType, @POSMenuItemID
	END

	CLOSE Items
	DEALLOCATE Items

	IF (RIGHT(@Msg,1) = ',')
		SET @Msg = LEFT(@Msg,LEN(@Msg)-1)

	SET @Msg = @Msg + '^' + CAST(@DietMenuLevel AS varchar(10)) + char(28) + CAST(@StandingOrder AS char(1)) 

    SET @Msg2 = 'Order canceled due to order pick up. Order ID: ' + CAST(@OrderID AS varchar(30))
    EXEC dbo.OrderSETCancelled @LoginUserID, @OrderID, 1, @Today, @Msg2, 800

    IF(@Msg IS NULL)
		SELECT '/Unable To Retrieve Order' as rMsg
    ELSE
        SELECT @Msg AS rMsg
go

