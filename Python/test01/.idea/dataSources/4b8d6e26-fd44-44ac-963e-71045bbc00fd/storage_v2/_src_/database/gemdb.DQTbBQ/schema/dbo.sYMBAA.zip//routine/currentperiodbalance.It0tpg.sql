

CREATE FUNCTION dbo.CurrentPeriodBalance(@AccountNo char(19),@MealPlanID int, @BeginTime datetime, @EndTime datetime)
RETURNS money
AS
BEGIN
	DECLARE @Return money
	SELECT 	@Return = SUM(TransTotal)
	FROM	tblDetail
	WHERE	AccountNo = @AccountNo
		AND MealPlanID = @MealPlanID
		AND TransDate >= @BeginTime
		AND TransDate <= @EndTime
	RETURN ISNULL(@Return,0)
END
go

