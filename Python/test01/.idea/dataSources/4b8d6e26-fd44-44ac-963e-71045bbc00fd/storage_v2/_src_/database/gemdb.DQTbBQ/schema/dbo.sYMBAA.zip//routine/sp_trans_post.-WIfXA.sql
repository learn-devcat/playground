CREATE PROCEDURE [dbo].[sp_Trans_Post]
@CoreID	    int,
@User		char(10),
@AccountNo	char(19),
@BadgeNo	char(19),
@TransDate	datetime,
@OutletNo	int,
@RefNum	    varchar(10),
@CheckNum	varchar(10),
@TransTotal	money,
@Sales1	    money,
@Comment	varchar(40),
@CycleNo	int,
@TransID	int,
@Category 	char(10)=' ',
@PaymentNo	int=0,
@ServeEmpl	int=0,
@PostEmpl	int=0,
@Covers	    smallint=0,
@RevCntr	int=0,
@Sales2	money=0,
@Sales3	money=0,
@Sales4	money=0,
@Sales5	money=0,
@Sales6	money=0,
@Sales7	money=0,
@Sales8	money=0,
@Sales9	money=0,
@Sales10	money=0,
@Sales11	money=0,
@Sales12	money=0,
@Sales13	money=0,
@Sales14	money=0,
@Sales15	money=0,
@Sales16	money=0,
@Tax1		money=0,
@Tax2		money=0,
@Tax3		money=0,
@Tax4		money=0,
@Dsc		money=0,
@Svc		money=0,
@SvcA		money=0,
@Correction	bit=0,
@Auditable	bit=0,
@PostDate	datetime = '',
@MealPlanID	int = 0,
@LocationID int = -1,
@IsPostingFromBatch bit = 0,
@BadgeSwiped bit = 0
AS
SET NOCOUNT ON
DECLARE	@TransClassID	int,
		@SubType		int,
		@OutletTTL		money,
		@TransDefTTL	money,
		@TransLimit		money,
		@IsPayment		bit,
		@LastPayDate	datetime,
		@LastChgDate	datetime,
		@CheckPayDate	datetime,
		@CheckChgDate	datetime,
		@Qty			int,
		@DailyQty		int,
		@DailyBalance	money,
		@ChgTotal		money,
		@PayTotal		money,
		@ChgQty		    int,
		@PayQty		    int,
		@CurrentError	int,
		@BatchError		int,
		@Msg			varchar(128) ,
		@IsMealPlan		int,
		@SlotNo			smallint,
		@Temp			int,
		@AddToBadgeBalance	int,
		@PostByTransDate	char(1),
		@ResetTtlQty	bit,
		@InOfflineMode bit,
		@OriginalPostDate datetime,
		@IsLocalTransaction bit,
		@Today datetime,
		@IncrementDailyQty bit

	SET @Today = getdate();
	SET @IncrementDailyQty = 1;

	-- Gets flag for badge swipe
	IF (@BadgeSwiped = 0)	
		SET @BadgeSwiped = dbo.BadgeSwiped(@BadgeNo);
	-- Removes badge swipe character if it exists in @BadgeNo
	SET @BadgeNo = dbo.RemoveBadgeSwipePrefix(@BadgeNo);

	SET @IsLocalTransaction = 0
	SET @CurrentError=0
	SET @Msg = ''
	
	-- First thing to do... We need to make sure current cycles exist before we look for them later in this procedure
	-- Updated 5-2-2011
	EXEC dbo.Cycles_MakeAllCurrent 0		
	
	-- Handle Posting by TransDate
	SELECT	@PostByTransDate = dbo.GetOverheadItem('PostByTransDate')

	SET @InOfflineMode = ISNULL(dbo.GetOverheadItem('InOfflineMode'),0)
	
	SET @OriginalPostDate = @PostDate
	
	SET @PostByTransDate = ISNULL(@PostByTransDate,'0')
	IF (@PostDate = '' AND @PostByTransDate = '1')
		SET @PostDate = @TransDate
	------------------------------
	
	SELECT 	@IsMealPlan 	= IsMealPlan,
			@SlotNo 		= SlotNo,
			@IsPayment 		= Payment,
			@TransClassID 	= TransClassID,
			@ResetTtlQty = ResetTtlQty
	FROM	dbo.tblTransDef
	WHERE	TransID = @TransID

	-- Get the setting for Badge Balance
	SELECT  @AddToBadgeBalance = AddToBadgeBalance
	FROM    dbo.tblTransClass
	WHERE   TransClassID = @TransClassID
	SET @AddToBadgeBalance = ISNULL(@AddToBadgeBalance,1)
	SET @IsMealPlan        = ISNULL(@IsMealPlan,0)

	-- 17-Feb-09 wjs	
	-- Get the LocationID, IF we haven't resolved it yet -- IF we have, then just use what came in...
	IF( @LocationID < 0 )
	  BEGIN
		SELECT @LocationID = ISNULL(LocationID, 0)
		FROM	dbo.tblOutletOHD
		WHERE	OutletNo = @OutletNo
	  END
	
	-- Get the current cycle number IF the value is less than 1 (using the field as a flag)
	-- IF we are passing a cycle Number in, we just use that.
	IF ( @CycleNo < 1 )						
	BEGIN
		IF (@PostDate = '')
			SELECT	@CycleNo = X.CycleNo
			FROM	dbo.tblAccountOHD	AS A
			INNER JOIN 	dbo.tblAccountClass AS AC ON A.AccountClassID = AC.AccountClassID
			INNER JOIN  dbo.tblCycleXlat AS X ON AC.CycleXRefID = X.xlatid
			WHERE	@Today BETWEEN X.BeginDate AND X.EndDate
					AND A.AccountNo = @AccountNo
	    ELSE
			    SELECT  @CycleNo = X.CycleNo
			      FROM	dbo.tblAccountOHD AS A
			INNER JOIN  dbo.tblAccountClass AS AC ON A.AccountClassID = AC.AccountClassID
			INNER JOIN  dbo.tblCycleXlat AS X ON AC.CycleXRefID = X.xlatid
			     WHERE  @PostDate BETWEEN X.BeginDate AND X.EndDate
			            AND A.AccountNo = @AccountNo
	END
	
	------------------[ OFFLINE MODE  ]-------------------------
	--IF we are in offline mode, post to batch AND do noting ELSE
	IF (@InOfflineMode > 0 AND @IsPostingFromBatch < 1)
	BEGIN
		EXEC @BatchError=dbo.sp_Batch_Insert @CoreID,@User,'OfflineMode',@AccountNo,@BadgeNo,@TransDate,@OutletNo,@RefNum,@CheckNum,@TransTotal,
							@Sales1,@Comment,@CycleNo,@TransID,@MealPlanID,@Category,@PaymentNo,@ServeEmpl,@PostEmpl,@Covers,
							@RevCntr,@Sales2,@Sales3,@Sales4,@Sales5,@Sales6,@Sales7,@Sales8,@Sales9,@Sales10,
							@Sales11,@Sales12,@Sales13,@Sales14,@Sales15,@Sales16,@Tax1,@Tax2,@Tax3,@Tax4,
							@Dsc,@Svc, ''							

		Return @BatchError
	END	
	
	-- If there is NOT a transaction already started, then start a local transaction, for this procedure only.
	-- set a variable to specify that this is a local transaction, that should be dealt with within this procedure.
		IF(@@TRANCOUNT = 0)
		BEGIN
		  BEGIN TRANSACTION
		  SET @IsLocalTransaction = 1
		END

		--SET the QTY
		IF @TransTotal >= 0         -- Negative Totals indicate a correction to a total
			SET @Qty = 1            -- AND should post the reverse.
		ELSE                        -- This QTY is maintained AND used througout the
			SET @Qty = -1			-- rest of this proceedure.
			
			
		IF( @Correction = 0 )
		    BEGIN
    		    
    		    --Post to tblDetail
			    SET @Msg='ERR: DetailOHD ' 
			    
			    EXEC @CurrentError=dbo.sp_Trans_PostDetail @CoreID,@User,@AccountNo,@BadgeNo,
					    @TransDate,@OutletNo,@RefNum,@CheckNum,@TransTotal,
					    @Sales1,@Comment,@CycleNo,@TransID,@Category,@PaymentNo,
					    @ServeEmpl,@PostEmpl,@Covers,@RevCntr,@Sales2,@Sales3,
					    @Sales4,@Sales5,@Sales6,@Sales7,@Sales8,@Sales9,@Sales10,
					    @Sales11,@Sales12,@Sales13,@Sales14,@Sales15,@Sales16,
					    @Tax1,@Tax2,@Tax3,@Tax4,@Dsc,@Svc,@Correction,@Auditable, 
						@PostDate, @MealPlanID, @LocationID, @BadgeSwiped
    	
			    IF (@CurrentError<>0)
			        GOTO END_PROC
				
		    END
		-- Post to tblTransDefTTL
		SET @Msg='ERR: TransDef TTL '  
		EXEC @CurrentError=dbo.sp_Trans_PostTransDefTTL @CycleNo,@TransID,@Qty,@TransTotal, @Correction
		IF (@CurrentError<>0)			
			GOTO END_PROC			
		
		--Post to OutletTTL
		SET @Msg='ERR: Outlet TTL '
		EXEC @CurrentError=dbo.sp_Trans_PostOutletTTL @CycleNo,@OutletNo,@Qty,@TransTotal,@IsPayment, @Correction
		IF (@CurrentError<>0)			
			GOTO END_PROC			
	
	    --Post to BadgesOHD
		SET @Msg='ERR: Badge OHD '
		EXEC @CurrentError=dbo.sp_Trans_PostBadge @AccountNo,@BadgeNo,@Qty,@TransTotal,@IsPayment, @Correction
		IF (@CurrentError<>0)			
			GOTO END_PROC
        -- Post to BadgeTTL
		IF ( @AddToBadgeBalance = 1 )
		    BEGIN
			    SET @Msg='ERR: Badge TTL '
			    EXEC @CurrentError = dbo.gem_Trans_PostBadgeTTL @User, @AccountNo, @BadgeNo, @TransDate, @TransTotal, @Qty, @IsPayment, @Correction
		    END
	
	    --Post to TrackingTTL
		SET @Msg='ERR: Tracking TTL '	
		EXEC @CurrentError=dbo.sp_Trans_PostTracking @AccountNo,@TransID,@CycleNo,@IsPayment,@TransTotal,@Sales1,@Sales2,@Sales3,
								@Sales4,@Sales5,@Sales6,@Sales7,@Sales8,@Sales9,@Sales10,@Sales11,
								@Sales12,@Sales13,@Sales14,@Sales15,@Sales16,@Tax1,@Tax2,@Tax3,
								@Tax4,@Dsc,@Svc,@SvcA,@Correction
		IF (@CurrentError<>0)
			GOTO END_PROC
			
		--Post to AccountTTL
		-- new param to decide IF the qty should be reset: 3-19-2010 RBB	
		SET @Msg='ERR: Account TTL, Trans Profile=' + CAST(@transClassid as varchar(5)) + ' '
		IF (dbo.dDateOnly(@TransDate) <> dbo.dDateOnly(@Today))
			SET @IncrementDailyQty = 0

		EXEC @CurrentError=dbo.sp_Trans_PostAccountTTL @AccountNo,@Qty,@TransTotal,@TransClassID,@IsPayment, @Correction, @ResetTtlQty, @OriginalPostDate, @IncrementDailyQty
		IF (@CurrentError<>0)
			GOTO END_PROC
			
			
		-- Post Transaction TTL (Stored by cycle)
		SET @Msg='ERR: Account Trans TTL Trans Profile=' + CAST(@transClassid as varchar(5))	+ ' '
		EXEC @CurrentError = dbo.sp_Trans_PostAccountTransTTL @AccountNo, @Qty, @TransTotal , @TransClassID, @IsPayment, @CycleNo, @Correction
		IF( @CurrentError <> 0 ) 
		    GOTO END_PROC	    
		    
		IF( @IsMealPlan = 1 AND @MealPlanID > 0 ) 
            BEGIN
				SET @Msg='ERR: Account Meal TTL, Meal Plan ID=' + CAST(@MealPlanID AS varchar(5)) + ' '
			    EXEC @CurrentError = dbo.gem_Trans_PostAccountMealTTL @User, @CoreID, @AccountNo, @SlotNo, @TransDate, @Qty, @TransTotal, @Correction, @MealPlanID
			    IF (@CurrentError <> 0)
			        GOTO END_PROC
		    END
		SET @Msg='ERR: Account Outlet Class TTL, Trans Profile=' + CAST(@transClassid as varchar(5)) + ' - OutletNo=' + CAST(@OutletNo as varchar(5))
		EXEC @CurrentError=dbo.sp_Trans_PostAccountOutletClassTTL @AccountNo,@Qty,@TransClassID,@TransTotal,@OutletNo,@IsPayment, @Correction, @ResetTtlQty, @OriginalPostDate
		IF (@CurrentError<>0)
			GOTO END_PROC
			
		--Post Reload to tblBatch
		IF (@Correction = 0) AND (@IsPayment <> 0)
		BEGIN
			EXEC @CurrentError = dbo.sp_Trans_PostBadgeReload @CoreID,@User,@AccountNo,@BadgeNo,@TransDate,@OutletNo,@RefNum,@CheckNum,@TransClassID,@TransTotal			
		END				
		  
	SET @Msg=''
	
	IF(@IsLocalTransaction = 1)
		COMMIT TRANSACTION			-- WHEW!  We made it!!.. commit ONLY if this is a local transaction

	RETURN 0 
	
END_PROC:
	IF(@IsLocalTransaction = 1)
		ROLLBACK TRANSACTION -- rollback the transaction ONLY if it is a local transaction
	
	IF (@Msg<>'')
	BEGIN
		IF(@CurrentError=2627)
			SET @Msg = @Msg +  ' Duplicate Transaction'
			
		EXEC dbo.sp_Logit 1 , @CoreID , @User , @Msg
	END
		
		
	IF( @CurrentError <> 0 )        -- attempted patch for failed posting
	    BEGIN -- wjs 21-Aug-03
	        SET @Msg = @Msg + ' Error #' + CAST( @CurrentError as Varchar(10))
	        goto BATCH_POST
	    END
	
	RETURN @CurrentError
	
--
--  Batch Post
--
--      IF we get to this point, we had some sort of error in the posting above. 
--      Our transaction has already been rolled back AND no trasaction is currently
--      active.  So, at this point, we just need to drop the transaction into the 
--      batch table, no transaction required.
--
--
BATCH_POST:
    IF (@CurrentError=2627)		--Duplicate trans, don't try to put this to batch.
        BEGIN
            RETURN 2627
		END
			
	IF(@IsPostingFromBatch = 0)	-- 6-oct-10 rbb - do not duplicate a transaction in batch, when posting from batch													
		EXEC @BatchError=dbo.sp_Batch_Insert @CoreID,@User,'EXCEPTION',@AccountNo,@BadgeNo,@TransDate,@OutletNo,@RefNum,@CheckNum,@TransTotal,
							@Sales1,@Comment,@CycleNo,@TransID,@MealPlanID,@Category,@PaymentNo,@ServeEmpl,@PostEmpl,@Covers,
							@RevCntr,@Sales2,@Sales3,@Sales4,@Sales5,@Sales6,@Sales7,@Sales8,@Sales9,@Sales10,
							@Sales11,@Sales12,@Sales13,@Sales14,@Sales15,@Sales16,@Tax1,@Tax2,@Tax3,@Tax4,
							@Dsc,@Svc, @Msg
			       
			            			            
	IF(@CurrentError <> 0 ) -- 6-OCT-10 RBB - if we have an error from ttl posting, return it, else return batch error
		RETURN @CurrentError
			            
	RETURN @BatchError
go

