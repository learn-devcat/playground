CREATE PROCEDURE dbo.ol_Reload
@CoreID		int,
@User			char(10),
@AccountNo		char(19),
@BadgeNo		char(19),
@TransTotal		money = 0,
@CheckNum		char(6) = '',
@TransID		int = 0,
@OutletNo		int = 0,
@Phone 		varchar(15) = '',
@PaymentNo		int = 1,
@RefNum		char(6) = '',
@Category 		char(10) = '',
@ServeEmpl		int = 0,
@Comment		varchar(40) = '',
@FirstName		varchar(15) = '',
@LastName		varchar(20) = '' 
AS 
 	
DECLARE @ReturnCode	int,
	@Test  		varchar(100),
	@TransDate	datetime,
	@Swiped		bit
	
	SET NOCOUNT ON
	--Get GC TransID AND OutletNo
	--Could change this to look for different Overhead VALUES IF not in a GC setting,
	--Such as 'DefaultTransID', 'DefaultOutlet'. These Overhead keys do not exist by
	--default AND would have to be added during setup.

	-- Gets flag for badge swipe	
	SET @Swiped = dbo.BadgeSwiped(@BadgeNo);
	-- Removes badge swipe character if it exists in @BadgeNo
	SET @BadgeNo = dbo.RemoveBadgeSwipePrefix(@BadgeNo);

	SET @TransDate = getdate()
	IF (@TransID = 0)
		SELECT @TransID = dbo.GetOverheadItem('GCTransID')
	IF (@OutletNo = 0)
		SELECT @OutletNo = dbo.GetOverheadItem('GCOutletNo')
	
	IF (@AccountNo = '')
	BEGIN
		
		SELECT 	 @AccountNo = tblBadgesOHD.AccountNo
		FROM 	dbo.tblBadgesOHD 
		WHERE 	tblBadgesOHD.BadgeNo = @BadgeNo AND
			tblBadgesOHD.inactive = 0 AND
			tblBadgesOHD.expiredate >= getdate() AND
			tblBadgesOHD.activeDate <= getdate() 
		IF (@@ROWCOUNT =0)
			GOTO NotOnFile
	END
	
		
	-- Everything must succeed or nothing succeeds... We're a TEAM player!!!  -- Everyone WINS!
	BEGIN TRANSACTION Reload
		
			-- UPDATE the account record IF we have something to UPDATE.
			UPDATE dbo.tblAccountOHD 
			SET	   FirstName = CASE @FirstName WHEN '' THEN A.FirstName ELSE @FirstName  END,
				   LastName = CASE @LastName WHEN '' THEN A.LastName ELSE @LastName  END,
				   Phone    = CASE @Phone       WHEN '' THEN A.Phone       ELSE @Phone   END,
				   LastUpdateDate = GETDATE()
			FROM	   dbo.tblAccountOHD AS A
			WHERE  A.AccountNo = @AccountNo
			IF (@@RowCount = 0)
				GOTO ReloadFailed

			-- Now, UPDATE badge record	
			UPDATE  dbo.tblBadgesOHD
			SET	    FirstName = CASE @FirstName WHEN '' THEN B.FirstName ELSE @FirstName  END,
				    LastName = CASE @LastName WHEN '' THEN B.LastName ELSE @LastName  END
			FROM	    dbo.tblBadgesOHD AS B
			WHERE   B.AccountNo = @AccountNo AND
				    B.BadgeNo = @BadgeNo
			IF (@@RowCount = 0)
				GOTO ReloadFailed
		
		--Insert the transaction
		EXEC @ReturnCode = dbo.sp_Trans_Post @CoreID, @User, @AccountNo, @BadgeNo, @TransDate, @OutletNo, 
						@RefNum, @CheckNum, @TransTotal, @TransTotal, @Comment, 0, @TransID,
						@Category, @PaymentNo, @ServeEmpl, @BadgeSwiped = @Swiped        
						
		IF (@ReturnCode <> 0)
			GOTO ReloadFailed
		
		--Add succeeded, so commit AND RETURN
		COMMIT TRANSACTION Reload
		SELECT 'success' as ReturnMsg
		RETURN
	
ReloadFailed:
		
		--Reload failed, so RETURN failure message		
		ROLLBACK TRANSACTION Reload
		SELECT '/Reload Failed' as ReturnMsg
		RETURN
NotOnFile:
		SELECT '/Not on File' as ReturnMsg
		RETURN
go

