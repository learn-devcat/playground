CREATE PROCEDURE [dbo].[Micros_TSDelete]
@TouchScreen	int
AS
	SET NOCOUNT ON

	DECLARE @SQL nvarchar(4000)
	
	DELETE	MicrosTouchScreenDef
	WHERE	ts_scrn_seq = @TouchScreen

	RETURN
go

