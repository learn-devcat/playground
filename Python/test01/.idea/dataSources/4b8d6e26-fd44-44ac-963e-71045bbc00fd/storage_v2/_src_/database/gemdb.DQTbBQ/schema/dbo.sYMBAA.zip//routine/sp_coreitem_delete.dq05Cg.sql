

CREATE PROCEDURE dbo.sp_CoreItem_Delete
@CoreID int
AS
	DELETE	cfgCore
	WHERE	CoreID = @CoreID
go

