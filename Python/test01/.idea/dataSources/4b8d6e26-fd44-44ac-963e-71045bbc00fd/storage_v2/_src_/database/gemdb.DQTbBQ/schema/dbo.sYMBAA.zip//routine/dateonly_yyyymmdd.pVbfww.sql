
CREATE  FUNCTION dbo.DateOnly_yyyymmdd (@WholeDate datetime)
RETURNS char(10)
AS 
BEGIN 
	RETURN
	CAST(DATEPART(year,@WholeDate) AS char(4)) + '/' +
	right('0' + RTRIM(CAST(DATEPART(month,@WholeDate) AS char(2))),2) + '/' + right('0' + RTRIM(CAST(DATEPART(day,@WholeDate) AS char(2))),2)
	 
END
go

