CREATE PROCEDURE [dbo].[PatientOnlyGetOrdersByDateRange]
@PatientID int,
@BeginDate datetime,
@EndDate   datetime
AS
	SET NOCOUNT ON

	DECLARE @BDate	datetime,
			@EDate	datetime,
			@Today	datetime

	SET @Today = getdate()

	DECLARE @Days TABLE (
		DateID	int IDENTITY(1,1),
		ODate	datetime)

	SET @BDate = @BeginDate
	SET @EDate = @EndDate

	WHILE (1=1)
	BEGIN
		INSERT INTO @Days
		VALUES (@BDate)

		SET @BDate = DATEADD(d, 1, @BDate)

		IF (@BDate > @EDate)
			BREAK
	END

	SELECT DateID, dbo.DateStringFormat(ODate, 110, @Today) AS ODate FROM @Days
	
	SELECT	O.OrderID,
		O.OrderDate,
		D.DateID,
		dbo.GetMealPeriodNameForOrder(O.OrderID) AS MealPeriod,
		K.Description AS Kitchen
	FROM dbo.tblOrderOHD AS O (NOLOCK)
	LEFT JOIN dbo.tblKitchens AS K (NOLOCK) ON O.SentToKitchenId = K.KitchenId
	LEFT JOIN @Days AS D ON dbo.dDateOnly(O.OrderDate) = D.ODate
	WHERE O.PatientID = @PatientID
		AND O.OrderDate BETWEEN @BeginDate AND @EndDate
	ORDER BY O.OrderDate, O.PostDate

	RETURN
go

