CREATE PROCEDURE [dbo].[ScheduledReportDelete]
@LoginUserID		varchar(250),
@ScheduledReportID	int

AS
	SET NOCOUNT ON

	DELETE dbo.tblScheduledReports
	WHERE ScheduledReportID = @ScheduledReportID

	RETURN
go

