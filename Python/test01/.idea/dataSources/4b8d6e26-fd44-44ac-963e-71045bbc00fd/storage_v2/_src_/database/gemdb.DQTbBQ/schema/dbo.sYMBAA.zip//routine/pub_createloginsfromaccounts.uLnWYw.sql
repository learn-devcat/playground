

CREATE PROCEDURE dbo.pub_CreateLoginsFromAccounts
AS
	SET NOCOUNT ON
	-- Check to see IF the GEMpublic databsae exists
	IF NOT EXISTS(SELECT [name] FROM master..sysdatabases WHERE [name] = 'GEMpublic')
		RETURN 
	-- first, remove any login records not in our gempay accounts table.
	DELETE FROM GEMpublic..tblAccountLogins
	WHERE AccountNo NOT IN (SELECT AccountNo FROM tblAccountOHD WHERE tblAccountOHD.AccountNo = GEMpublic..tblAccountLogins.AccountNo)
	-- Next, remove any login records that have been SET inactive in the GEMpay Account Table
 	--DELETE GEMpublic..tblAccountLogins 
 	--FROM GEMpublic..tblAccountLogins AS G
 	--	INNER JOIN tblAccountOHD AS A ON G.AccountNo = A.AccountNo
 	--WHERE A.Inactive = 1
 	-- now, insert any new records that don't exist in our login table.
 	INSERT INTO GEMpublic..tblAccountLogins(UserID, AccountNo, Password, UserQuestion, UserAnswer)
 		SELECT ISNULL(A.PublicID, A.AccountNo), A.AccountNo, CAST(LOWER(RTRIM(A.LastName)) AS VARBINARY(25)), 'What is my LastName', A.LastName
 		FROM tblAccountOHD AS A
 		WHERE LEN(A.LastName) > 0
 			AND AccountNo NOT IN (SELECT AccountNo FROM GEMpublic..tblAccountLogins WHERE AccountNo = A.AccountNo)
go

