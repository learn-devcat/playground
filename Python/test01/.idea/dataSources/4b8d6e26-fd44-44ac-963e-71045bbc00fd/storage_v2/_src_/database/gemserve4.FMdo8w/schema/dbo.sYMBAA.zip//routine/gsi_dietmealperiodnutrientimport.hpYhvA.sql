
CREATE PROCEDURE [dbo].[GSI_DietMealPeriodNutrientImport]
@LoginUserID		varchar(250),
@DietID		varchar(50),
@NutrientName	varchar(50),
@MealPeriodName	varchar(50),
@Qty		decimal(10,3)
AS
	SET NOCOUNT ON

	DECLARE @NutrientID int,
		@MealPeriodID int,
		@Return int
		
	SET @Return = -1

	SELECT 	@NutrientID = NutrientID
	FROM	dbo.cfgNutrients
	WHERE	[Description] = @NutrientName

	-- Return -1 if Nutrient doesn't exist
	IF (@@RowCount = 0)
	BEGIN
		SET @Return = -1
		GOTO Finished
	END

	SELECT 	@MealPeriodID = MealPeriodID
	FROM	dbo.tblMealPeriods
	WHERE	[Description] = @MealPeriodName

	-- Return -2 if Meal Period doesn't exist
	IF (@@RowCount = 0)
	BEGIN
		SET @Return = -2
		GOTO Finished
	END

	IF NOT EXISTS (SELECT 1 FROM dbo.tblDietMealPeriodNutrients WHERE (DietID = @DietID) AND (NutrientID = @NutrientID) AND (MealPeriodId = @MealPeriodID) AND (Qty = @Qty))
	BEGIN
		INSERT INTO dbo.tblDietMealPeriodNutrients (DietID, NutrientID, MealPeriodID, Qty)
			VALUES (@DietID, @NutrientID, @MealPeriodID, @Qty)

		SELECT @Return = SCOPE_IDENTITY()
	END
	ELSE
	BEGIN
		-- Entry already exists in tblDietMealPeriodNutrients table
		SET @Return = -3
	END

Finished:
	-- Return -1 if Nutrient doesn't exist, -2 if Meal Period doesn't exist, -3 if tblDietMealPeriodNutrients entry already exists, otheriwse return id
	SELECT @Return AS ErrorMessage
	RETURN
go

