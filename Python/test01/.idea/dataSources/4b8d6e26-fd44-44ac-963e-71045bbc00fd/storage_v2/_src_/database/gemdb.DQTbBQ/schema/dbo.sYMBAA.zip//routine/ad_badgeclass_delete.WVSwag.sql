


CREATE PROCEDURE dbo.ad_BadgeClass_Delete
@User			char(10),
@BadgeClassID	int
AS 
	DELETE	tblBadgeClass
	WHERE	BadgeClassID = @BadgeClassID
go

