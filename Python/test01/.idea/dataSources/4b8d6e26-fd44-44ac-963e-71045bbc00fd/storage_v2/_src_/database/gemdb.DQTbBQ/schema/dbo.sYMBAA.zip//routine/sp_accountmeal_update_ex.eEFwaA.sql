
	

CREATE PROCEDURE dbo.sp_AccountMeal_Update_EX
@AccountNo		char(19),
@MealPlanID		int,
@Slot			int,
@ActiveDate		varchar(25),
@ExpireDate		varchar(25),
@Active			bit,
@Count			int = 0
AS
	UPDATE	tblAccountMeal
	SET		Slot = @Slot, Active = @Active
	WHERE	AccountNo = @AccountNo
			AND MealPlanID = @MealPlanID
	UPDATE tblAccountMealTTL
	SET ActiveDate = CAST(@ActiveDate as datetime),
		ExpireDate = CAST(@ExpireDate as datetime),
		CurrentCount = @Count
	WHERE AccountNo = @AccountNo
		AND MealPlanID = @MealPlanID
		AND dbo.dDateOnly(ExpireDate) >= dbo.dDateOnly(getdate())
go

