
CREATE PROCEDURE dbo.MenuItemNutrientAdd
@LoginUserID		varchar(250),
@MenuItemID		int,
@NutrientID		int,
@Qty			int,
@MenuItemNutrientID	int OUTPUT

AS
	SET NOCOUNT ON

	INSERT INTO dbo.tblMenuItemNutrients(MenuItemID, NutrientID, Qty)
		VALUES(@MenuItemID, @NutrientID, @Qty)

	SELECT @MenuItemNutrientID = SCOPE_IDENTITY()
	
	RETURN
go

