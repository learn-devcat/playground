

CREATE PROCEDURE dbo.DietList

AS
	SET NOCOUNT ON

    SELECT  DietID,
            Description,
            AltDescription,
            POSDietID,
            POSDescription,
            Notes,
	Active,
	NPO
    FROM    dbo.tblDietOHD (NOLOCK)
	WHERE Active = 1
    ORDER BY Description

	RETURN
go

