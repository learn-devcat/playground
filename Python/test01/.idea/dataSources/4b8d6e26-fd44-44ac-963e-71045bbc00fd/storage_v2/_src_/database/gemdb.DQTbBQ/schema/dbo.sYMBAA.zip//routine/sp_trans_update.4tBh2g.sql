

CREATE PROCEDURE dbo.sp_Trans_Update
@User		char(10),
@DetailID	uniqueidentifier,
@AccountNo	char(19),
@BadgeNo	char(19),
@TransDate	datetime,
@Category	char(10),
@OutletNo	int,
@TransID	int,
@RefNum		char(6),
@ChkNum		char(6),
@PaymentNo	smallint,
@ServeEmpl	int,
@PostEmpl	int,
@Covers		smallint,
@RevCntr	smallint,
@TransTotal	money,
@Sales1		money,
@Sales2		money,
@Sales3		money,
@Sales4		money,
@Sales5		money,
@Sales6		money,
@Sales7		money,
@Sales8		money,
@Sales9		money,
@Sales10	money,
@Sales11	money,
@Sales12	money,
@Sales13	money,
@Sales14	money,
@Sales15	money,
@Sales16	money,
@Tax1		money,
@Tax2		money,
@Tax3		money,
@Tax4		money,
@Dsc		money,
@Svc		money,
@Comment	varchar(40),
@CoreID		int,
@CycleNo	int=0,
@Auditable	bit=0
AS
	DECLARE @ReturnCode		int,
			@Correction		bit,
			@cMsg			varchar(255)
	
BEGIN TRANSACTION
	SET @Correction = 0
	EXEC @ReturnCode = dbo.sp_Trans_RemovePost @User,@DetailID
	IF (@ReturnCode<>0)
		GOTO ERR_PROC
	EXEC @ReturnCode = dbo.sp_Trans_Post @CoreID,@User,@AccountNo,@BadgeNo,@TransDate,@OutletNo,@RefNum,@ChkNum,
						@TransTotal,@Sales1,@Comment,@CycleNo,@TransID,@Category,@PaymentNo,@ServeEmpl,
						@PostEmpl,@Covers,@RevCntr,@Sales2,@Sales3,@Sales4,@Sales5,@Sales6,@Sales7,@Sales8,
						@Sales9,@Sales10,@Sales11,@Sales12,@Sales13,@Sales14,@Sales15,@Sales16,@Tax1,@Tax2,
						@Tax3,@Tax4,@Dsc,@Svc,0,@Correction,@Auditable
	IF (@ReturnCode<>0)
		GOTO ERR_PROC 
	
COMMIT TRANSACTION
   	--[ UPDATE Log ]---------------------------------------
	SET @cMsg = 'Updated transaction for Account No <' + RTRIM(@AccountNo) + '> RefNo <' + @RefNum + '>'
	EXEC dbo.sp_Logit 2 , @CoreID , @User , @cMsg
	-------------------------------------------------------[ UPDATE Log END ]------
RETURN
ERR_PROC:
	ROLLBACK TRANSACTION
	
	   	--[ UPDATE Log ]---------------------------------------
	SET @cMsg = 'sp_Trans_Update FAILED'
	EXEC dbo.sp_Logit 2 , @CoreID , @User , @cMsg
	-------------------------------------------------------[ UPDATE Log END ]------
	
	RETURN @ReturnCode
go

