CREATE PROCEDURE [dbo].[Micros_MenuItemTypeClassList]
AS
	SET NOCOUNT ON

	DECLARE @SQL nvarchar(4000),
			@MicrosServerName varchar(50)
			
	SELECT @MicrosServerName = COALESCE(dbo.GetOverheadValueNull('MicrosServerName'),'Micros')

	SET @SQL = 'SELECT * FROM OPENQUERY(['+ @MicrosServerName +'],''SELECT	MI_TYPE_SEQ,
		OBJ_NUM,
		[NAME]
	FROM	micros.MI_TYPE_CLASS_DEF
	WHERE [NAME] IS NOT NULL
	ORDER BY CASE WHEN LEFT([NAME],2) = ''''RS'''' THEN 0 ELSE 1 END, [NAME]'')'	
	
	EXEC sp_executesql @SQL
	
	RETURN
go

