
CREATE PROCEDURE [dbo].[GSI_EmployeeImport]
@ImportUserID	varchar(250),
@FirstName		varchar(50),
@LastName		varchar(50),
@LoginUserId	varchar(255),
@UserRole		varchar(50),
@DatabaseName	varchar(255)

AS

-- Return Error Messages:
-- 0 - No errors
-- 1 - Import User ID is not authorized to add user
-- 2 - User Role not found. Database access could not be added for user
-- 3 - Database name is not a valid GEMserve database name
-- 4 - Database name is not a valid GEMenterprise database name
-- 5 - User already exists.  User not added.


	DECLARE	@UserID					int,		
			@UserName	   varchar(100),
			@Active					bit,
			@RequireNewPassword		bit,
			@Language				int,
			@RoleID					int,
			@DatabaseID				int,
			@SlotNumber				int,
			@IsManager				bit,
			@Msg		   varchar(500),
			@Return					int


	SET @Return = 0
	SET @Active = 1
	SET @Language = 1033
	SET @RequireNewPassword = 1
	SET @IsManager = 0
	SET @UserName = RTRIM(@FirstName) + ' ' + RTRIM(@LastName)
	
	--Make sure that Login User is authorized to add users to GEMenterprise
	IF @ImportUserID <> 'GEMimport'
	BEGIN
		SET @Msg = @ImportUserID + ' is not authorized to add user ' + @UserName + '.'
		SET @Return = 1
		GOTO Finished
	END

	--If user does not exist, then add user
	IF NOT EXISTS (SELECT 1 FROM [GEM].dbo.tblUsers WHERE LoginUserID = @LoginUserID)
	BEGIN
		
		--Insert user into database
        INSERT INTO [GEM].dbo.tblUsers(UserName, LoginUserID, Active, RequireNewPassword, Language)
        VALUES(@UserName, @LoginUserID, @Active, @RequireNewPassword, @Language)
        
        --Get the UserId
        SET @UserID = SCOPE_IDENTITY()
        
		--Get role id for user
		SELECT @RoleID = RoleID
		FROM [GEM].dbo.tblRoles
		WHERE [Description] = @UserRole
		
		-- No role found so log error
		IF (@RoleID IS NULL)
		BEGIN
			SET @Msg = 'User Role [' + @UserRole + '] not found.  Database access could not be added for ' + @UserName + '.'
			SET @Return = 2
			GOTO Finished
		END
		
		-- Get GEMserve Database ID
		SELECT @DatabaseID = DatabaseID
		FROM [GEM].dbo.tblDatabases
		WHERE DatabaseName = @DatabaseName
		
		-- If database is invalid, log error message
		IF (@DatabaseID IS NULL)
		BEGIN
			SET @Msg = @DatabaseName + ' is not a valid GEMserve database name. Access could not be added for ' + @UserName + '.'
			SET @Return = 3
			GOTO Finished
		END
		
		-- Get the next slot number
		SELECT @SlotNumber = (ISNULL(MAX(SlotNumber),0) + 1) 
		FROM [GEM].dbo.tblUserDatabases 
		WHERE SlotNumber < 999 
			AND DatabaseID = @DatabaseID
		
		-- Add user to GEMserve database
		INSERT INTO [GEM].dbo.tblUserDatabases(UserID, SlotNumber, RoleID, DatabaseID)
		VALUES (@UserID, @SlotNumber, @RoleID, @DatabaseID)
		
		-- Add managers and system administrators to GEMenteprise
		IF (@UserRole IN ('Manager', 'System Administrator'))
		BEGIN
		
			SET @IsManager = 1
			SET @DatabaseName = 'GEM'
		
			-- Get GEMserve Database ID
			SELECT @DatabaseID = DatabaseID
			FROM [GEM].dbo.tblDatabases
			WHERE DatabaseName = @DatabaseName
			
			-- If GEM database is invalid, log error message
			IF (@DatabaseID IS NULL)
			BEGIN
				SET @Msg = @DatabaseName + 'is not a valid GEMenterprise database name. Access could not be added for ' + @UserName + '.'
				SET @Return = 4
				GOTO Finished
			END
		
			-- Get the next slot number
			SELECT @SlotNumber = (ISNULL(MAX(SlotNumber),0) + 1) 
			FROM [GEM].dbo.tblUserDatabases 
			WHERE SlotNumber < 999
				AND DatabaseID = @DatabaseID
		
			-- Add user to GEMenterprise database
			INSERT INTO [GEM].dbo.tblUserDatabases(UserID, SlotNumber, RoleID, DatabaseID)
			VALUES (@UserID, @SlotNumber, @RoleID, @DatabaseID)
		
		END
		
		IF (@IsManager = 1)
			SET @Msg = 'Added user access for ' + @UserName + ' to GEMserve and GEMenterprise.'
		ELSE
			SET @Msg = 'Added user access for ' + @UserName + ' to GEMserve.'
		
	END
	ELSE
	BEGIN
		SET @Msg = @UserName + ' already exists. User not added.'
		SET @Return = 5
		GOTO Finished
	END

	Finished:
        EXEC [GEM].dbo.LogIt @ImportUserID, @Msg
		SELECT @Return AS ErrorMessage
		RETURN

go

