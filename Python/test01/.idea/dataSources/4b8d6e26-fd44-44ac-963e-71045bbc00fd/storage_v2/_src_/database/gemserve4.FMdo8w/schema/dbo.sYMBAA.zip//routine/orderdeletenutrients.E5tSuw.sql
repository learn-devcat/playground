


CREATE PROCEDURE dbo.OrderDeleteNutrients
@OrderID	int

AS

	DELETE 	dbo.tblPatientNutrientCount	
	WHERE	OrderID = @OrderID
go

