CREATE FUNCTION dbo.GetMealPeriod(@Today datetime)
RETURNS int
BEGIN
	DECLARE @Return	int

	DECLARE @Temp TABLE(MealPeriodID int, BeginTime varchar(5), EndTime varchar(5))

	IF EXISTS(SELECT CAST(KeyOut as int) FROM dbo.tblXlat WHERE xlatId = 'NoReportMealPeriod')
		INSERT INTO @Temp(MealPeriodID)
		SELECT DISTINCT MealPeriodID
		FROM dbo.tblWave 
		WHERE MealPeriodID NOT IN (SELECT CAST(KeyOut as int) FROM dbo.tblXlat WHERE xlatId = 'NoReportMealPeriod')
			AND MealPeriodID IS NOT NULL
	ELSE
		INSERT INTO @Temp(MealPeriodID)
		SELECT DISTINCT MealPeriodID FROM dbo.tblWave	

	UPDATE @Temp SET BeginTime = dbo.TimeString(dbo.MealPeriodStartTime(@Today,MealPeriodID)),
		EndTime = dbo.TimeString(dbo.MealPeriodEndTime(@Today, MealPeriodID))

	SELECT TOP 1 @RETURN = MealPeriodID
	FROM @Temp
	WHERE dbo.TimeString(BeginTime) <= dbo.TimeString(@Today) 
		AND dbo.TimeString(EndTime) >= dbo.TimeString(@Today)
	ORDER BY BeginTime, EndTime

	RETURN ISNULL(@Return, 0)
END
go

