CREATE  PROCEDURE [dbo].[sim140_TransPost]
    @CoreID int ,
    @User char(10) ,
    @AccountNo char(19) ,
    @BadgeNo char(19) ,
    @TransDate datetime ,
    @OutletNo int ,
    @RefNum char(6) ,
    @CheckNum char(6) ,
    @TransTotal money ,
    @Sales1 money ,
    @Comment varchar(40) ,
    @CycleNo int ,
    @TransID int ,
    @Category char(10) = ' ' ,
    @PaymentNo int     = 0 ,
    @ServeEmpl int     = 0 ,
    @PostEmpl int      = 0 ,
    @Covers smallint   = 0 ,
    @RevCntr int       = 0 ,
    @Sales2 money      = 0 ,
    @Sales3 money      = 0 ,
    @Sales4 money      = 0 ,
    @Sales5 money      = 0 ,
    @Sales6 money      = 0 ,
    @Sales7 money      = 0 ,
    @Sales8 money      = 0 ,
    @Sales9 money      = 0 ,
    @Sales10 money     = 0 ,
    @Sales11 money     = 0 ,
    @Sales12 money     = 0 ,
    @Sales13 money     = 0 ,
    @Sales14 money     = 0 ,
    @Sales15 money     = 0 ,
    @Sales16 money     = 0 ,
    @Tax1 money        = 0 ,
    @Tax2 money        = 0 ,
    @Tax3 money        = 0 ,
    @Tax4 money        = 0 ,
    @Dsc money         = 0 ,
    @Svc money         = 0 ,
    @SvcA money        = 0 ,
    @Correction bit    = 0 ,
    @Auditable bit     = 0 ,
    @PostDate datetime = '' ,
    @MealPlanID int    = 0 ,
    @LocationID int    = -1
AS 
    DECLARE @TempTransID int ,
            @TempOutletNo int ,
            @Error int ,
            @TransIDName varchar(25) ,
            @TransDateBegin datetime ,
            @TransDateEnd datetime ,
            @DupeTrans varchar(19) ,
            @ReturnData varchar(max),
            @Msg varchar(200),
			@Swiped bit

    EXEC dbo.sp_Logit 1, @CoreID, @User, @MealPlanID, 950

	-- Gets flag for badge swipe	
	SET @Swiped = dbo.BadgeSwiped(@BadgeNo);
	-- Removes badge swipe character if it exists in @BadgeNo
	SET @BadgeNo = dbo.RemoveBadgeSwipePrefix(@BadgeNo);
      
    SET @TransDateBegin = CAST(dbo.DateOnly(@TransDate) + ' 0:0' AS datetime)          -- Extract the date part from the transaction date coming in ...
    SET @TransDateEnd   = CAST(dbo.DateOnly(@TransDate) + ' 23:59:59.950' AS datetime)
      
    SELECT  @TempTransID = TransID ,
            @TransIDName = description
    FROM    dbo.tblTransDef
    WHERE   TransID = @TransID
   
    SELECT  @TempOutletNo = OutletNo
    FROM    dbo.tblOutletOHD
    WHERE   OutletNo = @OutletNo
   
    IF ( ISNULL(@TempTransID, 0) = 0 ) 
        BEGIN
            SELECT  '/TransID ' + cast( @TransID as varchar(6)) + ' Not Defined'
            RETURN
        END

    IF ( ISNULL(@TempOutletNo, 0) = 0 ) 
      BEGIN
            SELECT  '/Outlet ' + cast( @OutletNo as varchar(6)) + ' Not Defined'
            RETURN
      END
   
      SELECT TOP 1
               @DupeTrans = AccountNo                         -- Let's make sure that this transaction doesn't already exist
      FROM    dbo.tblDetail                                       --   Sure hope the index is up to date!!
      WHERE   AccountNo = @AccountNo
            AND BadgeNo = @BadgeNo
            AND TransDate BETWEEN @TransDateBegin
                           AND     @TransDateEnd
            AND ChkNum = @CheckNum
            AND TransTotal = @TransTotal
            AND OutletNo = @OutletNO
            AND TransID = @TransID
            AND PaymentNo = @PaymentNo


      IF ( @DupeTrans IS NULL)          -- Only a non-dup trans will actually post -- everything else will just ACT like it posted, but really it posted before...
         BEGIN		
         
            EXEC @Error= dbo.sp_Trans_Post @CoreID, @User, @AccountNo,
                  @BadgeNo, @TransDate, @OutletNo, @RefNum,
                  @CheckNum, @TransTotal, @Sales1, @Comment,
                  @CycleNo, @TransID, @Category, @PaymentNo,
                  @ServeEmpl, @PostEmpl, @Covers, @RevCntr, @Sales2,
                  @Sales3, @Sales4, @Sales5, @Sales6, @Sales7,
                  @Sales8, @Sales9, @Sales10, @Sales11, @Sales12,
                  @Sales13, @Sales14, @Sales15, @Sales16, @Tax1,
                  @Tax2, @Tax3, @Tax4, @Dsc, @Svc, @SvcA,
                  @Correction, @Auditable, @PostDate, @MealPlanID,
                  @LocationID, @BadgeSwiped = @Swiped

         END 
      ELSE 
         BEGIN
            SET @msg = 'Duplicate SIM Posting: Acct: '
                  + RTRIM(@AccountNo) + ' Badge: ' + RTRIM(@BadgeNo)
                  + ' Chk #' + @CheckNum + ' Total:'
                  + CAST(@TransTotal AS varchar(12))
            EXEC dbo.sp_Logit 1, @CoreID, @User, @msg
         END		
         					
      IF ( @Error <> 2627 AND @Error <> 0 ) 
         BEGIN
            SELECT  '/SQL Error ' + CAST(@Error AS varchar(25))	
         END
      ELSE 
         BEGIN     -- 21-Apr-14 wjs Don't go home empty handed -- get the new account balance information...
               EXEC @ReturnData = dbo.sim140_GetAccountWithBalance @CoreID , @user,@AccountNo,@BadgeNo,@OutletNo ,@TransID
               SELECT @ReturnData
            -- SELECT  @TransIDName		
         END
go

