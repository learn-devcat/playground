CREATE PROCEDURE [dbo].[sp_Dashboard_UpdateSort]
	@User			char(10),
	@DashboardID    int,
	@NewSortPosition  int
AS

	DECLARE @ExistingID int

	Select @ExistingID = ID
	FROM tblDashboardPages
	WHERE UserID = @User 
	AND ID = @DashboardID

	IF (@ExistingID IS NULL)
	BEGIN
	   INSERT INTO tblDashboardPages(Name, UserID, SerializedRequestData, PageURL, UserHidden, SortPosition, PrivilegeActionID,GoToURL,AllowInteraction)
	   	SELECT Top 1 Name,@User,SerializedRequestData, PageURL ,0,@NewSortPosition,PrivilegeActionID,GoToURL,AllowInteraction
		FROM tblDashboardPages
		WHERE ID = @DashboardID
	END
	ELSE
	BEGIN
		Update tblDashboardPages
		Set SortPosition = @NewSortPosition
		WHERE UserID = @User
		AND ID = @DashboardID
	END
go

