

CREATE PROCEDURE dbo.sp_CycleXLATgetNames
@CoreID int
 AS 
	SELECT distinct XlatID FROM tblCycleXLAT
go

