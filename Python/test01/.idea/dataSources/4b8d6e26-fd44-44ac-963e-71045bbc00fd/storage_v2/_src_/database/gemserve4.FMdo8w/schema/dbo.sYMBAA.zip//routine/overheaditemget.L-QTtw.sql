


CREATE PROCEDURE dbo.OverheadItemGet
@LoginUserID	varchar(250),
@KeyID	varchar(50)

AS
	SET NOCOUNT ON

	SELECT dbo.GetOverheadValue(@KeyID)

	RETURN
go

