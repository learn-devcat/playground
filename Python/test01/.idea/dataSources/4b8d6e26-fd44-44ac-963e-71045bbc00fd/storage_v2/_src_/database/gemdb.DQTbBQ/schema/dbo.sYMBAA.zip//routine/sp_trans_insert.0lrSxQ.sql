

CREATE PROCEDURE dbo.sp_Trans_Insert
@CoreID	int,
@User		char(10),
@AccountNo	char(19),
@BadgeNo	char(19),
@TransDate	datetime,
@OutletNo	int,
@RefNum	char(6),
@CheckNum	char(6),
@TransTotal	money,
@Sales1	money,
@Comment	varchar(40),
@TransID	int,
@Category 	char(10)=' ',
@PaymentNo	int=0,
@ServeEmpl	int=0,
@PostEmpl	int=0,
@Covers	smallint=0,
@RevCntr	int=0,
@Sales2	money=0,
@Sales3	money=0,
@Sales4	money=0,
@Sales5	money=0,
@Sales6	money=0,
@Sales7	money=0,
@Sales8	money=0,
@Sales9	money=0,
@Sales10	money=0,
@Sales11	money=0,
@Sales12	money=0,
@Sales13	money=0,
@Sales14	money=0,
@Sales15	money=0,
@Sales16	money=0,
@Tax1		money=0,
@Tax2		money=0,
@Tax3		money=0,
@Tax4		money=0,
@Dsc		money=0,
@Svc		money=0,
@SvcA		money=0
AS
	DECLARE 	@ReturnCode		int
	EXEC @ReturnCode = dbo.sp_Trans_Post @CoreID,@User,@AccountNo,@BadgeNo,@TransDate,@OutletNo,@RefNum,@CheckNum,
						@TransTotal,@Sales1,@Comment,0,@TransID,@Category,@PaymentNo,@ServeEmpl,
						@PostEmpl,@Covers,@RevCntr,@Sales2,@Sales3,@Sales4,@Sales5,@Sales6,@Sales7,
						@Sales8,@Sales9,@Sales10,@Sales11,@Sales12,@Sales13,@Sales14,@Sales15,@Sales16,
						@Tax1,@Tax2,@Tax3,@Tax4,@Dsc,@Svc,@SvcA,0
	IF @ReturnCode=0
		-- Log table entry
		INSERT INTO tblLog (UserID,CoreID,Description) VALUES(@User,'1','Inserted new transaction into tblDetail - RefNo <' + @RefNum + '>')
	ELSE
		RETURN @ReturnCode
		
	DECLARE 	@cMsg  char(255)
	IF @ReturnCode = 0
		SET @cMsg = 'Inserted new transaction into tblDetail - RefNo <' + @RefNum + '>'
	ELSE
		SET @cMsg = 'tblDetail insert FAILED'
	EXEC dbo.sp_Logit 3 , @CoreID , @User , @cMsg
	
	RETURN @ReturnCode
go

