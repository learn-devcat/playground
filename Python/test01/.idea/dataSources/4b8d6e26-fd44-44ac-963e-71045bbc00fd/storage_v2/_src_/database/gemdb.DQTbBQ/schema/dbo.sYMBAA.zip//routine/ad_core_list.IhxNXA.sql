

CREATE PROCEDURE dbo.ad_Core_List
AS
	SELECT	CoreID,
			Active,
			Description,
			Category,
			SWKEY,
			SWPIN,
			myIP,
			ExceptionIP,
			SysOptions,
			CycleNo
	FROM		cfgCore
	ORDER BY	CoreID
go

