

CREATE PROCEDURE dbo.ad_LocationsList
@UserID	varchar(10)
AS
	IF (@UserID = '')
		SELECT LocationID, Description
		FROM cfgLocations
		ORDER BY Description
	ELSE
		SELECT LocationID, Description
		FROM cfgLocations
		WHERE LocationID NOT IN (SELECT LocationID FROM cfgUserLocations WHERE UserID = @UserID)
		ORDER BY Description
go

