
CREATE  PROCEDURE dbo.sp_AccountMeal_Insert_EX
@AccountNo		char(19),
@MealPlanID		int,
@Slot			int,
@ActiveDate		varchar(25),
@ExpireDate		varchar(25),
@Active			bit,
@Count			int = 0
AS
	DECLARE		@InitialPeriods		int,
			@CurrentCount		int,
			@CurrentBalance	money
	SELECT 		@InitialPeriods = InitialNumPeriods,
			@CurrentCount = ReloadQty,
			@CurrentBalance = ReloadBalance
	FROM		tblPlanOHD
	WHERE	MealPlanID = @MealPlanID
	INSERT INTO	tblAccountMeal (AccountNo,MealPlanID, Slot, PeriodsRemain, Active)
		VALUES (@AccountNo, @MealPlanID, @Slot, @InitialPeriods - 1, @Active)
	INSERT INTO tblAccountMealTTL (AccountNo, MealPlanID, ActiveDate, ExpireDate, CurrentCount, CurrentBalance)
		VALUES (@AccountNo, @MealPlanID, CAST(@ActiveDate as datetime),CAST(@ExpireDate as datetime), @CurrentCount, @CurrentBalance)
go

