

CREATE PROCEDURE dbo.sp_Core_Insert
@CoreID int, 
@sDesc varchar(32)
AS
	INSERT INTO	cfgCore (CoreID, Active, Description)
	VALUES	(@CoreID,'1',@sDesc)
go

