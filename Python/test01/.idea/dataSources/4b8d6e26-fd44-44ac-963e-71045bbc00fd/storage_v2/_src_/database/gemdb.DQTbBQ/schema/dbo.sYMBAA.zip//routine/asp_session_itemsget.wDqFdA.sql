

CREATE   PROCEDURE [dbo].[ASP_Session_ItemsGet]
@UserID		char(10),
@ASPsessionID	bigint

AS
	SELECT 	*       --get session items less than 5 minutes old
	FROM	tblASPsession
	WHERE	ASPsessionID = @ASPsessionID And
		getdate() < (EnteredDate + .0035)

	--delete session items
	DELETE 	tblASPsession
	WHERE	ASPsessionID = @ASPsessionID

	--delete any orphaned session items older than 5 minutes old
	DELETE 	tblASPsession
	WHERE	getdate() > (EnteredDate + .0035)
go

