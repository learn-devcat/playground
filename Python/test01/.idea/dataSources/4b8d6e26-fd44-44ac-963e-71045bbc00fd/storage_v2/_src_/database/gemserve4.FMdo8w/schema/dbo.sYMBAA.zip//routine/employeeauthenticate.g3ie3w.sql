
CREATE PROCEDURE dbo.EmployeeAuthenticate
@LogInUserID	varchar(20),
@Password	varchar(200),
@BadgeNo	varchar(50)=''
AS
	SET NOCOUNT ON

	DECLARE @IsAdmin bit,
		@Return	 int

	IF (@BadgeNo <> '')
	BEGIN
		IF EXISTS (SELECT BadgeNo FROM dbo.tblEmployees WHERE BadgeNo = @BadgeNo)
			SET @Return = 1
		ELSE
			SET @Return = 2

		GOTO Done
	END

	SELECT @IsAdmin = IsAdmin 
	FROM	dbo.tblEmployees
	WHERE	LogInUserID = @LogInUserID
		AND [Password] = @Password

	IF (@@ROWCOUNT = 0)
		SET @Return = 2
	ELSE
		SET @Return = @IsAdmin

Done:	
	SELECT @Return 
	RETURN
go

