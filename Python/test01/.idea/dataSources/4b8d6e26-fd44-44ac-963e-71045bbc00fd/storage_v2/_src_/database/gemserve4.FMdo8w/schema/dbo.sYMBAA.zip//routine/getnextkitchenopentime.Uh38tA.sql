CREATE FUNCTION dbo.GetNextKitchenOpenTime
(@KitchenId	int, @Today	datetime)
RETURNS datetime
AS
BEGIN
	DECLARE @Return datetime,
			@Temp varchar(5)

	SELECT TOP 1 @Temp = StartTime
	FROM dbo.tblKitchenTimes 
	WHERE StartTime > dbo.TimeString(@Today)
		AND DATEPART(dw,@Today) = [Day]
		AND KitchenId = @KitchenId
	ORDER BY StartTime

	IF NOT (@Temp IS NULL)
		SET @Return = dbo.dDatePlusNewTime(@Today, @Temp)

	RETURN @Return
END
go

