CREATE PROCEDURE [dbo].[sp_Chart_BucketBalances]
AS
	SET NOCOUNT ON

	DECLARE @Data TABLE (Balance money, TransClassID int, Description varchar(50))

	INSERT INTO @Data
	VALUES (14209.44,10,'Payroll Deduction'),
	(4931.68,20,'Department'),
	(6733.01,30,'Residents'),
	(-932.04,40,'Gift Cards')

	SELECT * FROM @Data

--SELECT      CASE WHEN TC.DeclBalMode = 1 
--			THEN 0 - SUM(A.Balance)
--            ELSE SUM(A.Balance) END AS Balance, 
-- TC.TransClassID, TC.Description
--FROM dbo.tblAccountTTL AS A
--JOIN dbo.tblTransClass AS TC ON A.TransClassID = TC.TransClassID 
--GROUP BY TC.TransClassID, TC.Description, TC.DeclBalMode

RETURN 0
go

