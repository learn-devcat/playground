CREATE PROCEDURE dbo.ol_GetAccountListMP
@CoreID		int,
@User		varchar(10),
@BadgeNo	varchar(19),
@Slot		int,
@OutletNo	int
AS 
		DECLARE	@AccountNo	varchar(19),
		@LastName	varchar(20),
		@FirstName	varchar(15),
		@Description	varchar(30),
		@MealPlanID     int,
		@CurrentDate	datetime,
		@CurrentTime 	varchar(5),
		@TotalRows	int,
		@ReturnString	varchar(2000),
		@OutletSubType	int
	
	SET @CurrentDate = dbo.dDateOnly(getdate())
	SET @CurrentTime = dbo.TimeOnly(getdate())
	SET @TotalRows = 0
	SET @ReturnString = ''

	SET @BadgeNo = dbo.RemoveBadgeSwipePrefix(@BadgeNo);
	
	SELECT @OutletSubType = SubType FROM tblOutletOHD WHERE OutletNo = @OutletNo
	DECLARE MealPlans cursor FOR
	    SELECT	DISTINCT AO.AccountNo,
					ISNULL(AO.LastName,''),
					ISNULL(AO.FirstName,''),
					P.Name as description, -- ISNULL(AO.Description,''),
					ATT.MealPlanID
		FROM		dbo.tblBadgesOHD AS B
		INNER JOIN 	dbo.tblAccountOHD AS AO  	ON	B.AccountNo = AO.AccountNo  
		INNER JOIN 	dbo.tblAccountMeal AS A   	ON	AO.AccountNo = A.AccountNo
		INNER JOIN 	dbo.tblAccountMealTTL AS ATT ON	A.AccountNo = ATT.AccountNo
					                        AND A.MealPlanID = ATT.MealPlanID
					                        AND @CurrentDate BETWEEN dbo.dDateOnly(ATT.ActiveDate) 
					                        AND dbo.dDateOnly(ATT.ExpireDate)
		INNER JOIN dbo.tblPlanOHD AS P    ON	A.MealPlanID = P.MealPlanID
		INNER JOIN 	dbo.tblPlanDTL AS PD  ON	A.MealPlanID = PD.MealPlanID
				                            AND (@CurrentTime BETWEEN PD.BegTime AND PD.EndTime)
		WHERE	B.BadgeNo = @BadgeNo
			AND A.Slot = @Slot
			AND A.Active = 1    
			AND AO.InActive = 0
			AND B.Inactive = 0
			AND B.Lost     = 0
			AND B.Stolen   = 0
			AND dbo.ddateonly( AO.ActiveDate ) <= dbo.ddateonly( getdate())
			AND dbo.ddateonly( AO.ExpireDate ) >= dbo.ddateonly( getdate())
			AND dbo.ddateonly(  B.ActiveDate ) <= dbo.ddateonly( getdate()) 	-- Active dates only.
			AND dbo.ddateonly(  B.ExpireDate ) >= dbo.ddateonly( getdate())
			AND (P.SubType & @OutletSubType) = P.SubType
		
	OPEN MealPlans
	FETCH NEXT FROM MealPlans INTO @AccountNo, @FirstName, @LastName, @Description, @MealPlanID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @TotalRows = @TotalRows + 1
		
		SET @ReturnString = @ReturnString + CHAR(28) + RTRIM(@AccountNo) + ',' + RTRIM(@BadgeNo) + ',' +
			RTRIM(@LastName) + ',' + RTRIM(@FirstName) + ',' + RTRIM(@Description) + ',' + CAST(@MealPlanID as varchar(10))
		FETCH NEXT FROM MealPlans INTO @AccountNo, @FirstName, @LastName, @Description, @MealPlanID
	END
	CLOSE MealPlans
	DEALLOCATE MealPlans
	IF (@TotalRows > 0)
		SET @ReturnString = 'Success' + CHAR(28) + CAST(@TotalRows AS varchar(8)) + @ReturnString
	ELSE
		SET @ReturnString = 'Success' + CHAR(28) + CAST(@TotalRows AS varchar(8)) --+ @ReturnString

	SELECT @ReturnString
go

