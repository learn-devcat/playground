CREATE PROCEDURE dbo.XlatItemUpdate
@XlatID		varchar(50),
@KeyIn		varchar(100),
@KeyOut		varchar(100),
@Description	varchar(200)=null
AS

	SET NOCOUNT ON

	UPDATE dbo.tblXlat
	SET	[Description] = COALESCE(@Description, [Description])
	WHERE XlatID = @XlatID
		AND KeyIn = @KeyIn
		AND KeyOut = @KeyOut

	IF (@@ROWCOUNT = 0)
		INSERT INTo dbo.tblXlat (XlatID, KeyIn, KeyOut, [Description])
			VALUES (@XlatID, @KeyIn, @KeyOut, @Description)

	RETURN
go

