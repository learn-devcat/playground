


CREATE PROCEDURE [dbo].[sim_RetrieveOrderByOrderID]
@CoreID as int,
@LoginUserID 	varchar(250),
@WorkstationID int,
@OrderID	int
AS
    SET NOCOUNT ON
            
    DECLARE @RoomNumber as varchar(20),
        @SubLevel int,
        @PatientName varchar(50),
        @DietName varchar(50),
        @OrderWorkstationID int,
        @Sent int,
        @Received int,
        @Detail as varchar(4000),
        @Msg as varchar(2200),
        @PatientInfoOnOrder as char(1),
        @OrderDate datetime,
        @StandingOrder bit,
        @DietMenuLevel int,
        @ItemType int,
        @MenuItemID int,
        @POSMenuItemID int,
        @IsDiet bit,
        @OrderType	int,
        @OrderedFor varchar(20),
    @Today datetime,
    @Msg2 varchar(1000)

    SELECT @PatientInfoOnOrder = dbo.GetOverheadValue('PatientInfoOnOrder')

    IF ( @PatientInfoOnOrder = '' )
        SET @PatientInfoOnOrder = '0'

    SELECT @Today = getdate();

    SELECT @RoomNumber = R.RoomNumber + ISNULL(PV.Bed,''),
        @SubLevel = O.SubLevel,
        @PatientName = P.FullName, 
    @OrderWorkstationID = O.WorkstationID,
    @Sent = O.Sent,
    @Received = O.Received,
    @DietName = DT.Description,
    @OrderDate = O.OrderDate,
    @StandingOrder = O.StandingOrder,
    @DietMenuLevel = COALESCE(DT.MenuLevel,1),
    @OrderType = O.OrderType,
    @OrderedFor = O.OrderedFor
    FROM    dbo.tblOrderOHD O
        LEFT JOIN dbo.tblPatientOHD AS P (NOLOCK) ON O.PatientID = P.Patientid
        LEFT JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON O.PatientVisitID = PV.PatientVisitID
            AND PV.MergedTo IS NULL
            AND PV.DischargeDate IS NULL
        LEFT JOIN dbo.tblPatientDiet AS PD (NOLOCK) 
            ON PD.[ID] = dbo.GetActivePatientDietID(PV.PatientVisitId, O.OrderDate)
        LEFT JOIN dbo.tblDietOHD AS DT (NOLOCK) ON PV.DietID = DT.DietID
        LEFT JOIN dbo.tblRoomOHD AS R (NOLOCK) ON PV.RoomID = R.RoomID
    WHERE   O.OrderID = @OrderID
                     
    IF( @@ROWCOUNT = 0)
    BEGIN
        SELECT '/Order Not On File' AS rMsg
        RETURN
    END
    
    IF( @Received <> 0)
    BEGIN
        SELECT '/Order Already Sent' AS rMsg
        RETURN
    END
     
    -- Get Detail
    SELECT @Msg = 'RETRIEVE' + char(28) + CAST(@OrderID as varchar(10)) + '^' + @RoomNumber + '^' + 
    CASE
        WHEN @PatientInfoOnOrder = '1' THEN @PatientName 
        ELSE ''
    END + '^' + CAST(@SubLevel as varchar(5)) + '^' +
        @DietName + '^' + dbo.DateString(@OrderDate) + ' ' + dbo.TimeString(@OrderDate) + '^' 
    
    SET @Msg = @Msg + dbo.GetOrderDetail(@OrderID, @OrderType, 0)

    SET @Msg = @Msg + '^' + CAST(@DietMenuLevel AS varchar(10)) + '^' +
    CAST(@OrderType as varchar(10)) + '^' + @OrderedFor +
    char(28) + CAST(@StandingOrder AS char(1)) 

    SET @Msg2 = 'Order canceled due to order pick up. Order ID: ' + CAST(@OrderID AS varchar(30))
    EXEC dbo.OrderSETCancelled @LoginUserID, @OrderID, 1, @Today, @Msg2, 800

    IF(@Msg IS NULL)
            SELECT '/Unable To Retrieve Order' as rMsg
    ELSE
            SELECT @Msg AS rMsg
go

