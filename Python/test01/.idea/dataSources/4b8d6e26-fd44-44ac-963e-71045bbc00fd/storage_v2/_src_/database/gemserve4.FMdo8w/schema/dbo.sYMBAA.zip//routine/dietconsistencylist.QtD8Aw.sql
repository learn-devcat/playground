CREATE PROCEDURE [dbo].[DietConsistencyList]

AS
SET NOCOUNT ON

	SELECT	Main_Mlvl_Seq,
			Consistency
	FROM	dbo.tblDietConsistency
	WHERE	Consistency IS NOT NULL

	RETURN
go

