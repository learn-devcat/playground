CREATE FUNCTION [dbo].[MealCountForMonthByLocationEX](@WhatMonth as int, @WhatYear as int, @LocationID as int, @OrderType int)
RETURNS int
BEGIN
	DECLARE @Return int

	/*
		Order Type - Matches the INQ number from the SIM
		================================================
		1 = Patient Order
		2 = Guest Order
		4 = Parent Order
		6 = Dr. Order
		7 = Stork Order
	*/

	SELECT @Return = COUNT([Date])
	FROM dbo.tblOrderLOG AS L (NOLOCK)
	JOIN dbo.tblOrderOHD AS O (NOLOCK) ON L.OrderID = O.OrderID
	WHERE MONTH([Date]) = @WhatMonth
		AND YEAR([Date]) = @WhatYear
		AND COALESCE(O.RoomID, -1) IN (SELECT RoomID FROM dbo.tblRoomOHD WHERE LocationClassID = @LocationID)
		AND dbo.GetActionID('RECEIVED') = ActionID
		AND COALESCE(O.OrderType,1) = @OrderType

	RETURN COALESCE(@Return, 0)
END
go

