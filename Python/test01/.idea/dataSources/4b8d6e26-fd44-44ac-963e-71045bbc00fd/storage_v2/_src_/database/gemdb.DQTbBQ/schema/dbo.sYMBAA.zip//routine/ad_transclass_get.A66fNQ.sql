

CREATE PROCEDURE [dbo].[ad_TransClass_Get]
@User				char(10),
@TransClassID		int
AS 
	SELECT	TransClassID,
			Description,
			Status,
			DisablePOSPosting,
			DeclBalMode,
			AddToBadgeBalance,
			SubType,
			EnableTimepay,
			Limit,
			MinTransaction,
			MaxTransaction,
			MaxPeriods,
			MinPayment,
			RecurChgClassID,
			TransID,
			RecurChgPayTransID,
			Breakpoints,
			Automatic,
			ContributeToGlobalBalance
	FROM	tblTransClass
	WHERE	TransClassID = @TransClassID
go

