

CREATE FUNCTION dbo.GetMealPeriodName(@OrderDate datetime)
RETURNS varchar(50)
BEGIN
	DECLARE @Return	varchar(50)

	SELECT TOP 1 @Return = M.[Description]
	FROM	dbo.tblMealPeriods AS M
		JOIN dbo.tblWave AS W ON M.MealPeriodID = W.MealPeriodID
	WHERE dbo.TimeString(W.BeginTime) < dbo.TimeString(@OrderDate) 
		AND dbo.TimeString(W.EndTime) > dbo.TimeString(@OrderDate)
	ORDER BY W.BeginTime

	RETURN ISNULL(@Return, 'None')
END
go

