
CREATE  PROCEDURE dbo.WorkorderDTLClass_Delete
@User                   char(10),
@WorkOrderDTLClassID    int
AS
	DELETE	tblWorkorderDTLClass
	WHERE   WorkOrderDTLClassID = @WorkOrderDTLClassID
go

