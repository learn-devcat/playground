








CREATE        PROCEDURE dbo.EmployeeOHD_Get
@User			char(10),
@EmployeeID		int
AS
    SELECT  	E.EmployeeID,
	        E.EmployeeClassID,
	        C.EmployeeClassName,
	        C.Description,
	        RTRIM(LastName) + ', ' + RTRIM(FirstName) as FullName,
		EmployeeNumber,
	        LocationID,
                FirstName,
                LastName,
                PhoneNumber,
                PagerNumber,
                CellNumber,
                eMail,
                SkillLevel,
                UserID,
		Password,
                PasswordQuestion,
                PasswordAnswer,
                LastLogonDate,
                ExpireDate,
                ActiveDate,
                Notes,
		WorkorderClassID,
		LaborCenterID,
                LogonHours,
                C.CanCreateWorkOrder,
                C.CanDeleteWorkOrder,
                C.CanCloseWorkOrder,
                C.CanPrintWorkOrder,
                C.CanCompleteWorkOrderDTL,
                C.CanAddWorkOrderDTL,
                C.CanDeleteWorkOrderDTL	,
		C.ViewAllWorkorders,
		C.ViewWorkordersInClass,
		C.AdjustWorkorderCharge,
		C.ConfigString	
        FROM	tblEmployeeOHD E
	    LEFT JOIN tblEmployeeClass C on C.EmployeeClassID = E.EmployeeClassID
	    WHERE   EmployeeID = @EmployeeID
go

