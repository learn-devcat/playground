CREATE PROCEDURE [dbo].[NonSelectDetailUpdate]
@LoginUserID		varchar(250),
@NonSelectItemID	int,
@NonSelectOrderID	int,
@MenuItemID		int,
@ItemType		int,
@IsDiet			bit,
@IsFreeText		bit,
@FreeText		varchar(250)

AS

	SET NOCOUNT ON

	IF (@NonSelectItemID <=0)
		INSERT INTO dbo.tblNonSelectDetail (NonSelectOrderID, MenuItemID, ItemType, IsDiet, IsFreeText, [FreeText])
			VALUES (@NonSelectOrderID, @MenuItemID, @ItemType, @IsDiet, @IsFreeText, @FreeText)

	ELSE
		UPDATE dbo.tblNonSelectDetail
		SET MenuItemID = COALESCE(@MenuItemID,MenuItemID),
			ItemType = COALESCE(@ItemType,ItemType),
			IsDiet = COALESCE(@IsDiet,IsDiet),
			IsFreeText = COALESCE(@IsFreeText,IsFreeText),
			[FreeText] = COALESCE(@FreeText,[FreeText])
		WHERE NonSelectItemID = @NonSelectItemID

	RETURN
go

