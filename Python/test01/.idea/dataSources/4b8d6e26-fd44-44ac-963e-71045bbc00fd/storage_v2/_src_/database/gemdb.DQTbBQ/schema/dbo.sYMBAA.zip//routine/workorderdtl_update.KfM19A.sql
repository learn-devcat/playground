
CREATE           PROCEDURE dbo.WorkorderDTL_Update
@User                   char(10),
@WorkorderID            int, 
@WorkOrderDTLID         int, 
@WorkOrderDTLDefID      int,        
@AssigningEmployeeID    int = 0,
@AssignedEmployeeID	int = 0,
@CompletingEmployeeID   int = 0,
@AssignmentDate         datetime = null,
@CompletionDate         datetime = null,   
@Completed              bit = 0,
@ActualHours            money = 0,      
@ActualStartDate        datetime = null,
@ScheduledStartDate     datetime = null, 
@Price                  money = 0.00,    
@Notes                  VarChar(500) = '',
@PriceChangeReason	varchar(250),
@Cost                   money = 0.00     
AS
	DECLARE @Err	int
	SET NOCOUNT ON
	UPDATE	tblWorkorderDTL
        SET WorkOrderDTLDefID   = @WorkOrderDTLDefID,
            AssigningEmployeeID = @AssigningEmployeeID,
	    AssignedEmployeeID 	= @AssignedEmployeeID,
            AssignmentDate      = @AssignmentDate,
            CompletingEmployeeID= @CompletingEmployeeID,
            Completed           = @Completed,           
            Price               = @Price,
            Cost                = @Cost,
            ActualHours         = Round(@ActualHours,2),
            ScheduledStartDate  = @ScheduledStartDate,
            ActualStartDate     = @ActualStartDate,
            CompletionDate      = @CompletionDate, 
            Notes               = @Notes, 
	    PriceChangeReason	= @PriceChangeReason
	WHERE	WorkOrderID    = @WorkOrderID AND
	        WorkOrderDTLID = @WorkOrderDTLID 
	IF @@Error <> 0
	    SET @Err = @@Error
	    
	SELECT @Err
	
RETURN
go

