CREATE FUNCTION [dbo].[GetActiveDietNotesEX]
(@PatientVisitID varchar(50), @Today datetime, @WaveID int)

RETURNS varchar(3000)

AS
	BEGIN
		-- PATCH 4.0.3 3/15/10 -- Changes to only retrieve the notes for the Active Date
		DECLARE @Return	varchar(3000),
			@EndTime char(5),
			@ORMSeparator varchar(10),
			@Description varchar(1000),
			@NoteID		int,
			@TransactionIdentifier varchar(50),
			@ActiveOnly int

		SELECT @ActiveOnly = COALESCE(dbo.GetOverheadValueNull('NotesForActiveDietOnly'), 1)

		DECLARE @Notes TABLE (NoteID int, NoteType int, ActiveDate datetime, Description varchar(1000))

		SELECT @ORMSeparator = COALESCE(dbo.GetOverheadValueNULL('ORMSeparator'),'|')

		IF (@ActiveOnly = 1) -- Shows notes for active diet only or manual notes
		BEGIN
			SELECT @TransactionIdentifier = TransactionIdentifier
			FROM dbo.tblPatientDiet (NOLOCK)
			WHERE [ID] = dbo.GetActivePatientDietID(@PatientVisitID, @Today)

			IF (@WaveID > 0)
			BEGIN
				SELECT @EndTime = EndTime
				FROM dbo.tblWave (NOLOCK)
				WHERE WaveID = @WaveID

				SET @Today = dbo.dDatePlusNewTime(@Today,@EndTime)
			END

			INSERT INTO @Notes (NoteID, NoteType, ActiveDate, Description)
			SELECT NoteID, NoteType, ActiveDate, Notes
			FROM dbo.tblPatientNotes
			WHERE PatientVisitID = @PatientVisitID
				AND dbo.GetCancelStatus(CancelDate, @Today) = 0
				AND ActiveDate <= @Today
				AND (TransactionIdentifier = @TransactionIdentifier OR TransactionIdentifier = '')
		END
		ELSE IF (@ActiveOnly = 2) -- Shows notes for active diet only, manual notes, and any non-diet notes such as supplements, etc.
		BEGIN
			SELECT @TransactionIdentifier = TransactionIdentifier
			FROM dbo.tblPatientDiet (NOLOCK)
			WHERE [ID] = dbo.GetActivePatientDietID(@PatientVisitID, @Today)

			IF (@WaveID > 0)
			BEGIN
				SELECT @EndTime = EndTime
				FROM dbo.tblWave (NOLOCK)
				WHERE WaveID = @WaveID

				SET @Today = dbo.dDatePlusNewTime(@Today,@EndTime)
			END

			INSERT INTO @Notes (NoteID, NoteType, ActiveDate, Description)
			SELECT NoteID, NoteType, ActiveDate, Notes
			FROM dbo.tblPatientNotes
			WHERE PatientVisitID = @PatientVisitID
				AND dbo.GetCancelStatus(CancelDate, @Today) = 0
				AND ActiveDate <= @Today
				AND ((TransactionIdentifier = @TransactionIdentifier OR TransactionIdentifier = '') OR NoteType <> 100)
		END		
		ELSE -- Shows all diet notes regardless of diet
		BEGIN
			IF (@WaveID > 0)
			BEGIN
				SELECT @EndTime = EndTime
				FROM dbo.tblWave (NOLOCK)
				WHERE WaveID = @WaveID

				SET @Today = dbo.dDatePlusNewTime(@Today,@EndTime)
			END

			INSERT INTO @Notes (NoteID, NoteType, ActiveDate, Description)
			SELECT NoteID, NoteType, ActiveDate, Notes
			FROM dbo.tblPatientNotes
			WHERE PatientVisitID = @PatientVisitID
				AND dbo.GetCancelStatus(CancelDate, @Today) = 0
				AND ActiveDate <= @Today
		END

		/* The Notes field is no longer used in the tblPatientDiet table - JLB 01/24/14
		SELECT TOP 1 @Return = Notes
		FROM dbo.tblPatientDiet
		WHERE PatientVisitID = @PatientVisitID
			AND ActiveDate <= @Today
		ORDER BY ActiveDate DESC, PostDate DESC
		*/

		-- Make sure our variable is not null
		SET @Return = COALESCE(@Return, '')

		-- Add all of the tblPatientNotes values
		WHILE (1=1)
		BEGIN
			SET @Description = NULL
			
			-- PATCH 10/14/10 - Notes beginning with an asterick have the first priority in the sort order
			SELECT TOP 1 @Description = CASE WHEN LEFT(Description,1) = '*' 
				THEN RIGHT(Description,LEN(Description)-1) 
				ELSE Description END,
				@NoteID = NoteID
			FROM @Notes
			ORDER BY CASE WHEN LEFT(Description,1) = '*' THEN 0 ELSE 1 END,
				ActiveDate DESC, NoteID

			IF (@Description IS NULL)
				BREAK

			SET @Return = @Return + @ORMSeparator + @Description
			
			DELETE @Notes 
			WHERE NoteID = @NoteID
		END		

		SET @Return = RTRIM(LTRIM(@Return))

		IF (RIGHT(@Return,1) = @ORMSeparator)
			SET @Return = LEFT(@Return,LEN(@Return) - 1)

		IF (LEFT(@Return,1) = @ORMSeparator)
			SET @Return = RIGHT(@Return,LEN(@Return) - 1)

		RETURN ISNULL( @Return, '' )
	END
go

