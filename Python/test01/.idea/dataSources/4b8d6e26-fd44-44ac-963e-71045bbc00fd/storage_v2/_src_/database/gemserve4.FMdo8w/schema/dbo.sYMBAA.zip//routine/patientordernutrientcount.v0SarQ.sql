
CREATE FUNCTION dbo.PatientOrderNutrientCount(@OrderID int, @FieldSeparator char(1))
RETURNS varchar(255)
BEGIN

	DECLARE @Return 	varchar(255),
		@Qty		decimal(10,3)

	SET @Return = ''

	-- Cursor to retrieve the nutrient values for a specific order
	DECLARE Nutrients cursor FOR
		SELECT P.Qty
		FROM cfgNutrients AS N (NOLOCK)
			LEFT JOIN tblPatientNutrientCount AS P (NOLOCK) ON P.NutrientID = N.NutrientID AND P.OrderID = @OrderID
		ORDER BY N.NutrientID

	OPEN Nutrients
	FETCH NEXT FROM Nutrients INTO @Qty

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @Return = @Return +@FieldSeparator + CAST(ISNULL(CAST(@Qty * 1000 AS int), 0) AS varchar(10))
		
		FETCH NEXT FROM Nutrients INTO @Qty
	END

	CLOSE Nutrients
	DEALLOCATE Nutrients

	IF (LEN(@Return) > 0)
		SET @Return = RIGHT(@Return,LEN(@Return)-1)

	RETURN @Return	
END
go

