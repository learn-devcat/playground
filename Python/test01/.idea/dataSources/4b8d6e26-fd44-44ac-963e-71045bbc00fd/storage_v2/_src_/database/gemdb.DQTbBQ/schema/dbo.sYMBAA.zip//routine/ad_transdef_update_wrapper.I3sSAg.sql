CREATE PROCEDURE [dbo].[ad_TransDef_Update_Wrapper]
    @User char(10) ,
    @TransID int ,
    @VendingID int ,
    @TransClassID int ,
    @SubType int ,
    @SourceXfer int ,
    @Description varchar(24) ,
    @glAccount varchar(16) ,
    @Category char(10) ,
    @Status int ,
    @Payment bit ,
    @EnforceSchedule smallint ,
    @Preset money ,
    @TransLimit money ,
    @SlotNo smallint = 0 ,
    @IsMealPlan bit = 0 ,
    @ResetTtlQty bit = 0 ,
    @VendorID int ,
    @MachineTAG varchar(16) ,
    @OutletNo int ,
    @LocationID int ,
    @InActive bit ,
    @RefundAllowed bit ,
    @MaxItemPrice money ,
    @Comment varchar(255) ,
    @AllSame bit = 0 ,
    @item1 smallint = 0 ,
    @item2 smallint = 0 ,
    @item3 smallint = 0 ,
    @item4 smallint = 0 ,
    @item5 smallint = 0 ,
    @item6 smallint = 0 ,
    @item7 smallint = 0 ,
    @item8 smallint = 0 ,
    @item9 smallint = 0 ,
    @item10 smallint = 0 ,
    @item11 smallint = 0 ,
    @item12 smallint = 0 ,
    @item13 smallint = 0 ,
    @item14 smallint = 0 ,
    @item15 smallint = 0 ,
    @item16 smallint = 0 ,
    @item17 smallint = 0 ,
    @item18 smallint = 0 ,
    @item19 smallint = 0 ,
    @item20 smallint = 0 ,
    @item21 smallint = 0 ,
    @item22 smallint = 0 ,
    @item23 smallint = 0
AS 
	SET NOCOUNT ON

    DECLARE @err1 int ,
        @err2 int		
		
    BEGIN TRANSACTION 
	
    EXEC dbo.ad_TransDef_Update @User, @TransID, @TransID, @TransClassID,
        @SubType, @SourceXfer, @Description, @glAccount, @Category, @Status,
        @Payment, @EnforceSchedule, @Preset, @TransLimit, @SlotNo, @IsMealPlan,
        @AllSame, @item1, @item2, @item3, @item4, @item5, @item6, @item7,
        @item8, @item9, @item10, @item11, @item12, @item13, @item14, @item15,
        @item16, @item17, @item18, @item19, @item20, @item21, @item22, @item23,
        @ResetTtlQty
	    
    SET @err1 = @@ERROR
    
    IF ( @VendingID = -1 ) 
        BEGIN
    	--if vendid is -1, we aren't adding or editing a vending item
            SET @err2 = 0
        END
    ELSE 
        BEGIN
			--we check for the existing vending id here because the insert and update
			--sprocs should stay automonous. That is to say, the update sproc should
			--only update items known to exist.
            IF ( NOT EXISTS ( SELECT    1
                              FROM      dbo.tblVendingDTL
                              WHERE     ID = @VendingID )
               ) 
                EXEC dbo.ad_Vending_Insert @Description, @VendorID,
                    @MachineTAG, NULL, NULL, @OutletNo, @TransID, @LocationID,
                    @InActive, @RefundAllowed, @MaxItemPrice, @Comment
		  
            ELSE 
                EXEC dbo.ad_Vending_Update @VendingID, @Description, @VendorID,
                    @MachineTAG, NULL, NULL, @OutletNo, @TransID, @LocationID,
                    @InActive, @RefundAllowed, @MaxItemPrice, @Comment
	
            SET @err2 = @@ERROR    	
        END
	
    IF ( @err1 <> 0 ) 
        BEGIN
            ROLLBACK TRANSACTION
            SET @err1 = 1
        END
    ELSE 
        IF ( @err2 <> 0 ) 
            BEGIN
                ROLLBACK TRANSACTION
                SET @err1 = 2
            END	
        ELSE 
            COMMIT TRANSACTION
	
    SELECT @err1
go

