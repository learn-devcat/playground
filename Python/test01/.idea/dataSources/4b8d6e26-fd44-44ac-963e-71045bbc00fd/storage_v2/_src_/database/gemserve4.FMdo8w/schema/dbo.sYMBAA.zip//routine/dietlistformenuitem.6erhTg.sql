CREATE PROCEDURE dbo.DietListForMenuItem
@MenuItemID	int

AS
	SET NOCOUNT ON



	SELECT  DISTINCT D.POSDietID AS DietID,
	    	D.POSDescription AS [Description],
		CASE WHEN dbo.GetTSLocation(T.RowStart, T.ColStart) = 0 THEN 0
			ELSE CAST(COALESCE(T.DietID,0) AS bit) 
		END AS OnDiet
	FROM    dbo.tblDietOHD AS D (NOLOCK)
		LEFT JOIN dbo.tblMenuItem_Touchscreen AS T (NOLOCK) ON D.POSDietID = T.DietID 
			AND T.MenuItemID = @MenuItemID
			AND (T.RowStart > 0 AND T.ColStart > 0)
	WHERE 	D.Active = 1
		AND D.POSDietID > 0
	ORDER BY D.[POSDescription]
		
	RETURN
go

