

CREATE PROCEDURE dbo.ScanInsert_Bulk
@ImportFile	nvarchar(400),
@FormatFile	nvarchar(400)
AS
	SET NOCOUNT ON

	DECLARE @SQL	nvarchar(2000)

	SET @SQL = 'BULK INSERT dbo.tblScan FROM ''' + @ImportFile +
		''' WITH (FORMATFILE=''' + @FormatFile + ''')'

	EXEC sys.sp_executesql @SQL

	RETURN
go

