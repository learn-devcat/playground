
CREATE FUNCTION dbo.PatientAllergenOptions(@PatientID int)
RETURNS varchar(5000)
BEGIN
	DECLARE @Return varchar(5000),
		@Allergen varchar(50)

	SET @Return = ''

	DECLARE Allergens cursor FOR
		SELECT CASE
				WHEN P.AllergenID IS NULL THEN '0'
				ELSE '1'
			END AS Allergen
		FROM	cfgAllergens AS A (NOLOCK) 
			LEFT JOIN tblPatientAllergens AS P (NOLOCK) ON P.AllergenID = A.AllergenID
				AND P.PatientID = @PatientID
		ORDER BY A.[Description]

	OPEN Allergens

	FETCH NEXT FROM Allergens INTO @Allergen

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @Return = @Return + ',' + @Allergen
		
		FETCH NEXT FROM Allergens INTO @Allergen
	END

	CLOSE Allergens
	DEALLOCATE Allergens

	IF (LEN(@Return) > 0)
		SET @Return = RIGHT(@Return,LEN(@Return)-1)

	RETURN @Return	
END
go

