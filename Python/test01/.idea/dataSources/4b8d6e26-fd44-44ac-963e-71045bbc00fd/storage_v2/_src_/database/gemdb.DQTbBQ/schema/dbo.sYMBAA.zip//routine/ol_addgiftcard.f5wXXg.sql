CREATE PROCEDURE [dbo].[ol_AddGiftCard]
    @CoreID int ,
    @User char(10) ,
    @BadgeNo char(19) ,
    @TransTotal money = 0 ,
    @CheckNum char(6) = '' ,
    @LastName char(20) = 'Valued Customer' ,
    @TransID int = 3000 ,
    @OutletNo int = 3000 ,
    @Phone char(15) = '' ,
    @FirstName char(15) = '' ,
    @RefNum char(6) = '' ,
    @Address1 varchar(40) = '' ,
    @Address2 varchar(40) = '' ,
    @Address3 varchar(40) = '' ,
    @Address4 varchar(40) = '' ,
    @Address5 varchar(40) = '' ,
    @Comment varchar(40) = '' ,
    @Category char(10) = 'GIFTCARD' ,
    @PaymentNo int = 1 ,
    @ServeEmpl int = 0,
	@LocationID int = 0
AS 
    DECLARE	@ReturnCode int,
			@ActiveDate datetime, 
			@ExpireDate datetime, 
			@TransDate datetime, 
			@ExpireDays int,
			@AccountNo char(19),
			@MiddleName char(15)

	--stop sp messages from being returned
    SET NOCOUNT ON

	--Temporary Fix until Online can be fixed to take a middle name parameter - JLB 01-17-2017
	SET @MiddleName = ''

    SELECT TOP 1
            @AccountNo = B.AccountNo
    FROM    tblBadgesOHD AS B
            LEFT JOIN tblAccountTTL AS T ON T.AccountNo = B.AccountNo
    WHERE   B.BadgeNo = @BadgeNo
            AND T.TransClassID = 3000
    ORDER BY B.PrimaryBadge ,
            B.Accountno DESC
    IF ISNULL(@AccountNo, '') > '' 
        BEGIN 
            SELECT  '/Card Already Active'
            RETURN
        END

    SET @LastName = LEFT(@Lastname, 20)		-- So we don't overflow our buffer.
    BEGIN TRANSACTION
	
		--Insert and update a new account
    EXEC @ReturnCode = dbo.sp_Account_Insert @User, @BadgeNo, 3000
    IF ( @ReturnCode <> 0 ) 
        GOTO AddFailed
		
    SELECT  @ExpireDays = ISNULL(sValue, '365')
    FROM    cfgOverhead
    WHERE   UPPER(oKey) = 'GCEXPIREDAYS'
    
    SET @ActiveDate = GETDATE()
    SET @ExpireDate = GETDATE() + CAST(@ExpireDays AS int)

    EXEC @ReturnCode = dbo.sp_Account_Update @User, @BadgeNo, '', 0, '',
        @FirstName, @MiddleName, @LastName, @Phone, '', '', 3000, '', @ActiveDate,
        @ExpireDate, 0, 0, 0, 0, 0, 0, 0, 0, @LocationID


    IF ( @ReturnCode <> 0 ) 
        GOTO AddFailed
											
		--Insert and update a new badge
    EXEC @ReturnCode = dbo.sp_Badge_Insert @User, @BadgeNo, @BadgeNo
    IF ( @ReturnCode <> 0 ) 
        GOTO AddFailed
		
    EXEC @ReturnCode = dbo.sp_Badge_Update @User, @BadgeNo, @BadgeNo, @BadgeNo,
        0, 1, @ActiveDate, @ExpireDate, 3000, '', @FirstName, @MiddleName, @LastName,
		999999, 999999, '', 0, 0, 0, 999999, @LocationID

    IF ( @ReturnCode <> 0 ) 
        GOTO AddFailed
		
		--Insert account TTL     
    EXEC @ReturnCode = dbo.sp_AccountTTL_Insert @User, @BadgeNo, 3000
    IF ( @ReturnCode <> 0 ) 
        GOTO AddFailed
		
		--Insert and update account address
    EXEC @ReturnCode = dbo.sp_Address_Insert @User, 10, @BadgeNo
    IF ( @ReturnCode <> 0 ) 
        GOTO AddFailed
		
    EXEC @ReturnCode = dbo.sp_Address_Update @User, 10, 10, @BadgeNo,
        @Address1, @Address2, @Address3, @Address4, @Address5
    IF ( @ReturnCode <> 0 ) 
        GOTO AddFailed
		
		--Insert the transaction
    SET @TransDate = GETDATE()
    EXEC @ReturnCode = dbo.sp_Trans_Post @CoreID, @User, @BadgeNo, @BadgeNo,
        @TransDate, @OutletNo, @RefNum, @CheckNum, @TransTotal, @TransTotal,
        @Comment, 0, @TransID, @Category, @PaymentNo, @ServeEmpl       

    IF ( @ReturnCode <> 0 ) 
        GOTO AddFailed
		
		--Add succeeded, so commit and return
    COMMIT TRANSACTION
    SELECT  'Success'
    RETURN
	
    AddFailed:
		
		--Add failed, so return failure message		
    ROLLBACK TRANSACTION
    IF ( @ReturnCode = 2627 ) 
        SELECT  '/Card Already Active'
    ELSE 
        SELECT  '/Account Activation Failed'
go

