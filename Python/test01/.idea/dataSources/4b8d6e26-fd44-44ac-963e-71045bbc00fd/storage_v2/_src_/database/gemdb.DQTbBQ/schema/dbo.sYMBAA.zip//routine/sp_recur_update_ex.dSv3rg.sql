
CREATE       PROCEDURE [dbo].[sp_Recur_Update_EX]
@User			char(10),
@RecurID		uniqueidentifier,
@AccountNo		char(19),
@ClassID		int,
@AcctClassID	int,
@TransID		int,
@OutletNo		int,
@Description	char(24),
@Amount			money,
@Percent		money,
@Minimum		bit,
@Balance		bit,
@PastDue		bit,
@TrackSlotNum	int,
@TrackIDNum		int,
@tax1			bit,
@tax2			bit,
@tax3			bit,
@tax4			bit,
@Active			bit,
@AllowNegAmt		bit,
@BatchID		char(10),
@ExpiredAccountsOnly	bit, 
@PostToAltAccount	bit, 
@AltAccountNo		varchar(19), 
@AltBadgeNo		varchar(19), 
@AltTransID		int,
@AltOutletNo	int,
@UseOutletClassBal BIT,
@Formula		VARCHAR(500),
@BalanceMax		money
		
AS 
		SET Nocount ON

		UPDATE 	tblRecurChg
		SET		AccountNo = @AccountNo,
				ClassID = @ClassID,
				AcctClassID = @AcctClassID,
				TransID = @TransID,
				OutletNo = @OutletNo,
				Description = @Description,
				Amount = @Amount,
				[Percent] = @Percent,
				Minimum = @Minimum,
				Balance = @Balance,
				PastDue = @PastDue,
				TrackSlotNum = @TrackSlotNum,
				TrackIDNum = @TrackIDNum,
				Tax1 = @tax1,
				Tax2 = @tax2,
				Tax3 = @tax3,
				Tax4 = @tax4,
				Active = @Active,
				AllowNegAmt = @AllowNegAmt,
				BatchID = @BatchID,
				ExpiredAccountsOnly = @ExpiredAccountsOnly,
				PostToAltAccount = @PostToAltAccount,
				AltAccountNo = @AltAccountNo, 
				AltBadgeNo = @AltBadgeNo, 
				AltTransID = @AltTransID,
				AltOutletNo = @AltOutletNo,
				UseOutletClassBal = @UseOutletClassBal,
				Formula = @Formula,
				BalanceMax = CASE WHEN @BalanceMax = 0 THEN NULL ELSE @BalanceMax END

		WHERE	RecurID = @RecurID

		SELECT @@Error
go

