
CREATE	FUNCTION dbo.GetRecurAmount (
					@AccountNo 		char(19),
					@AccountClassID 	int, 
					@Amount 		money, 
					@TransID 		int, 
					@PastDue 		bit, 
					@Minimum 		bit, 
					@Balance 		bit, 
					@TrackSlotNum 		int, 
					@TrackIDNum 		int,
					@CycleNo		int,
					@Today			datetime,
					@AllowNegAmt		bit) 
RETURNS money
AS 
BEGIN 
	
	DECLARE @ReturnAmount	money,
			@TransIDAmount	money,
			@PastDueAmount	money,
			@BalanceAmount	money,
			@TrackAmount	money,
			@AccountTTL		int,
			@IsPayment	int,
			@AllowNegativeRecurring	int
	
	DECLARE @item1	int,
			@item2	int,
			@item3	int,
			@item4	int,
			@item5	int,
			@item6	int,
			@item7	int,
			@item8	int,
			@item9	int,
			@item10	int,
			@item11	int,
			@item12	int,
			@item13	int,
			@item14	int,
			@item15	int,
			@item16	int,
			@Chg1	money,
			@Chg2	money,
			@Chg3	money,
			@Chg4 	money,
			@Chg5	money,
			@Chg6	money,
			@Chg7	money,
			@Chg8	money,
			@Chg9	money,
			@Chg10	money,
			@Chg11	money,
			@Chg12	money,
			@Chg13	money,
			@Chg14	money,
			@Chg15	money,
			@Chg16	money
		-- TODO --Get PastDueAmount total
			
			
		--Get TransIDAmount total
			SELECT	@TransIDAmount = Preset
 			FROM	tblTransDef
 			WHERE	TransID = @TransID
			
			--Get the BalanceAmount total (AccountTTL)
			SET @AccountTTL = dbo.GetTTLFromTransID(@TransID)
			SELECT 	@BalanceAmount = ISNULL(Balance ,0)
			FROM	tblAccountTTL
			WHERE	AccountNo = @AccountNo AND
					TransClassID = @AccountTTL
	
			--Get the TrackAmount total
			IF ISNULL(@AccountClassID,0) = 0
				SELECT @AccountClassID = AccountClassID
				FROM	tblAccountOHD
				WHERE	AccountNo = @AccountNo
				
			SELECT 	@item1 = item1,
					@item2 = item2,
					@item3 = item3,
					@item4 = item4,
					@item5 = item5,
					@item6 = item6,
					@item7 = item7,
					@item8 = item8,
					@item9 = item9,
					@item10 = item10,
					@item11 = item11,
					@item12 = item12,
					@item13 = item13,
					@item14 = item14,
					@item15 = item15,
					@item16 = item16
			FROM	tblTrackingOHD INNER JOIN
					tblAccountClass
			ON		tblTrackingOHD.TrackingGrp = tblAccountClass.TrackingGrp
			WHERE	tblAccountClass.AccountClassID = @AccountClassID
			SELECT	@Chg1 = ISNULL(Chg1,0),
					@Chg2 = ISNULL(Chg2,0),
					@Chg3 = ISNULL(Chg3,0),
					@Chg4 = ISNULL(Chg4,0),
					@Chg5 = ISNULL(Chg5,0),
					@Chg6 = ISNULL(Chg6,0),
					@Chg7 = ISNULL(Chg7,0),
					@Chg8 = ISNULL(Chg8,0),
					@Chg9 = ISNULL(Chg9,0),
					@Chg10 = ISNULL(Chg10,0),
					@Chg11 = ISNULL(Chg11,0),
					@Chg12 = ISNULL(Chg12,0),
					@Chg13 = ISNULL(Chg13,0),
					@Chg14 = ISNULL(Chg14,0),
					@Chg15 = ISNULL(Chg15,0),
					@Chg16 = ISNULL(Chg16,0)
			FROM	tblTrackingTTL
			WHERE	tblTrackingTTL.AccountNo = @AccountNo AND
					tblTrackingTTL.CycleNo = @CycleNo
			IF @TrackIDNum = @item1 SET @TrackAmount = ISNULL(@Chg1,0)
			IF @TrackIDNum = @item2 SET @TrackAmount = ISNULL(@Chg2,0)
			IF @TrackIDNum = @item3 SET @TrackAmount = ISNULL(@Chg3,0)
			IF @TrackIDNum = @item4 SET @TrackAmount = ISNULL(@Chg4,0)
			IF @TrackIDNum = @item5 SET @TrackAmount = ISNULL(@Chg5,0)
			IF @TrackIDNum = @item6 SET @TrackAmount = ISNULL(@Chg6,0)
			IF @TrackIDNum = @item7 SET @TrackAmount = ISNULL(@Chg7,0)
			IF @TrackIDNum = @item8 SET @TrackAmount = ISNULL(@Chg8,0)
			IF @TrackIDNum = @item9 SET @TrackAmount = ISNULL(@Chg9,0)
			IF @TrackIDNum = @item10 SET @TrackAmount = ISNULL(@Chg10,0)
			IF @TrackIDNum = @item11 SET @TrackAmount = ISNULL(@Chg11,0)
			IF @TrackIDNum = @item12 SET @TrackAmount = ISNULL(@Chg12,0)
			IF @TrackIDNum = @item13 SET @TrackAmount = ISNULL(@Chg13,0)
			IF @TrackIDNum = @item14 SET @TrackAmount = ISNULL(@Chg14,0)
			IF @TrackIDNum = @item15 SET @TrackAmount = ISNULL(@Chg15,0)
			IF @TrackIDNum = @item16 SET @TrackAmount = ISNULL(@Chg16,0)
			
	
	/* PROCESS THE AMOUNT */		
	IF (@PastDue = 1)
		--get the past due amount for this account
		SET @ReturnAmount = dbo.GetPastDue(@AccountNo, @TransID, @Today - 7)
	ELSE
	BEGIN
		IF (@Amount <> 0)
		BEGIN
			--check to see IF this is a 'minimum' amount
			IF (@Minimum = 1)
			BEGIN
				--Get the Balance or Tracking AND compare it to the Amount (min)
				IF (@Balance = 1)
					--Get the account balance FROM the AccountTTL
					SET @ReturnAmount = @BalanceAmount
				ELSE
				BEGIN
					--IF (@TrackSlotNum <> 0)
						--get the slot number, the TransID AND the amount FROM the TrackingOHD AND TrackingTTL
					--ELSE
					IF (@TrackIDNum <> 0)
						--check the TrackingOHD to see IF this TransID is being tracked. IF so, get the amount
					 	SET @ReturnAmount = @TrackAmount
				END
				--Process for the minimum amount
				--IF this is a payment TransID, then reverse the Balance sign
				SELECT @IsPayment = Payment
				FROM 	tblTransDef
				WHERE TransID = @TransID
				IF (@IsPayment = 1)
				BEGIN
					SET @ReturnAmount = -@ReturnAmount
				END
				IF (@ReturnAmount - @Amount < 0)
					SET @ReturnAmount = ABS(@ReturnAmount - @Amount)											
				ELSE
					SET @ReturnAmount = 0
			END
			ELSE
			BEGIN
				--Added code here to allow a restriction on the maximum amount that can be charged at one time	1/17/2003 rbishop
				--IF the Amount is greater than 0 then it is a maximum threshold, so reset the amount being charged
				--to the @Amount value
				-- The code referenced above was embeded in the code for when the "Minimum" bit was on, therefore the minimum bit had to be on for it to run,
				-- AND then the code for the minimum bit would alter this code, making it incorrect. The code was moved to this position AND altered slightly
				-- to make it work here. Tests show correct operation. change made 3/17/2006 rbeverly
				IF ((@Amount > @BalanceAmount) AND (@Balance = 1))
					SET @ReturnAmount = @BalanceAmount
				ELSE
					SET @ReturnAmount = @Amount
			END
		END
		ELSE
		BEGIN
			IF (@TransIDAmount <> 0)
				--use the TransDef amount for processing
				SET @ReturnAmount = @TransIDAmount
			ELSE				
			BEGIN
				IF (@Balance = 1)
					--get the balance for this account FROM AccountTTL
					SET @ReturnAmount = @BalanceAmount
				ELSE
				BEGIN
					--IF (@TrackSlotNum <> 0)
						--get the slot number, the TransID AND the amount FROM the TrackingOHD AND TrackingTTL
					--ELSE
					IF (@TrackIDNum <> 0)
						--check the TrackingOHD to see IF this TransID is being tracked. IF so, get the amount
						SET @ReturnAmount = @TrackAmount
					ELSE
					 	--no amount was found, so nothing to post!
		 				SET @ReturnAmount = 0
				END
			END
		END
	END		
	IF ( @ReturnAmount < 0 AND @AllowNegAmt = 0 )
		SET @ReturnAmount = 0
	RETURN @ReturnAmount		
END
go

