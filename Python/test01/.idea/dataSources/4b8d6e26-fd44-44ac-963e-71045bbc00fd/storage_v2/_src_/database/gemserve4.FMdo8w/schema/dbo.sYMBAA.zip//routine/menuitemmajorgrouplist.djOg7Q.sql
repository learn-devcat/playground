

CREATE PROCEDURE dbo.MenuItemMajorGroupList
AS
	SET NOCOUNT ON

	SELECT	MenuItemMajorGroupID,
		MAJ_GRP_SEQ,
		OBJ_NUM,
		[NAME]
	FROM	dbo.tblMenuItemMajorGroup
	WHERE [NAME] IS NOT NULL

	RETURN
go

