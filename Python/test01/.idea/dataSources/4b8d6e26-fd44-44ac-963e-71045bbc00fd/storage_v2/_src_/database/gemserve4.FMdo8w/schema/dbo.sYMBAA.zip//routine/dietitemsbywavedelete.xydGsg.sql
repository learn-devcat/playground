

CREATE PROCEDURE dbo.DietItemsByWaveDelete
@LoginUserID		varchar(250),
@DietID		int,
@WaveID		int

AS
	SET NOCOUNT ON

	DELETE	dbo.tblDietDtl 
	FROM	dbo.tblDietDtl AS DD (NOLOCK)
		JOIN dbo.tblDietWave AS DW (NOLOCK) ON DD.DietWaveID = DW.DietWaveID
	WHERE	DW.DietID = @DietID
		AND DW.WaveID = @WaveID

	RETURN
go

