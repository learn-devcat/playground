

CREATE PROCEDURE [dbo].[ad_AccountCategory_Delete]
@User			char(10),
@Category		char(10)
AS 
	SET NOCOUNT ON
	
	DELETE tblAccountCategory WHERE Category = @Category
	
	IF(@@ROWCOUNT = 0)
		SELECT 'Database failed deleting category: [' + @Category + ']' 
	ELSE
		SELECT ''
go

