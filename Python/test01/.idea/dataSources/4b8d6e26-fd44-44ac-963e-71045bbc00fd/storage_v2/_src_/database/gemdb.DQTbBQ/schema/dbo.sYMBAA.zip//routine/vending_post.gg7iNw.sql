CREATE PROCEDURE [dbo].[Vending_Post]
@CoreID	integer,
@User		char(10),
@BadgeNo	char(19),
@MachineTAG	varchar(50),
@ChkNum	varchar(10),
@Total		money
AS

	DECLARE @AccountNo 	char(19),
			@Today		datetime,
			@Comment	varchar(40),				-- comments cause statements & reports to use extra lines so use sparingly ...
			@RefNumber   varchar(10),
			@BadgeClassID int,
			@AccountClassID int,
			@OutletNO int,
			@LocationID int,
			@CashierID int,
			@TransID int,
			@MealPlanID int
			

	SET @Today = getdate()
	SET @CashierID = 0				-- Not using employees or cashiers yet, so just dummy this up.
	--SET @MealPlanID = 0				-- TODO: Resolve at some point --
	SET @Comment = ''				-- TODO: Any exceptions should stuff an explanation here.  (40 chars max, of course)
	SET @RefNumber = 'Vending'

	--SET @RefNumber = 'VM-' + CAST(@TerminalID AS varchar(25))
	

	-- Resolve the accountno
	-- ordering by  primarybadge' DESC'  helps us to make sure we are getting any primary's on top (since 1 = primary 0=not)
	-- we need to also ensure we are getting the badge inside the active-expire date range as well as one that isn't lost or stolen..
	
	SELECT TOP 1 @AccountNo = AccountNo,
				@BadgeClassID = BadgeClassID
	FROM	tblBadgesOHD B
	WHERE	BadgeNo = @BadgeNo
			AND Inactive = 0
			AND Lost = 0
			AND Stolen = 0
			AND dbo.dDateOnly(b.ActiveDate) <= dbo.dDateOnly(@Today)
			AND dbo.dDateOnly(b.ExpireDate) >= dbo.dDateOnly(@Today)
	order by b.PrimaryBadge DESC

	--set @AccountNo = ISNULL( @AccountNo , '' )				-- in case we don't resolve the badge no.
	
	Select @AccountClassID = AccountClassID
	from   tblAccountOHD
	where  AccountNO = @AccountNO

	if( @@ROWCOUNT = 0 )				-- Should never happen, but if it does, let's still try to post this trans...
		select @AccountClassID = @BadgeClassID
   
	

	Select @OutletNo = OutletNo,
			@TransID = TransID,
			@LocationID = LocationID
	from	 tblVendingDTL
	where	MachineTAG = @MachineTAG 
			and Isnull( AccountClassID , @AccountClassID ) =  @AccountClassID
			and Isnull( BadgeClassID , @BadgeClassID ) = @BadgeClassID

	-- This should never happen...
	if( @OutletNo = 0 ) or (@TransID = 0 )
	  begin
			select 0.03 as ReturnValue
			return
	  end

	-- Resolve the Meal Plan ID, if there is one ..
	SELECT @MealPlanID = ISNULL(dbo.VM_ValidateMealPlan(@AccountNo,@TransID,@OutletNO, getdate(), 1), 0)


	-- post it
	EXEC sp_Trans_Post @CoreID, @User, @AccountNo, @BadgeNo , @Today , 
			@OutletNO,@RefNumber, @ChkNum, @Total , @Total,
			 @Comment, 	-- comment
			-1 , @TransID,
			'', 0, @CashierID, 0, 0, @OutletNO,
			0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'',@MealPlanID
go

