
CREATE PROCEDURE [dbo].[sim_GetOrdersForWave]
@WaveID			int,
@WaveDate		varchar(30),
@RoomNumber		varchar(10),
@OrderType		int=1,
@PatientVisitID	varchar(50)=''
AS
	SET NOCOUNT ON

	DECLARE @OrderID	int,
			@OrderedFor	varchar(16),
			@OrderWave	varchar(30),
			@POSRoomLookup	int,
			@TotalOrders	int,
			@ReturnString varchar(4000)

	SET @ReturnString = ''

	SELECT @POSRoomLookup = COALESCE(dbo.GetOverheadValueNull('POSRoomLookup'),0)

	IF (@POSRoomLookup = 1)
		SET @RoomNumber = @RoomNumber + '%'

	SELECT @TotalOrders = COUNT(OrderID)
		FROM dbo.tblOrderOHD AS O (NOLOCK)
			JOIN dbo.tblRoomOHD AS R (NOLOCK) ON O.RoomID = R.RoomID
		WHERE   dbo.dDateOnly(OrderDate) = dbo.dDateOnly(@WaveDate)
				AND WaveID = @WaveID
				AND COALESCE(Cancelled,0) = 0
				AND R.RoomNumber LIKE @RoomNumber
				AND O.OrderType = @OrderType
				AND O.PatientVisitID = CASE WHEN @PatientVisitID <> '' THEN @PatientVisitID
						ELSE '%' END

	DECLARE Orders CURSOR FOR
		SELECT O.OrderID, 
		CASE WHEN O.OrderType = 1 THEN LEFT(P.LastName,15) ELSE OrderedFor END,
		O.OrderType,
		W.Description
		FROM dbo.tblOrderOHD AS O (NOLOCK)
			JOIN dbo.tblRoomOHD AS R (NOLOCK) ON O.RoomID = R.RoomID
			JOIN dbo.tblWave AS W (NOLOCK) ON O.WaveID = W.WaveID
			LEFT JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON O.PatientVisitID = PV.PatientVisitID
			LEFT JOIN dbo.tblPatientOHD AS P (NOLOCK) ON PV.PatientID = P.PatientID
		WHERE   dbo.dDateOnly(OrderDate) = dbo.dDateOnly(@WaveDate)
				AND O.WaveID = @WaveID
				AND COALESCE(Cancelled,0) = 0
				AND R.RoomNumber LIKE @RoomNumber
				AND O.OrderType = @OrderType
				AND O.PatientVisitID = CASE WHEN @PatientVisitID <> '' THEN @PatientVisitID
						ELSE '%' END
		ORDER BY P.LastName

	OPEN Orders

	FETCH NEXT FROM Orders INTO @OrderID, @OrderedFor, @OrderType, @OrderWave

	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @ReturnString = @ReturnString + CAST(@OrderID AS varchar(10)) + ',' + @OrderedFor +
		',' + CAST(@OrderType AS varchar(5)) + ',' + @OrderWave + CHAR(28)

		FETCH NEXT FROM Orders INTO @OrderID, @OrderedFor, @OrderType, @OrderWave
	END

	CLOSE Orders
	DEALLOCATE Orders

	IF (LEN(@ReturnString) > 0)
		SET @ReturnString = LEFT(@ReturnString,LEN(@ReturnString) - 1)		

	SET @ReturnString = CAST(@TotalOrders AS varchar(10)) + CHAR(28) + @ReturnString
	SELECT @ReturnString AS rMsg
go

