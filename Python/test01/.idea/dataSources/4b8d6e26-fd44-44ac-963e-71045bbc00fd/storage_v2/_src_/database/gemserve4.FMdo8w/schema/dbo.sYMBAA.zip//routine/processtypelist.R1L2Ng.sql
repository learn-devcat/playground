


CREATE PROCEDURE dbo.ProcessTypeList

AS

	SELECT ProcessTypeID,
		[Description],
		Source
	FROM	dbo.cfgProcessTypes (NOLOCK)
	ORDER BY [Description]

	RETURN
go

