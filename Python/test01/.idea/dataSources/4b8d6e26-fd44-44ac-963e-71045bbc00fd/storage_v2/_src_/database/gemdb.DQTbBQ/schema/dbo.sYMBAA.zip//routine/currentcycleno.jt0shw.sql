

CREATE FUNCTION dbo.CurrentCycleNo (@CoreID int)
RETURNS smallint
AS 
BEGIN 
	DECLARE @CycleNo integer
	-- Check the cfgCore table for the CycleNo value.
	SELECT @CycleNo = CycleNo FROM cfgCore WHERE CoreID = @CoreID
	-- Default to 1 (Write/Updates) IF we didn't get one.
	RETURN ISNULL( @CycleNo, 1 )
END
go

