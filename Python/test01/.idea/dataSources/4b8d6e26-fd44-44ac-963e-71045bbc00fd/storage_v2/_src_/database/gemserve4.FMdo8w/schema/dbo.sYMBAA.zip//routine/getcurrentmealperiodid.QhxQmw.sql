
CREATE FUNCTION dbo.GetCurrentMealPeriodID(@Today datetime)
RETURNS int
AS
BEGIN
        DECLARE @MealPeriodID int

        SELECT TOP 1 @MealPeriodID = MealPeriodID
            FROM dbo.tblWave (NOLOCK)
	    WHERE BeginTime <= dbo.TimeString(@Today)
	            AND EndTime >= dbo.TimeString(@Today)
	    ORDER BY EndTime

        RETURN ISNULL(@MealPeriodID,0)
END
go

