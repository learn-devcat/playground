

CREATE PROCEDURE dbo.gem_UserDeleteLocation
@UserID		varchar(10),
@LocationID	int = -1
AS
	IF (@LocationID = -1)
		DELETE cfgUserLocations WHERE UserID = @UserID
	ELSE
		DELETE cfgUserLocations WHERE UserID = @UserID AND LocationID = @LocationID
go

