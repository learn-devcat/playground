


CREATE PROCEDURE dbo.ProcessTypeDelete
@LoginUserID		varchar(250),
@ProcessTypeID	int

AS

	DELETE dbo.cfgProcessTypes WHERE ProcessTypeID = @ProcessTypeID

	RETURN
go

