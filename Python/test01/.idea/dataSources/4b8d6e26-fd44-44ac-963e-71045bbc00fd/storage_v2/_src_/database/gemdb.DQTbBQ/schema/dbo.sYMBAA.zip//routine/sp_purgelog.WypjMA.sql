CREATE PROCEDURE [dbo].[sp_PurgeLog]

AS

	DECLARE	@LogRetentionDays	int,
			@LogRetentionDate	datetime,
			@cMsg 				char(255)
	
	SET	@LogRetentionDays = ISNULL(NULLIF(dbo.GetOverheadItem('LogRetentionDays'),''), 180)
	SET @LogRetentionDate = dbo.dDateOnly(getdate() - @LogRetentionDays)
	SET @cMsg = 'MAINTENANCE: Purged logs prior to ' + CONVERT(varchar(10), @LogRetentionDate,120) + '.'

	IF (ISDate(@LogRetentionDate) = 1)
	BEGIN
		DELETE FROM dbo.tblLog
		WHERE LogDate < @LogRetentionDate
		
		EXEC dbo.sp_Logit 0 , 1, 'DAILY', @cMsg
	END
go

