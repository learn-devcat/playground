

CREATE PROCEDURE dbo.MenuItemAllergenAddByName
@LoginUserID		varchar(250),
@MenuItemID		int,
@AllergenName		varchar(50),
@MenuItemAllergenID	int OUTPUT

AS
	SET NOCOUNT ON

	DECLARE @AllergenID int

	SELECT 	@AllergenID = AllergenID
	FROM	dbo.cfgAllergens
	WHERE	[Description] = @AllergenName

	IF NOT (@AllergenID IS NULL)
	BEGIN
		INSERT INTO dbo.tblMenuItemAllergens(MenuItemID, AllergenID)
			VALUES(@MenuItemID, @AllergenID)

		SELECT @MenuItemAllergenID = SCOPE_IDENTITY()		
	END
	ELSE	
		SET @MenuItemAllergenID = -1

	RETURN
go

