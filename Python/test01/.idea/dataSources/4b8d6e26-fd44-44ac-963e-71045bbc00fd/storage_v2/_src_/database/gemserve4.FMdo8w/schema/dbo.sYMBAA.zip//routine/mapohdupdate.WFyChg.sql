

CREATE PROCEDURE dbo.MapOHDUpdate
@MapNumber	int,
@Title		varchar(50),
@SubTitle	varchar(50),
@Description	varchar(50),
@CssSrc		varchar(128),
@Href		varchar(255)

AS
	UPDATE	dbo.tblMapOHD
	SET	Title = @Title,
		SubTitle = @SubTitle,
		Description = @Description,
		CssSrc = @CssSrc,	
		Href = @Href
	WHERE	MapNumber = @MapNumber
go

