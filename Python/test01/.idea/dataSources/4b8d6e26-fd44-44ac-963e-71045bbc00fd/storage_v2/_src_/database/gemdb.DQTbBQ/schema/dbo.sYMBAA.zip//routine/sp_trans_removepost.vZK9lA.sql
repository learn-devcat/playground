CREATE    PROCEDURE dbo.sp_Trans_RemovePost
@User		char(10),
@DetailID	uniqueidentifier
AS
DECLARE 	@CoreID	int,
		@UserCoreID	int,
		@AccountNo	char(19),
		@BadgeNo	char(19),
		@TransDate	datetime,
		@PostDate	datetime,
		@OutletNo	int,
		@RefNum	char(6),
		@ChkNum	char(6),
		@TransTotal	money,
		@Category 	char(10),
		@PaymentNo	int,
		@ServeEmpl	int,
		@PostEmpl	int,
		@Covers	smallint,
		@RevCntr	int,
		@Sales1	money,
		@Sales2	money,
		@Sales3	money,
		@Sales4	money,
		@Sales5	money,
		@Sales6	money,
		@Sales7	money,
		@Sales8	money,
		@Sales9	money,
		@Sales10	money,
		@Sales11	money,
		@Sales12	money,
		@Sales13	money,
		@Sales14	money,
		@Sales15	money,
		@Sales16	money,
		@Tax1		money,
		@Tax2		money,
		@Tax3		money,
		@Tax4		money,
		@Dsc		money,
		@Svc		money,
		@SvcA		money,
		@Comment	varchar(40),
		@CycleNo	int,
		@TransID	int,
		@Qty		int,
		@TransClassID	int,
		@IsPayment	int,
		@CurrentCycle	int,
		@Correction	bit,
		@CurrentError	int,
		@ReturnCode	int,
		@HasClearance	int,
		@cMsg		varchar(255),
		@Auditable	bit,
		@xlatID		varchar(20),
		@MealPlanID	int,
		@myMsg		varchar(50)
	SET @CurrentError=0
	
		SET @Qty=1
		SET @Correction=1
		SET @SvcA=0
		--Get the VALUES FROM the tblDetail record
		SELECT	@CoreID	=CoreID,
				@AccountNo	=AccountNo,
				@BadgeNo	=BadgeNo,
				@TransDate	=TransDate,
				@PostDate	=PostDate,
				@OutletNo	=OutletNo,
				@RefNum	=RefNum,
				@ChkNum	=ChkNum,
				@TransTotal	=TransTotal,
				@Category	=Category,
				@PaymentNo	=PaymentNo,
				@ServeEmpl	=ServeEmpl,
				@PostEmpl	=PostEmpl,
				@Covers	=Covers,
				@RevCntr	=RevCntr,
				@Sales1	=Sales1,
				@Sales2	=Sales2,
				@Sales3	=Sales3,
				@Sales4	=Sales4,
				@Sales5	=Sales5,
				@Sales6	=Sales6,
				@Sales7	=Sales7,
				@Sales8	=Sales8,
				@Sales9	=Sales9,
				@Sales10	=Sales10,
				@Sales11	=Sales11,
				@Sales12	=Sales12,
				@Sales13	=Sales13,
				@Sales14	=Sales14,
				@Sales15	=Sales15,
				@Sales16	=Sales16,
				@Tax1		=Tax1,
				@Tax2		=Tax2,
				@Tax3		=Tax3,
				@Tax4		=Tax4,
				@Dsc		=Dsc,
				@Svc		=Svc,
				@Comment	=Comment,
				@CycleNo	=CycleNo,
				@TransID	=TransID,
				@Auditable  =Auditable,
				@MealPlanID	=MealPlanID
		FROM		tblDetail
		WHERE 	DetailID=@DetailID
		-- Get the xlatID
		SELECT	@xlatID = AC.CycleXRefID
		FROM		tblAccountOHD	AS A
				INNER JOIN
				tblAccountClass AS AC
		ON		A.AccountClassID = AC.AccountClassID
		WHERE	A.AccountNo = @AccountNo
		-- Get the cycleNo for this transaction
		SET @CycleNo = dbo.GetCycleByXREF(@CycleNo, @PostDate, @xlatID)
		SET @CurrentError=@@ERROR
		IF (@CurrentError<>0)
			GOTO	END_PROCEDURE
		SELECT	@CurrentCycle = X.CycleNo
		FROM		tblAccountOHD	AS A
				INNER JOIN
				tblAccountClass AS AC
		ON		A.AccountClassID = AC.AccountClassID
				INNER JOIN		
				tblCycleXlat AS X
		ON		AC.CycleXRefID = X.xlatid
		WHERE	getdate() BETWEEN X.BeginDate AND X.EndDate
				AND A.AccountNo = @AccountNo
		SET @CurrentError=@@ERROR
		IF (@CurrentError<>0)
			GOTO	END_PROCEDURE
		SET @UserCoreID=dbo.GetCoreIDFromUser(@User)
		IF (@CoreID = 0)
			SET @CoreID = 1
		--Check latest security model for proper clearance (30002 is the actionID for deleting a transaction)
		SET @HasClearance = dbo.IsPermitted(@User, 30002)
		IF (@HasClearance = 0)
			BEGIN
				SET @CURRENTERROR=5001
				GOTO END_PROCEDURE
			END
		
		--DELETE the detail item
		EXEC @CurrentError=sp_Trans_DetailDelete @User,@DetailID
		IF (@CurrentError<>0)
			GOTO END_PROCEDURE
		EXEC @CurrentError=sp_Trans_Post @CoreID,@User,@AccountNo,@BadgeNo,@TransDate,@OutletNo,@RefNum,@ChkNum,@TransTotal,
							@Sales1,@Comment,@CycleNo,@TransID,@Category,@PaymentNo,@ServeEmpl,@PostEmpl,@Covers,
							@RevCntr,@Sales2,@Sales3,@Sales4,@Sales5,@Sales6,@Sales7,@Sales8,@Sales9,@Sales10,
							@Sales11,@Sales12,@Sales13,@Sales14,@Sales15,@Sales16,@Tax1,@Tax2,@Tax3,@Tax4,
							@Dsc,@Svc,@SvcA,@Correction,@Auditable,'',@MealPlanID
							
		SET @CurrentError=@@ERROR
		IF (@CurrentError<>0)
			GOTO END_PROCEDURE
		
	SET @cMsg = 'Posting removed - Detail ID <' + CAST(@DetailID as varchar(50)) + '>'
	EXEC dbo.sp_Logit 1 , @CoreID , @User , @cMsg

	RETURN 0
END_PROCEDURE:
	
	IF (@CurrentError = 5001) 
		SET @cMsg = 'sp_Trans_RemovePost FAILED. Permission denied. Check user security levels' + ISNULL(@myMsg,'Null')
	ELSE
		SET @cMsg = 'sp_Trans_RemovePost FAILED. Error #' + @CurrentError
	EXEC dbo.sp_Logit 1 , @CoreID , @User , @cMsg

	RETURN @CurrentError
go

