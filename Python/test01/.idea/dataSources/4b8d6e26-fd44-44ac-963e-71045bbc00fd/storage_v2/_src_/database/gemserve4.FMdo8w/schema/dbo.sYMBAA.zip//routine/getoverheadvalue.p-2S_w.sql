

----------------------------------------------------------------------------------
--
--  GetOverheadValue             16-Aug-03 w.j.scott
--
--  This function will retrieve a value from the Overhead, which is local to 
--  the current database.  
--
--  TODO: future version can check the current overhead, and if not found,
--        revert to the GEM overhead.
--
--
-----------------------------------------------------------------------------------
CREATE FUNCTION dbo.GetOverheadValue
(
	@KeyID varchar(50)
)
RETURNS varchar(50)
AS
	BEGIN
	    declare @Value varchar(50)
	    
	    Select @Value = Value 
	      from cfgOverhead
	     where KeyID = @KeyID
	        
	    RETURN isNull( @Value , '' )  	    
	END
go

