CREATE PROCEDURE [dbo].[sim_Diet_Get]
@CoreID INT, @LoginUserID VARCHAR (250), @PatientVisitID VARCHAR (50), @WaveID INT, @WaveDate DATETIME
AS
SET NOCOUNT ON

	DECLARE @Qty		int,
		@Description		varchar(50),
		@DietID		int,
		@POSDietID	int,
		@ChainID		int,
		@TimeOffset		int,
		@Notes			varchar(500),
		@DietNotes		varchar(500),
		@ReturnString		varchar(2000),
		@BeginTime		char(5),
		@DietMenuLevel		int,
		@MealPeriodID   int,
		@PatientID int,
		@TempNotes		varchar(500),
		@OnHold		bit,
		@DOBonPOS	varchar(5),
		@DOB		varchar(50),
		@WaveOnPOS	varchar(5),
		@WaveName	varchar(50),
		@Separator	varchar(10),
		@PatientDietID	int,
		@PatientName	varchar(50)

	SELECT @DOBonPOS = COALESCE(dbo.GetOverheadValueNull('DOBOnPOS'),'0')
	SELECT @WaveOnPOS = COALESCE(dbo.GetOverheadValueNull('WaveOnPOS'),'0')
	SELECT @Separator = COALESCE(dbo.GetOverheadValueNull('ORMSeparator'),'|')

	IF (@WaveOnPOS = '1')
		SELECT @WaveName = 'Wave=[' + Description + '] '
		FROM dbo.tblWave
		WHERE WaveID = @WaveID
	ELSE
		SET @WaveName = ''

	SELECT @BeginTime = EndTime
	FROM dbo.tblWave 
	WHERE WaveID = @WaveID

	SELECT @PatientID = PatientID
	FROM dbo.tblPatientVisit
	WHERE PatientVisitID = @PatientVisitID
	
	SELECT @PatientName = FullName
	FROM dbo.tblPatientOHD
	WHERE PatientID = @PatientID

	-----------------------------------------------------------------------------------------------------------------
	-- MODIFICATION TO HANDLE ANYTIME WAVE
	-----------------------------------------------------------------------------------------------------------------
	-- If an order is being processed for an 'Anytime' Wave, we need to use the current date and time
	-- as the order date/time so that we pick up the correct diet for the patient.
	--
	-- Prior to this change, the beginning time of the wave was used to retrieve the patient's diet.
	-- However, if it was 2:00 pm and the patient's diet changed at 1:00 pm, the wrong diet would be sent back.
	IF EXISTS (SELECT 1 FROM dbo.tblXlat WHERE xlatid = 'AnytimeWave' AND KeyIn = CAST(@WaveID as varchar(10)))
		SET @WaveDate = getdate()
	ELSE
		SET @WaveDate = dbo.dDatePlusNewTime(@WaveDate, @BeginTime)

	SELECT @OnHold = dbo.GetHoldStatusEX(@PatientID, @WaveDate)

	IF (@OnHold = 1)
	BEGIN
		SELECT @ReturnString = '/Patient on Hold'
	END
	ELSE
	BEGIN
		SELECT @PatientDietID = dbo.GetActivePatientDietID(@PatientVisitID, @WaveDate)

		SELECT @PatientID = PV.PatientID
		FROM	dbo.tblPatientVisit AS PV (NOLOCK) 
		WHERE	PV.PatientVisitID = @PatientVisitID
	
		-- Get the Diet information we need for the return string
		SELECT TOP 1 @ReturnString = D.Description, 
			@DietID = dbo.GetActiveDiet(@PatientVisitID, @WaveDate),
			@POSDietID = dbo.GetActivePOSDiet(@PatientVisitID, @WaveDate),
			@Notes = P.Notes,
			@DietNotes = dbo.GetActiveDietNotesEX(@PatientVisitID, @WaveDate, @WaveID),
			@DietMenuLevel = COALESCE(PD.MenuLevel,D.MenuLevel,1),
			@DOB = 'DOB:[' + dbo.DateStringFormat(COALESCE(P.Birthdate,''), -1, getdate()) + ']'
		FROM	dbo.tblPatientOHD AS P (NOLOCK)
			JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON P.PatientID = PV.PatientID
			JOIN dbo.tblDietOHD AS D (NOLOCK) ON dbo.GetActiveDiet(@PatientVisitID, @WaveDate) = D.DietID
			LEFT JOIN dbo.tblPatientDiet AS PD ON PD.Id = @PatientDietId
		WHERE	PV.PatientVisitID = @PatientVisitID
		ORDER BY PV.EnteredDate DESC
	
		-- Get the chain wave ID if one exists
		SELECT @ChainID = NextWaveID,
			@TimeOffset = Offsetminutes
		FROM	tblDietChain
		WHERE	DietID = @DietID
			AND WaveID = @WaveID
			AND Active <> 0
	
		SET @TempNotes = @WaveName + RTRIM(COALESCE(@DietNotes,'')) + CHAR(10) + RTRIM(COALESCE(@Notes,''))

		-- Add DOB to notes if option is set
		IF (@DOBonPOS = '1')
			SET @TempNotes = @DOB + ' ' + @TempNotes

		IF (LEN(@TempNotes) > 500)
			SET @TempNotes = LEFT(@TempNotes,500)

		-- Add the ChainID if one exists. If not, add a zero
		SET @ReturnString = @ReturnString + CHAR(28) + CAST(COALESCE(@ChainID, 0) as varchar(10)) + CHAR(28) + CAST(COALESCE(@TimeOffSet,0) as varchar(5))
	
		-- Add the diet max nutrients
		SET @ReturnString = @ReturnString + CHAR(28) + dbo.DietMaxNutrients(@PatientDietID,  ',')  
	
		-- Add the diet wave (meal period) Max Nutrients
		-- Get the MealPeriodID to pass to the DietWaveMaxNutrients function
		SELECT @MealPeriodID = MealPeriodID FROM dbo.tblWave WHERE WaveID = @WaveID
		SET @ReturnString = @ReturnString + CHAR(28) + dbo.DietMealPeriodMaxNutrients(@PatientDietID, @MealPeriodID, ',')
	
		-- Add the Patient Current Nutrient Count
		SET @ReturnString = @ReturnString + CHAR(28) + dbo.PatientDailyNutrientCountEX(@PatientID, @WaveDate,  ',')  	
	
		-- Add the Patient Allergens
		SET @ReturnString = @ReturnString + CHAR(28) + COALESCE(dbo.PatientAllergens(@PatientID),'')
	
		-- Add the Patient Notes
		SET @ReturnString = @ReturnString + CHAR(28) + @TempNotes
	
		-- POS Diet ID
		SET @ReturnString = @ReturnString + CHAR(28) + CAST(@POSDietID AS varchar(10))
	
		-- Diet Menu Level
		SET @ReturnString = @ReturnString + CHAR(28) + CAST(COALESCE(@DietMenuLevel,0) AS varchar(10))
	
		-- Diet ID
		SET @ReturnString = @ReturnString + CHAR(28) + CAST(@DietID AS varchar(10))
	
		-- Add the Patient Meal Period Nutrient Count
		SET @ReturnString = @ReturnString + CHAR(28) + dbo.PatientMealPeriodNutrientCountEX(@PatientID, @WaveDate, @MealPeriodID, ',')			

		SET @ReturnString = @ReturnString + CHAR(28) + @PatientName
	END

	-- Return the string				
	SELECT REPLACE(@ReturnString,'\','/') AS ReturnString

	RETURN
go

