

CREATE PROCEDURE dbo.ad_Interface_List
AS
	SELECT	InterfaceID,
			CoreID,
			Active,
			Category,
			Description,
			Contact,
			myIP,
			ExceptionIP,
			GatewayIP,
			PrinterIP,
			SysOptions
	FROM		cfgInterface
	ORDER BY	CoreID, InterfaceID
go

