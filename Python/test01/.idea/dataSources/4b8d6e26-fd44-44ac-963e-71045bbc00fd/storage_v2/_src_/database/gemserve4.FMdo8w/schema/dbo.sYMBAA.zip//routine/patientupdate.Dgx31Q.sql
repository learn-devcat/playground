CREATE PROCEDURE [dbo].[PatientUpdate]
@LoginUserID			varchar(250),
@PatientID			int,
@PVID				int,
@PatientVisitID		varchar(50),
@PatientClassID		int,
@Active				int,
@MedicalRecordID	varchar(30),
@LastName			varchar(30),
@FirstName			varchar(30),
@MiddleInitial		varchar(1),
@RoomNumber			varchar(10),
@Bed				varchar(20),
@BadgeNo			varchar(19),
@BirthDate			varchar(50),
@Gender				int,
@EntryDate			datetime,
@DietID				int,
@NonSelect			bit=null,
@Status				int=0,
@Allergies			varchar(6000)='',
@Notes				text=null,
@DischargeDate		datetime=null,
@PatientStatusFlags	varchar(6000)='',
@ForceUpdate		bit=0,
@OnHold				bit=0,
@HoldReleaseTime	datetime=null,
@PatientDietID		int=null,
@DietNotes			varchar(500)=null,
@UserField1			varchar(50)=null,
@UserField2			varchar(50)=null,
@UserField3			varchar(50)=null,
@UserField4			varchar(50)=null,
@HoldActiveTime		datetime=null,
@MenuLevel			int=null

AS
    SET NOCOUNT ON

    DECLARE @RoomID	        int,
            @CurrentDietID  int,
            @CurrentRoomID	int,
            @CurrentBed	varchar(20),
            @NewRoom	varchar(10),
            @NewDiet    varchar(50),
            @Period     varchar(100),
            @Msg        varchar(250),
            @Allergen   varchar(50),
            @AllergenID	int,
            @StatusFlagID varchar(50),
            @StatusFlagName varchar(50),
            @Checked	char(1),
            @Start	int,
            @CurrentNonSelect	bit,
            @NextID varchar(50),
            @OrderID int,
            @OrderDate datetime,
            @MealPeriod	varchar(50),
            @TempPatientID int,
            @TempOnHold bit,
            @IgnoreMRNDups bit,
            @Today	datetime,
            @ActiveDate datetime,
            @OldPatientVisitID varchar(50)


    SET @Today = getdate()
    SET @ActiveDate = DATEADD(mi,-2,@Today)

    IF (@DischargeDate = '')
        SET @DischargeDate = NULL

    -- For manual entering of Patients and Patient Visits
    SELECT @IgnoreMRNDups = COALESCE(dbo.GetOverheadValueNull('IgnoreMRNDups'),0)
    IF (@IgnoreMRNDups = 1)
        SET @ForceUpdate = 1

    SELECT TOP 1 @CurrentRoomID = ISNULL(RoomID,0),
        @CurrentBed = Bed
    FROM	dbo.tblPatientVisit
    WHERE	PatientVisitID = @PatientVisitID
        AND MergedTo IS NULL
        AND DischargeDate IS NULL
    ORDER BY EnteredDate DESC

    SELECT 	@RoomID = RoomID,
        @NewRoom = RoomNumber
    FROM dbo.tblRoomOHD
    WHERE RoomNumber = @RoomNumber

    IF EXISTS (SELECT 1 FROM dbo.tblPatientOHD WHERE MedicalRecordID = @MedicalRecordID AND @PatientID < 0)
    BEGIN
        IF (@ForceUpdate = 1)
            SELECT @PatientID = PatientID FROM dbo.tblPatientOHD WHERE MedicalRecordID = @MedicalRecordID
        ELSE
        BEGIN
            SELECT -2100 AS PatientID
            RETURN
        END
    END

    SELECT @TempOnHold = OnHold
    FROM dbo.tblPatientOHD
    WHERE PatientID = @PatientID

    IF (@PatientID <= 0)
    BEGIN
        INSERT INTO dbo.tblPatientOHD (PatientClassID, Active, MedicalRecordID, LastName, FirstName, 
            MiddleInitial, BadgeNo, BirthDate, Gender, Status,  
            UserField1, UserField2, UserField3, UserField4, EnteredBy, HoldReleaseTime, HoldActiveTime)
        VALUES (@PatientClassID, @Active, @MedicalRecordID, @LastName, @FirstName, 
            @MiddleInitial, @BadgeNo, @BirthDate, @Gender, @Status,
            @UserField1, @UserField2, @UserField3, @UserField4, @LoginUserID, @HoldReleaseTime, @HoldActiveTime)

        SET @PatientID = SCOPE_IDENTITY()		

        IF (@PatientVisitID = '')
            EXEC @PatientVisitID = dbo.GetRandomIDStringEX

        -- Add patient visit record
        IF NOT EXISTS(SELECT PatientVisitID FROM dbo.tblPatientVisit WHERE PatientVisitID = @PatientVisitID AND DischargeDate IS NULL)
        BEGIN
            -- Add patient visit record
            INSERT INTO dbo.tblPatientVisit (PatientVisitID, PatientID, PatientClassID, RoomID, Bed, 
                    EntryDate, NonSelect, EnteredBy)
            VALUES (@PatientVisitID, @PatientID, @PatientClassID, @RoomID, @Bed, @EntryDate, @NonSelect, @LoginUserID)
        END
        ELSE
        BEGIN
            EXEC @NextID = GetRandomIDStringEX
            SET @PatientVisitID = @PatientVisitID + '-' + @NextID

            INSERT INTO dbo.tblPatientVisit (PatientVisitID, PatientID, PatientClassID, RoomID, Bed, 
                    EntryDate, NonSelect, EnteredBy)
            VALUES (@PatientVisitID, @PatientID, @PatientClassID, @RoomID, @Bed, @EntryDate, @NonSelect, @LoginUserID)
        END

        SET @Msg = 'Patient Admitted'
        EXEC dbo.PatientLOGAdd 7000, @LoginUserID, @PatientID, @PatientVisitID, @RoomID, @Msg

        -- Add nonselect orders if required
        IF(@NonSelect = 1)
            EXEC dbo.NonSelectOrderAdd @PatientID, @DietID
    END
    ELSE
    BEGIN
        IF (@OnHold = 0 AND @TempOnHold = 1)
        BEGIN
            -- Hold is being manually released.
            -- This procedure cancels any previous orders that are no longer valid due to the time.
            EXEC dbo.PatientReleaseHold @PatientID
        END	
    
        IF (@OnHold = 0)
        BEGIN
            SET @HoldReleaseTime = null
            SET @HoldActiveTime = null
        END
        ELSE
        BEGIN
            IF (@HoldActiveTime IS NULL)
                SET @HoldActiveTime = getdate()

            IF (@HoldReleaseTime IS null)
                SET @HoldReleaseTime = '12-31-9999'
        END

        SELECT TOP 1 @CurrentNonSelect = NonSelect 
        FROM dbo.tblPatientVisit (NOLOCK)
        WHERE PatientVisitID = @PatientVisitID
        ORDER BY EnteredDate DESC

        UPDATE	dbo.tblPatientOHD
        SET PatientClassID = @PatientClassID,
            Active = @Active,
            MedicalRecordID = @MedicalRecordID,
            LastName = @LastName,
            FirstName = @FirstName,
            MiddleInitial = @MiddleInitial,
            BadgeNo = @BadgeNo,
            BirthDate = @BirthDate,
            Gender = @Gender,
            Status = @Status,
            UserField1 = COALESCE(@UserField1, UserField1),
            UserField2 = COALESCE(@UserField2, UserField2),
            UserField3 = COALESCE(@UserField3, UserField3),
            UserField4 = COALESCE(@UserField4, UserField4),
            LastUpdateBy = @LoginUserID,
            HoldReleaseTime = @HoldReleaseTime,
            HoldActiveTime = @HoldActiveTime
        WHERE	PatientID = @PatientID


        IF EXISTS (SELECT 1 FROM dbo.tblPatientVisit WHERE PVID = @PVID)
        BEGIN
            -- Get the original Patient Visit ID and see if it needs to be updated as well
            SELECT @OldPatientVisitID = PatientVisitID
            FROM dbo.tblPatientVisit
            WHERE PVID = @PVID

            IF @OldPatientVisitID <> @PatientVisitID
                UPDATE dbo.tblPatientVisit
                SET PatientVisitID = @PatientVisitID,
                    PatientClassID = @PatientClassID,
                    RoomID = @RoomID,
                    Bed = @Bed,	
                    NonSelect = @NonSelect,
                    EntryDate = COALESCE(@EntryDate, EntryDate),
                    LastUpdateBy = @LoginUserID
                WHERE	PVID = @PVID
            ELSE
                UPDATE dbo.tblPatientVisit
                SET	PatientClassID = @PatientClassID,
                    RoomID = @RoomID,
                    Bed = @Bed,	
                    NonSelect = @NonSelect,
                    EntryDate = COALESCE(@EntryDate, EntryDate),
                    LastUpdateBy = @LoginUserID
                WHERE	PVID = @PVID

            IF EXISTS (SELECT 1 FROM dbo.tblPatientVisit WHERE PVID = @PVID AND DischargeDate IS NULL) AND @DischargeDate IS NOT NULL
                EXEC dbo.PatientDischarge @LoginUserID, @PatientVisitID, @DischargeDate		
            
        END
        ELSE
        BEGIN
            INSERT INTO dbo.tblPatientVisit (PatientVisitID, PatientID, PatientClassID, RoomID, Bed, 
                    EntryDate, NonSelect, EnteredBy)
            VALUES (@PatientVisitID, @PatientID, @PatientClassID, @RoomID, @Bed, @EntryDate, @NonSelect, @LoginUserID)
        END

        IF(@CurrentNonSelect <> @NonSelect)
        BEGIN
            IF(@NonSelect = 0)
                -- nonselect was turned off for this patient,
                -- so delete all future nonselect orders
                DELETE dbo.tblOrderOHD
                WHERE PatientVisitID = @PatientVisitID 
                    AND NonSelectOrder = 1
                    AND OrderDate > @Today
            ELSE
                -- nonselect was selected, so add nonselect
                -- orders for this patient
                EXEC dbo.NonSelectOrderAdd @PatientID, @PatientVisitID, @DietID
        END
    END
    
        WHILE (LEN(@Allergies)>0)
        BEGIN
            -- Find a comma in the text string
            SET @Allergen = LEFT(@Allergies, CHARINDEX(',', @Allergies))

            IF ((@Allergen IS NOT NULL) AND (@Allergen <> ''))
            BEGIN
                -- Remove the allergen description
                SET @Allergies = RIGHT(@Allergies, LEN(@Allergies) - CHARINDEX(',', @Allergies))
                SET @Allergen = LEFT(@Allergen,LEN(@Allergen)-1)

                -- If the check value of the current allergen is 1, then add it to the 
                -- patient's allergen list
                IF (LEFT(@Allergies,1) = '1')
                BEGIN
                    SELECT @AllergenID = AllergenID
                    FROM dbo.cfgAllergens
                    WHERE [Description] = @Allergen
        
                    IF NOT EXISTS(SELECT AllergenID FROM dbo.tblPatientAllergens
                            WHERE PatientID = @PatientID
                                AND AllergenID = @AllergenID)
                    BEGIN
                        INSERT INTO dbo.tblPatientAllergens(PatientID, AllergenID)
                            SELECT @PatientID, AllergenID
                            FROM cfgAllergens WHERE UPPER([Description]) = UPPER(@Allergen)
            
                        SELECT @Msg = 'Allergen added: ' + UPPER([Description])
                            FROM cfgAllergens WHERE UPPER([Description]) = UPPER(@Allergen)
        
                        EXEC dbo.PatientLOGAdd 1000, @LoginUserID, @PatientID, @PatientVisitID, @RoomID, @Msg
                    END
                END
                ELSE
                BEGIN
                    DELETE dbo.tblPatientAllergens 
                    WHERE PatientID = @PatientID
                        AND AllergenID IN (SELECT AllergenID FROM cfgAllergens WHERE UPPER([Description]) = UPPER(@Allergen))
        
                    IF (@@ROWCOUNT > 0)
                    BEGIN
                        SELECT @Msg = 'Allergen removed: ' + UPPER([Description])
                        FROM cfgAllergens WHERE UPPER([Description]) = UPPER(@Allergen)

                        EXEC dbo.PatientLOGAdd 7000, @LoginUserID, @PatientID, @PatientVisitID, @RoomID, @Msg
                    END
                END

                -- Remove the check value
                IF (LEN(@Allergies) = 2)
                    SET @Allergies = ''
                ELSE
                    SET @Allergies = RIGHT(@Allergies, LEN(@Allergies) - CHARINDEX(',', @Allergies))
            END
            ELSE
                SET @Allergies = ''
        END
        
        -- Update the Patient Status Flags
        WHILE (LEN(@PatientStatusFlags) > 0)
        BEGIN
            -- Find the comma in the text string
            SET @StatusFlagID = LEFT(@PatientStatusFlags, CHARINDEX(',', @PatientStatusFlags)-1)
            
            IF (@StatusFlagID IS NOT NULL AND @PatientStatusFlags <> '')
            BEGIN
                -- Remove the StatusFlagID from the PatientStatusFlags string
                SET @PatientStatusFlags = RIGHT(@PatientStatusFlags, LEN(@PatientStatusFlags) - CHARINDEX(',',@PatientStatusFlags))
                -- Get the checked value of the status flag
                SET @Checked = LEFT(@PatientStatusFlags,1)
            
                IF (@Checked = 1)
                BEGIN
                    IF NOT EXISTS (SELECT 1 FROM dbo.tblPatientStatusFlags WHERE PatientID = @PatientID AND StatusFlagID = @StatusFlagID)
                    BEGIN
                        INSERT INTO dbo.tblPatientStatusFlags(PatientID,StatusFlagID)
                        VALUES(@PatientID,@StatusFlagID)
                    
                        SELECT @Msg = 'Patient Status [' + UPPER([Description]) + '] set to [ON].'
                        FROM dbo.tblStatusFlags
                        WHERE StatusFlagID = @StatusFlagID
                    
                        EXEC dbo.PatientLOGAdd 1000, @LoginUserID, @PatientID, @PatientVisitID, @RoomID, @Msg
                    END
                END
                ELSE
                BEGIN
                    DELETE dbo.tblPatientStatusFlags
                    WHERE PatientID = @PatientID
                        AND StatusFlagID = @StatusFlagID
                
                    IF (@@ROWCOUNT > 0)
                    BEGIN
                        SELECT @Msg = 'Patient Status [' + UPPER([Description]) + '] set to [OFF].'
                        FROM dbo.tblStatusFlags
                        WHERE StatusFlagID = @StatusFlagID
                    
                        EXEC dbo.PatientLOGAdd 1000, @LoginUserID, @PatientID, @PatientVisitID, @RoomID, @Msg
                    END
                END
            
                --Remove the Checked Value from the PatientStatusFlags String
                IF (CHARINDEX(',',@PatientStatusFlags) > 0)
                    SET @PatientStatusFlags = RIGHT(@PatientStatusFlags, LEN(@PatientStatusFlags) - 2)
                ELSE
                    SET @PatientStatusFlags = ''
            END
            ELSE
                SET @PatientStatusFlags = ''
        END
        -- Update the diet information
        SELECT @CurrentDietID = dbo.GetActiveDiet(@PatientVisitID, @Today)
    
        IF ( @DietID <> ISNULL(@CurrentDietID,-99) )
        BEGIN    
            INSERT INTO dbo.tblPatientDiet(PatientVisitID, DietID, ActiveDate, Source, Notes, UpdateID, UpdateDate)
            SELECT @PatientVisitID, @DietID, @ActiveDate,'Manual', Description, @LoginUserID, @Today
                FROM dbo.tblDietOHD WHERE DietID = @DietID

            SELECT @PatientDietID = SCOPE_IDENTITY()

            SELECT  @NewDiet = Description
            FROM    dbo.tblDietOHD (NOLOCK)
            WHERE   DietID = @DietID
                
            SET @Msg = '*' + ISNULL(UPPER(@NewDiet),'NOT FOUND') + ' diet added for ' + dbo.DateString(@Today) + ' by ' + @LoginUserID + ' (starts at: Immediate)'
            EXEC dbo.PatientLOGAdd 7000, @LoginUserID, @PatientID, @PatientVisitID, @RoomID, @Msg

            -- Get the next OrderID
            SELECT @OrderID = OrderID
            FROM tblOrderOHD 
            WHERE OrderDate > @Today
                AND COALESCE(Cancelled, 0) = 0
                AND PatientID = @PatientID
                AND Received = 0	
                AND OrderType = 1
            ORDER BY OrderDate DESC		

            WHILE (@OrderID IS NOT NULL)
            BEGIN
                -- Insert a log entry into the Order Log the order being cancelled
                INSERT INTO dbo.tblOrderLOG ( OrderID ,  ActionID , LoginUserID )
                SELECT OrderID, 700, @LoginUserID
                FROM    dbo.tblOrderOHD AS O (NOLOCK)
                            JOIN dbo.tblPatientOHD AS P (NOLOCK) ON O.PatientID = P.PatientID
                WHERE OrderID = @OrderID

                SELECT @MealPeriod = M.[Description],
                    @OrderDate = O.OrderDate
                FROM dbo.tblOrderOHD AS O (NOLOCK)
                    JOIN dbo.tblWave AS W (NOLOCK) ON O.WaveID = W.WaveID
                    JOIN dbo.tblMealPeriods AS M (NOLOCK) ON W.MealPeriodID = M.MealPeriodID
                WHERE O.OrderID = @OrderID

                SET @Msg = @MealPeriod + 'Order cancelled due to manual Diet Change. Order ID:' + CAST(@OrderID AS varchar(10))
                EXEC dbo.PatientLOGAdd 7000, @LoginUserID, @PatientID, @PatientVisitID, @RoomID, @Msg
    
                -- Set the cancelled flag to 1 this order
                UPDATE  dbo.tblOrderOHD
                SET Cancelled = 1,
                CancelDate = @Today,
                LastUpdateBy = @LoginUserID
                WHERE OrderID = @OrderID

                -- Get the next OrderID
                SET @OrderID = NULL

                SELECT @OrderID = OrderID
                FROM tblOrderOHD 
                WHERE OrderDate > @Today
                    AND COALESCE(Cancelled, 0) = 0
                    AND PatientID = @PatientID	
                    AND Received = 0	
                    AND OrderType = 1
                ORDER BY OrderDate DESC
            END
        END
    
    -- Update the MenuLevel in the tblPatientDiet table
    UPDATE dbo.tblPatientDiet SET MenuLevel = CASE WHEN @MenuLevel < 2 THEN NULL ELSE @MenuLevel END
    WHERE Id = @PatientDietId

    IF NOT EXISTS (SELECT 1 FROM dbo.tblPatientOHD WHERE PatientID = @PatientID AND CAST(Notes AS varchar(1000)) = CAST(@Notes AS varchar(1000)))
    BEGIN
        EXEC dbo.PatientNotesUpdate @PatientID, @Notes
        SET @Msg = 'Updated Patient Notes'
        EXEC dbo.PatientLOGAdd 7000, @LoginUserID, @PatientID, @PatientVisitID, @RoomID, @Msg
    END

    --IF NOT (@DietNotes IS NULL)
    --	EXEC dbo.PatientDietNotesUpdate @LoginUserID, @PatientDietID, @DietNotes		

    -- Log Room Change
    IF(@RoomID <> @CurrentRoomID)
    BEGIN
        SET @Msg = 'Moved to room ' + @NewRoom

        UPDATE dbo.tblPatientVisit
        SET PreviousRoomID = @CurrentRoomID,
            PreviousBed = @CurrentBed,
            LastUpdateBy = @LoginUserID
        WHERE PatientVisitID = @PatientVisitID
        
        EXEC dbo.PatientLOGAdd 7000, @LoginUserID, @PatientID, @PatientVisitID, @RoomID, @Msg
    END

    SELECT @PatientID AS PatientID

    RETURN
go

