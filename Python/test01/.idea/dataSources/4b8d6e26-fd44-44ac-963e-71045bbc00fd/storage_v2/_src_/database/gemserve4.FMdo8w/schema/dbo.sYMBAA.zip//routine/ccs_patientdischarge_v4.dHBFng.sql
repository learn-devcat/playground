


CREATE PROCEDURE [dbo].[CCS_PatientDischarge_v4]
@PatientVisitID varchar(50),
@DischargeDate  varchar(20),
@Source         varchar(50),
@ConnectionName	varchar(50)=''

AS
	DECLARE @PatientID	int,
			@Msg        varchar(250),
			@MyDate     datetime,
			@RoomID	    int

	IF (ISDATE(@DischargeDate) = 0)
		SET @MyDate = getdate()
	ELSE
		SET @MyDate = CAST(@DischargeDate AS datetime)
	
	-- If this patient does not exist in our system, then log an error
	IF NOT EXISTS (SELECT 1 FROM dbo.tblPatientVisit WHERE PatientVisitID = @PatientVisitID) 
	BEGIN
		SET @Msg = 'Unable to process discharge for PatientVisitID' + @PatientVisitID + '. PatientVisitID does not exist.'
		GOTO TransError
	END

	SELECT @PatientID = PatientID,
		@RoomID = RoomID
	FROM dbo.tblPatientVisit
	WHERE PatientVisitID = @PatientVisitID
 
   	-- Cancel all patient orders for this patient visit that are in the future. 
	-- Insert a log entry into the Orer Log for all orders that we are cancelling
	INSERT INTO dbo.tblOrderLOG (OrderID, ActionID, LoginUserID)
		SELECT 	OrderID, 700, 'HL7'
		FROM	dbo.tblOrderOHD AS O (NOLOCK)
			JOIN dbo.tblPatientVisit AS P (NOLOCK) ON (O.PatientVisitID = P.PatientVisitID OR O.PatientVisitID = P.MergedTo)
		WHERE O.OrderDate >= getdate()  
		    	AND ISNULL(O.Cancelled,0) <> 1
			AND COALESCE(O.Received,0) <> 1
		    	AND O.PatientVisitID = @PatientVisitID
		    	
	-- Deletes all nutrient counts for orders that are being canceled.
	DELETE dbo.tblPatientNutrientCount 
	WHERE OrderID IN (SELECT OrderID FROM dbo.tblOrderOHD AS O (NOLOCK)
		JOIN dbo.tblPatientVisit AS P (NOLOCK) ON (O.PatientVisitID = P.PatientVisitID OR O.PatientVisitID = P.MergedTo)
       	WHERE O.OrderDate >= getdate() 
                	AND ISNULL(O.Cancelled,0) <> 1
			AND COALESCE(O.Received,0) <> 1
	    	AND O.PatientVisitID = @PatientVisitID)

	-- Insert a log entry into the Patient Log for all orders that we are cancelling
	SET @Msg = ' Order cancelled due to Patient Discharge. Order ID: '
	INSERT INTO dbo.tblPatientLog (EventClassID, LoginUserID, PatientID, PatientVisitID, RoomID, [Description], [Date])
	SELECT 7000, @Source, P.PatientID, P.PatientVisitID, P.RoomID, M.[Description] + @Msg + CAST(O.OrderID AS varchar(30)), getdate()
	FROM dbo.tblOrderOHD AS O (NOLOCK)
	        JOIN dbo.tblPatientVisit AS P (NOLOCK) ON O.PatientVisitID = P.PatientVisitID
			JOIN dbo.tblWave AS W (NOLOCK) ON O.WaveID = W.WaveID
			JOIN dbo.tblMealPeriods AS M (NOLOCK) ON W.MealPeriodID = M.MealPeriodID
	WHERE O.OrderDate >= getdate() 
		AND ISNULL(O.Cancelled,0) <> 1
		AND COALESCE(O.Received,0) <> 1
		AND O.PatientVisitID = @PatientVisitID				
	
     -- Cancel all future orders associated with the PatientVisitID
	UPDATE  dbo.tblOrderOHD
	SET Cancelled = 1,
		CancelDate = getdate(),
		LastUpdateBy = @Source
	WHERE   PatientVisitID = @PatientVisitID
		AND ISNULL(Cancelled,0) <> 1
		AND COALESCE(Sent,0) <> 1
		AND OrderDate >= getdate()
	        
	-- Archive Patient
        UPDATE dbo.tblPatientVisit
        SET DischargeDate = @MyDate,
            ArchiveDate = @MyDate,
			LastUpdateBy = @Source
        WHERE PatientVisitID = @PatientVisitID
        
	SET @Msg = 'Discharge processed for PatientVisitID:' + @PatientVisitID
	EXEC dbo.Logit 1, @Msg, 'system'
	
	EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, @PatientVisitID, @RoomID, 'Discharged patient.'    
	EXEC dbo.ProcessLogInsert @Source

   RETURN
    
TransError:

	IF ( @Msg IS NULL )    
        	SET @Msg = 'Unable to process Discharge for PatientVisitID:' + @PatientVisitID
        
	SET @ConnectionName = 'Idt' + @ConnectionName
	EXEC dbo.WorkstationUpdateByID @ConnectionName


    EXEC dbo.Logit 1, @Msg, 'system'


go

