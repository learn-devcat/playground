

CREATE FUNCTION dbo.FullName (@Title char(10),@FirstName char(20),@LastName char(30)) 
RETURNS varchar(60)
AS 
BEGIN
	DECLARE @ReturnString	varchar(60)
	IF RTRIM(@Title)=''
		BEGIN
			SET @ReturnString=RTRIM(@FirstName) + ' ' + RTRIM(@LastName)
		END
	ELSE
		BEGIN
			SET @ReturnString=RTRIM(@Title) + ' ' + RTRIM(@FirstName) + ' ' + RTRIM(@LastName)
		END
	RETURN ltrim(@ReturnString)
END
go

