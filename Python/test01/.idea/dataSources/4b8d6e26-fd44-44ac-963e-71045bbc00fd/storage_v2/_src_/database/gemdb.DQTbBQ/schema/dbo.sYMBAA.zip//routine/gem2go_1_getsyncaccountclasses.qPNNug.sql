

CREATE PROCEDURE [dbo].[gem2go_1_GetSyncAccountClasses]
    @CoreID int ,
    @User char(10)
AS
    SET NOCOUNT ON 

		Select AccountClassId,
				[Name],
				Department,
				EnableTimepay
		From dbo.tblAccountClass      
         
    return
go

