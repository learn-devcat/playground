


CREATE  PROCEDURE dbo.ad_TransXref_Edit
	@User			char(10),
	@id 			int,
	@DELETE			bit,
	@LocationID 		int = NULL,
	@OutletNo 		int = NULL,
	@AccountClassID 	int = -1,
	@BadgeClassID 		int = -1,
	@SIMtype 		int = -1,
	@POSTenderKey 		int = -1,
	@TransID 		int = -1,
	@AltPOSTenderKey 	int = -1,
	@AltTransID 		int = -1,
	@Payload 		varchar(128) = '',
	@POSkeyType1 		int = -1,
	@POSKeyType2 		int = -1,
	@POSKeyType3 		int = -1,
	@POSKey1 		int = -1,
	@POSKey2 		int = -1,
	@POSKey3 		int = -1,
	@POSKeyValue1 		varchar(32) = '',
	@POSKeyValue2 		varchar(32) = '',
	@POSKeyValue3 		varchar(32) = '',
	@POSDiscount 		int = -1,
	@POSDiscountAmt 	varchar(10) = '',
	@POSServiceCharge 	int = -1,
	@POSServiceChargeAmt	varchar(10) = '',
	@POSTaxExempt 		int = -1
	

AS 
	DECLARE @Message varchar(255)

	IF @DELETE = 1
		GOTO DODELETE

	IF (@id = -1)
	BEGIN
		INSERT dbo.tblTransXREF 
		VALUES(@LocationID,
			@OutletNo,
			@AccountClassID,
			@BadgeClassID,
			@SIMtype,
			@POSTenderKey,
			@TransID,
			@AltPOSTenderKey,
			@AltTransID,
			@Payload,
			@POSkeyType1,
			@POSKeyType2,
			@POSKeyType3,
			@POSKey1,
			@POSKey2,
			@POSKey3,
			@POSKeyValue1,
			@POSKeyValue2,
			@POSKeyValue3,
			@POSDiscount,
			@POSDiscountAmt,
			@POSServiceCharge,
			@POSServiceChargeAmt,
			@POSTaxExempt)

/*

------[ XREF Support Keys ]------------------------------------
(from the SIM code)

var AccountClassID      : N9
var BadgeClassID        : N9

var Payload             : A250          // Misc data returned from the XREF.

var POSTenderKey        : N9
var AltPOSTenderKey     : N9
var TransID             : N9
var AltTransID          : N9

var POSKeyBegin         : N1            // Used internally to syncronize the KEY actions.

var POSKeyType[3]       : N9            // Aux keys during functions.
var POSKey[3]           : N9
var POSKeyValue[3]      : A32
var POSDiscountKey      : N9
var POSDiscountAmt      : A10
var POSServiceChargeKey : N9
var POSServiceChargeAmt : A10
var POSTaxExempt        : N1

var LocationList[50]    : A40
var NumLocations        : N3

*/

		SELECT @Message = 'New TransXREF Item Added: ID(' + CAST([id] as varchar(8)) + ')'
				  FROM	dbo.tblTransXREF
				  WHERE	[id] = @id
	END
	ELSE
	BEGIN

		UPDATE	dbo.tblTransXREF
		SET	LocationID = @LocationID,
			OutletNo = @OutletNo,
			AccountClassID = @AccountClassID,
			BadgeClassID = @BadgeClassID,
			SIMtype = @SIMtype,
			POSTenderKey = @POSTenderKey,
			TransID = @TransID,
			AltPOSTenderKey = @AltPOSTenderKey,
			AltTransID =@AltTransID,
			Payload = @Payload,
			POSkeyType1 = @POSkeyType1,
			POSKeyType2 =@POSKeyType2,
			POSKeyType3 = @POSKeyType3,
			POSKey1 = @POSKey1,
			POSKey2 = @POSKey2,
			POSKey3 = @POSKey3,
			POSKeyValue1 = @POSKeyValue1,
			POSKeyValue2 = @POSKeyValue2,
			POSKeyValue3 = @POSKeyValue3,
			POSDiscount = @POSDiscount,
			POSDiscountAmt = @POSDiscountAmt,
			POSServiceCharge = @POSServiceCharge,
			POSServiceChargeAmt = @POSServiceChargeAmt,
			POSTaxExempt = @POSTaxExempt
		WHERE	[id] = @id

		SELECT @Message = 'TransXREF item edited: ID(' + CAST(@id as varchar(8)) + ')'
	END

	EXEC dbo.sp_Logit 9, 1, @User, @Message, 1010	
	SELECT @Message AS 'Rtn'

	RETURN

	DODELETE:
	DELETE	dbo.tblTransXREF
	WHERE	id = @id

	SELECT @Message = 'TransXREF item deleted: ID(' + CAST(@id as varchar(8)) + ')'
	
	EXEC dbo.sp_Logit 9, 1, @User, @Message, 1010	
	SELECT @Message AS 'Rtn'
go

