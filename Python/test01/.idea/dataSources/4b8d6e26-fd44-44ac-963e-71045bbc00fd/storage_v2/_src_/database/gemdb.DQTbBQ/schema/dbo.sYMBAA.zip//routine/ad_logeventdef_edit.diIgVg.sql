


CREATE  PROCEDURE [dbo].[ad_LogEventDef_Edit]
@User			char(10),
@ExistingEventID	int,
@NewEventID	int,
@Description		varchar(24),
@DELETE			bit = 0

AS 
	DECLARE @EventID int,
		@Message varchar(255),
		@ErrNum int

	IF @DELETE = 1
		GOTO DODELETE

	IF (@NewEventID > -1 AND @ExistingEventID = -1)
	BEGIN
		INSERT dbo.tblLogEventDEF 
		VALUES(@NewEventID, @Description)
		
		SET @ErrNum = @@ERROR

		SELECT @Message = 	'New Application Item Added: (' + CAST(EventID as varchar(8)) + ') ' +  [Description]
					FROM	dbo.tblLogEventDEF
					WHERE	EventID = @NewEventID
	END
	ELSE
	BEGIN

		SET @EventID = CASE 
				WHEN @NewEventID > -1 
				THEN @NewEventID
				ELSE @ExistingEventID 
			     END
		UPDATE	dbo.tblLogEventDEF
		SET	EventID = @EventID,
			[Description] = @Description
		WHERE	EventID = @ExistingEventID
		
		SET @ErrNum = @@ERROR

		SELECT @Message = 	('Edit of ApplicationID (' + CAST(@EventID as varchar) + ') ' + 
					CASE WHEN (SELECT EventID FROM dbo.tblLogEventDEF WHERE EventID = EventID) IS NULL
					     THEN 'FAILED'
					     ELSE 'SUCCEDED'
					     END)
	END

	EXEC dbo.sp_Logit 9, 1, @User, @Message, 1010	
	SELECT @Message AS 'Rtn'

	RETURN

	DODELETE:
	DELETE	dbo.tblLogEventDEF
	WHERE	EventID = @ExistingEventID
	
	SET @ErrNum = @@ERROR

	IF EXISTS (SELECT * FROM dbo.tblLogEventDEF WHERE EventID = @ExistingEventID)
		SELECT @Message = 'DELETE Application ID (' + CAST(@ExistingEventID as varchar(8)) + ') Failed'
	ELSE
		SELECT @Message = 'DELETE Application ID (' + CAST(@ExistingEventID as varchar(8)) + ') Succeded'

	
	EXEC dbo.sp_Logit 9, 1, @User, @Message, 1010	
	SELECT @ErrNum AS 'Rtn'
go

