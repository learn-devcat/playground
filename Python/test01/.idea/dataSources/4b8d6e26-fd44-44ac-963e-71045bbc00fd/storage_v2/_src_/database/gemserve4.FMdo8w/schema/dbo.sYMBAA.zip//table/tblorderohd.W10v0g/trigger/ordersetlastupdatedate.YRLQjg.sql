CREATE TRIGGER OrderSetLastUpdateDate ON dbo.tblOrderOHD FOR INSERT, UPDATE    
AS
      UPDATE    dbo.tblOrderOHD
       SET              LastUpdateDate = getdate()
       FROM         Inserted AS I JOIN
                              dbo.tblOrderOHD AS O ON I.OrderID = O.OrderID
go

