
CREATE  PROCEDURE dbo.AccountsOrBadges_ListByAnyCriteria
@User		varchar(10),
@Criteria	varchar(20)
AS
	SELECT 	A.AccountNo,            -- SELECT FROM info matching AccountNo
		B.BadgeNo,
		B.Status,
		A.Description,
		Case ISNULL(B.Title,'') When '' Then A.Title ELSE B.Title END as Title,
		Case ISNULL(B.FirstName,'') When '' Then A.FirstName ELSE B.FirstName END as FirstName,
		Case ISNULL(B.MiddleName,'') When '' Then A.MiddleName ELSE B.MiddleName END as MiddleName,
		Case ISNULL(B.LastName,'') When '' Then A.LastName ELSE B.LastName END as LastName,
		B.Status, 
		B.PrimaryBadge, 
		B.ActiveDate, 
		B.ExpireDate,
		B.BadgeClassID, 
		dbo.NameLookup(B.AccountNo, B.BadgeNo) AS Name,
		B.Limit, 
		B.DailyLimit,
		B.ImagePath,
		B.TransLimit,
		B.Inactive,
		B.Lost,
		B.Stolen
	FROM	tblAccountOHD A
			Right JOIN
		tblBadgesOHD B On A.AccountNo = B.AccountNo
	WHERE	B.AccountNo = @Criteria
		AND A.LocationID IN (SELECT LocationID FROM dbo.cfgUserLocations WHERE UserID = @User)
Union
	-- SELECT FROM info matching BadgeNo
	SELECT 	A.AccountNo,
		B.BadgeNo,
		B.Status,
		A.Description,
		Case ISNULL(B.Title,'') When '' Then A.Title ELSE B.Title END as Title,
		Case ISNULL(B.FirstName,'') When '' Then A.FirstName ELSE B.FirstName END as FirstName,
		Case ISNULL(B.MiddleName,'') When '' Then A.MiddleName ELSE B.MiddleName END as MiddleName,
		Case ISNULL(B.LastName,'') When '' Then A.LastName ELSE B.LastName END as LastName,
		B.Status, 
		B.PrimaryBadge, 
		B.ActiveDate, 
		B.ExpireDate,
		B.BadgeClassID, 
		dbo.NameLookup(B.AccountNo, B.BadgeNo) AS Name,
		B.Limit, 
		B.DailyLimit,
		B.ImagePath,
		B.TransLimit,
		B.Inactive,
		B.Lost,
		B.Stolen
	FROM	tblAccountOHD A
			Right JOIN
		tblBadgesOHD B On A.AccountNo = B.AccountNo
	WHERE	B.BadgeNo = @Criteria
	AND A.LocationID IN (SELECT LocationID FROM dbo.cfgUserLocations WHERE UserID = @User)
Union
	-- SELECT FROM info matching Account LastName
	SELECT 	A.AccountNo,
		B.BadgeNo,
		B.Status,
		A.Description,
		Case ISNULL(B.Title,'') When '' Then A.Title ELSE B.Title END as Title,
		Case ISNULL(B.FirstName,'') When '' Then A.FirstName ELSE B.FirstName END as FirstName,
		Case ISNULL(B.MiddleName,'') When '' Then A.MiddleName ELSE B.MiddleName END as MiddleName,
		Case ISNULL(B.LastName,'') When '' Then A.LastName ELSE B.LastName END as LastName,
		B.Status, 
		B.PrimaryBadge, 
		B.ActiveDate, 
		B.ExpireDate,
		B.BadgeClassID, 
		dbo.NameLookup(B.AccountNo, B.BadgeNo) AS Name,
		B.Limit, 
		B.DailyLimit,
		B.ImagePath,
		B.TransLimit,
		B.Inactive,
		B.Lost,
		B.Stolen
	FROM	tblAccountOHD A
			Right JOIN
		tblBadgesOHD B On A.AccountNo = B.AccountNo
	WHERE	A.LastName Like '%' + @Criteria + '%'
	AND A.LocationID IN (SELECT LocationID FROM dbo.cfgUserLocations WHERE UserID = @User)
Union
	-- SELECT FROM info matching Badge LastName
	SELECT 	A.AccountNo,
		B.BadgeNo,
		B.Status,
		A.Description,
		Case ISNULL(B.Title,'') When '' Then A.Title ELSE B.Title END as Title,
		Case ISNULL(B.FirstName,'') When '' Then A.FirstName ELSE B.FirstName END as FirstName,
		Case ISNULL(B.MiddleName,'') When '' Then A.MiddleName ELSE B.MiddleName END as MiddleName,
		Case ISNULL(B.LastName,'') When '' Then A.LastName ELSE B.LastName END as LastName,
		B.Status, 
		B.PrimaryBadge, 
		B.ActiveDate, 
		B.ExpireDate,
		B.BadgeClassID, 
		dbo.NameLookup(B.AccountNo, B.BadgeNo) AS Name,
		B.Limit, 
		B.DailyLimit,
		B.ImagePath,
		B.TransLimit,
		B.Inactive,
		B.Lost,
		B.Stolen
	FROM	tblAccountOHD A
			Right JOIN
		tblBadgesOHD B On A.AccountNo = B.AccountNo
	WHERE	B.LastName Like '%' + @Criteria + '%'
	AND A.LocationID IN (SELECT LocationID FROM dbo.cfgUserLocations WHERE UserID = @User)
go

