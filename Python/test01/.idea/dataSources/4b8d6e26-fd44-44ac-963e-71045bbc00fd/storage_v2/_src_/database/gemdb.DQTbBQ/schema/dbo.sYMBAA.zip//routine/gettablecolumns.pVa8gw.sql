CREATE PROCEDURE dbo.GetTableColumns @tableName VARCHAR(50)
AS 
    BEGIN
        SET NOCOUNT ON
		
        CREATE TABLE [#spt_datatype_info]
            (
              [TYPE_NAME] [sysname] NOT NULL,
              [DATA_TYPE] [smallint] NOT NULL,
              [PRECISION] [int] NULL,
              [LITERAL_PREFIX] [varchar](32) COLLATE Latin1_General_BIN NULL,
              [LITERAL_SUFFIX] [varchar](32) COLLATE Latin1_General_BIN NULL,
              [CREATE_PARAMS] [varchar](32) COLLATE Latin1_General_BIN NULL,
              [NULLABLE] [smallint] NOT NULL,
              [CASE_SENSITIVE] [smallint] NOT NULL,
              [SEARCHABLE] [smallint] NOT NULL,
              [UNSIGNED_ATTRIBUTE] [smallint] NULL,
              [MONEY] [smallint] NOT NULL,
              [AUTO_INCREMENT] [smallint] NULL,
              [LOCAL_TYPE_NAME] [sysname] NULL,
              [MINIMUM_SCALE] [smallint] NULL,
              [MAXIMUM_SCALE] [smallint] NULL,
              [SQL_DATA_TYPE] [smallint] NOT NULL,
              [SQL_DATETIME_SUB] [smallint] NULL,
              [NUM_PREC_RADIX] [int] NULL,
              [INTERVAL_PRECISION] [smallint] NULL,
              [USERTYPE] [smallint] NULL
            )
        INSERT  #spt_datatype_info
                EXEC sp_datatype_info

        ALTER TABLE [#spt_datatype_info]
        ADD [ss_dtype] [tinyint]

        UPDATE  #spt_datatype_info
        SET     ss_dtype = xtype
        FROM    systypes
        WHERE   [name] = CASE WHEN charindex('(', [TYPE_NAME]) > 0
                              THEN LEFT([TYPE_NAME],
                                        charindex('(', [TYPE_NAME]) - 1)
                              WHEN charindex(' ', [TYPE_NAME]) > 0
                              THEN LEFT([TYPE_NAME],
                                        charindex(' ', [TYPE_NAME]) - 1)
                              ELSE [TYPE_NAME]
                         END
   

        SELECT  c.name,
                t.NAME DataType,
                CASE WHEN ( SELECT TOP 1
                                    LITERAL_PREFIX
                            FROM    #spt_datatype_info
                            WHERE   ss_dtype = t.xtype
                          ) = '''' THEN 'true'
                     ELSE 'false'
                END isQuoted
        FROM    dbo.syscolumns c
                JOIN dbo.sysobjects o ON c.id = o.id
                JOIN dbo.systypes t ON c.xtype = t.xtype
        WHERE   o.name = @tableName
        ORDER BY c.colorder
        
        DROP TABLE #spt_datatype_info  
    END
go

