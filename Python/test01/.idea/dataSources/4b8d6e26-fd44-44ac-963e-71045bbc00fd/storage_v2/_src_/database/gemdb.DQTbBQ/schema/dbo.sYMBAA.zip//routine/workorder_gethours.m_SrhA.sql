Create      PROCEDURE dbo.Workorder_GetHours
@User           char(10),
@WorkOrderID    int
AS
    SELECT	SUM(DEF.EstimatedHours) as EstHrsTotal,
		SUM(DTL.ActualHours) as ActualHrsTotal
    FROM    	tblWorkOrderDTL as DTL
			LEFT JOIN
		tblWorkorderDTLDef as DEF ON DTL.WorkorderDTLDefID = DEF.WorkorderDTLDefID
    WHERE   	WorkOrderID = @WorkOrderID
go

