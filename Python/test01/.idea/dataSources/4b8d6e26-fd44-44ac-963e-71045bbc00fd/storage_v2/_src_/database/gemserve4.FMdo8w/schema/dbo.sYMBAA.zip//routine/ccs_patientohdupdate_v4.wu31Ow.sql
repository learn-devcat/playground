
CREATE PROCEDURE [dbo].[CCS_PatientOHDUpdate_v4]
@MedicalRecordID	varchar(30),
@LastName		varchar(30),
@FirstName		varchar(30),
@MiddleInitial		varchar(50),
@Birthdate		varchar(50),
@EntryDate		varchar(50),
@Source             	varchar(50),
@PatientClass		varchar(32)='',
@Gender		varchar(50)=null,
@OrderType	varchar(50)='NW',
@ConnectionName varchar(50)=''


AS
	DECLARE @PatientClassID	int	

	DECLARE @Msg varchar(250),
	        @PatientID int,
		@Temp varchar(100),
		@Today datetime,
		@MergedTo varchar(50),
		@ProcessAdmit	varchar(10),
		@iGender	int
	
	IF (@OrderType <> '')
	BEGIN
		IF EXISTS (SELECT 1 FROM dbo.tblXlat WHERE xlatId = 'ORMOrderType')
		BEGIN
			IF NOT EXISTS (SELECT 1 FROM dbo.tblXlat WHERE KeyIn = @OrderType AND xlatId = 'ADTOrderType')
			BEGIN
				SET @PatientID = -1
				SET @Msg = 'Admit ignored for non-processed order type [' + @OrderType + ']. MedicalRecordID [' + @MedicalRecordID + '].'
				GOTO Finished
			END
		END
	END

	IF(LTRIM(@MedicalRecordID) = '')
	BEGIN
		SET @Msg = 'Unable to process Admit. Blank MedicalRecordID for ' + @Source
		SET @PatientID = -1
		GOTO Finished
	END

	IF (@Source LIKE '%ADT-A08%')
		SELECT @ProcessAdmit = dbo.GetOverheadValue('ProcessA08Admit')		
	ELSE
		SET @ProcessAdmit = '1'

	IF (@ProcessAdmit = '')
		SET @ProcessAdmit = '1'	

	SELECT @iGender = KeyOut FROM dbo.tblXlat WHERE xlatId = 'Gender' AND KeyIn = @Gender
	SELECT @iGender = COALESCE(@iGender,0)
	
	SET @Today = getdate()
	SELECT @PatientClassID = dbo.PatientClassLookup(@PatientClass)

    IF (@PatientClassID <= 0)
    BEGIN
        SET @Msg = 'PatientOHD update ignored for non-processed Patient Class [' + @PatientClass + ']. MedicalRecordId [' + @MedicalRecordID + '].'
		SET @PatientID = -1
        GOTO Finished
    END

	IF EXISTS (SELECT 1 FROM dbo.tblPatientOHD (NOLOCK) WHERE MedicalRecordID = @MedicalRecordID)
	BEGIN
		SELECT @MergedTo = MergedTo FROM dbo.tblPatientOHD WHERE MedicalRecordID = @MedicalRecordID

	        -- Update the master patient record
		UPDATE dbo.tblPatientOHD
		SET LastName = @LastName,
			FirstName = @FirstName,
			MiddleInitial = @MiddleInitial,
			BirthDate = @BirthDate,
			Gender = @iGender,
			MergedTo = CASE 
				WHEN @Source = 'ADT-A08' THEN NULL
				ELSE MergedTo
				END,
			LastUpdateBy = @Source
		FROM	dbo.tblPatientOHD
		WHERE MedicalRecordID = @MedicalRecordID

		SELECT @PatientID = PatientID
		FROM dbo.tblPatientOHD
		WHERE MedicalRecordID = @MedicalRecordID
		
		IF (@MergedTo IS NOT NULL)
			EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, '', null, 'Unmerged patient.'

		EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, '', null, 'Updated patient information.'
		EXEC dbo.ProcessLogInsert @Source
	END
	ELSE
	BEGIN
		IF (@ProcessAdmit = '0')
		BEGIN
			SET @Msg = 'Admit for ADT-A08 record ignored. Medical Record ID [' + @MedicalRecordID + ']'
			SET @PatientID = -1
			GOTO Finished
		END

		IF (@EntryDate = '')
			SET @EntryDate = @Today		
	
		INSERT INTO dbo.tblPatientOHD (Active, MedicalRecordID, LastName, FirstName, 
		    MiddleInitial, BirthDate, Gender, EnteredBy, PatientClassID)
		VALUES (1, @MedicalRecordID, @LastName, @FirstName, 
		    @MiddleInitial, @BirthDate, @iGender, @Source, @PatientClassID)
		
		SELECT @PatientID = SCOPE_IDENTITY()
		

	    	EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, '', null, 'Admitted patient.'
		EXEC dbo.ProcessLogInsert @Source
	END

Finished:
	IF NOT (@Msg IS NULL)
	  	EXEC dbo.Logit 1, @Msg, 'system'

	SET @ConnectionName = 'Idt' + @ConnectionName
	EXEC dbo.WorkstationUpdateByID @ConnectionName

	SELECT COALESCE(@PatientID,-1) AS PatientID

	RETURN


go

