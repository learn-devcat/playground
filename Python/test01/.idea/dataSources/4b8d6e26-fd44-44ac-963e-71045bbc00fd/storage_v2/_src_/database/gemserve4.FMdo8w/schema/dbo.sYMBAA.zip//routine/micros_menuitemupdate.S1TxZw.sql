CREATE PROCEDURE [dbo].[Micros_MenuItemUpdate]
@ObjectNumber INT OUTPUT, @Name VARCHAR (16), @MajorGroupSeq INT, @FamilyGroupSeq INT, @MIGroupSeq INT, @MITypeSeq INT, @MLvlClassSeq INT, 
@PrnDefClassSeq INT, @CrossRef1 VARCHAR (16), @Cost DECIMAL (12, 2), @Price DECIMAL (12, 2), @CondimentAllowed INT=1, @CondimentGroup INT=1
AS
SET NOCOUNT ON

DECLARE @SQL		nvarchar(4000),
		@Mi_Seq		int,
		@Overhead	varchar(10),
		@TempObjectNumber int,
		@MicrosServerName varchar(50),
		@PriceLevelNutrientID varchar(50),
		@PresetAmt DECIMAL(10,3)
			
SELECT @MicrosServerName = COALESCE(dbo.GetOverheadValueNull('MicrosServerName'),'Micros')
SELECT @PriceLevelNutrientID = COALESCE(dbo.GetOverheadValueNull('PriceLevelNutrientID'),-1)

SET @Overhead = dbo.GetOverheadValue('CondimentAllowed')
IF (@Overhead <> '') 
 SET @CondimentAllowed = CAST(@Overhead AS int)

SET @Overhead = dbo.GetOverheadValue('CondimentGroup')
IF (@Overhead <> '') 
 SET @CondimentGroup = CAST(@Overhead AS int)

IF EXISTS (SELECT obj_num FROM MicrosMenuItems WHERE obj_num = @ObjectNumber)
BEGIN
 SELECT @MI_Seq = mi_seq
 FROM MicrosMenuItems
 WHERE obj_num = @ObjectNumber

 SET @SQL = 'UPDATE mi
 SET name_1 = ''' + @Name + ''',' +
  'maj_grp_seq = ' + CAST(@MajorGroupSeq AS varchar(20)) + ',' +
  'fam_grp_seq = ' + CAST(@FamilyGroupSeq AS varchar(20)) + ',' +
  'mi_grp_seq = ' + CAST(@MIGroupSeq AS varchar(20)) + ',' +
  'mi_type_seq = ' + CAST(@MITypeSeq AS varchar(20)) + ',' +
  'mlvl_class_seq = ' + CAST(@MLvlClassSeq AS varchar(20)) + ',' +
  'prn_def_class_seq = ' + CAST(@PRnDefClassSeq AS varchar(20)) + ',' +
  'cross_ref1 = ''' + @CrossRef1 + ''',' +
  'cond_allowed = COALESCE(cond_allowed, ' + CAST(@CondimentAllowed AS varchar(20)) + '),' +
  'cond_grp_mem_seq = COALESCE(cond_grp_mem_seq, ' + CAST(@CondimentGroup AS varchar(20)) + ') ' +
 'FROM OPENQUERY(['+ @MicrosServerName +'],' + '''SELECT * FROM micros.mi_def WHERE mi_seq = ' + CAST(@MI_Seq AS varchar(20)) + ''') mi'
 
 EXEC sp_executesql @SQL
END
ELSE
BEGIN
 IF (COALESCE(@ObjectNumber,0) <=0)
 BEGIN
  SELECT @Overhead = dbo.GetOverheadValue('POSMenuItemObjectNum')
  SET @ObjectNumber = CAST(@Overhead as int)
 END
 
 INSERT INTO MicrosMenuItems (obj_num,name_1,maj_grp_seq,fam_grp_seq,
         mi_grp_seq,mi_type_seq,mlvl_class_seq,prn_def_class_seq,cross_ref1,
  cond_allowed, cond_grp_mem_seq)
 VALUES(@ObjectNumber, @Name, @MajorGroupSeq, @FamilyGroupSeq,
  @MIGroupSeq, @MITypeSeq, @MLvlClassSeq, @PrnDefClassSeq, @CrossRef1,
  @CondimentAllowed, @CondimentGroup)

 SELECT @MI_Seq = mi_seq
 FROM MicrosMenuItems
 WHERE obj_num = @ObjectNumber

 SET @TempObjectNumber = @ObjectNumber + 1
 UPDATE dbo.cfgOverhead SET Value = CAST(@TempObjectNumber as varchar(10)) WHERE KeyID = 'POSMenuItemObjectNum'
END

--Set preset_amt_1 to the value of the nutrient for the menuitem
IF (@PriceLevelNutrientID > -1)
	SELECT @PresetAmt = Qty
	FROM dbo.tblMenuItemNutrients AS MN
	JOIN dbo.tblMenuItemOHD AS MI ON MN.MenuItemID = Mi.MenuItemID
	WHERE MI.POSMenuItemID = @ObjectNumber
		AND NutrientID = @PriceLevelNutrientID

SET @SQL = 'UPDATE pr ' +
 'SET preset_amt_1 = ' + CAST(COALESCE(@PresetAmt,0) AS varchar(25)) + ',' +
  'preset_amt_2 = ' + CAST(COALESCE(@PresetAmt,0) AS varchar(25)) + ',' +
  'preset_amt_3 = ' + CAST(COALESCE(@PresetAmt,0) AS varchar(25)) + ',' +
  'preset_amt_4 = ' + CAST(COALESCE(@PresetAmt,0) AS varchar(25)) + ',' +
  'preset_amt_5 = ' + CAST(COALESCE(@PresetAmt,0) AS varchar(25)) + ',' +
  'preset_amt_6 = ' + CAST(COALESCE(@PresetAmt,0) AS varchar(25)) + ',' +
  'preset_amt_7 = 0,' +
  'preset_amt_8 = 0,' +
  'preset_amt_9 = 0,' +
  'preset_amt_10 = ' + CAST(@Price AS varchar(25)) + ',' +
  'cost_1 = ' + CAST(@Cost AS varchar(25)) + ',' +
  'cost_2 = ' + CAST(@Cost AS varchar(25)) + ',' +
  'cost_3 = ' + CAST(@Cost AS varchar(25)) + ',' +
  'cost_4 = ' + CAST(@Cost AS varchar(25)) + ',' +
  'cost_5 = ' + CAST(@Cost AS varchar(25)) + ',' +
  'cost_6 = ' + CAST(@Cost AS varchar(25)) + ',' +
  'cost_7 = ' + CAST(@Cost AS varchar(25)) + ',' +
  'cost_8 = ' + CAST(@Cost AS varchar(25)) + ',' +
  'cost_9 = ' + CAST(@Cost AS varchar(25)) + ',' +
  'cost_10 = ' + CAST(@Cost AS varchar(25)) + 
 'FROM OPENQUERY(['+ @MicrosServerName +'],' + '''SELECT * FROM micros.mi_price_def WHERE mi_seq = ' + CAST(@MI_Seq AS varchar(20)) + ''') pr'

EXEC sp_executesql @SQL

RETURN @Mi_Seq
go

