

CREATE PROCEDURE dbo.MenuItemTouchScreenLocations
@MenuItemID	int
AS
	SET NOCOUNT ON

	SELECT DISTINCT C.MenuItemCategoryID AS MenuItemLocationID, 
		dbo.GetTSLocation(T.RowStart, T.ColStart) AS Location,
		C.[Description] AS CategoryName
	FROM	dbo.tblMenuItemOHD AS M (NOLOCK)
		JOIN dbo.tblMenuItem_TouchScreen AS T (NOLOCK) ON M.MenuItemID = T.MenuItemID
		JOIN dbo.tblMenuItemCategory AS C (NOLOCK) ON T.MenuCategoryID = C.MenuItemCategoryID
	WHERE M.MenuItemID = @MenuItemID
		AND dbo.GetTSLocation(T.RowStart, T.ColStart)  > 0
	ORDER BY C.MenuItemCategoryID


	RETURN
go

