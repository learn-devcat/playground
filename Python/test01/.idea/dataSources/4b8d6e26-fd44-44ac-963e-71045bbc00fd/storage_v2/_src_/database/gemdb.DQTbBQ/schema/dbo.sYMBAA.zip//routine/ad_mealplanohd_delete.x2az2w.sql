

CREATE PROCEDURE dbo.ad_MealPlanOHD_Delete
@MealPlanID	int
AS
	DELETE tblPlanOHD 
	WHERE MealPlanID = @MealPlanID
go

