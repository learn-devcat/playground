CREATE PROCEDURE dbo.HL7_PatientCancelAdmit
@MedicalRecordID	varchar(30),
@PatientVisitID     varchar(50),
@DischargeDate  	varchar(20),
@Source             varchar(50)

AS
    BEGIN TRANSACTION
        DECLARE @Msg varchar(250),
                @MyDate datetime

        IF ( @DischargeDate = '0' OR @DischargeDate = '' )
            SET @MyDate = getdate()
        ELSE
            SET @MyDate = dbo.HL7ConvertDateTime(@DischargeDate, getdate())            

        -- If this patient does not exist in our system, then log an error
        IF NOT EXISTS (SELECT PatientVisitID FROM dbo.tblPatientVisit WHERE PatientVisitID = @PatientVisitID) 
        BEGIN
            SET @Msg = 'Unable to process Cancel Admit for PatientVisitID:' + @PatientVisitID + '. Patient Visit does not exist.'
            GOTO TransError
        END
        
        -- Archive the Patient Visit
	    UPDATE dbo.tblPatientVisit
	    SET ArchiveDate = getdate(),
		DischargeDate = @MyDate
	    WHERE PatientVisitID = @PatientVisitID
	    
	    EXEC dbo.ProcessLogInsert @Source
    COMMIT TRANSACTION	    
    RETURN
    
TransError:
	ROLLBACK TRANSACTION

	IF ( @Msg IS NULL )    
        SET @Msg = 'Unable to process Cancel Admit for MedicalRecordID:' + @MedicalRecordID
        
    EXEC dbo.Logit 1, @Msg, 'system'

Done:
go

