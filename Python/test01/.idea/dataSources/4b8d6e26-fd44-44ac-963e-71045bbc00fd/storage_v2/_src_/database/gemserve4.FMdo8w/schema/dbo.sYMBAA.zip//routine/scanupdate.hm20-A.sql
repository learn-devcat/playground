


CREATE PROCEDURE dbo.ScanUpdate
(
	@BatchID varchar(10)  = 'system'
)
AS

	DECLARE @ScanTime 	datetime,
		@ActionID 	int,
		@OrderID  	int,
		@ScanRecordID 	int,
		@SentActionID 	int,
		@PostStatus 	char(1),
		@Msg 		varchar(128),
		@Temp 		varchar(100),
		@ScanWindow 	int
   
	SET NOCOUNT ON 

  	EXEC dbo.logit 40000,'Run SP: ScanUpdate Begin','System'

	-- Get the number of minutes a button scan is valid.
	SELECT @Temp = dbo.GetOverheadValue('ScanWindow')
	IF(ISNUMERIC(@Temp) = 1)
		SET @ScanWindow = CAST(@Temp AS int)
	ELSE
		-- Set to the default value, since no overhead item found.
		SET @ScanWindow = 180
	
	-- First, clean up any previous POSTED entries. (just like we do for our batch file)
	DELETE dbo.tblScan
	WHERE  PostStatus = 'P' AND UPPER(BatchID) = UPPER(@BatchID)
	
	-- Setup some status here -- Just so we DON'T get non-actionable
	-- items in our cursor.
	UPDATE dbo.tblScan
	   SET PostStatus = 'N'
	WHERE  UPPER(BatchID) = UPPER(@BatchID)
		
   	-- We are tracking the items that were sent to the POS 
	-- for the linking OrderID to which we'll attach this delivery.
	SELECT @SentActionID = ActionID
	FROM   dbo.tblActions
	WHERE  ActionKEY = 'SEND'
	
	IF(@SentActionID IS NULL)
	BEGIN
		EXEC dbo.logit 0,'Action ID for ScanUpdate Not Found','ErrorSys'
		RETURN
	END
	
	DECLARE Scans cursor FOR
		SELECT	S.[ScanID], 
			OH.OrderID, 
			S.ScanTime, 
			S.PostStatus
		FROM	dbo.tblScan AS S
			JOIN dbo.tblOrderOHD AS OH (NOLOCK) ON S.OrderID = OH.OrderID
			JOIN dbo.tblRoomOHD AS R (NOLOCK) ON S.RoomID = R.RoomID
		WHERE 	COALESCE(S.PostStatus,'') <> 'P'
		        AND UPPER(S.BatchID) = UPPER(@BatchID)
   	
	OPEN Scans
	
	FETCH NEXT FROM Scans INTO @ScanRecordID, @OrderID, @ScanTime, @PostStatus

	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		-- Set this OrderID to Delivered (500) based on the last setting, but is dynamic in the proc.
		EXEC OrderSETDelivered @OrderID, 1 , @ScanTime
        
		IF(@@ERROR > 0)       -- This will most likely never be called since the previous proc eats it.
		BEGIN
			SET @Msg = 'System Error: ' + CAST( @@ERROR AS varchar(10))
			EXEC logit 99999, @Msg , 'ErrorSys'
		END
		ELSE
		BEGIN
			UPDATE dbo.tblScan
			SET PostStatus = 'P'
			WHERE CURRENT OF Scans
		END
	         
		FETCH NEXT FROM Scans INTO @ScanRecordID, @OrderID, @ScanTime, @PostStatus
	END
	   
	CLOSE Scans
	DEALLOCATE Scans
          
  	EXEC dbo.logit 40001,'Run SP: ScanUpdate Complete','System'
	
	RETURN
go

