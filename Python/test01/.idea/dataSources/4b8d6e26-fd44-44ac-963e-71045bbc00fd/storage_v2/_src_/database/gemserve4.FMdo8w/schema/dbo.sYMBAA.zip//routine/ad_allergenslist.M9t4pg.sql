

CREATE PROCEDURE dbo.ad_AllergensList
AS
	SET NOCOUNT ON

	SELECT AllergenID, 
		Description
	FROM	dbo.cfgAllergens (NOLOCK) 
	ORDER BY [Description]

	RETURN
go

