CREATE PROCEDURE [dbo].[LocationMenuItemUpdate]
@LoginUserID		varchar(250),
@LocationMenuItemID		int,
@LocationClassID		int,
@POSMenuItemID			int

AS
	IF (@LocationMenuItemID < 1)
	BEGIN
		INSERT INTO dbo.[tblLocationMenuItems] (LocationClassID, POSMenuItemID)
			VALUES (@LocationClassID, @POSMenuItemID)

		SET @LocationMenuItemID = SCOPE_IDENTITY()
	END
	ELSE
		UPDATE dbo.[tblLocationMenuItems]
		SET LocationClassID = @LocationClassID,
			POSMenuItemID = @POSMenuItemID
		WHERE [LocationMenuItemID] = @LocationMenuItemID


	SELECT @LocationMenuItemID AS LocationMenuItemID
go

