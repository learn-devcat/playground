

CREATE FUNCTION dbo.HL7ConvertDate
	(
        @Input  varchar(20),
        @Today  datetime
	)
RETURNS smalldatetime
AS
	BEGIN
		DECLARE	@MyDate smalldatetime

	    IF ( LEN(@Input) < 7 )
	        SET @MyDate = CAST(@Today as smalldatetime)
	    ELSE
	   BEGIN
		if( CharIndex( '-' , @Input )  = 0  and CharIndex( '/' , @Input )  =0 )
		BEGIN
     		   SET @Input = LEFT(@Input,4) + '/' + SUBSTRING(@Input,5,2) + '/' + SUBSTRING(@Input,7,2)
		END

		SET @MyDate = CAST(@Input as smalldatetime)	
   	   	
	    END		
	    RETURN @MyDate
	END
go

