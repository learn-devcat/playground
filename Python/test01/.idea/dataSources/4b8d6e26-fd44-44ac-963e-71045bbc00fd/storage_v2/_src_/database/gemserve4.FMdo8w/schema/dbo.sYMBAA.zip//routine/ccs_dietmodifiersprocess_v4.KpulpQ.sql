
CREATE PROCEDURE [dbo].[CCS_DietModifiersProcess_v4]
@PatientDietID		varchar(50),
@Modifiers		varchar(3000),
@Source			varchar(100),
@ModifierKeys		varchar(3000),
@ActiveDate		varchar(50),
@TransactionIdentifier	varchar(50),
@OrderType              varchar(50)='',
@NoteType				varchar(50)

AS
    SET NOCOUNT ON

    DECLARE @PatientID		int,
        @PatientVisitID		varchar(50),
        @DietID			int,
        @CurrentModifier	varchar(100),
        @CurrentNutrient	int,
        @MyID			int,
        @MealPeriodID		int,
        @RoomID			int,
        @KeyIn			varchar(100),
        @KeyOut			varchar(100),
        @ModifierValue		decimal(10,3),
        @TempValue		varchar(200),
        @Msg			varchar(500),
        @ORMSeparator		varchar(10),
        @ModifierPriority	varchar(10),
        @EndLoop		int,
        @NoteTypeID		varchar(50)

    DECLARE @Values TABLE (myID int IDENTITY(1,1),
                KeyIn varchar(100),
                KeyOut varchar(100),
                [Description] varchar(200),
                TempValue varchar(200))

    IF (@Modifiers = '')
        RETURN

    SELECT @ORMSeparator = dbo.GetOverheadValue('ORMSeparator')
    IF (@ORMSeparator = '')
        SET @ORMSeparator = '|'

    SET @EndLoop = 0
    
    -- Default NoteTypeID to Diet Note if NoteType does not exist in XLAT Table or is blank
    IF (@NoteType = '') OR (NOT EXISTS (SELECT 1 FROM dbo.tblXLAT WHERE xlatID = 'NoteType' AND KeyIn = @NoteType))
        SET @NoteTypeID = '100'
    ELSE
        SELECT @NoteTypeID = KeyOut
        FROM dbo.tblXLAT
        WHERE xlatID = 'NoteType' AND KeyIn = @NoteType

    -- Check to see if modifiers need to be prioritized
    SELECT @ModifierPriority = COALESCE(dbo.GetOverheadValueNull('ModifierPriority'),'0')
    IF (@ModifierPriority = '1')
        SET @Modifiers = dbo.PrioritizeModifierList(@Modifiers)
    
    SELECT @PatientID = P.PatientID,
        @PatientVisitID = PV.PatientVisitID,
        @DietID = PD.DietID,
        @RoomID = PV.RoomID
    FROM dbo.tblPatientOHD AS P (NOLOCK)
    JOIN dbo.tblPatientVisit AS PV (NOLOCK) ON P.PatientID = PV.PatientID
    JOIN dbo.tblPatientDiet AS PD (NOLOCK) ON PV.PatientVisitID = PD.PatientVisitID
    WHERE PD.[ID] = @PatientDietID

    WHILE (@EndLoop = 0)
    BEGIN
        IF (CHARINDEX(@ORMSeparator,@Modifiers) > 0)
        BEGIN
            SET @CurrentModifier = SUBSTRING(@Modifiers,1,CHARINDEX(@ORMSeparator,@Modifiers)-1)
            SET @Modifiers = SUBSTRING(@Modifiers, CHARINDEX(@ORMSeparator,@Modifiers) + 1,LEN(@Modifiers) - LEN(@CurrentModifier))
        END
        ELSE
        BEGIN
            -- Process the last item
            SET @CurrentModifier = @Modifiers
            SET @EndLoop = 1
        END

        -- ************************************************
        -- Patient Status
        -- ************************************************
        IF EXISTS (SELECT 1 FROM dbo.tblXLAT WHERE xlatID = 'OptionalStatus' AND KeyIn = @CurrentModifier)
        BEGIN
            EXEC dbo.CCS_PatientStatusUpdate_v4 @PatientID, @PatientDietID, @CurrentModifier, @Source
        END
        
        -- ************************************************
        -- Visit Notes
        -- ************************************************
        IF EXISTS (SELECT 1 FROM dbo.tblXlat WHERE xlatId = 'VisitNote' AND KeyIn = @CurrentModifier)
        BEGIN
            EXEC dbo.CCS_PatientNotesUpdate_v4 @PatientVisitID, @NoteTypeID, @Source, @CurrentModifier, @TransactionIdentifier, @OrderType, @ActiveDate, 1, null
        END

        -- ************************************************
        -- Diet Textures
        -- ************************************************
        IF EXISTS (SELECT 1 FROM dbo.tblXlat WHERE xlatId = 'Textures' AND KeyIn = @CurrentModifier)
        BEGIN
            EXEC dbo.CCS_PatientDietTexture_v4 @PatientDietId, @CurrentModifier; 
        END
        
        -- ************************************************
        -- Daily Nutrient Overrides
        -- ************************************************
        -- Get the nutrientID for the modifier
        -- Since there can be more than one entry in the xlat table for this modifier,
        -- use a table variable to hold all nutrients that are found
        INSERT INTO @Values(KeyOut, TempValue)
        SELECT KeyOut, [Description]
        FROM dbo.tblXlat
        WHERE KeyIn = @CurrentModifier
            AND xlatID = 'ModifierNutrientID'
    
        SET @KeyOut = NULL
        SELECT TOP 1 @MyID = MyID,
            @KeyOut = KeyOut,
            @TempValue = TempValue
        FROM @Values
        ORDER BY myID
    
        -- Process until all items are done
        WHILE (@KeyOut IS NOT NULL)
        BEGIN
            -- Get the NutrientID for the modifier
            SELECT @CurrentNutrient = NutrientID
            FROM cfgNutrients (NOLOCK)
            WHERE NutrientID = CAST(@KeyOut AS int)
    
            -- Get the nutrient value for the modifier
            SET @ModifierValue = CAST(@TempValue as decimal(10,3))
    
            UPDATE dbo.tblPatientDailyNutrientOverride
            SET Qty = @ModifierValue
            WHERE PatientID = @PatientID
                AND DietID = @DietID
                AND NutrientID = @CurrentNutrient
                AND PatientDietID = @PatientDietID

            IF (@@ROWCOUNT = 0)
                -- Insert the value into the daily overrides table
                INSERT INTO dbo.tblPatientDailyNutrientOverride(PatientID, PatientDietID, NutrientID, DietID, Qty)
                    VALUES (@PatientID, @PatientDietID, @CurrentNutrient, @DietID, @ModifierValue)
    
            -- Delete the item just processed
            DELETE @Values WHERE myID = @MyID 
    
            -- check for more items
            IF EXISTS (SELECT myID FROM @Values)
            BEGIN
                SET @KeyOut = NULL
                SELECT TOP 1 @MyID = MyID,
                    @KeyOut = KeyOut,
                    @TempValue = TempValue
                FROM @Values
                ORDER BY myID
            END
            ELSE
                BREAK
        END
        -- ************************************************
        -- End daily nutrient overrides
        -- ************************************************
    
    
        -- ************************************************
        -- MealPeriodOverrides
        -- ************************************************
        DELETE @Values
    
        INSERT INTO @Values(KeyIn, KeyOut, [Description])
            SELECT DISTINCT KeyIn, KeyOut, [Description]
            FROM dbo.tblXlat 
        WHERE 	LEFT(KeyIn,LEN(@CurrentModifier)) = @CurrentModifier
            AND SUBSTRING(KeyIn,LEN(@CurrentModifier) + 1,1) = '_'
            AND ISNUMERIC(SUBSTRING(KeyIn,LEN(@CurrentModifier) + 2,1)) = 1
            AND xlatID = 'NutrientByMealPeriod'

        SET @KeyIn = NULL
        SELECT TOP 1 @MyID = MyID,
            @KeyIn = KeyIn,
            @KeyOut = KeyOut,
            @TempValue = [Description]
        FROM @Values
        ORDER BY myID

        WHILE (@KeyIn IS NOT NULL)
        BEGIN
            -- Get the NutrientID for the modifier
            SELECT @CurrentNutrient = NutrientID
            FROM cfgNutrients (NOLOCK)
            WHERE NutrientID = CAST(@KeyOut AS int)
    
            -- Get the quantity and MealPeriodID		
            SET @ModifierValue = -1

            IF (ISNUMERIC(SUBSTRING(@KeyIn,LEN(@CurrentModifier) + 2,LEN(@KeyIn) - (LEN(@CurrentModifier) + 1))) = 1)
                SELECT @ModifierValue = CAST(@TempValue AS decimal(10,3)),
                    @MealPeriodID = CAST(SUBSTRING(@KeyIn,LEN(@CurrentModifier) + 2,LEN(@KeyIn) - (LEN(@CurrentModifier) + 1)) as int)

            -- If a Qty is found, then update the override table
            IF (@ModifierValue > -1)
            BEGIN
                UPDATE dbo.tblPatientMealPeriodNutrientOverride
                SET Qty = @ModifierValue
                WHERE PatientID = @PatientID
                    AND NutrientID = @CurrentNutrient
                    AND MealPeriodID = @MealPeriodID
                    AND PatientDietID = @PatientDietID

                IF (@@ROWCOUNT = 0)
                    INSERT INTO dbo.tblPatientMealPeriodNutrientOverride (PatientID, PatientDietID, NutrientID, MealPeriodID, Qty)
                    SELECT @PatientID, @PatientDietID, @CurrentNutrient, @MealPeriodID, @ModifierValue
            END
    
            -- Delete the item just processed
            DELETE @Values WHERE myID = @MyID 
    
            -- check for more items
            IF EXISTS (SELECT myID FROM @Values)
            BEGIN
                SET @KeyOut = NULL
                SELECT TOP 1 @MyID = myID,
                    @KeyIn = KeyIn,
                    @KeyOut = KeyOut,
                    @TempValue = [Description]
                FROM @Values
                ORDER BY myID
            END
            ELSE
                BREAK
        END
        -- ************************************************
        -- End Meal Period Overrides
        -- ************************************************

    END

    SET @Msg = 'Diet modifiers processed for Patient Visit ID: [' + @PatientVisitID + '].'
    EXEC dbo.Logit 1, @Msg, 'system'

    RETURN
go

