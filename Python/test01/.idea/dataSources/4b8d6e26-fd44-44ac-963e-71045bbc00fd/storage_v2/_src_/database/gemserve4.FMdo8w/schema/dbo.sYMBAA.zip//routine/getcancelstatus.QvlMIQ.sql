CREATE FUNCTION [dbo].[GetCancelStatus]
(@CancelDate DATETIME, @Now DATETIME)
RETURNS BIT
AS
BEGIN
	DECLARE @Return	bit

	IF (@CancelDate IS NULL)
		SET @Return = 0
	ELSE
		SELECT @Return = CASE WHEN @CancelDate < @Now THEN 1
			ELSE 0
		END

	RETURN @Return
END
go

