

CREATE FUNCTION dbo.FutureVouchersExist(@AccountNo char(19), @MealPlanID int, @Today datetime)
RETURNS	datetime
AS
BEGIN
	DECLARE	@Return datetime
	SELECT	@Return = MAX(dbo.dDateOnly(TransDate))
	FROM	tblDetail
	WHERE	AccountNo = @AccountNo
		AND MealPlanID = @MealPlanID
		AND TransDate > @Today
	RETURN ISNULL(@Return,'12-31-9999')
END
go

