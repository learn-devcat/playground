

CREATE PROCEDURE dbo.ad_Connection_Get
@ConnectionID int
AS
	SELECT	ConnectionID, InterfaceID, Active, Description, Category, ComPort, Baud,
			DataBits, StopBits, Parity, ComInit, InterfaceType, ModemActive, PhoneNumber,
			ConnectionType, MyPort, RemoteIP, RemotePort, xlat,SysOptions,
			InquireProc,AuthorizationProc, PostingProc,
            		ModemSetup, WaitCarrier, ModemDialPrefix, ModemDownTime, ModemUpTime, LicenseKey
	FROM		cfgConnection
	WHERE	ConnectionID = @ConnectionID
go

