


CREATE  PROCEDURE dbo.sp_User_Update
@UserID		varchar(16),
@NewUserID	varchar(16),
@PW		varchar(100),
@UserName	varchar(50),
@Department	varchar(20),
@UserOptions	varchar(50),
@LicenseKey	char(27),
@Language 	int,
@SlotNo		int,
@OutletClass	int
AS
	DECLARE @Cmsg  char(255),
		@CoreID	int
	SET @CoreID = dbo.GetCoreIDFromUser(@UserID)
	UPDATE	cfgUsers
	SET	UserID = @NewUserID,
		UserName = @UserName,
		Department = @Department,
		UserOptions = @UserOptions,
		LicenseKey = @LicenseKey,
		Language = @Language,
		SlotNo = @SlotNo,
		OutletClass = @OutletClass
	WHERE	UserID = @UserID
	-- Check for password change
	IF (@PW <> '*****') 
	BEGIN
		UPDATE cfgUsers
		SET PW = @PW,
			LastPWChange = getdate()			
		WHERE UserID = @NewUserID
		SET @Cmsg = 'Password changed for user <' + @UserID + '>'
		EXEC dbo.sp_Logit 0, @CoreID, @UserID, @Cmsg, 102
	END
	
	SET @Cmsg = 'Updated user <' + @UserID + '>'
	EXEC dbo.sp_Logit 2 , @CoreID , @UserID , @Cmsg
go

