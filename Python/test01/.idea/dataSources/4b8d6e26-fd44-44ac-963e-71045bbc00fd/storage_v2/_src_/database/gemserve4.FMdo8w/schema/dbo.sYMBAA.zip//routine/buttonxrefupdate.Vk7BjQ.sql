

CREATE PROCEDURE dbo.ButtonXrefUpdate
@LoginUserID	varchar(250),
@ID		int,
@ButtonID	varchar(50),
@RoomNumber	varchar(10),
@Bed		varchar(10)
AS

	SET NOCOUNT ON

	IF (@ID > 0)
	BEGIN
		UPDATE dbo.tblButtonXref
		SET 	ButtonID = @ButtonID,
			RoomNumber = @RoomNumber,
			Bed = @Bed
		WHERE	[ID] = @ID			
	END
	ELSE
	BEGIN
		INSERT INTO dbo.tblButtonXref(ButtonID, RoomNumber, Bed)
			VALUES(@ButtonID, @RoomNumber, @Bed)

		SELECT @ID = SCOPE_IDENTITY()
	END

	SELECT @ID AS RowID
	RETURN
go

