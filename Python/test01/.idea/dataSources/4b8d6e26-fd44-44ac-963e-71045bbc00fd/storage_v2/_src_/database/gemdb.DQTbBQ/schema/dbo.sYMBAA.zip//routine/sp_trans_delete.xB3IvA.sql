


CREATE  PROCEDURE [dbo].[sp_Trans_Delete]
    @User CHAR(10) ,
    @DetailID UNIQUEIDENTIFIER
AS 
    DECLARE @ReturnCode INT ,
			@cMsg CHAR(255) ,
			@CoreID INT
			
    SELECT @cMsg =  'Deleted Transaction <Acc#:' + RTRIM(AccountNo) + 
					' Name:' + dbo.GetAccountName(AccountNo) + 
					' Check:' + RTRIM(ChkNum) +
					' Outlet:' + CAST(OutletNo AS VARCHAR(6)) +
					' TransID:' + CAST(TransID AS VARCHAR(6)) +
					' Date:' + CAST(TransDate AS VARCHAR(12)) +
					' Total:' + CAST(TransTotal AS VARCHAR(16)) +
					'>'
    FROM    dbo.tblDetail
    WHERE   DetailID = @DetailID
	
    BEGIN TRANSACTION
    EXEC @ReturnCode = dbo.sp_Trans_RemovePost @User, @DetailID	
    IF @ReturnCode = 0 
        BEGIN 
            COMMIT TRANSACTION	
        END
    ELSE 
        BEGIN
            ROLLBACK TRANSACTION  
        END   
		
		--[ UPDATE Log ]---------------------------------------

    SET @CoreID = dbo.GetCoreIDFromUser(@User)
		
    IF ( @ReturnCode <> 0 ) 
        SET @cMsg = 'sp_Trans_Delete FAILED - transaction ID <' + CAST(@DetailID AS VARCHAR(50)) + '>' 
  			
    EXEC dbo.sp_Logit 0, 0, @User, @cMsg, 300
	-------------------------------------------------------[ UPDATE Log END ]------
	
	
    RETURN @ReturnCode
go

