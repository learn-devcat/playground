


CREATE	FUNCTION [dbo].[BinaryPosition]( @PositionNo int)
RETURNS bigint
AS
BEGIN
	/*
		Returns the static decimal value of the bit number passed in.
		i.e.	1 = 1
				2 = 2
				3 = 4
				4 = 8
				5 = 16
				etc.
		Could be used to check a status bit by ordinal rather than
		having to remember large bit VALUES

		Allowed VALUES range FROM 1 to 31
	*/

	IF (@PositionNo NOT BETWEEN 1 AND 31)
		RETURN 0

	RETURN 	POWER(2, @PositionNo - 1)
	
END
go

