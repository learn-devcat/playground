

CREATE PROCEDURE dbo.ad_MealPlanOHD_Insert
@MealPlanID		int,
@Name			varchar(32),
@Status		int,
@SubType		int,
@Freq			char(3),
@InitialNumPeriods	smallint,
@FirstDayOfWeek	smallint,
@ReloadQty		int,
@ReloadBalance	money
AS
	INSERT INTO	tblPlanOHD (MealPlanID, Name, Status, SubType, Freq, InitialNumPeriods, FirstDayOfWeek, ReloadQty, ReloadBalance)
		VALUES(@MealPlanID, @Name, @Status, @SubType, @Freq, @InitialNumPeriods, @FirstDayOfWeek, @ReloadQty, @ReloadBalance)
go

