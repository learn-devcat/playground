CREATE PROCEDURE [dbo].[sp_Task_ClearImportTable]

AS

	DECLARE	@Msg	varchar(255)

	SET @Msg = 'The Account Import table has been cleared'

	TRUNCATE TABLE dbo.tblAccountImport

	SELECT @Msg AS [Msg]
go

