CREATE PROCEDURE [dbo].[PatientDietUpdate]
@LoginUserID			varchar(250),
@PatientDietID			int,
@PatientVisitID			varchar(50),
@DietID					int=null,
@ActiveDate				datetime=null,
@Source					varchar(50)=null,
@Notes					varchar(1000)=null,
@Cancelled				bit=null,
@CancelDate				datetime=null,
@TransactionIdentifier	varchar(50)=null
AS
	SET NOCOUNT ON

	DECLARE @Today	datetime,
			@Msg varchar(500),
			@PatientID			int,
			@RoomID				int,
			@CurrentDietID		int,
			@CurrentDietName	varchar(50),
			@NewDietName		varchar(50),
			@CurrentActiveDate	datetime,
			@CurrentCancelDate	datetime,
			@OldDietID			int,
			@OldActiveDate		datetime

	SET @Today = getdate()

	SELECT @PatientID = PatientID,
			@RoomID = RoomID
	FROM dbo.tblPatientVisit
	WHERE PatientVisitID = @PatientVisitID

	SELECT @NewDietName = Description
	FROM dbo.tblDietOHD
	WHERE DietID = @DietID

	--Get currently active diet and active date for patient
	SELECT	@OldDietID = DietID,
			@OldActiveDate = ActiveDate
	FROM	tblPatientDiet
	WHERE	[ID] = dbo.GetActivePatientDietID(@PatientVisitID, @Today)

	IF (@PatientDietID = -1)
	BEGIN
		INSERT INTO dbo.tblPatientDiet (PatientVisitID, DietID, ActiveDate, PostDate, Source, Notes, TransactionIdentifier, UpdateDate, UpdateID) 
			VALUES (@PatientVisitID, @DietID, @ActiveDate, @Today, @Source, @Notes, @TransactionIdentifier, @Today, @LoginUserID)
	
		SET @Msg = 'Inserted new Patient Diet - [' + @NewDietName + ']'
		EXEC dbo.PatientLOGAdd 7000, @LoginUserID, @PatientID, @PatientVisitID, @RoomID, @Msg

		SET @PatientDietID = SCOPE_IDENTITY()
	END
	ELSE
	BEGIN
		SELECT @CurrentDietID = DietID,
			@CurrentActiveDate = ActiveDate,
			@CurrentCancelDate = CancelDate
		FROM dbo.tblPatientDiet
		WHERE ID = @PatientDietID

		SELECT @CurrentDietName = Description
		FROM dbo.tblDietOHD
		WHERE DietID = @CurrentDietID

		UPDATE dbo.tblPatientDiet
			SET DietID = COALESCE(@DietID, DietID),
			ActiveDate = COALESCE(@ActiveDate, ActiveDate),
			Source = COALESCE(@Source, Source),
			Notes = COALESCE(@Notes, Notes),
			CancelDate = @CancelDate,
			TransactionIdentifier = COALESCE(@TransactionIdentifier, TransactionIdentifier),
			UpdateDate = @Today,
			UpdateID = @LoginUserID
		WHERE ID = @PatientDietID

		SET @Msg = 'Modified Patient Diet - Old Values = [Diet: ' + @CurrentDietName + ', ActiveDate: ' + 
			CAST(@CurrentActiveDate AS varchar(30)) + ', CancelDate: ' + CASE WHEN @CurrentCancelDate IS NULL THEN ' N/A'
			ELSE CAST(@CurrentCancelDate AS varchar(30)) END + '] | New Values = [Diet: ' + @NewDietName + ', ActiveDate: ' + 
			CAST(@ActiveDate AS varchar(30)) + ', CancelDate: ' + CASE WHEN COALESCE(@Cancelled,0) = 0 THEN ' N/A'
			ELSE CAST(@Today AS varchar(30)) END + ']'

		EXEC dbo.PatientLOGAdd 7000, @LoginUserID, @PatientID, @PatientVisitID, @RoomID, @Msg
	END

	/* Check to see if diet is changing and if the diet has a newer active date than the current diet.
	   If so, then cancel the future orders for the patient. */
	IF (COALESCE(@OldDietID, -1) <> @DietID AND COALESCE(@OldActiveDate,'1/1/1900') < @ActiveDate) OR (dbo.GetActivePatientDietID(@PatientVisitID, @Today) = -1)
	BEGIN
		EXEC dbo.OrderCancel @PatientVisitID, @Source, @ActiveDate
	END

	-- Return the PatientDietID
	SELECT @PatientDietID AS PatientDietID

	RETURN
go

