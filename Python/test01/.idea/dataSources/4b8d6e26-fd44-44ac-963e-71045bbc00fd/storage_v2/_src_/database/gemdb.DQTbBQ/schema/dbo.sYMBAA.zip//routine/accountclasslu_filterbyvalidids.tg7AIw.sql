
CREATE FUNCTION [dbo].[AccountClassLu_FilterByValidIds] (@TempClass varchar(32), @ValidIds varchar(100))
RETURNS int
AS 
BEGIN 
	DECLARE @TempID int
	-- Looks up the Account Class using the Xref field and filter by valid ids if @ValidIds string is passed.
	-- If no match is found, see if it is a legit account class id, then return it,
	-- else return NULL
	IF(@ValidIds <> NULL)
	BEGIN
		DECLARE @ClassCount int
		
		SET @ClassCount = dbo.DelimitedStringFieldCount ( @ValidIds, ',' )

		WHILE @ClassCount > 0
		BEGIN
			SELECT	@TempID = AccountClassID
			FROM	tblAccountClass
			WHERE	Xref = @TempClass AND
					AccountClassID = CAST(dbo.GetDelimitedStringField( @ValidIds, ',', @ClassCount) AS int)
			
			IF(@TempID <> NULL)
				BREAK
			
			SET @ClassCount = @ClassCount - 1
		END
	END
	ELSE
	BEGIN
		SELECT TOP 1 @TempID = AccountClassID FROM tblAccountClass WHERE Xref=@TempClass
	END
	
	IF(@TempID IS NULL)
	BEGIN
		IF(ISNUMERIC(@TempClass) > 0)
			SELECT @TempID = AccountClassID FROM tblAccountClass WHERE AccountClassID = CAST(@TempClass AS int)
	END
		
	RETURN @TempID
END
go

