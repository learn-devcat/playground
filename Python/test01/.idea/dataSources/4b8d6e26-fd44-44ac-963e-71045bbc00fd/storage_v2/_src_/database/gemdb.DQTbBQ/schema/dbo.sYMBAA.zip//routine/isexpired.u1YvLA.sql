CREATE  FUNCTION [dbo].[IsExpired] (@ExpireDate datetime=NULL, @CompareDate datetime=NULL)
RETURNS BIT
AS 
BEGIN 
	IF (COALESCE(@CompareDate,'') = '') OR (ISDATE(@CompareDate) = 0)
		SET @CompareDate = GETDATE()

	IF (@ExpireDate IS NULL) OR (@ExpireDate >= @CompareDate)
		RETURN 0
	
	RETURN 1
END
go

