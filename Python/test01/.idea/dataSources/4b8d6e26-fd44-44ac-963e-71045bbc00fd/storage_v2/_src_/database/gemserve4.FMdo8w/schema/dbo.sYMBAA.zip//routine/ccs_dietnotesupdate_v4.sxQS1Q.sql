CREATE PROCEDURE [dbo].[CCS_DietNotesUpdate_v4]
@PatientDietID	varchar(50),
@PatientVisitID	varchar(50),
@OrderType		varchar(50),
@Notes		varchar(1000),
@Source			varchar(100),
@ActiveDate		varchar(50),
@TransactionIdentifier varchar(50),
@NoteType		varchar(50)
AS
	SET NOCOUNT ON

	DECLARE @NoteTypeID	varchar(50)

	-- Update the notes
	BEGIN
				-- Default NoteTypeID to Diet Note if NoteType does not exist in XLAT Table or is blank
		IF (@NoteType = '') OR (NOT EXISTS (SELECT 1 FROM dbo.tblXLAT WHERE xlatID = 'NoteType' AND KeyIn = @NoteType))
			SET @NoteTypeID = '100'
		ELSE
			SELECT @NoteTypeID = KeyOut
			FROM dbo.tblXLAT
			WHERE xlatID = 'NoteType' AND KeyIn = @NoteType
			
		EXEC dbo.CCS_PatientNotesUpdate_v4 @PatientVisitID, @NoteTypeID, @Source, @Notes, @TransactionIdentifier, @OrderType, @ActiveDate, 1, null		
	END

	RETURN


go

