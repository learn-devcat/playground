CREATE PROCEDURE [dbo].[Micros_TSInsertKey]
@TouchScreen int,
@NextScreen int
AS
	SET NOCOUNT ON

	DECLARE @ScreenSeq int,
		@DietID int,
		@MenuCategoryID int

	DECLARE @Table TABLE (KeySeq int IDENTITY(100,1),
				MenuItemID int,
				POSMenuItemID int,
				RowStart int,
				ColStart int,
				Height int,
				Width int,
				Font int,
				Color int,
				IconPlacement char(1),
				IconID int,
				Legend varchar(16),
				KeyType int,
				NextScreen int,
				KeyNumber int)

	SELECT @ScreenSeq = ts_scrn_seq 
	FROM MicrosTouchScreenDef
	WHERE obj_num = @TouchScreen

	SET @DietID = CAST(@TouchScreen / 100 as int)
	SET @MenuCategoryID = @TouchScreen % 100

	INSERT INTO @Table (MenuItemID, POSMenuItemID,RowStart,ColStart,Height,Width,Font,Color,IconPlacement,
				IconID,Legend,KeyType,NextScreen,KeyNumber)
		SELECT 	T.MenuItemID, M.POSMenuItemID, T.RowStart, T.ColStart, T.Height, T.Width, T.Font, T.Color,
			T.IconPlacement, T.IconID, T.Legend, T.KeyType, (@NextScreen + T.NextScreen), M.POSMenuItemSEQ
		FROM 	dbo.tblMenuItem_TouchScreen AS T (NOLOCK)
			JOIN dbo.tblMenuItemOHD AS M (NOLOCK) ON T.MenuItemID = M.MenuItemID
		WHERE	T.DietID = @DietID
			AND T.MenuCategoryID = @MenuCategoryID
			AND T.Active = 1
			AND (T.RowStart <> 0 AND T.ColStart <> 0)

	INSERT INTO MicrosTouchScreenKeyDef(ts_scrn_seq,ts_key_seq,cfg_sect_ver_seq,row_start,col_start,height,width,font,
		color_combo,icon_placement,icon_id,legend,key_type,key_num,[next],last_updated_by)
		SELECT @ScreenSeq, KeySeq, 1,RowStart, ColStart, Height, Width, Font,
			Color, IconPlacement, IconID, Legend, KeyType, KeyNumber, NextScreen, 1
		FROM 	@Table

	UPDATE dbo.tblMenuItem_Touchscreen
		SET Modified = 0
	WHERE	DietID = @DietID
		AND MenuCategoryID = @MenuCategoryID
		AND Active = 1

	RETURN
go

