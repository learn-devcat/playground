
CREATE PROCEDURE dbo.MenuUpdate
@LoginUserID		varchar(250),
@MenuID		int,
@ParentID	int,
@Description	varchar(50),
@MenuAction	varchar(50),
@MenuImage	varchar(50) = null,
@MenuHoverImage	varchar(50) = null,
@Sequence	int = null,
@IsSeparator	bit = null,
@IsDisabled	bit = null,
@IsChecked	bit = null,
@MenuGroup	int = null,
@ActionID	int = null

AS

	IF (@ParentID = 0)
		SET @ParentID = null

	IF (@MenuImage = '')
		SET @MenuImage = null

	IF (@MenuHoverImage = '')
		SET @MenuHoverImage = null

	IF (@MenuID <> 0)
		UPDATE dbo.cfgWebMenus
		SET ParentID = @ParentID,
			[Description] = @Description,
			MenuAction = @MenuAction,
			MenuImage = ISNULL(@MenuImage, MenuImage),
			MenuHoverImage = ISNULL(@MenuHoverImage, MenuHoverImage),
			[Sequence] = ISNULL(@Sequence, [Sequence]),
			IsSeparator = ISNULL(@IsSeparator, IsSeparator),
			IsDisabled = ISNULL(@IsDisabled, IsDisabled),
			IsChecked = ISNULL(@IsChecked, IsChecked),
			MenuGroup = ISNULL(@MenuGroup, MenuGroup),
			ActionID = ISNULL(@ActionID, ActionID)
		WHERE	MenuID = @MenuID
	ELSE
	BEGIN
		IF (@Sequence IS NULL)
			SELECT @Sequence = MAX([SEQUENCE]) + 1 FROM cfgWebMenus

		INSERT INTO dbo.cfgWebMenus(ParentID, [Description], MenuAction, MenuImage, MenuHoverImage, [Sequence], IsSeparator, IsDisabled, 
			IsChecked, MenuGroup, ActionID)
		VALUES(@ParentID, @Description, @MenuAction, @MenuImage, @MenuHoverImage, @Sequence, @IsSeparator, @IsDisabled, 
			@IsChecked, @MenuGroup, ISNULL(@ActionID, 151000))
		
	END
go

