

CREATE PROCEDURE dbo.sp_Recur_DeleteCharge
@User			char(10),
@RecurID		uniqueidentifier
AS 
	DELETE	tblRecurChg
   	WHERE	RecurID = @RecurID
go

