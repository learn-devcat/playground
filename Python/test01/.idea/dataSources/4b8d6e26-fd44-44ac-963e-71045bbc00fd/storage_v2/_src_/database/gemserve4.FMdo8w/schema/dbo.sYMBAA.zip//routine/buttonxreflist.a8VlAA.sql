

CREATE PROCEDURE dbo.ButtonXrefList
@ByLocation	bit=0
AS

	SET NOCOUNT ON

	IF(@ByLocation = 1)
		SELECT 	B.[ID],
			B.ButtonID,
			B.RoomNumber,
			B.Bed,
			B.ActionID
		FROM 	dbo.tblButtonXref AS B
			JOIN dbo.tblRoomOHD AS R ON B.RoomNumber = R.RoomNumber
			JOIN dbo.tblLocationClass AS L ON R.LocationClassID = L.LocationClassID
		ORDER BY L.[Description]
	ELSE	
		SELECT 	[ID],
			ButtonID,
			RoomNumber,
			Bed,
			ActionID
		FROM 	dbo.tblButtonXref
		ORDER BY RoomNumber

	RETURN
go

