


CREATE   PROCEDURE dbo.EmployeeOHD_Delete
@User			char(10),
@EmployeeID		int
AS
	DELETE	tblEmployeeOHD
	WHERE   EmployeeID = @EmployeeID
go

