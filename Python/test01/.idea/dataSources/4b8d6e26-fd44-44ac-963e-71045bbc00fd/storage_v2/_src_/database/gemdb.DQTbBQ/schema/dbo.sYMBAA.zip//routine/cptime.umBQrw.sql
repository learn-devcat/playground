

CREATE FUNCTION dbo.CPTime(@WholeDate smalldatetime)
RETURNS char(5)
AS 
BEGIN 
	DECLARE	@Return	as char(5)
	DECLARE	@Hour	as int,
			@Min	as int
			
	
	SELECT @Hour = DATEPART(hh,@WholeDate),@Min = DATEPART(mi,@WholeDate)
	
	IF (@Min < 10) 
		BEGIN
			IF (@Hour < 10)
				SET @Return = '0' + CAST(@Hour AS char(1)) + ':0' + CAST(@Min AS char(1))
			ELSE
				SET @Return = CAST(@Hour AS char(2)) + ':0' + CAST(@Min AS char(1))
		END
	ELSE
		BEGIN
			IF (@Hour < 10)
				SET @Return = '0' + CAST(@Hour AS char(1)) + ':' + CAST(@Min AS char(2))
			ELSE
				SET @Return = CAST(@Hour AS char(2)) + ':' + CAST(@Min AS char(2))
		END
	 
	RETURN @Return
END
go

