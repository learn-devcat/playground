

CREATE PROCEDURE dbo.VM_Post 
@CoreID	int,
@User		char(10),
@BadgeNo	char(19),
@Outlet	int,
@TransID	int,
@TerminalID	int,
@ChkNum	varchar(10),
@CashierID	int,
@Subtotal	money,
@Tax		money,
@Dsc		money,
@Svc		money,
@Total		money,
@MealPlanID	int
AS
	DECLARE @AccountNo 	char(19),
		@Today		datetime,
		@RefNumber   varchar(10)
	SET @Today = getdate()
	SET @RefNumber = 'VM - ' + CAST(@TerminalID AS varchar(25))
	-- Resolve the accountno
	-- ordering by  primarybadge' DESC'  helps us to make sure we are getting any primary's on TOP (since 1 = primary 0=not)
	-- we need to also ensure we are getting the badge inside the active-expire date range as well as one that isn't lost or stolen..
	
	SELECT TOP 1 @AccountNo = AccountNo
	FROM	tblBadgesOHD
	WHERE	BadgeNo = @BadgeNo
			AND Inactive = 0
			AND Lost = 0
			AND Stolen = 0
			AND dbo.dDateOnly(ActiveDate) <= dbo.dDateOnly(@Today)
			AND dbo.dDateOnly(ExpireDate) >= dbo.dDateOnly(@Today)
	
	-- post it
	EXEC sp_Trans_Post @CoreID, @User, @AccountNo, @BadgeNo , @Today , 
			@Outlet,@RefNumber, @ChkNum, @Total , @Subtotal,
			 '', 	-- comment
			-1 , @TransID,
			'', 0, @CashierID, 0, 0, @Outlet,
			0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,@Tax,0,0,0,@Dsc, @Svc,0,0,0,'',@MealPlanID
go

