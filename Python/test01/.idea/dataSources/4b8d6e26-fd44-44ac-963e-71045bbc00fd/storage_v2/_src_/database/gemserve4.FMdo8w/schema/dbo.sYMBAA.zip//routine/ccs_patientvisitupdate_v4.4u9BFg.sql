

CREATE PROCEDURE [dbo].[CCS_PatientVisitUpdate_v4]
@PatientID		int,
@PatientVisitID     	varchar(50),
@RoomNumber		varchar(50),
@EntryDate		varchar(25),
@Source             	varchar(50),
@Bed			varchar(20)='',
@PatientClass		varchar(32)='',
@Location		varchar(50)='',
@DischargeDate	varchar(50)='',
@NonSelect		varchar(10) = '',
@ConnectionName	varchar(50) = ''

AS
	DECLARE @PatientClassID	int	

	DECLARE @Msg varchar(250),
	        @RoomID	int,
	        @CurrentRoomID int,
		@CurrentBed varchar(20),
		@Temp varchar(100),
		@MergedTo varchar(32),
		@Today datetime,
		@ResetRoom varchar(10)
	
	SET @Today = getdate()

	IF (@PatientID = -1)
		RETURN

	IF(LTRIM(@PatientVisitID) = '')
	BEGIN
		SET @Msg = 'Unable to process Admit. Blank PatientVisitID for ' + @Source
	  	GOTO Finished
	END

	-- Skip updates for patients already discharged
	IF(@DischargeDate <> '')
	BEGIN
		SET @Msg = 'Update record ignored for discharged patient.  -  ' + @Source
	  	GOTO Finished
	END

	IF (ISDATE(@EntryDate) = 0)
		SET @EntryDate = getdate()

	SELECT @ResetRoom = COALESCE(dbo.GetOverheadValueNULL('ResetRoomOnBlank'),'0')

	SELECT  @CurrentRoomID = RoomID,
   		    @CurrentBed = Bed
	FROM	dbo.tblPatientVisit
	WHERE	PatientVisitID = @PatientVisitID


	IF (@RoomNumber = '')
		SET @RoomNumber = @Location
	ELSE
	BEGIN
	 	IF EXISTS (SELECT 1 FROM dbo.tblXlat WHERE xlatId = 'ExcludeLocation' AND KeyIn = @Location)
		BEGIN
			SET @Msg = 'Update record ignored for excluded location [' + @Location + ']. PatientVisitId [' + @PatientVisitID + ']'
		  	GOTO Finished
		END
	END

	SELECT @RoomID = dbo.RoomID(@RoomNumber, @Bed)

	IF(@Bed = '')
		SET @Bed = NULL

	SELECT @PatientClassID = dbo.PatientClassLookup(@PatientClass)

    IF (@PatientClassID <= 0)
    BEGIN
        SET @Msg = 'Update ignored for non-processed Patient Class [' + @PatientClass + ']. PatientVisitID [' + @PatientVisitID + '].'
        GOTO Finished
    END

	IF EXISTS (SELECT PatientVisitID FROM dbo.tblPatientVisit (NOLOCK) WHERE PatientVisitID = @PatientVisitID)
	BEGIN
		-- Update the existing patient
		SELECT @MergedTo = MergedTo FROM dbo.tblPatientOHD WHERE PatientID = @PatientID

       	-- Update the Patient Visit record
		UPDATE dbo.tblPatientVisit
		SET 	DischargeDate = NULL,
			RoomID = CASE WHEN @ResetRoom = '1' THEN @RoomID
					ELSE COALESCE(@RoomID, @CurrentRoomID) END,
			PatientClassID = @PatientClassID,
			Bed = CASE WHEN @ResetRoom = '1' THEN @Bed
					ELSE COALESCE(@Bed,@CurrentBed) END,
			EntryDate = @EntryDate,
			LastUpdateBy = @Source
		FROM	dbo.tblPatientVisit
		WHERE PatientVisitID = @PatientVisitID

		IF (@RoomID IS NULL AND @ResetRoom = '1')
	        -- Set the cancelled flag to 1 for any orders in future waves
	        UPDATE  dbo.tblOrderOHD
	        SET Cancelled = 1,
	            CancelDate = getdate()
	        FROM    dbo.tblOrderOHD AS O (NOLOCK)
	                JOIN tblPatientVisit AS P (NOLOCK) ON (O.PatientVisitID = P.PatientVisitID OR O.PatientVisitID = P.MergedTo)
	        WHERE O.OrderDate > getdate()
	                AND ISNULL(O.Cancelled,0) <> 1
		  AND O.PatientVisitID = @PatientVisitID

		IF(@CurrentRoomID <> CASE WHEN @ResetRoom = '1' THEN @RoomID
			ELSE COALESCE(@RoomID, @CurrentRoomID) END)
		BEGIN
			UPDATE dbo.tblPatientVisit
			SET PreviousRoomID = @CurrentRoomID,
				PreviousBed = @CurrentBed,
				LastUpdateBy = @Source
			WHERE PatientVisitID = @PatientVisitID

			EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, @PatientVisitID, @RoomID, 'Updated patient location.'
		END

		IF (@MergedTo IS NOT NULL)
			EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, @PatientVisitID, @RoomID, 'Unmerged patient.'

		EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, @PatientVisitID, @RoomID, 'Updated patient information.'
		EXEC dbo.ProcessLogInsert @Source
	END
	ELSE
	BEGIN
		-- Add patient visit record
		INSERT INTO dbo.tblPatientVisit (PatientVisitID, PatientID, PatientClassID, RoomID, Bed, 
				EntryDate, NonSelect, EnteredBy, LastUpdateBy)
		VALUES (@PatientVisitID, @PatientID, @PatientClassID, @RoomID, @Bed, @EntryDate, 0, @Source, @Source)

	    EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, @PatientVisitID, @RoomID, 'Admitted patient.'
		EXEC dbo.ProcessLogInsert @Source
	END

Finished:
	IF NOT (@Msg IS NULL)
		EXEC dbo.Logit 1, @Msg, 'system'

	SET @ConnectionName = 'Idt' + @ConnectionName
	EXEC dbo.WorkstationUpdateByID @ConnectionName

	SELECT @PatientVisitID AS PatientVisitID

	RETURN

go

