CREATE PROCEDURE [dbo].[StatusFlagsList]

AS
SET NOCOUNT ON

	SELECT	StatusFlagID, 
			[Description],
			OnDashboard
	FROM	dbo.tblStatusFlags (NOLOCK) 
	ORDER BY [Description]

	RETURN
go

