

CREATE PROCEDURE dbo.sp_Badge_GetPrimary
@AccountNo	char(19)
AS
	SELECT	BadgeNo
	FROM		tblBadgesOHD
	WHERE	AccountNo=@AccountNo AND PrimaryBadge=1
go

