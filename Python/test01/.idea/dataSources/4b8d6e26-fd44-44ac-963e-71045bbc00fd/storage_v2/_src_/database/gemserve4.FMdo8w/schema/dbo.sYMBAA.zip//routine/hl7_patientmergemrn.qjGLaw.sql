CREATE PROCEDURE dbo.HL7_PatientMergeMRN
@MedicalRecordID	varchar(30),
@OldMedicalRecordID	varchar(30),
@LastName		varchar(30),
@FirstName		varchar(30),
@MiddleInitial		varchar(50),
@EntryDate		varchar(25),
@Source             	varchar(50),
@BirthDate		varchar(25),
@Gender			varchar(10),
@PatientClass		varchar(32)

AS
	SET NOCOUNT ON
	DECLARE @PatientID	int,
		@Msg		varchar(100),
		@PatientClassID	int

	SELECT @PatientID = PatientID
	FROM dbo.tblPatientOHD
	WHERE MedicalRecordID = @OldMedicalRecordID

	IF NOT EXISTS (SELECT 1 FROM dbo.tblPatientOHD WHERE MedicalRecordID = @OldMedicalRecordID)
	BEGIN
		SELECT @PatientClassID = dbo.PatientClassLookup(@PatientClass)

		INSERT INTO dbo.tblPatientOHD (Active, MedicalRecordID, LastName, FirstName, 
			    MiddleInitial, BirthDate, Gender, EnteredBy, PatientClassID)
		    VALUES (1, @MedicalRecordID, @LastName, @FirstName, 
			    @MiddleInitial, @BirthDate, @Gender, @Source, @PatientClassID)
	END

	UPDATE dbo.tblPatientOHD
	SET MergedTo = @MedicalRecordID
	WHERE MedicalRecordID = @OldMedicalRecordID

	SET @Msg = 'Merged patient information for MRN [' + @OldMedicalRecordID + '] to MRN [' + @MedicalRecordID + '].'
	EXEC dbo.PatientLOGAdd 7000, 'HL7', @PatientID, '', 0, @Msg
	EXEC dbo.ProcessLogInsert @Source

	EXEC dbo.Logit 1, @Msg, 'system'

	RETURN
go

