
CREATE PROCEDURE [dbo].[CCS_PatientNotesUpdate_v4]
@PatientVisitID varchar(50),
@NoteType		varchar(50),
@Source			varchar(50),
@Notes			varchar(1000),
@TransactionIdentifier	varchar(50),
@OrderType		varchar(50),
@ActiveDate		varchar(50),
@Append		varchar(50),
@ExpirationDate	varchar(50)
AS

	SET NOCOUNT ON

	DECLARE @Today datetime,
			@ORMSeparator	varchar(10),
			@CurrentNote	varchar(200),
			@Description	varchar(200),
			@RemoveNotes	varchar(200),
			@TempNotes		varchar(4000),
			@Msg			varchar(250),
			@PatientID		int,
			@EndLoop		int,
			@NoteTypeID		varchar(50),
			@dActiveDate	datetime,
			@dExpirationDate datetime

	SET @Today = getdate()

	-- No Notes exist so exit
	IF (RTRIM(LTRIM(@Notes)) = '' OR @Notes IS NULL)
		GOTO EndProcess

	-- Determine the NoteTypeID
	IF EXISTS (SELECT 1 FROM dbo.tblXLAT WHERE xlatID = 'NoteType' AND KeyOut = @NoteType)
	BEGIN	
		SET @NoteTypeID = @NoteType
	END
	ELSE
	BEGIN
		SELECT @NoteTypeID = KeyOut
		FROM dbo.tblXLAT
		WHERE xlatID = 'NoteType'
			AND KeyIn = @NoteType

		IF (@NoteTypeID IS NULL)
			SET @NoteTypeID = '0'
	END

	-- Set the Date Time fields
	IF (ISDATE(@ActiveDate) = 0)
		SET @dActiveDate = NULL
	ELSE
		SET @dActiveDate = CAST(@ActiveDate AS datetime)

	IF (ISDATE(@ExpirationDate) = 0)
		SET @dExpirationDate = NULL
	ELSE
		SET @dExpirationDate = CAST(@ExpirationDate AS datetime)

	-- Get the ORM separator
	SELECT @ORMSeparator = dbo.GetOverheadValue('ORMSeparator')
	IF (@ORMSeparator = '')
		SET @ORMSeparator = '|'
			
	-- Determine if note is Patient Note or Visit Note based on the Order Type
	IF (@OrderType = '')
	BEGIN
		-- Note is a Patient Note
		-- Get Patient ID
		SELECT @PatientID = PatientID
		FROM dbo.tblPatientVisit
		WHERE PatientVisitID = @PatientVisitID
		
		-- Log and exit if patient doesn't exist
		IF (@PatientID IS NULL)
		BEGIN
			SET @PatientID = -1
			SET @Msg = 'Unable to process patient notes. Patient Visit ID: ' + @PatientVisitID + ' does not exist.'
			GOTO EndProcess
		END
		
		-- Begin Patient Note processing
		SET @EndLoop = 0
		
		-- Loop through each note and process it
		WHILE (@EndLoop = 0)
		BEGIN
			IF (CHARINDEX(@ORMSeparator, @Notes) > 0)
			BEGIN
				SET @CurrentNote = SUBSTRING(@Notes,1,CHARINDEX(@ORMSeparator, @Notes)-1)
				SET @Notes = SUBSTRING(@Notes, CHARINDEX(@ORMSeparator, @Notes) + 1, LEN(@Notes) - LEN(@CurrentNote))
			END
			ELSE
			BEGIN
				-- Process the last note
				SET @CurrentNote = @Notes
				SET @EndLoop = 1
			END
			
			-- Check to see if Patient Note should be removed
			IF EXISTS (SELECT 1 FROM dbo.tblXLAT WHERE xlatID = 'RemovePatientNotes' AND KeyIn = @CurrentNote)
			BEGIN
				-- Get the note to remove for XLAT table
				SET @RemoveNotes = (SELECT [Description] FROM dbo.tblXLAT WHERE xlatID = 'RemovePatientNotes' AND KeyIn = @CurrentNote)
				
				-- Remove the translated note and set the TempNotes variable
				SET @TempNotes = (SELECT REPLACE(CAST(Notes AS varchar(4000)),@RemoveNotes,'') FROM dbo.tblPatientOHD WHERE PatientID = @PatientID)
				
				-- Clean up the patient notes
				WHILE CHARINDEX(@ORMSeparator + @ORMSeparator, @TempNotes) > 0
				BEGIN
					SELECT @TempNotes = REPLACE(@TempNotes, @ORMSeparator + @ORMSeparator, @ORMSeparator)
				END
				
				-- Remove the right ORMSeparator				
				IF RIGHT(@TempNotes,1) = @ORMSeparator
					SET @TempNotes = LEFT(@TempNotes,LEN(@TempNotes)-1)
					
				-- Remove the left ORMSeparator				
				IF LEFT(@TempNotes,1) = @ORMSeparator
					SET @TempNotes = RIGHT(@TempNotes,LEN(@TempNotes)-1)					
					
				-- Update the patient notes	
				UPDATE dbo.tblPatientOHD
				SET Notes = @TempNotes
				WHERE PatientID = @PatientID
			END
			
			--See if the Patient Note needs to be translated in the XLAT table
			IF EXISTS (SELECT 1 FROM dbo.tblXLAT WHERE xlatID = 'PatientNotes' AND KeyIn = @CurrentNote)
				SET @CurrentNote = (SELECT [Description] FROM dbo.tblXLAT WHERE xlatID = 'PatientNotes' AND KeyIn = @CurrentNote)
		
			-- Determine if note exists already
			IF NOT EXISTS (SELECT 1 FROM dbo.tblPatientOHD WHERE PatientID = @PatientID AND Notes LIKE '%' + @CurrentNote + '%')
			BEGIN
				-- If notes exist already append existing notes to current note otherwise just write current notes
				IF EXISTS(SELECT 1 FROM dbo.tblPatientOHD WHERE PatientID = @PatientID AND LEN(CAST(Notes AS varchar(400))) > 1) 				
					UPDATE dbo.tblPatientOHD
					SET Notes = CAST(Notes AS varchar(4000)) + @ORMSeparator + @CurrentNote
					WHERE PatientID = @PatientID
				ELSE
					UPDATE dbo.tblPatientOHD
					SET Notes = @CurrentNote
					WHERE PatientID = @PatientID
			END	
		END
	END
	ELSE
	BEGIN	
		-- Note is a Visit Note
		IF EXISTS (SELECT 1 FROM dbo.tblXlat WHERE xlatId = 'CancelOrderType' AND KeyIn = @OrderType)
		BEGIN
			-- Order is being cancelled
			UPDATE dbo.tblPatientNotes 
			SET Cancelled = 1,
				CancelDate = @Today,
				UpdateDate = @Today,
				UpdateID = @Source
			WHERE TransactionIdentifier = @TransactionIdentifier
				AND PatientVisitID = @PatientVisitID
		END
		ELSE
		BEGIN
			--- Begin note processing
			SET @EndLoop = 0
			
			-- Loop through each note and process it
			WHILE (@EndLoop = 0)
			BEGIN
				IF (CHARINDEX(@ORMSeparator, @Notes) > 0)
				BEGIN
					SET @CurrentNote = SUBSTRING(@Notes,1,CHARINDEX(@ORMSeparator, @Notes)-1)
					SET @Notes = SUBSTRING(@Notes, CHARINDEX(@ORMSeparator, @Notes) + 1, LEN(@Notes) - LEN(@CurrentNote))
				END
				ELSE
				BEGIN
					-- Process the last note
					SET @CurrentNote = @Notes
					SET @EndLoop = 1
				END
				
				-- Check to see if visit note need to be translated in the XLAT table
				IF EXISTS (SELECT 1 FROM dbo.tblXLAT WHERE xlatID = 'VisitNote' AND KeyIn = @CurrentNote 
					AND KeyOut IN ('',@NoteTypeID))
				BEGIN
					-- Set the translation note to the current note and get the note type from the XLAT table
					SELECT 	@CurrentNote = [Description]
					FROM 	dbo.tblXLAT
					WHERE	(xlatID = 'VisitNote' AND KeyIn = @CurrentNote) 
						AND (COALESCE(KeyOut,'') = '' OR KeyOut = @NoteTypeID) 
				END
				
				--  Check to see if the current note is blank
				IF (@CurrentNote <> '')
				BEGIN
				-- Determine whether to insert or update the note in the table
					IF EXISTS (SELECT 1 FROM tblPatientNotes WHERE NoteType = CAST(@NoteTypeID AS int) AND TransactionIdentifier = @TransactionIdentifier
						AND Notes = @CurrentNote AND PatientVisitID = @PatientVisitID)
					BEGIN
						-- Note exists already
						UPDATE dbo.tblPatientNotes 
						SET ActiveDate = COALESCE(@dActiveDate, @Today),
							PostDate = @Today,
							ExpirationDate = COALESCE(@dExpirationDate,'1/1/2050'),
							Source = @Source,
							Cancelled = 0,
							CancelDate = NULL,
							UpdateDate = @Today,
							UpdateID = @Source
						WHERE TransactionIdentifier = @TransactionIdentifier 
							AND NoteType = CAST(@NoteTypeID AS int) 
							AND Notes = @CurrentNote
							AND PatientVisitID = @PatientVisitID
					END
					ELSE
					BEGIN
						-- Note does not currently exist so add it to the table
						INSERT INTO dbo.tblPatientNotes (PatientVisitID, NoteType, ActiveDate, 
							ExpirationDate, Notes, Source, TransactionIdentifier)
						VALUES (@PatientVisitID, CAST(@NoteTypeID AS int), COALESCE(@dActiveDate, @Today),
							COALESCE(@dExpirationDate,'1/1/2050'), @CurrentNote, @Source, @TransactionIdentifier)
					END					
				END
			END
		END
	END

EndProcess:
	IF NOT (@Msg IS NULL)
		EXEC dbo.LogIt 1, @Msg, 'system'

	RETURN


go

