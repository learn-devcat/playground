


CREATE PROCEDURE dbo.NutrientDelete
@LoginUserID		varchar(250),
@NutrientID	int

AS
	SET NOCOUNT ON

	DELETE dbo.cfgNutrients
	WHERE NutrientID = @NutrientID

	RETURN
go

