CREATE PROCEDURE ccs1 @p1 varchar (50),@p2 varchar (max),@p3 varchar(50),@p4 varchar(max),@p5 int,@p6 int
AS
IF NOT EXISTS (SELECT 1 FROM [dbo].[TaskControls] WHERE [TaskId] = @p5 AND [Sequence] = @p6)
	INSERT INTO [dbo].[TaskControls] ([ControlType],[ControlValue],[DefaultValue],[Query],[TaskId],[Sequence]) VALUES (@p1,@p2,@p3,@p4,@p5,@p6)
go

