CREATE PROCEDURE dbo.LaborCenter_Delete
@User      	char(10),
@LaborCenterID	int
AS 
	DELETE 	tblLaborCenter
	WHERE	LaborCenterID	= @LaborCenterID
go

